/*
 * Copyright (C) 2018 EZ-Wheel S.A.S.
 *
 * @brief ezw-log macro DLT-like API public header
 */

#ifndef EZW_LOG_MACROS_H
#define EZW_LOG_MACROS_H

#ifdef ENABLE_DLT
#include <dlt.h>
#else
#include "ezw_log_msg_encode.h"
#endif

#ifndef EZW_LOG_MACRO_ENABLE
/* @brief User-definable macro to enable or disable EZW_LOG macros
 *
 * Default value is enabled for all files.
 * The user, with the help of the build system can enable or disable macros
 * for each C files independently.
 */
#define EZW_LOG_MACRO_ENABLE (1)
#endif/*EZW_LOG_MACRO_ENABLE*/

#ifndef EZW_LOG_MACRO_DISPLAY_FILE
/* @brief User-definable macro to enable or disable __FILE__ inclusion on each log message
 *
 * Default value is disable for all files, because the file path is absolute and thus very long.
 * The user, with the help of the build system can enable or disable macros
 * for each C files independently.
 */
#define EZW_LOG_MACRO_DISPLAY_FILE (0)
#endif/*EZW_LOG_MACRO_DISPLAY_FILE*/

#ifndef EZW_LOG_MACRO_DISPLAY_FUNC
/* @brief User-definable macro to enable or disable __func__ inclusion on each log message
 *
 * Default value is enable for all files.
 * The user, with the help of the build system can enable or disable macros
 * for each C files independently.
 */
#define EZW_LOG_MACRO_DISPLAY_FUNC (1)
#endif/*EZW_LOG_MACRO_DISPLAY_FUNC*/

#ifndef EZW_LOG_MACRO_DISPLAY_LINE
/* @brief User-definable macro to enable or disable __LINE__ inclusion on each log message
 *
 * Default value is enable for all files.
 * The user, with the help of the build system can enable or disable macros
 * for each C files independently.
 */
#define EZW_LOG_MACRO_DISPLAY_LINE (1)
#endif/*EZW_LOG_MACRO_DISPLAY_LINE*/

#if EZW_LOG_MACRO_ENABLE

#ifdef ENABLE_DLT

#define EZW_STR(str) DLT_STRING(str)

#define EZW_INT8(val)  DLT_INT16(val)
#define EZW_INT16(val) DLT_INT16(val)
#define EZW_INT32(val) DLT_INT32(val)
#define EZW_INT64(val) DLT_INT64(val)

#define EZW_UINT8(val)  DLT_UINT16(val)
#define EZW_UINT16(val) DLT_UINT16(val)
#define EZW_UINT32(val) DLT_UINT32(val)
#define EZW_UINT64(val) DLT_UINT64(val)

#define EZW_INT(val)  DLT_INT(val)
#define EZW_UINT(val) DLT_UINT(val)

#define EZW_LOG(ctx, lvl,  ...) DLT_LOG(ctx, lvl, __VA_ARGS__)

#else

#define EZW_LOG_PROTECT_CALL(instr) ((ERROR_NONE == err) ? err = (instr) : 0)

#define EZW_STR(str) EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_str(msg, str))
#define EZW_ERR(err) EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_err(msg, err))

#define EZW_INT8(val)  EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_int8(msg, (int8_t)val))
#define EZW_INT16(val) EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_int16(msg, (int16_t)val))
#define EZW_INT32(val) EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_int32(msg, (int32_t)val))
#define EZW_INT64(val) EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_int64(msg, (int64_t)val))

#define EZW_UINT8(val)  EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_uint8(msg, (uint8_t)val))
#define EZW_UINT16(val) EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_uint16(msg, (uint16_t)val))
#define EZW_UINT32(val) EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_uint32(msg, (uint32_t)val))
#define EZW_UINT64(val) EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_uint64(msg, (uint64_t)val))

#define EZW_INT(val)  EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_int(msg, (int64_t)val))
#define EZW_UINT(val) EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_uint(msg, (uint64_t)val))

#define EZW_HEX(val)  EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_hex(msg, (uint64_t)val, sizeof(val)))


#define EZW_LOG(ctx, lvl,  ...)\
    do {\
    if (true == ezw_log_is_enabled()) {\
        ezw_log_msg_t *msg = ezw_log_msg_get_new_buffer();\
        ezw_error_t err = ERROR_NONE;\
        err = ezw_log_msg_encode_begin(msg);\
        EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_header(msg, ctx, lvl)); \
        if (EZW_LOG_MACRO_DISPLAY_FILE) { EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_str(msg, __FILE__)); }\
        if (EZW_LOG_MACRO_DISPLAY_FUNC) { EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_str(msg, __func__)); }\
        if (EZW_LOG_MACRO_DISPLAY_LINE) { EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_uint(msg, (uint64_t)__LINE__)); }\
        __VA_ARGS__;\
        EZW_LOG_PROTECT_CALL(ezw_log_msg_encode_end(msg));\
        EZW_LOG_PROTECT_CALL(ezw_log_send_msg(ctx, lvl, msg));\
        ezw_log_msg_free_buffer(msg);\
    }\
    } while(0)

#endif/*ENABLE_DLT*/

#else

#define EZW_STR(str)

#define EZW_INT8(val)
#define EZW_INT16(val)
#define EZW_INT32(val)
#define EZW_INT64(val)

#define EZW_UINT8(val)
#define EZW_UINT16(val)
#define EZW_UINT32(val)
#define EZW_UINT64(val)

#define EZW_INT(val)
#define EZW_UINT(val)

#define EZW_LOG(ctx, lvl,  ...)

#endif/*EZW_LOG_MACRO_ENABLE*/

#endif/*EZW_LOG_MACROS_H*/
