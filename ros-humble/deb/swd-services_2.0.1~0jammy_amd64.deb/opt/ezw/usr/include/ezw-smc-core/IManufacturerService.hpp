/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file IManufacturerService.hpp
 */

#ifndef EZW_SMCCORE_IMANUFACTURERSERVICE_HPP
#define EZW_SMCCORE_IMANUFACTURERSERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief Manufacturer services.
         */
        class IManufacturerService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~IManufacturerService() = default;

            /** Indicates the manufacturer device parameters. */
            struct DeviceParameters {
                std::string manufacturer_device_name      = std::string{}; /*!< The device name. */
                std::string hardware_version_description  = std::string{}; /*!< The hardware version description. */
                std::string manufacturer_software_version = std::string{}; /*!< The software version description. */
            };

            /** Indicates the configured SWD product parameters. */
            struct SWDParameters {
                uint32_t motctrl_speed_pid_p  = uint32_t{}; /*!< The proportional parameter (mdeg.s-1) of the speed motor control bloc. Default : 200. */
                uint32_t motctrl_speed_pid_i  = uint32_t{}; /*!< The integral parameter (mdeg.s-1) of the speed motor control bloc. Default : 10. */
                uint32_t motctrl_speed_pid_d  = uint32_t{}; /*!< The derivative parameter (mdeg.s-1) of the speed motor control bloc. Default : 0. */
                uint32_t motctrl_speed_pid_tw = uint32_t{}; /*!< The integral anti-windup time constant parameter (ms) of the speed motor control bloc. Default : 316. */
                uint32_t motctrl_speed_pid_tn = uint32_t{}; /*!< The derivative filter time constant parameter (ms) of the speed motor control bloc. Default : 300. */
            };

            /** Indicates the state of a system error. */
            enum class SystemErrorStatus
            {
                EZW_SAFETY_CHECK_NORMAL  = 0,
                EZW_SAFETY_CHECK_WARNING = 1,
                EZW_SAFETY_CHECK_ERROR   = 2,
            };

            /** Indicates the state of a system error protection. */
            enum class SystemErrorProtectState
            {
                EZW_PROTECT_NONE                = 0, /**< No error. */
                EZW_PROTECT_ZERO_TORQUE_PROTECT = 1, /**< This protection reduces to null the current inside the motor. */
                EZW_PROTECT_BRAKE_CC_PROTECT    = 2, /**< This protection try to suppress the curent inside the motor by a short-circuit of the motor phase with the brake CC . */
                EZW_PROTECT_APPLY_SBC_CONFIG    = 3, /**< This protection stop the drive with the SBC. */
            };

            /** Output source. */
            enum class OutputSource
            {
                CAN_ALIM    = 0, /**< CAN alimentation. */
                CAN_IO_ALIM = 1, /**< CAN IO alimentation. */
            };

            /**
             * @brief Retrieve the device parameters.
             *
             * @param pParams The device parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getDeviceParameters(DeviceParameters &pParams) const = 0;

            /**
             * @brief Retrieve the SWD product parameters.
             *
             * @param pParams The SWD product parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSWDParameters(SWDParameters &pParams) const = 0;

            /**
             * @brief Modify the SWD product parameters.
             *  NOTA :
             *  - Changes will be applied at the next transition into OPERATION_ENABLED state.
             *  - Storing is possible into the non-volatile memory (MANUFACTURER bloc).
             *
             * @param pParams The new SWD product parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSWDParameters(const SWDParameters &pParams) = 0;

            /**
             * @brief Retrieve the validity of the calibration in non volatile memory.
             *
             * @param pIsvalid The calibration validity.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getCalibrationValidity(bool &pIsvalid) const = 0;

            /**
             * @brief Retrieve the system error states.
             *
             * @param pBatteryUv Indicates the state of a battery under voltage.
             * @param pBatteryOv Indicates the state of a battery over voltage.
             * @param pPhaseOc Indicates the state of a phase over current.
             * @param pMosOt Indicates the state of a MOS over temperature.
             * @param pDrvOt Indicates the state of a driver over temperature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSystemErrorState(SystemErrorStatus &pBatteryUv, SystemErrorStatus &pBatteryOv, SystemErrorStatus &pPhaseOc, SystemErrorStatus &pMosOt, SystemErrorStatus &pDrvOt) const = 0;

            /**
             * @brief Retrieve the system error protection state.
             *
             * @param pPrevState The previous system error protect state.
             * @param pCurrentState The actual system error protect state.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSystemErrorProtectState(SystemErrorProtectState &pPrevState, SystemErrorProtectState &pCurrentState) const = 0;

            /**
             * @brief Retrieve the SWD product software version. Ex : 1.0.1
             *
             * @param pSwVersion The software version.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSWVersion(std::string &pSwVersion) const = 0;

            /**
             * @brief Retrieve the SWD product software id. Ex : 2
             *      NOTA
             *      [
             *          FW_UNKNOWN = 0U
             *          FW_SWD_RECOVERY =1U
             *          FW_SWD_CORE = 2U
             *          FW_SWD_150 = 3U
             *          ...
             *          Maintenance = 255U
             *      ]
             *
             * @param pSwId The software id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSWId(uint8_t &pSwId) const = 0;

            /**
             * @brief Retrieve the SWD product software reference. Ex : FW_SWD_CORE
             *
             * @param pSoftwareRef The software reference.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSWRef(std::string &pSoftwareRef) const = 0;

            /**
             * @brief Retrieve the SWD product hardware version. Ex : 5
             *      NOTA
             *      [
             *          0 = Hardware version init
             *          1 = A
             *          2 = B
             *          3 = C
             *          4 = D
             *          5 = E
             *          6 = F
             *          7 = G
             *          8 = H
             *          9 = I
             *          10 = J
             *          ...
             *      ]
             *
             * @param pHwVersion The hardware version.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getHWVersion(uint32_t &pHwVersion) const = 0;

            /**
             * @brief Retrieve the SWD product hardware id. Ex : 777
             *      NOTA
             *      [
             *          727 = SWD150
             *          777 = SWDCore or SWD125
             *          ...
             *      ]
             *
             * @param pHwId The hardware id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getHWId(uint32_t &pHwId) const = 0;

            /**
             * @brief Retrieve the SWD product id. Ex : 15
             *      NOTA
             *      [
             *          NO_PRODUCT_REF = 0U
             *          ezSWD125IM.14/C = 1U
             *          ezSWD125IM.14B/C = 2U
             *          ezSWD125IM.25/C = 3U
             *          ezSWD125IM.25B/C = 4U
             *          ezSWD125IM.4/C = 5U
             *          ezSWD125IM.4B/C = 6U
             *          ...
             *          ezSWD150IH.14/C-0 = 7U
             *          ezSWD150IH.14/C-1 = 8U
             *          ezSWD150IH.14B/C-0 = 9U
             *          ezSWD150IH.14B/C-1 = 10U
             *          ezSWD150IH.25/C-0 = 11U
             *          ezSWD150IH.25/C-1 = 12U
             *          ezSWD150IH.25B/C-0 = 13U
             *          ezSWD150IH.25B/C-1 = 14U
             *          ...
             *          ezSWDcore.14/C = 15U
             *          ezSWDcore.14B/C = 16U
             *          ezSWDcore.25/C = 17U
             *          ezSWDcore.25B/C = 18U
             *          ezSWDcore.4/C = 19U
             *          ezSWDcore.4B/C = 20U
             *          ezSWDcore.0/C = 21U
             *          ...
             *      ]
             *
             * @param pProductId The product id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getProductId(uint32_t &pProductId) const = 0;

            /**
             * @brief Retrieve the SWD product reference. Ex : ezSWD125IM.14/C
             *
             * @param pProductRef The product reference.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getProductRef(std::string &pProductRef) const = 0;

            /**
             * @brief Retrieve the position distance of the SWD product in mm.
             *      FORMULA : position_value / NbStepRevolutionElec / NbPolePair / Reduction x Diameter x M_PI
             *      NOTA : The previous parameters are defined into the configuration file.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : The format of the configuration file is JSON
             *             ie. Nidec motor :
             *              "nbStepRevolutionElec": 6,
             *              "nbPolePair": 5,
             *              "reduction": 14.0,
             *              "diameter": 125.0
             *
             * @param pOdometryValue The position distance of the SWD Core in mm.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getOdometryValue(int32_t &pOdometryValue) const = 0;

            /**
             * @brief Retrieve the position distance of the SWD product in mm.
             *      FORMULA : position_value / NbStepRevolutionElec / NbPolePair / Reduction x Diameter x M_PI
             *      NOTA : The previous parameters are defined into the configuration file.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : The format of the configuration file is JSON
             *             ie. Nidec motor :
             *              "nbStepRevolutionElec": 6,
             *              "nbPolePair": 5,
             *              "reduction": 14.0,
             *              "diameter": 125.0
             *
             * @param pOdometryValue The position distance of the SWD product in mm.
             * @param pTimestamp The timestamp in microseconds (Unix epoch time from 1 January 1970).
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getOdometryValueTS(int32_t &pOdometryValue, uint64_t &pTimestamp) const = 0;

            /**
             * @brief Retrieve a more precise position distance of the SWD product in mm at low level speed. (Warning : This position is non-safe. Safety relevant applications should rely with getOdometryValue()).
             *      FORMULA : accurate_position_value / Reduction x Diameter x M_PI
             *      NOTA : The previous parameters are defined into the configuration file.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : The format of the configuration file is JSON
             *             ie. Nidec motor :
             *              "reduction": 14.0,
             *              "diameter": 125.0
             *
             * @param pAccurateOdometryValue The accurate position distance of the SWD product in mm.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getAccurateOdometryValue(int32_t &pAccurateOdometryValue) const = 0;

            /**
             * @brief Retrieve a more precise position distance of the SWD product in mm at low level speed. (Warning : This position is non-safe. Safety relevant applications should rely with getOdometryValue()).
             *      FORMULA : accurate_position_value / Reduction x Diameter x M_PI
             *      NOTA : The previous parameters are defined into the configuration file.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : The format of the configuration file is JSON
             *             ie. Nidec motor :
             *              "reduction": 14.0,
             *              "diameter": 125.0
             *
             * @param pAccurateOdometryValue The accurate position distance of the SWD product in mm.
             * @param pTimestamp The timestamp in microseconds (Unix epoch time from 1 January 1970).
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getAccurateOdometryValueTS(int32_t &pAccurateOdometryValue, uint64_t &pTimestamp) const = 0;

            /**
             * @brief Retrieve the precise multiturn position value, in units of motor mechanical degrees.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : This position is non-safe and is for information only. Safety relevant applications should rely on safe object "0x6064: position_value".
             *
             * @param pAccuratePositionValue The precise multiturn position value, in units of motor mechanical degrees.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getAccuratePositionValue(int32_t &pAccuratePositionValue) const = 0;

            /**
             * @brief Retrieve the precise multiturn position value, in units of motor mechanical degrees.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : This position is non-safe and is for information only. Safety relevant applications should rely on safe object "0x6064: position_value".
             *
             * @param pAccuratePositionValue The precise multiturn position value, in units of motor mechanical degrees.
             * @param pTimestamp The timestamp in ms from 1970.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getAccuratePositionValueTS(int32_t &pAccuratePositionValue, uint64_t &pTimestamp) const = 0;

            /**
             * @brief Retrieve the control value for an OutputSource
             *      NOTA : Value of 1 means OutputSource is active
             *      NOTA : Value of 0 means OutputSource is inactive
             *      NOTA : Value of control can be saved in EEPROM ( MANUFACTURER data )
             *      NOTA : Value of control is applied immediately
             *
             * @param pOutputSource which OutputSource control you want to get.
             * @param pControl control for the OutputSource : 1 OutputSource is active, 0 OutputSource is inactive
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getOutputControl(const OutputSource &pOutputSource, bool &pControl) const = 0;

            /**
             * @brief Set the control value for an OutputSource
             *      NOTA : Value of 1 means OutputSource is active
             *      NOTA : Value of 0 means OutputSource is inactive
             *      NOTA : Value of control can be saved in EEPROM ( MANUFACTURER data )
             *      NOTA : Value of control is applied immediately
             *
             * @param pOutputSource which OutputSource control you want to set.
             * @param pControl control for the OutputSource : 1 OutputSource is active, 0 OutputSource is inactive
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setOutputControl(const OutputSource &pOutputSource, const bool &pControl) = 0;

            /**
             * @brief Retrieve the status of an OutputSource
             *      NOTA : Value of 1 means OutputSource is active
             *      NOTA : Value of 0 means OutputSource is inactive
             *
             * @param pOutputSource which OutputSource status you want to get.
             * @param pStatus The status of OutputSource.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getOutputStatus(const OutputSource &pOutputSource, bool &pStatus) const = 0;

            /**
             * @brief Modify the external brake presence flag.
             *      NOTA : Value of 1 means external brake is configured to be present.
             *      NOTA : Value of 0 means external brake is configured to be not present.
             *
             * @param pExternalbrakepresence The external brake presence flag.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setExternalBrakePresence(const bool &pExternalbrakepresence) = 0;

            /**
             * @brief Retrieve the external brake presence flag.
             *      NOTA : Value of 1 means external brake is configured to be present.
             *      NOTA : Value of 0 means external brake is configured to be not present.
             *
             * @param pExternalbrakepresence The external brake presence flag.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getExternalBrakePresence(bool &pExternalbrakepresence) const = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_IMANUFACTURERSERVICE_HPP */
