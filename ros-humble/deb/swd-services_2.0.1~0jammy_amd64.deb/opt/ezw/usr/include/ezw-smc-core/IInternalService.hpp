/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file IInternalService.hpp
 */

#ifndef EZW_SMCCORE_IINTERNALSERVICE_HPP
#define EZW_SMCCORE_IINTERNALSERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief Internal use only.
         */
        class IInternalService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~IInternalService() = default;

            /** Indicates the internal parameters to store/restore into the non-volatile memory. */
            enum class _BlocId
            {
                FACTORY      = 5, /**< Factory parameters (index from 6000h to 9FFFh => reserved manufacturer + motor calibration parameters). */
                TEST_RESULTS = 6, /**< Manufacturer test results. */
            };

            /** Indicates the manufacturer device parameters. */
            struct _DeviceParameters {
                std::string manufacturer_device_name      = std::string{}; /*!< Indicates the device name. */
                std::string hardware_version_description  = std::string{}; /*!< Indicates the hardware version description. */
                std::string manufacturer_software_version = std::string{}; /*!< Indicates the software version description. */
            };

            /** Indicates the self tests results. */
            struct _SelfTestStatus {
                uint8_t auto_init_status    = uint8_t{}; /*!< PBIT tests status. */
                uint8_t motor_driver_status = uint8_t{}; /*!< Motor tests status. */
            };

            /** Calibration parameters of the both signals : sin & cos. */
            struct _CalibrationParameters {
                bool    is_valid              = bool{};    /*!< True if calibration parameters are avalaible. */
                int32_t cos_adc_offset_mv     = int32_t{}; /*!< Cosinus - offset of the zero value in mv read by ADC (between 0 - 5000ms; usually 2500mv). */
                float   cos_gain              = float{};   /*!< Cosinus - normalisation factor to bring signal between [-1;1] from [0;2] mv; usually 0.001. */
                int32_t cos_angle_offset_mdeg = int32_t{}; /*!< Cosinus - diff angle between magnetic pole of the motor and the sensor (between 0 - 360000 mdeg). */
                int32_t sin_adc_offset_mv     = int32_t{}; /*!< Sinus - offset of the zero value in mv read by ADC (between 0 - 5000ms; usually 2500mv). */
                float   sin_gain              = float{};   /*!< Sinus - normalisation factor to bring signal between [-1;1] from [0;2] mv; usually 0.001. */
                int32_t sin_angle_offset_mdeg = int32_t{}; /*!< Sinus - diff angle between magnetic pole of the motor and the sensor (between 0 - 360000 mdeg). */
            };

            /** System error configuration. */
            struct _SystemErrorConfig {
                uint32_t time_ms_zero_torque_protect   = uint32_t{}; /*!< Temps en ms a attendre pour aller en mode CC protect si le courant est toujours au dessus du courant max zero protect. */
                uint32_t time_ms_brake_cc_protect      = uint32_t{}; /*!< Temps en ms a rester en CC protect avant d'aller en SBC config. */
                int32_t  battery_uv_warning            = int32_t{};  /*!< Tension du bus DC en mv (MEAS_VPACK) a partir de laquelle on passe en warning si tension au niveau warning pendant au moins Tuv warning 16 V. */
                int32_t  battery_uv_error              = int32_t{};  /*!< Tension du bus DC en MV (MEAS_VPACK) a partir de laquelle on passe en error effet immediat 14 V. */
                int32_t  battery_ov_warning            = int32_t{};  /*!< Seuil Vpack_ov_warning = 32v pendant Tov_warning = 1 seconde. */
                int32_t  battery_ov_error              = int32_t{};  /*!< Seuil Vpack_uv_error = 14v effet immediat. */
                int32_t  phase_oc_warning              = int32_t{};  /*!< IPhase_oc_warning = 25A pendant Toc_warning = 100µs. */
                int32_t  phase_oc_error                = int32_t{};  /*!< Seuil IPhase _oc_error = 30A effet immediat. */
                uint32_t battery_uv_warning_timeout_ms = uint32_t{}; /*!< Temps en ms (1s) avant de passer en error. */
                uint32_t battery_ov_warning_timeout_ms = uint32_t{}; /*!< Temps en ms (1s) avant de passer en error. */
                uint32_t phase_oc_warning_timeout_ms   = uint32_t{}; /*!< Temps en ms (1s) avant de passer en error. */
                float    phase_over_board_factor       = float{};    /*!< 1.0 correction pour mesure courant phase. */
                int32_t  mos1_temp_threshold_rise      = int32_t{};  /*!< Seuil de detection de temperature haut du mos 1 */
                int32_t  mos1_temp_threshold_fall      = int32_t{};  /*!< Seuil de detection de temperature bas du mos 1 */
                int32_t  mos2_temp_threshold_rise      = int32_t{};  /*!< Seuil de detection de temperature haut du mos 2 */
                int32_t  mos2_temp_threshold_fall      = int32_t{};  /*!< Seuil de detection de temperature bas du mos 2 */
            };

            /** Id of the system error code.
             *  NOTA :
             *  - The enum shall be aligned with ezw_system_error_code_id_t enum order */
            enum class SystemErrorId
            {
                ERROR_COM_GEN                           = 0,
                ERROR_TEMP_GEN                          = 1,
                ERROR_DC_OVER_CURRENT_1                 = 2,
                ERROR_DC_OVER_CURRENT_2                 = 3,
                ERROR_BMS_OVER_CURRENT                  = 4,
                ERROR_OVER_VOLTAGE_1                    = 5,
                ERROR_OVER_VOLTAGE_2                    = 6,
                ERROR_UNDER_VOLTAGE_1                   = 7,
                ERROR_UNDER_VOLTAGE_2                   = 8,
                ERROR_BMS_UNDER_VOLTAGE                 = 9,
                ERROR_BMS_OVER_VOLTAGE                  = 10,
                ERROR_BMS_UNDER_VOLTAGE_CHA             = 11,
                ERROR_EXCESS_TEMPERATURE_DEVICE         = 12,
                ERROR_OVER_TEMPERATURE_BMS              = 13,
                ERROR_UNDER_TEMPERATURE_BMS             = 14,
                ERROR_EXCESS_TEMPERATURE_DRIVE          = 15,
                ERROR_BMS_PACK_TEMP_SENSOR              = 16,
                ERROR_CANOPEN_PARAMETER_ERROR           = 17,
                ERROR_BMS_INTERNAL_ERROR                = 18,
                ERROR_MOTOR_BLOCKED                     = 19,
                ERROR_POWER_ADDITIONAL_MODULE           = 20,
                ERROR_OSSD_STO_1                        = 21,
                ERROR_OSSD_STO_2                        = 22,
                ERROR_SAFE_IN_1                         = 23,
                ERROR_SAFE_IN_2                         = 24,
                ERROR_SAFE_OUT_1                        = 25,
                ERROR_SAFE_OUT_2                        = 26,
                ERROR_HALL_INCONSISTENCY                = 27,
                ERROR_SAFE_DRVOFF_COHERENCY             = 28,
                ERROR_SAFE_STO_COHERENCY                = 29,
                ERROR_SAFE_NBRAKE                       = 30,
                ERROR_SAFE_NBRAKE_INT                   = 31,
                ERROR_SAFE_NBRAKE_CTRL                  = 32,
                ERROR_SAFE_NCCSTATE                     = 33,
                ERROR_SAFE_MCU_NBRAKE                   = 34,
                ERROR_SAFE_BLC                          = 35,
                ERROR_FAULT_EXT_BRAKE_CMD               = 36,
                ERROR_ENDRV                             = 37,
                ERROR_FAULT_ALIM_EXT                    = 38,
                ERROR_FAULT_EMERGENCY                   = 39,
                ERROR_FAULT_EXT_BRAKE_PRESENCE          = 40,
                ERROR_FAULT_BRAKE_OC                    = 41,
                ERROR_FAULT_SBU_ACTIVATED               = 42,
                ERROR_FAULT_SBU_ACTIVATION_ERROR        = 43,
                ERROR_DRIVER_GENERIC                    = 44,
                ERROR_CAN_ERROR_PASSIVE                 = 45,
                ERROR_CAN_RECOVERED_FROM_BUS_OFF        = 46,
                ERROR_PROTOCOL_ERROR_SRDO_SCT_TIMEOUT   = 47,
                ERROR_PROTOCOL_ERROR_SRDO_SRVT_TIMEOUT  = 48,
                ERROR_PROTOCOL_ERROR_SRDO_DATA_MISMATCH = 49,
                ERROR_PROTOCOL_ERROR_SRDO_WRONG_MSG     = 50,
                ERROR_PROTOCOL_ERROR_SRDO_WRONG_LEN     = 51,
                ERROR_PROTOCOL_ERROR_EVENT_TIMER        = 52,
                ERROR_NUMOF                             = 53,
            };

            /** Indicates the status of a system error code. */
            struct SystemErrorOutput {
                SystemErrorId system_error_id = SystemErrorId{}; /*!< Id of the system error code. */
                bool          status          = bool{};          /*!< True if the system error code is enabled. */
            };

            /**
             * @brief Store the internal parameters of the specified bloc id into the non-volatile memory.
             *
             * @param pBlocId The internal bloc id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _storeParameters(const _BlocId &pBlocId) = 0;

            /**
             * @brief Restore the internal default parameters of the specified bloc id. Restoring is done by declaring the stored parameters in NVM as invalid.
             *  The function does not load the internal default parameters.
             *  The internal default values shall be set valid after the CANopen device is reset (NMT service reset node for sub-index from 01h to 7Fh, NMT service reset communication for sub-index 02h) or power cycled.
             * .
             *
             * @param pBlocId The internal bloc id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _restoreDefaultParameters(const _BlocId &pBlocId) = 0;

            /**
             * @brief Modify the device parameters.
             *
             * @param pParams The device parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _setDeviceParameters(const _DeviceParameters &pParams) = 0;

            /**
             * @brief Retrieve the self tests status.
             *
             * @param pSelfTestStatus The self tests status.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _getSelfTestStatus(_SelfTestStatus &pSelfTestStatus) const = 0;

            /**
             * @brief Simulate self test status.
             *
             * @param pSelfTestStatus The self tests status to simulate.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _simulateSelfTestError(const _SelfTestStatus &pSelfTestStatus) const = 0;

            /**
             * @brief Retrieve the calibration parameters used by the system.
             *
             * @param pParams The calibration parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _getCalibrationParameters(_CalibrationParameters &pParams) const = 0;

            /**
             * @brief Retrieve the system error configuration.
             *
             * @param pConfig The system error configuration.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _getSystemErrorConfig(_SystemErrorConfig &pConfig) const = 0;

            /**
             * @brief Modify the system error configuration.
             *
             * @param pConfig The system error configuration.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _setSystemErrorConfig(const _SystemErrorConfig &pConfig) = 0;

            /**
             * @brief Indicates the level1 error:
             *      VELOCITY_INVALID_VELOCITY_UPDATE    = 0x00000001
             *      FACADE00_MOTOR_FORCE_ANGLE          = 0x00000002
             *      FACADE00_MOTOR_SET_RATIO            = 0x00000004
             *      FACADE01_MOTOR_FORCE_ANGLE          = 0x00000008
             *      FACADE01_MOTOR_SET_RATIO            = 0x00000010
             *      DEADBEEF                            = 0x00000020
             *      VELOCITY_UPDATE                     = 0x00000040
             *      SET_ANGULAR_SPEED                   = 0x00000080
             *      TEMPSFTY_GET_SAFETY_FLAGS           = 0x00000100
             *      TEMPSFTY_GET_TEMPERATURE_MOS1       = 0x00000200
             *      TEMPSFTY_GET_TEMPERATURE_MOS2       = 0x00000400
             *      TEMPSFTY_GET_TEMPERATURE_PIN_DRIVER = 0x00000800
             *      MOTCTRL_BRAKE_GROUND                = 0x00001000
             *      HALL_GET_MOTOR_SPEED                = 0x00002000
             *      HALL_GET_SINCOS_INCREMENTS          = 0x00004000
             *      TEMPSFTY_PROCESS                    = 0x00008000
             *      MOTCTRL_PROCESS                     = 0x00010000
             *      DRV_OFF                             = 0x00020000
             *      ERROR_MANAGER                       = 0x00040000
             *      SAFE_SPEED_MANAGER                  = 0x00080000
             *
             * @param pLevel1Error The level1 error.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _getLevel1Error(uint32_t &pLevel1Error) const = 0;

            /**
             * @brief Retrieve all the system error code statuses.
             *
             * @param pItems Indicates all the system error code statuses.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSystemErrorOutputs(std::vector<SystemErrorOutput> &pItems) const = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_IINTERNALSERVICE_HPP */
