/**
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file ICANOpenDispatcher.hpp
 */

#ifndef EZW_SMCCORE_ICANOPENDISPATCHER_HPP
#define EZW_SMCCORE_ICANOPENDISPATCHER_HPP

/* Includes -------------------------------------------- */
#include "IService.hpp"

#include <chrono>

/* Defines --------------------------------------------- */

/* Variable declaration -------------------------------- */

/* Class ----------------------------------------------- */
namespace ezw
{
    namespace smccore
    {
        class ICANOpenDispatcher : public IService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            ~ICANOpenDispatcher() override = default;

            virtual ezw_error_t            init()                        = 0;
            virtual bool                   isConfigLoaded() const        = 0;
            virtual bool                   isClientInitialized() const   = 0;
            virtual bool                   isUpdatePdoTerminated() const = 0;
            virtual ICoreService::ModeEnum getMode() const               = 0;

            // SW Update
            virtual ezw_error_t getSWVersion(uint32_t &pSWVersion) const = 0;
            virtual ezw_error_t getHWConfig(uint32_t &pHWConfig) const   = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_ICANOPENDISPATCHER_HPP */
