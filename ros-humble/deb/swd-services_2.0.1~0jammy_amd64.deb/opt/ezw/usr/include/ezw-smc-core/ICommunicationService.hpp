/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file ICommunicationService.hpp
 */

#ifndef EZW_SMCCORE_ICOMMUNICATIONSERVICE_HPP
#define EZW_SMCCORE_ICOMMUNICATIONSERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief [CIA301] Communication setting.
         */
        class ICommunicationService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~ICommunicationService() = default;

            /** Indicates the parameters to store/restore into the non-volatile memory. */
            enum class BlocId
            {
                ALL           = 1, /**< Used to store/restore all parameters. */
                COMMUNICATION = 2, /**< Used to store/restore communication parameters (index from 1000h to 1FFFh) and LSS parameters (index from 2100h to 2102h) */
                APPLICATION   = 3, /**< Used to store/restore application parameters (index from 6000h to 9FFFh). */
                MANUFACTURER  = 4, /**< Used to store/restore manufacturer parameters. */
            };

            /** Indicates the identity device parameters. */
            struct IdentityParameters {
                uint32_t vendor_id       = uint32_t{}; /*!< Indicates the Vendor-ID. */
                uint32_t product_code    = uint32_t{}; /*!< Indicates the product code. */
                uint32_t revision_number = uint32_t{}; /*!< Indicates the revision number. */
                uint32_t serial_number   = uint32_t{}; /*!< Indicates the serial number. */
            };

            /** Indicates the bit timming. */
            enum class BitTiming
            {
                BT_1000 = 0, /**< Baud rate of 1 MBit/sec */
                BT_800  = 1, /**< Baud rate of 800 kBit/sec */
                BT_500  = 2, /**< Baud rate of 500 kBit/sec */
                BT_250  = 3, /**< Baud rate of 250 kBit/sec */
                BT_125  = 4, /**< Baud rate of 125 kBit/sec */
                BT_100  = 5, /**< Baud rate of 100 kBit/sec */
                BT_50   = 6, /**< Baud rate of 50 kBit/sec */
                BT_20   = 7, /**< Baud rate of 20 kBit/sec */
                BT_10   = 8, /**< Baud rate of 10 kBit/sec */
            };

            /** Indicates the configured network parameters. */
            struct NetworkParameters {
                BitTiming bit_timing   = BitTiming{}; /*!< The bit timing index of the device. */
                uint8_t   node_id      = uint8_t{};   /*!< The node id of the device : from 1 to 127. */
                bool      rt_activated = bool{};      /*!< True means R_termination is activated. */
            };

            /** Represents a COB-ID.
             *  A COB-ID allows to specify the CAN-ID of the message on the can bus and its validity.
             *  NOTA :
             *  - SWD product allows only CAN-ID in 11 bits format.
             *  - SWD product doesn't allows TPDO send in RTR mode (bit 30 = 1).
             *  - SWD product doesn't allows dynamic SDO connections (bit 30 = 0).
             *  - The bit valid (bit 31) allows selecting which TPDOs/RPDOs are used in the NMT state Operational. */
            struct COBID {
                uint16_t can_id = uint16_t{}; /*!< The CAN-ID. */
                bool     valid  = bool{};     /*!< True if valid else False. */
                bool     flag   = bool{};     /*!< Represents the bit 30. SDO : False = value is assigned statically; TPDO : True = no RTR allowed on this PDO; RPDO : not used */
            };

            /** Indicates the configured communication parameters. */
            struct CommunicationParameters {
                uint16_t can_id_sync  = uint16_t{}; /*!< Indicates the configured CAN-ID of the synchronization object (SYNC). Default : 80h. */
                uint16_t prod_hb_time = uint16_t{}; /*!< Indicates the configured cycle time of the heartbeat in steps of 1 ms. 0h = heartbeat disabled. Default : 500ms. */
            };

            /** Indicates the SDO server id. */
            enum class SDOId
            {
                SDO_1 = 1, /**< Id of the SDO server 1 (default SDO server : read Only). */
                SDO_2 = 2, /**< Id of the SDO server 2. */
                SDO_3 = 3, /**< Id of the SDO server 3. */
                SDO_4 = 4, /**< Id of the SDO server 4. */
            };

            /** Indicates the SDO server communication parameters.
             *  NOTA :
             *  - The SDO server 1 communication parameters are in read only mode.
             *  - COB-ID of the SDO reception of the SDO 1 server is $NODEID+0x600.
             *  - COB-ID of the SDO transmission of the SDO 1 server is $NODEID+0x580.
             *  - Only static SDO connections are allowed (bit dyn 30 = 0).
             *  - Static SDO connections are configured non-temporarily and may be saved in non-volatile memory. */
            struct SDOCommunicationParameters {
                COBID cob_id_client_to_server = COBID{}; /*!< Indicates the configured COB-ID of the SDO reception. */
                COBID cob_id_server_to_client = COBID{}; /*!< Indicates the configured COB-ID of the SDO transmission. */
            };

            /** Indicates the PDO id. */
            enum class PDOId
            {
                PDO_1 = 1, /**< Id of the PDO 1. */
                PDO_2 = 2, /**< Id of the PDO 2. */
                PDO_3 = 3, /**< Id of the PDO 3. */
                PDO_4 = 4, /**< Id of the PDO 4. */
                PDO_5 = 5, /**< Id of the PDO 5. */
                PDO_6 = 6, /**< Id of the PDO 6. */
                PDO_7 = 7, /**< Id of the PDO 7. */
                PDO_8 = 8, /**< Id of the PDO 8. */
            };

            /** Indicates the transmission type of a PDO.
             *  Cyclic Synchronous PDOs are transmitted with the SYNC message. The Cyclic synchronous options 1-240 can be used to divide down when the PDO is transmitted so that a value of 2 is transmitted every other SYNC message etc.
             *  the device still samples on the SYNC message as before so sample lag is only ever SYNC interval behind, but the update rate can be divided down.
             *  With Acyclic synchronous these only transmit when a Remote request from another device ‘pre-triggers’ the PDO or A device (profile) specific event ‘pre-triggers’ the PDO. */
            enum class PDOTransmissionType
            {
                PDO_SYNC_1   = 1,
                PDO_SYNC_2   = 2,
                PDO_SYNC_3   = 3,
                PDO_SYNC_4   = 4,
                PDO_SYNC_5   = 5,
                PDO_SYNC_6   = 6,
                PDO_SYNC_7   = 7,
                PDO_SYNC_8   = 8,
                PDO_SYNC_9   = 9,
                PDO_SYNC_10  = 10,
                PDO_SYNC_11  = 11,
                PDO_SYNC_12  = 12,
                PDO_SYNC_13  = 13,
                PDO_SYNC_14  = 14,
                PDO_SYNC_15  = 15,
                PDO_SYNC_16  = 16,
                PDO_SYNC_17  = 17,
                PDO_SYNC_18  = 18,
                PDO_SYNC_19  = 19,
                PDO_SYNC_20  = 20,
                PDO_SYNC_21  = 21,
                PDO_SYNC_22  = 22,
                PDO_SYNC_23  = 23,
                PDO_SYNC_24  = 24,
                PDO_SYNC_25  = 25,
                PDO_SYNC_26  = 26,
                PDO_SYNC_27  = 27,
                PDO_SYNC_28  = 28,
                PDO_SYNC_29  = 29,
                PDO_SYNC_30  = 30,
                PDO_SYNC_31  = 31,
                PDO_SYNC_32  = 32,
                PDO_SYNC_33  = 33,
                PDO_SYNC_34  = 34,
                PDO_SYNC_35  = 35,
                PDO_SYNC_36  = 36,
                PDO_SYNC_37  = 37,
                PDO_SYNC_38  = 38,
                PDO_SYNC_39  = 39,
                PDO_SYNC_40  = 40,
                PDO_SYNC_41  = 41,
                PDO_SYNC_42  = 42,
                PDO_SYNC_43  = 43,
                PDO_SYNC_44  = 44,
                PDO_SYNC_45  = 45,
                PDO_SYNC_46  = 46,
                PDO_SYNC_47  = 47,
                PDO_SYNC_48  = 48,
                PDO_SYNC_49  = 49,
                PDO_SYNC_50  = 50,
                PDO_SYNC_51  = 51,
                PDO_SYNC_52  = 52,
                PDO_SYNC_53  = 53,
                PDO_SYNC_54  = 54,
                PDO_SYNC_55  = 55,
                PDO_SYNC_56  = 56,
                PDO_SYNC_57  = 57,
                PDO_SYNC_58  = 58,
                PDO_SYNC_59  = 59,
                PDO_SYNC_60  = 60,
                PDO_SYNC_61  = 61,
                PDO_SYNC_62  = 62,
                PDO_SYNC_63  = 63,
                PDO_SYNC_64  = 64,
                PDO_SYNC_65  = 65,
                PDO_SYNC_66  = 66,
                PDO_SYNC_67  = 67,
                PDO_SYNC_68  = 68,
                PDO_SYNC_69  = 69,
                PDO_SYNC_70  = 70,
                PDO_SYNC_71  = 71,
                PDO_SYNC_72  = 72,
                PDO_SYNC_73  = 73,
                PDO_SYNC_74  = 74,
                PDO_SYNC_75  = 75,
                PDO_SYNC_76  = 76,
                PDO_SYNC_77  = 77,
                PDO_SYNC_78  = 78,
                PDO_SYNC_79  = 79,
                PDO_SYNC_80  = 80,
                PDO_SYNC_81  = 81,
                PDO_SYNC_82  = 82,
                PDO_SYNC_83  = 83,
                PDO_SYNC_84  = 84,
                PDO_SYNC_85  = 85,
                PDO_SYNC_86  = 86,
                PDO_SYNC_87  = 87,
                PDO_SYNC_88  = 88,
                PDO_SYNC_89  = 89,
                PDO_SYNC_90  = 90,
                PDO_SYNC_91  = 91,
                PDO_SYNC_92  = 92,
                PDO_SYNC_93  = 93,
                PDO_SYNC_94  = 94,
                PDO_SYNC_95  = 95,
                PDO_SYNC_96  = 96,
                PDO_SYNC_97  = 97,
                PDO_SYNC_98  = 98,
                PDO_SYNC_99  = 99,
                PDO_SYNC_100 = 100,
                PDO_SYNC_101 = 101,
                PDO_SYNC_102 = 102,
                PDO_SYNC_103 = 103,
                PDO_SYNC_104 = 104,
                PDO_SYNC_105 = 105,
                PDO_SYNC_106 = 106,
                PDO_SYNC_107 = 107,
                PDO_SYNC_108 = 108,
                PDO_SYNC_109 = 109,
                PDO_SYNC_110 = 110,
                PDO_SYNC_111 = 111,
                PDO_SYNC_112 = 112,
                PDO_SYNC_113 = 113,
                PDO_SYNC_114 = 114,
                PDO_SYNC_115 = 115,
                PDO_SYNC_116 = 116,
                PDO_SYNC_117 = 117,
                PDO_SYNC_118 = 118,
                PDO_SYNC_119 = 119,
                PDO_SYNC_120 = 120,
                PDO_SYNC_121 = 121,
                PDO_SYNC_122 = 122,
                PDO_SYNC_123 = 123,
                PDO_SYNC_124 = 124,
                PDO_SYNC_125 = 125,
                PDO_SYNC_126 = 126,
                PDO_SYNC_127 = 127,
                PDO_SYNC_128 = 128,
                PDO_SYNC_129 = 129,
                PDO_SYNC_130 = 130,
                PDO_SYNC_131 = 131,
                PDO_SYNC_132 = 132,
                PDO_SYNC_133 = 133,
                PDO_SYNC_134 = 134,
                PDO_SYNC_135 = 135,
                PDO_SYNC_136 = 136,
                PDO_SYNC_137 = 137,
                PDO_SYNC_138 = 138,
                PDO_SYNC_139 = 139,
                PDO_SYNC_140 = 140,
                PDO_SYNC_141 = 141,
                PDO_SYNC_142 = 142,
                PDO_SYNC_143 = 143,
                PDO_SYNC_144 = 144,
                PDO_SYNC_145 = 145,
                PDO_SYNC_146 = 146,
                PDO_SYNC_147 = 147,
                PDO_SYNC_148 = 148,
                PDO_SYNC_149 = 149,
                PDO_SYNC_150 = 150,
                PDO_SYNC_151 = 151,
                PDO_SYNC_152 = 152,
                PDO_SYNC_153 = 153,
                PDO_SYNC_154 = 154,
                PDO_SYNC_155 = 155,
                PDO_SYNC_156 = 156,
                PDO_SYNC_157 = 157,
                PDO_SYNC_158 = 158,
                PDO_SYNC_159 = 159,
                PDO_SYNC_160 = 160,
                PDO_SYNC_161 = 161,
                PDO_SYNC_162 = 162,
                PDO_SYNC_163 = 163,
                PDO_SYNC_164 = 164,
                PDO_SYNC_165 = 165,
                PDO_SYNC_166 = 166,
                PDO_SYNC_167 = 167,
                PDO_SYNC_168 = 168,
                PDO_SYNC_169 = 169,
                PDO_SYNC_170 = 170,
                PDO_SYNC_171 = 171,
                PDO_SYNC_172 = 172,
                PDO_SYNC_173 = 173,
                PDO_SYNC_174 = 174,
                PDO_SYNC_175 = 175,
                PDO_SYNC_176 = 176,
                PDO_SYNC_177 = 177,
                PDO_SYNC_178 = 178,
                PDO_SYNC_179 = 179,
                PDO_SYNC_180 = 180,
                PDO_SYNC_181 = 181,
                PDO_SYNC_182 = 182,
                PDO_SYNC_183 = 183,
                PDO_SYNC_184 = 184,
                PDO_SYNC_185 = 185,
                PDO_SYNC_186 = 186,
                PDO_SYNC_187 = 187,
                PDO_SYNC_188 = 188,
                PDO_SYNC_189 = 189,
                PDO_SYNC_190 = 190,
                PDO_SYNC_191 = 191,
                PDO_SYNC_192 = 192,
                PDO_SYNC_193 = 193,
                PDO_SYNC_194 = 194,
                PDO_SYNC_195 = 195,
                PDO_SYNC_196 = 196,
                PDO_SYNC_197 = 197,
                PDO_SYNC_198 = 198,
                PDO_SYNC_199 = 199,
                PDO_SYNC_200 = 200,
                PDO_SYNC_201 = 201,
                PDO_SYNC_202 = 202,
                PDO_SYNC_203 = 203,
                PDO_SYNC_204 = 204,
                PDO_SYNC_205 = 205,
                PDO_SYNC_206 = 206,
                PDO_SYNC_207 = 207,
                PDO_SYNC_208 = 208,
                PDO_SYNC_209 = 209,
                PDO_SYNC_210 = 210,
                PDO_SYNC_211 = 211,
                PDO_SYNC_212 = 212,
                PDO_SYNC_213 = 213,
                PDO_SYNC_214 = 214,
                PDO_SYNC_215 = 215,
                PDO_SYNC_216 = 216,
                PDO_SYNC_217 = 217,
                PDO_SYNC_218 = 218,
                PDO_SYNC_219 = 219,
                PDO_SYNC_220 = 220,
                PDO_SYNC_221 = 221,
                PDO_SYNC_222 = 222,
                PDO_SYNC_223 = 223,
                PDO_SYNC_224 = 224,
                PDO_SYNC_225 = 225,
                PDO_SYNC_226 = 226,
                PDO_SYNC_227 = 227,
                PDO_SYNC_228 = 228,
                PDO_SYNC_229 = 229,
                PDO_SYNC_230 = 230,
                PDO_SYNC_231 = 231,
                PDO_SYNC_232 = 232,
                PDO_SYNC_233 = 233,
                PDO_SYNC_234 = 234,
                PDO_SYNC_235 = 235,
                PDO_SYNC_236 = 236,
                PDO_SYNC_237 = 237,
                PDO_SYNC_238 = 238,
                PDO_SYNC_239 = 239,
                PDO_SYNC_240 = 240,
                PDO_ASYNC_FF = 255, /**< Asynchronous: The data become valid when the PDO message is received and are taken over into the object dictionary. */
            };

            /** Indicates the communication parameters of a PDO. */
            struct PDOCommunicationParameters {
                COBID               cob_id            = COBID{};               /*!< Indicates the COB-ID used by the PDO. */
                PDOTransmissionType transmission_type = PDOTransmissionType{}; /*!< Indicates the transmission type. Default : PDO_SYNC_1 in TX. */
                uint16_t            event_timer       = uint16_t{};            /*!< Independent of the transmission type the RPDO event timer is used recognize the expiration in ms of the RPDO.
                                                                                * In mode PDO_ASYNC_FF additionally an event time can be used for TPDO.
                                                                                * If an event timer exists for a TPDO (value not equal to 0) the elapsed timer in ms is considered to be an event (not implemented). */
            };

            /** Indicates the mapping parameters of a PDO. */
            struct PDOMappingParameters {
                uint8_t               nb    = uint8_t{};               /*!< Indicates the number of mapped application objects in PDO. */
                std::vector<uint32_t> items = std::vector<uint32_t>{}; /*!< Indicates the mapped application objects in PDO : Index SubIndex Size (0x0 to inactive). */
            };

            /**
             * @brief Store the parameters of the specified bloc id into the non-volatile memory.
             *
             * @param pBlocId The bloc id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t storeParameters(const BlocId &pBlocId) = 0;

            /**
             * @brief Restore the default parameters of the specified bloc id. Restoring is done by declaring the stored parameters in NVM as invalid.
             *  The function does not load the default parameters.
             *  The default values shall be set valid after the CANopen device is reset (NMT service reset node for sub-index from 01h to 7Fh, NMT service reset communication for sub-index 02h) or power cycled.
             * .
             *
             * @param pBlocId The bloc id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t restoreDefaultParameters(const BlocId &pBlocId) = 0;

            /**
             * @brief Retrieve the device parameters.
             *
             * @param pParams The device parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getIdentityParameters(IdentityParameters &pParams) const = 0;

            /**
             * @brief Retrieve the network parameters.
             *
             * @param pParams The network parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getNetworkParameters(NetworkParameters &pParams) const = 0;

            /**
             * @brief Modify the network parameters.
             *
             * @param pParams The new network parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setNetworkParameters(const NetworkParameters &pParams) = 0;

            /**
             * @brief Retrieve the communication parameters.
             *
             * @param pParams The communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getCommunicationParameters(CommunicationParameters &pParams) const = 0;

            /**
             * @brief Modify the communication parameters.
             *
             * @param pParams The communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setCommunicationParameters(const CommunicationParameters &pParams) = 0;

            /**
             * @brief Retrieve the SDO communication parameters of the specified SDO id.
             *
             * @param pId The SDO id.
             * @param pParams The communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSDOCommunicationParameters(const SDOId &pId, SDOCommunicationParameters &pParams) const = 0;

            /**
             * @brief Modify the SDO communication parameters of the specified SDO id.
             *
             * @param pId The SDO id.
             * @param pParams The new communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSDOCommunicationParameters(const SDOId &pId, const SDOCommunicationParameters &pParams) = 0;

            /**
             * @brief Retrieve the communication parameters of the specified RPDO id (PDO the CANopen device is able to receive).
             *
             * @param pId The PDO id.
             * @param pParams The communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getRPDOCommunicationParameters(const PDOId &pId, PDOCommunicationParameters &pParams) const = 0;

            /**
             * @brief Modify the communication parameters of the specified RPDO id (PDO the CANopen device is able to receive).
             *
             * @param pId The PDO id.
             * @param pParams The new communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setRPDOCommunicationParameters(const PDOId &pId, const PDOCommunicationParameters &pParams) = 0;

            /**
             * @brief Retrieve the communication parameters of the specified TPDO id (PDO the CANopen device is able to transmit).
             *
             * @param pId The PDO id.
             * @param pParams The communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getTPDOCommunicationParameters(const PDOId &pId, PDOCommunicationParameters &pParams) const = 0;

            /**
             * @brief Modify the communication parameters of the specified TPDO id (PDO the CANopen device is able to transmit).
             *
             * @param pId The PDO id.
             * @param pParams The new communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setTPDOCommunicationParameters(const PDOId &pId, const PDOCommunicationParameters &pParams) = 0;

            /**
             * @brief Retrieve the mapping parameters of the specified RPDO id (PDO the CANopen device is able to receive).
             *
             * @param pId The PDO id.
             * @param pParams The mapping parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getRPDOMappingParameters(const PDOId &pId, PDOMappingParameters &pParams) const = 0;

            /**
             * @brief Modify the mapping parameters of the specified RPDO id (PDO the CANopen device is able to receive).
             *
             * @param pId The PDO id.
             * @param pParams The new mapping parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setRPDOMappingParameters(const PDOId &pId, const PDOMappingParameters &pParams) = 0;

            /**
             * @brief Retrieve the mapping parameters of the specified TPDO id (PDO the CANopen device is able to transmit).
             *
             * @param pId The PDO id.
             * @param pParams The mapping parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getTPDOMappingParameters(const PDOId &pId, PDOMappingParameters &pParams) const = 0;

            /**
             * @brief Modify the Mapping parameters of the specified TPDO id (PDO the CANopen device is able to transmit).
             *
             * @param pId The PDO id.
             * @param pParams The new mapping parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setTPDOMappingParameters(const PDOId &pId, const PDOMappingParameters &pParams) = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_ICOMMUNICATIONSERVICE_HPP */
