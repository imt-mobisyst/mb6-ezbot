/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file IVelocityModeService.hpp
 */

#ifndef EZW_SMCCORE_IVELOCITYMODESERVICE_HPP
#define EZW_SMCCORE_IVELOCITYMODESERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief [CIA402-2] The velocity mode controls the speed (velocity) of the SWD product but not its position.
         *  The selection of a new target velocity use a acceleration / deceleration ramp.
         *  The velocity mode is composed of three main functions:
         *  - velocity limit function
         *  - ramp function
         *  - velocity control function
         *  and is composed of the following factor functions:
         *  - factor function
         *  - reverse factor function.
         */
        class IVelocityModeService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~IVelocityModeService() = default;

            /** [CIA402-2] Velocity mode parameters.
             *  The velocity mode use some parameters to control the velocity control function. */
            struct VelocityModeParameters {
                uint32_t vl_velocity_min_amount               = uint32_t{}; /*!< The configured minimum amount of velocity. The value shall be given in rotations per minute (r/min) or in user-defined velocity units. Default : 40 r/min */
                uint32_t vl_velocity_max_amount               = uint32_t{}; /*!< The configured maximum amount of velocity. The values shall be given in rotations per minute (r/min) or in user-defined velocity units. Default : 2000 r/min */
                uint32_t vl_velocity_acceleration_delta_speed = uint32_t{}; /*!< The configured delta speed of the slope of the acceleration ramp. The values shall be given in rotations per minute (r/min) or in user-defined velocity units. Default : 500 r/min. */
                uint16_t vl_velocity_acceleration_delta_time  = uint16_t{}; /*!< The configured delta time of the slope of the acceleration ramp. The values shall be given in second or in user-defined time units. Default : 1s. */
                uint32_t vl_velocity_deceleration_delta_speed = uint32_t{}; /*!< The configured delta speed of the slope of the deceleration ramp. The values shall be given in rotations per minute (r/min) or in user-defined velocity units. Default : 500 r/min. */
                uint16_t vl_velocity_deceleration_delta_time  = uint16_t{}; /*!< The configured delta time of the slope of the deceleration ramp. The values shall be given in second or in user-defined time units. Default : 1s. */
                uint32_t vl_velocity_quick_stop_delta_speed   = uint32_t{}; /*!< The configured delta speed of the slope of the deceleration ramp for quick stop. The values shall be given in rotations per minute (r/min) or in user-defined velocity units. Default : 1000 r/min. */
                uint16_t vl_velocity_quick_stop_delta_time    = uint16_t{}; /*!< The configured delta time of the slope of the deceleration ramp for quick stop. The values shall be given in second or in user-defined time units. Default : 1s. */
                int16_t  vl_set_point_factor_numerator        = int16_t{};  /*!< The configured numerator of the velocity set-point factor. Default : 1 */
                int16_t  vl_set_point_factor_denominator      = int16_t{};  /*!< The configured denominator of the velocity set-point factor. Default : 1 */
                int32_t  vl_dimension_factor_numerator        = int32_t{};  /*!< The configured numerator of the velocity dimension factor. Default : 1 */
                int32_t  vl_dimension_factor_denominator      = int32_t{};  /*!< The configured denominator of the velocity dimension factor. Default : 1 */
            };

            /** [CIA402-2] Velocity mode statusword.
             *  The velocity mode use some bits of the CIA402 statusword to report some status. */
            struct VelocityModeStatusword {
                bool internal_limit_active = bool{}; /*!< If True, the velocity demand value is limited to vl_velocity_max_amount / vl_velocity_min_amount. */
            };

            /** [CIA402-2] Velocity mode controlword.
             *  The velocity mode use some bits of the CIA402 controlword to control the velocity control function. */
            struct VelocityModeControlword {
                bool enable_ramp    = bool{}; /*!< If False, the velocity demand value shall be controlled in any other (manufacturer-specific) way, for example by a test function generator or manufacturer-specific halt function; else, the velocity demand value shall accord with ramp output value. */
                bool unlock_ramp    = bool{}; /*!< If False, the ramp output value shall be locked to current output value; else the ramp output value shall follow ramp input value. */
                bool reference_ramp = bool{}; /*!< If False, the ramp input value shall be set to zero; else the ramp input value shall accord with ramp reference. */
                bool halt           = bool{}; /*!< If True, the motor shall be stopped. */
            };

            /**
             * @brief Indicate the required velocity of the system. It will be multiplied by the vl dimension factor and the vl set-point factor.
             *  The value shall be given in user-defined velocity units or in revolutions per minute (r/min), if the vl dimension factor and the vl set-point factor are not implemented or have the value 1.
             *  Positive values shall indicate forward direction and negative values shall indicate reverse direction.
             *
             * @param pTargetVelocity The required velocity (range : -2000 to 2000 r/min).
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setTargetVelocity(const int16_t &pTargetVelocity) = 0;

            /**
             * @brief Retrieve the actual required velocity of the system.
             *
             * @param pTargetVelocity The actual required velocity of the system.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getTargetVelocity(int16_t &pTargetVelocity) const = 0;

            /**
             * @brief Retrieve the actual velocity of the system. The value shall be given in the very same unit as the vl target velocity.
             *      Positive values shall indicate forward direction and negative values shall indicate reverse direction.
             *
             * @param pVelocityActualValue The actual velocity of the system.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityActualValue(int32_t &pVelocityActualValue) const = 0;

            /**
             * @brief Retrieve the actual velocity of the system. The value shall be given in the very same unit as the vl target velocity.
             *      Positive values shall indicate forward direction and negative values shall indicate reverse direction.
             *
             * @param pVelocityActualValue The actual velocity of the system.
             * @param pTimestamp The timestamp in ms from 1970.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityActualValueTS(int32_t &pVelocityActualValue, uint64_t &pTimestamp) const = 0;

            /**
             * @brief Retrieve the instantaneous velocity generated by the ramp function. The value shall be given in the very same unit as the vl target velocity.
             *      Positive values shall indicate forward direction and negative values shall indicate reverse direction.
             *      NOTA : The velocity demand depends of the velocity polarity parameter.
             *
             * @param pVelocityDemand The instantaneous velocity generated by the ramp function.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityDemand(int16_t &pVelocityDemand) const = 0;

            /**
             * @brief Retrieve the position of the SWD product in motor revolution increments. The SWD product resolution is 30 increments par revolution.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *
             * @param pPositionValue The position of the SWD product in motor revolution increments.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getPositionValue(int32_t &pPositionValue) const = 0;

            /**
             * @brief Retrieve the position of the SWD product in motor revolution increments. The SWD product resolution is 30 increments par revolution.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *
             * @param pPositionValue The position of the SWD product in motor revolution increments.
             * @param pTimestamp The timestamp in ms from 1970.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getPositionValueTS(int32_t &pPositionValue, uint64_t &pTimestamp) const = 0;

            /**
             * @brief Retrieve the velocity mode parameters.
             *
             * @param pParams The velocity mode parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityModeParameters(VelocityModeParameters &pParams) const = 0;

            /**
             * @brief Modify the velocity mode parameters.
             *
             * @param pParams The new velocity mode parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setVelocityModeParameters(const VelocityModeParameters &pParams) = 0;

            /**
             * @brief Retrieve the velocity mode statusword.
             *
             * @param pParams The velocity mode statusword.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityModeStatusword(VelocityModeStatusword &pParams) const = 0;

            /**
             * @brief Retrieve the velocity mode controlword.
             *
             * @param pParams The velocity mode controlword.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityModeControlword(VelocityModeControlword &pParams) const = 0;

            /**
             * @brief Modify the enable ramp flag into the velocity mode controlword.
             *
             * @param pEnableRamp If False, the velocity demand value shall be controlled in any other (manufacturer-specific) way, for example by a test function generator or manufacturer-specific halt function; else, the velocity demand value shall accord with ramp output value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setEnableRamp(const bool &pEnableRamp) = 0;

            /**
             * @brief Modify the unlock ramp flag into the velocity mode controlword.
             *
             * @param pUnlockRamp If False, the ramp output value shall be locked to current output value; else the ramp output value shall follow ramp input value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setUnlockRamp(const bool &pUnlockRamp) = 0;

            /**
             * @brief Modify the reference ramp flag into the velocity mode controlword.
             *
             * @param pReferenceRamp If False, the ramp input value shall be set to zero; else the ramp input value shall accord with ramp reference.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setReferenceRamp(const bool &pReferenceRamp) = 0;

            /**
             * @brief Modify the halt flag into the velocity mode controlword.
             *
             * @param pHalt If True, the motor shall be stopped.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setHalt(const bool &pHalt) = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_IVELOCITYMODESERVICE_HPP */
