/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file ISRDOService.hpp
 */

#ifndef EZW_SMCCORE_ISRDOSERVICE_HPP
#define EZW_SMCCORE_ISRDOSERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief CIA304 : SRDO (Safety Related Data Object).
         * This is similar to a PDO, but additional properties are defined. These are:
         * - cyclic data transmission with timeout monitoring
         * - Double transmission of usage data, one of which is inverted bit by bit
         * - Check the data consistency
         * - Check the time interval between the inverted and non-inverted data
         * - Backup of the configuration through a CRC.
         *
         * NOTA : To make an entire SRDO configuration valid, a flag must be set to Index 0x13FE in
         * the object dictionary. This flag is automatically set to an invalid configuration for every
         * write access that is done to a safety-related SRDO parameter. After completing the
         * configuration, this flag must be set to a valid configuration.
         */
        class ISRDOService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~ISRDOService() = default;

            /** Indicates the SRDO Id. NOTA : id 3 to 8 doesn't exist. */
            enum class SRDOId
            {
                SRDO_1  = 1,  /**< Id of the SRDO 1. */
                SRDO_2  = 2,  /**< Id of the SRDO 2. */
                SRDO_9  = 9,  /**< Id of the SRDO 9. */
                SRDO_10 = 10, /**< Id of the SRDO 10. */
                SRDO_11 = 11, /**< Id of the SRDO 11. */
                SRDO_12 = 12, /**< Id of the SRDO 12. */
                SRDO_13 = 13, /**< Id of the SRDO 13. */
                SRDO_14 = 14, /**< Id of the SRDO 14. */
                SRDO_15 = 15, /**< Id of the SRDO 15. */
                SRDO_16 = 16, /**< Id of the SRDO 16. */
            };

            /** Indicates the direction of a SRDO. */
            enum class SRDODirection
            {
                SRDO_TX = 1, /**< The SRDO is switched on as send-SRDO (TSRDO). */
                SRDO_RX = 2, /**< The SRDO is switched on as receiver-SRDO (RSRDO). */
            };

            /** Indicates the transmission type of a SRDO. */
            enum class SRDOTransmissionType
            {
                PDO_ASYNC_FE = 254, /**< Asynchronous: The data become valid when the PDO message is received and are taken over into the object dictionary. */
            };

            /** Indicates the communication parameters of a SRDO.
             *  NOTA : COB IDs in the range from 0x100 to 0x180 are used so that the transmission in the CANopen network does not interfere with other services and the priority of the CAN IDs is higher than that of PDOs. */
            struct SRDOParameters {
                bool                 valid             = bool{};                 /*!< Indicates the validity of the SRDO. True if exists / is valid; False if does not exist / is not valid. SRDO1 and SRDO2 are not modifiable. */
                uint16_t             sct               = uint16_t{};             /*!< Indicates the refresh time SCT (Safety Cycle Time) of the SRDO. Default : 25ms. */
                uint8_t              srvt              = uint8_t{};              /*!< Indicates the srvt (Safety-related Validation Time) time between the 2 CAN messages of an SRDO. Default : 20ms. */
                SRDOTransmissionType transmission_type = SRDOTransmissionType{}; /*!< Indicates the transmission type. Fix : PDO_ASYNC_FE. */
                uint16_t             can_id1           = uint16_t{};             /*!< Indicates the CAN identifier (11 bits) for plain data. */
                uint16_t             can_id2           = uint16_t{};             /*!< Indicates the CAN identifier (11 bits) for bitwise inverted data. */
            };

            /** Indicates the mapping parameters of a SRDO. */
            struct SRDOMapping {
                uint8_t               mapping_count = uint8_t{};               /*!< Indicates the number of mapped data in SRDO. 2 mapping entry by data object (normal and inverted). */
                std::vector<uint32_t> data          = std::vector<uint32_t>{}; /*!< Indicates the mapped data in SRDO. */
            };

            /**
             * @brief Retrieve the communication parameters of the specified SRDO id.
             *
             * @param pId The SRDO id.
             * @param pDirection The direction of the SRDO.
             * @param pParameters The communication parameters of the SRDO.
             * @param pSignature The signature of the SRDO.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSRDOParameters(const SRDOId &pId, SRDODirection &pDirection, SRDOParameters &pParameters, uint16_t &pSignature) const = 0;

            /**
             * @brief Modify the communication parameters of the specified SRDO id.
             *
             * @param pId The SRDO id.
             * @param pParameters The new communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSRDOParameters(const SRDOId &pId, const SRDOParameters &pParameters) = 0;

            /**
             * @brief Retrieve the mapping parameters of the specified SRDO id.
             *
             * @param pId The SRDO id.
             * @param pMapping The configured mapping parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSRDOMapping(const SRDOId &pId, SRDOMapping &pMapping) const = 0;

            /**
             * @brief Retrieve the SRDO configuration valid flag (0x13fe => 0xA5 the configuration is valid; other values the configuration is invalid).
             *
             * @param pIsvalid The SRDO configuration valid flag.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSRDOConfigurationValidity(bool &pIsvalid) const = 0;

            /**
             * @brief Modify the SRDO configuration valid flag (0x13fe => 0xA5 the configuration is valid; other values the configuration is invalid).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSRDOConfigurationValidity() = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_ISRDOSERVICE_HPP */
