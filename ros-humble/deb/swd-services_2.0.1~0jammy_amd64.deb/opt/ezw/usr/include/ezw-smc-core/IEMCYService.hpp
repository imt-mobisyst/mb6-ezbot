/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file IEMCYService.hpp
 */

#ifndef EZW_SMCCORE_IEMCYSERVICE_HPP
#define EZW_SMCCORE_IEMCYSERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief Emergency ( EMCY ) functionalities
         */
        class IEMCYService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~IEMCYService() = default;

            /** Indicates the behavior in case of an error.
             *  NOTA :
             *      - Each ErrorType have an ErrorBehavior.
             *      - ErrorBehavior will affect the NMT state machine. */
            enum class ErrorBehavior
            {
                NMT_PREOP     = 0, /**< Change NMT to PreOperational ( Only if NMT was in Operational ). */
                NMT_NO_CHANGE = 1, /**< No change to NMT. */
                NMT_STOP      = 2, /**< NMT state change to Stopped state. */
            };

            /** There are 3 different Emergency ErrorType.
             *      In case of an error, NMT state shall be affected in accordance
             *      with ErrorBehavior parameter.
             *  NOTA :
             *      - COMMUNICATION ErrorBehavior shall be read-only */
            enum class ErrorType
            {
                COMMUNICATION = 1, /**< Communication error, handled by stack. */
                EMCY_ERROR    = 2, /**< EMCY Message that are flaged ERROR. */
                EMCY_WARNING  = 3, /**< EMCY Message that are flaged WARNING. */
            };

            /** Emergency error codes used. */
            enum class EMCY_ERROR_CODE
            {
                GENERIC_ERROR                     = 4096,  /**< Definition for error code generic error */
                ERROR_RESET                       = 0,     /**< Definition for error code reset error */
                DC_OVER_CURRENT_1                 = 8737,  /**< Definition for error code over current type 1 = warning */
                DC_OVER_CURRENT_2                 = 8738,  /**< Definition for error code over current type 2 = error */
                BMS_OC                            = 8753,  /**< Definition for error code over current BMS */
                OVER_VOLTAGE_1                    = 12817, /**< Definition for error code over voltage type 1 = error */
                OVER_VOLTAGE_2                    = 12818, /**< Definition for error code over current type 2 = warning */
                UNDER_VOLTAGE_1                   = 12833, /**< Definition for error code under voltage type 1 = error */
                UNDER_VOLTAGE_2                   = 12834, /**< Definition for error code under voltage type 2 = warning */
                BMS_UV                            = 12849, /**< Definition for error code under voltage BMS */
                BMS_OV                            = 12850, /**< Definition for error code over voltage BMS */
                BMS_UV_CHA                        = 12851, /**< Definition for error code under voltage BMS during CHA */
                TEMPERATURE                       = 16384, /**< Definition for error code temperature */
                EXCESS_TEMPERATURE_DEVICE         = 16912, /**< Definition for error code temperature in device */
                OVER_TEMPERATURE_BMS              = 16928, /**< Definition for error code OT in pack */
                UNDER_TEMPERATURE_BMS             = 16929, /**< Definition for error code UT in pack */
                EXCESS_TEMPERATURE_DRIVE          = 17168, /**< Definition for error code temperature in device driver */
                BMS_PACK_TEMP_SENSOR              = 20496, /**< Definition for error code BMS pack temp sensor */
                CANOPEN_DEVICE_SOFT               = 24576, /**< Definition for error code device soft */
                CANOPEN_PARAMETER_ERROR           = 24608, /**< Definition for error code canopen parameter */
                BMS_INTERNAL_ERROR                = 24848, /**< Definition for error code BMS internal error */
                POWER_ADDITIONAL_MODULES          = 28928, /**< Definition for error code powering additional modules */
                MOTOR_BLOCKED                     = 28961, /**< Definition for error code motor blocked */
                OSSD_STO_1                        = 32769, /**< Definition for error code OSSD input STO signal 1 */
                OSSD_STO_2                        = 32770, /**< Definition for error code OSSD input STO signal 2 */
                SAFE_IN_1                         = 32771, /**< Definition for error code safe input signal 1 */
                SAFE_IN_2                         = 32772, /**< Definition for error code safe input signal 2 */
                SAFE_OUT_1                        = 32773, /**< Definition for error code safe output signal 1 */
                SAFE_OUT_2                        = 32774, /**< Definition for error code safe output signal 2 */
                HALL_INCONSISTENCY                = 32775, /**< Definition for error code hall effect sensor inconsistency */
                DRVOFF_COHERENCY                  = 32776, /**< Definition for error code driver off inconsistency */
                STO_COHERENCY                     = 32777, /**< Definition for error code STO inconsistency */
                NBRAKE                            = 32778, /**< Definition for error code nbrake */
                NBRAKE_CTRL                       = 32779, /**< Definition for error code nbrake control */
                ENDRV                             = 32780, /**< Definition for error code endrv state */
                FAULT_ALIM_EXT                    = 32781, /**< Definition for error code fault alim ext */
                EMERGENCY                         = 32782, /**< Definition for error code nsto state */
                BRAKE_PRESENCE                    = 32784, /**< Definition for error code external brake presence */
                BRAKE_OC                          = 32785, /**< Definition for error code brake oc */
                SBU_SET                           = 32786, /**< Definition for error code sbu activated */
                SBU_ACTIVATION_ERROR              = 32787, /**< Definition for error code sbu wrong activation */
                NCCSTATE                          = 32788, /**< Definition for error code N_CC_STATE consistency diag error (SM23) */
                MCU_NBRAKE                        = 32789, /**< Definition for error code MCU_NBRAKE diag */
                BLC                               = 32790, /**< Definition for error code BRAKE_LOCK_CHECK diag */
                EXT_BRAKE_CMD                     = 32791, /**< Definition for error code external brake command error */
                NBRAKE_INT                        = 32792, /**< Definition for error code NBRAKE check in interrupt */
                DRIVER_GENERIC                    = 32848, /**< Definition for error code driver generic */
                CAN_ERROR_PASSIVE                 = 33056, /**< Definition for error code can error passive */
                CAN_RECOVER_BUS_OFF               = 33088, /**< Definition for error code can bus off */
                PROTOCOL_ERROR_SRDO_SCT_TIMEOUT   = 33281, /**< Definition for error code timeout receiving fresh data */
                PROTOCOL_ERROR_SRDO_SRVT_TIMEOUT  = 33282, /**< Definition for error code timeout receiving inverted data */
                PROTOCOL_ERROR_SRDO_DATA_MISMATCH = 33283, /**< Definition for error code mismatching data and inverted data */
                PROTOCOL_ERROR_SRDO_WRONG_MSG     = 33284, /**< Definition for error code srdo wrong message */
                PROTOCOL_ERROR_SRDO_WRONG_LEN     = 33285, /**< Definition for error code srdo wrong len */
                PROTOCOL_ERROR_EVENT_TIMER        = 33286, /**< Definition for error code event timer timeout */
            };

            /**
             * @brief Retrieve the ErrorBehavior of selected ErrorType.
             *
             * @param pErrorType Selected ErrorType.
             * @param pErrorBehavior ErrorBehavior of selected ErrorType.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getErrorBehavior(const ErrorType &pErrorType, ErrorBehavior &pErrorBehavior) const = 0;

            /**
             * @brief Set the ErrorBehavior of selected ErrorType.
             *
             * @param pErrorType Selected ErrorType.
             * @param pErrorBehavior ErrorBehavior of selected ErrorType.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setErrorBehavior(const ErrorType &pErrorType, const ErrorBehavior &pErrorBehavior) = 0;

            /**
             * @brief Clear all previous error stored in the pre-defined error array.
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t clearErrorList() = 0;

            /**
             * @brief Return the number of error present in the pre-defined error array.
             *
             * @param pErrorCount Number of errors.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getErrorCount(int32_t &pErrorCount) const = 0;

            /**
             * @brief Return error register.
             *      Error Register is made of 8 bits indicating the type of error that happend:
             *      - [0] Generic
             *      - [1] Current
             *      - [2] Voltage
             *      - [3] Temperature
             *      - [4] Communication
             *      - [5] Device profile specific
             *      - [6] 0 (Reserved)
             *      - [7] Manufacturer
             *
             * @param pErrorRegister 8 bits error register.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getErrorRegister(uint8_t &pErrorRegister) const = 0;

            /**
             * @brief Return EMCY_ERROR_CODE (as UInt32) at index in the pre-defined error array.
             *
             * @param pIndex Selected index.
             * @param pEmcyErrorCode cf EMCY_ERROR_CODE.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getError(const int32_t &pIndex, uint32_t &pEmcyErrorCode) const = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_IEMCYSERVICE_HPP */
