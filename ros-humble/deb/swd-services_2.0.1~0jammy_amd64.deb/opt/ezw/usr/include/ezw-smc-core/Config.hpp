/**
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file Config.hpp
 */
#ifndef EZW_SMCCORE_CONFIG_HPP
#define EZW_SMCCORE_CONFIG_HPP

#include "ezw_types.h"

#include "ezw-tools/HardwareHelper.hpp"
#include "ezw-tools/INIParser.hpp"

#include "ezw_log.h"

#include <iostream>

#include <sstream>
#include <stdexcept>

#include <fstream>
#include <map>
#include <string>

namespace ezw
{
    namespace smccore
    {
        class Config {
            static constexpr const char *mClassName = "Config";

          public:
            Config() : mContextId(CON_APP), mNodeId(0), mCoreNodeId(0), mCoreNodeIsMaster(true), mCanDevice(""), mDbusNamespace(""), mHWConfigurationEntry(""), mNbStepRevolutionElec(0U), mNbPolePair(0U), mReduction(0.), mDiameter(0.), mAccuratePositionResolution(0)
            {
            }

            ezw_error_t load(const std::string &pFilename)
            {
                ezw_error_t lError = ERROR_INTERNAL;

                std::ifstream lFile;

                lFile.open(pFilename, std::ifstream::in);
                if (!lFile.is_open()) {
                    EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Can't open config file : " + pFilename).c_str()));
                    return lError;
                }

                EZW_LOG(mContextId, EZW_LOG_INFO, EZW_STR(mClassName), EZW_STR(std::string("Parsing config file : " + pFilename).c_str()));

                if (!ezw::tools::INIParser::instance()->parse(lFile)) {
                    EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Error during parsing of config file : " + pFilename).c_str()));
                    return lError;
                }

                if (!ezw::tools::INIParser::instance()->getInteger("contextId", mContextId)) {
                    EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Invalid type for contextId").c_str()));
                    return lError;
                }

                if (!ezw::tools::INIParser::instance()->getInteger("nodeId", mNodeId)) {
                    EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Invalid type for nodeId").c_str()));
                    return lError;
                }

                if (!ezw::tools::INIParser::instance()->getInteger("coreNodeId", mCoreNodeId)) {
                    EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Invalid type for coreNodeId").c_str()));
                    return lError;
                }

                if (!ezw::tools::INIParser::instance()->getBoolean("coreNodeIsMaster", mCoreNodeIsMaster)) {
                    EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Invalid type for coreNodeIsMaster").c_str()));
                    return lError;
                }

                if (!ezw::tools::INIParser::instance()->getString("canDevice", mCanDevice)) {
                    EZW_LOG(mContextId, EZW_LOG_WARN, EZW_STR(mClassName), EZW_STR(std::string("Invalid type for canDevice => can0 by default").c_str()));
                    mCanDevice = "can0";
                }

                if (!ezw::tools::INIParser::instance()->getString("dbusNamespace", mDbusNamespace)) {
                    EZW_LOG(mContextId, EZW_LOG_WARN, EZW_STR(mClassName), EZW_STR(std::string("Invalid type for dbusNamespace").c_str()));
                    return lError;
                }

                if (!ezw::tools::INIParser::instance()->getString("HWConfigurationEntry", mHWConfigurationEntry)) {
                    EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Invalid type for HWConfigurationEntry").c_str()));
                    return lError;
                }

                if (!ezw::tools::INIParser::instance()->getString("CANOpenEDSFile", mCANOpenEDSFilePath)) {
                    EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Invalid type for CANOpenEDSFile").c_str()));
                    return lError;
                }

                ezw::tools::HardwareHelper lHardwareHelper(mContextId);

                lError = lHardwareHelper.init(pFilename);
                if (lError != ERROR_NONE) {
                    return lError;
                }

                lError = lHardwareHelper.getHWConfigurationMember("nbStepRevolutionElec", mNbStepRevolutionElec);
                if (ERROR_NONE != lError) {
                    return lError;
                }

                lError = lHardwareHelper.getHWConfigurationMember("nbPolePair", mNbPolePair);
                if (ERROR_NONE != lError) {
                    return lError;
                }

                lError = lHardwareHelper.getHWConfigurationMember("reduction", mReduction);
                if (ERROR_NONE != lError) {
                    return lError;
                }

                lError = lHardwareHelper.getHWConfigurationMember("diameter", mDiameter);
                if (ERROR_NONE != lError) {
                    return lError;
                }

                mPath = pFilename;

                return ERROR_NONE;
            }

            int getContextId() const
            {
                return mContextId;
            }

            int getNodeId() const
            {
                return mNodeId;
            }

            int getCoreNodeId() const
            {
                return mCoreNodeId;
            }

            bool getCoreNodeIsMaster() const
            {
                return mCoreNodeIsMaster;
            }

            std::string getCanDevice() const
            {
                return mCanDevice;
            }

            std::string getDbusNamespace() const
            {
                return mDbusNamespace;
            }

            std::string getHWConfigurationEntry() const
            {
                return mHWConfigurationEntry;
            }

            int getNbStepRevolutionElec() const
            {
                return mNbStepRevolutionElec;
            }

            int getNbPolePair() const
            {
                return mNbPolePair;
            }

            double getReduction() const
            {
                return mReduction;
            }

            double getDiameter() const
            {
                return mDiameter;
            }

            void setAccuratePositionResolution(uint8_t pAccuratePositionResolution)
            {
                mAccuratePositionResolution = pAccuratePositionResolution;
            }

            uint8_t getAccuratePositionResolution() const
            {
                return mAccuratePositionResolution;
            }

            std::string getCANOpenEDSFilePath() const
            {
                return mCANOpenEDSFilePath;
            }

            const std::string &getPath() const
            {
                return mPath;
            }

          private:
            std::string mPath;

            int         mContextId;
            int         mNodeId;
            int         mCoreNodeId;
            bool        mCoreNodeIsMaster;
            std::string mCanDevice;
            std::string mDbusNamespace;

            std::string mHWConfigurationEntry;

            int     mNbStepRevolutionElec;
            int     mNbPolePair;
            double  mReduction;
            double  mDiameter;
            uint8_t mAccuratePositionResolution;

            std::string mCANOpenEDSFilePath;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_CONFIG_HPP */
