/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file IService.hpp
 */

#ifndef EZW_SMCCORE_ISERVICE_HPP
#define EZW_SMCCORE_ISERVICE_HPP

#include "ICANOpenService.hpp"
#include "ICommunicationService.hpp"
#include "ICoreService.hpp"
#include "IEMCYService.hpp"
#include "IInternalService.hpp"
#include "IManufacturerService.hpp"
#include "INMTService.hpp"
#include "IPDSService.hpp"
#include "ISRDOService.hpp"
#include "ISafeMotionService.hpp"
#include "IVelocityModeService.hpp"

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        class IService : public ICoreService, public IInternalService, public INMTService, public IEMCYService, public IPDSService, public ISafeMotionService, public ICommunicationService, public IManufacturerService, public IVelocityModeService, public ISRDOService, public ICANOpenService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~IService() = default;

            /** Indicates the error type. */
            enum class ErrorEnum
            {
                ERROR_NOT_INITIALIZED = 0, /**< Not initialized error. */
                ERROR_NONE            = 1, /**< No error occurred. */
                ERROR_HARDWARE        = 2, /**< Hardware error. */
                ERROR_CONFIG          = 3, /**< Configuration error. */
                ERROR_ARGUMENT        = 4, /**< Argument error. */
                ERROR_INTERNAL        = 5, /**< Internal error. */
                ERROR_EXTERNAL        = 6, /**< External error. */
            };
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_ISERVICE_HPP */
