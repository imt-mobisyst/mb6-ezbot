/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file ICoreService.hpp
 */

#ifndef EZW_SMCCORE_ICORESERVICE_HPP
#define EZW_SMCCORE_ICORESERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief SWD product services.
         */
        class ICoreService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~ICoreService() = default;

            /** Indicates the canopen object dictionary mode type. */
            enum class ModeEnum
            {
                REMOTE = 0, /**< The canopen object dictionary is synchronize with the device. (default) */
                LOCAL  = 1, /**< The canopen object dictionary is local. Load/SaveSettingsFromDevice shall be used to synchronize it with the device. */
            };

            /**
             * @brief Connect to the canopen device with the node id specifed.
             *
             * @param pNodeId The node id of the device : from 1 to 127.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t connect(const uint8_t &pNodeId) = 0;

            /**
             * @brief Disconnect from the canopen device.
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t disconnect() = 0;

            /**
             * @brief Retrieve the core status connection.
             *
             * @param pIsConnected The connection status.
             * @param pIsPdoInitSucceeded The PDO status.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getConnectionStatus(bool &pIsConnected, bool &pIsPdoInitSucceeded) = 0;

            /**
             * @brief Get the connected node id.
             *
             * @param pNodeId The node id of the connected device : from 1 to 127.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getConnectedNodeId(uint8_t &pNodeId) = 0;

            /**
             * @brief Get the CAN device.
             *
             * @param pCanDevice The CAN device. (ie "can0")
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getCanDevice(std::string &pCanDevice) = 0;

            /**
             * @brief Retrieve the SWD core services version. Ex : 0.2.8
             *
             * @param pCoreVersion The core version.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getCoreVersion(std::string &pCoreVersion) = 0;

            /**
             * @brief Switch into the specified canopen object dictionary mode.
             *
             * @param pMode The new mode.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t switchMode(const ModeEnum &pMode) = 0;

            /**
             * @brief Load settings from DCF file.
             *
             * @param pDcfFile Indicates the DCF file.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t loadSettingsFromDCF(const std::string &pDcfFile) = 0;

            /**
             * @brief Save settings to DCF file.
             *
             * @param pDcfFile Indicates the DCF file.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t saveSettingsToDCF(const std::string &pDcfFile) = 0;

            /**
             * @brief Load settings from the device.
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t loadSettingsFromDevice() = 0;

            /**
             * @brief Save settings to the device.
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t saveSettingsToDevice() = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_ICORESERVICE_HPP */
