/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file INMTService.hpp
 */

#ifndef EZW_SMCCORE_INMTSERVICE_HPP
#define EZW_SMCCORE_INMTSERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief [CIA301] Network management (NMT).
         */
        class INMTService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~INMTService() = default;

            /** Indicates the NMT state of the SWD product.
             *  NOTA :
             *  - CANopen devices enter the NMT state Pre-operational directly after finishing the CANopen devices initialization.
             *  - During this NMT state CANopen device parameterization and CAN-ID-allocation via SDO (e.g. using a configuration tool) is possible.
             *    Then the CANopen devices may be switched directly into the NMT state Operational.
             *  - The NMT state machine determines the behavior of the communication function unit.
             *  NOTA :
             *  - In the NMT state Pre-operational, communication via SDOs is possible. PDOs do not exist, so PDO/SRDO communication are not allowed.
             *  - In the NMT state Operational, all communication objects are active.
             *  - In the NMT state Stopped, all communication objects are stopped (except node guarding and heartbeat, if active). */
            enum class NMTState
            {
                UNKNOWN = 0,   /**< The SWD product is not detected on the can bus. */
                STOPPED = 4,   /**< The SWD product is in the NMT state Stopped. */
                OPER    = 5,   /**< The SWD product is in the NMT state Operational. */
                PREOP   = 127, /**< The SWD product is in the NMT state Pre-operational. */
            };

            /** Indicates the NMT state command.
             *  NOTA : The NMT state initialisation is divided into three NMT sub-states in order to enable a complete or partial reset of the SWD product:
             *  - Initialising : This is the first NMT sub-state the CANopen device enters after power-on or hardware reset.
             *    After finishing the basic CANopen device initialisation the CANopen device enters autonomously into the NMT sub-state reset application.
             *  - Reset application : In this NMT sub-state the parameters of the manufacturer-specific profile area and of the standardized device profile area are set to their power-on values.
             *    After setting of the power-on values the NMT sub-state reset communication is entered autonomously.
             *  - Reset communication : In this NMT sub-state the parameters of the communication profile area are set to their power-on values.
             *    After this the NMT state Initialisation is finished and the CANopen device executes the NMT service boot-up write and enters the NMT state Pre-operational.
             *  NOTA : Power-on values are the last stored parameters. */
            enum class NMTCommand
            {
                OPER       = 1,   /**< Switch into the NMT state Operational. */
                STOP       = 2,   /**< Switch into the NMT state Stopped. */
                PREOP      = 128, /**< Switch into the NMT state Pre-operational. */
                RESET_NODE = 129, /**< Switch into the NMT sub-state Reset application. */
                RESET_COMM = 130, /**< Switch into the NMT sub-state Reset communication. */
            };

            /**
             * @brief Retrieve the NMT state of the SWD product.
             *
             * @param pNmtState The NMT state.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getNMTState(NMTState &pNmtState) const = 0;

            /**
             * @brief Modify the NMT state of the SWD product.
             *
             * @param pNmtCommand The new NMT state.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setNMTState(const NMTCommand &pNmtCommand) = 0;

            /**
             * @brief Broadcast the NMT state to all CANopen nodes.
             *
             * @param pNmtCommand The new NMT state.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t broadcastNMTState(const NMTCommand &pNmtCommand) = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_INMTSERVICE_HPP */
