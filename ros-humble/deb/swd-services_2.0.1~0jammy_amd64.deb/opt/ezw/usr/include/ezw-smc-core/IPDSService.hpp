/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file IPDSService.hpp
 */

#ifndef EZW_SMCCORE_IPDSSERVICE_HPP
#define EZW_SMCCORE_IPDSSERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief [CIA402-2] Controlling the Power Drive System (PDS).
         */
        class IPDSService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~IPDSService() = default;

            /** Indicates the PDS finite state automaton (FSA) state of the SWD product.
             *  The PDS FSA defines the application behavior of the PDS.
             *  The PDS FSA defines the PDS status and the possible control sequence of the PDS.
             *  The state of the PDS also determines which commands are accepted. For example, it is only possible to start a point-to-point move when the drive is in the operation enabled state.
             *  NOTA :
             *  - In the not ready to switch on state, the SWD product performs the device self-test and the self initialization and the drive function is disabled.
             *  - In the switch on disabled state, the communication is activated and the drive function is disabled.
             *  - In the ready to switch on state, the SWD product is ready to switch on and the drive function is disabled.
             *  - In the switch on state, the SWD product is ready to enter into operation enabled and the drive function is disabled.
             *  - In the operation enabled state, the drive function is enabled.
             *  - In the quick stop active state, the quick stop function is started.
             *  - In the fault reaction active state, the configured fault reaction function is executed.
             *  - In the fault state, the drive function is disabled. */
            enum class PDSState
            {
                NOT_READY_TO_SWITCH_ON = 0, /**< The PDS is in FSA state not ready to switch on. */
                SWITCH_ON_DISABLED     = 1, /**< The PDS is in FSA state switch on disabled. */
                READY_TO_SWITCH_ON     = 2, /**< The PDS is in FSA state ready to switch on. */
                SWITCHED_ON            = 3, /**< The PDS is in FSA state switch on. */
                OPERATION_ENABLED      = 4, /**< The PDS is in FSA state operation enabled. */
                QUICK_STOP_ACTIVE      = 5, /**< The PDS is in FSA state quick stop active. */
                FAULT_REACTION_ACTIVE  = 6, /**< The PDS is in FSA state fault reaction active. */
                FAULT                  = 7, /**< The PDS is in FSA state fault. */
            };

            /** Indicates the PDS supported functions. */
            struct PeripheralStatus {
                bool brake_applied            = bool{}; /*!< Brake applied, if present. */
                bool low_level_power_applied  = bool{}; /*!< Low-level power applied. */
                bool high_level_power_applied = bool{}; /*!< High-level power applied. */
                bool driver_enabled           = bool{}; /*!< Drive function enabled. */
                bool configuration_allowed    = bool{}; /*!< Configuration allowed. */
                bool communication_enabled    = bool{}; /*!< Communication enabled. */
            };

            /** Indicates what action shall be performed when one of the following events occurres:
             *  bus-off, NMT stopped state entered, reset application, and reset communication.
             *  NOTA :
             *  - Modification is not allowed in OPERATION_ENABLED, QUICK_STOP_ACTIVE and FAULT_REACTION_ACTIVE STATE.
             *  - Changes will be applied at the next transition into OPERATION_ENABLED state.
             *  - Storing is possible into the non-volatile memory (APPLICATION bloc). */
            enum class AbortConnectionOptionCode
            {
                AC_OPTION_0 = 0, /**< No action. */
                AC_OPTION_1 = 1, /**< Fault signal. */
                AC_OPTION_2 = 2, /**< Disable voltage command. */
                AC_OPTION_3 = 3, /**< Quick stop command. */
            };

            /** Indicates what action is performed when the quick stop function is executed.
             *  NOTA :
             *  - Modification is not allowed in OPERATION_ENABLED, QUICK_STOP_ACTIVE and FAULT_REACTION_ACTIVE STATE
             *  - Changes will be applied at the next transition into OPERATION_ENABLED state.
             *  - Storing is possible into the non-volatile memory (APPLICATION bloc). */
            enum class QuickStopOptionCode
            {
                QS_OPTION_1 = 1, /**< Slow down on slow down ramp and transit into switch on disabled. */
                QS_OPTION_2 = 2, /**< Slow down on quick stop ramp and transit into switch on disabled. */
                QS_OPTION_5 = 5, /**< Slow down on slow down ramp and stay in quick stop active. */
                QS_OPTION_6 = 6, /**< Slow down on quick stop ramp and stay in quick stop active. */
            };

            /** Indicates what action is performed if there is a transition from operation enabled state to ready to switch on state.
             *  The slow down ramp is the deceleration value of the used mode of operations.
             *  NOTA :
             *  - Modification is not allowed in OPERATION_ENABLED, QUICK_STOP_ACTIVE and FAULT_REACTION_ACTIVE STATE
             *  - Changes will be applied at the next transition into OPERATION_ENABLED state.
             *  - Storing is possible into the non-volatile memory (APPLICATION bloc). */
            enum class ShutdownOptionCode
            {
                SD_OPTION_0 = 0, /**< Disable drive function (switch-off the drive power stage). */
                SD_OPTION_1 = 1, /**< Slow down with slow down ramp; disable of the drive function. */
            };

            /** Indicates what action is performed if there is a transition from operation enabled state to switched on state.
             *  The slow down ramp is the deceleration value of the used mode of operations.
             *  NOTA :
             *  - Modification is not allowed in OPERATION_ENABLED, QUICK_STOP_ACTIVE and FAULT_REACTION_ACTIVE STATE
             *  - Changes will be applied at the next transition into OPERATION_ENABLED state.
             *  - Storing is possible into the non-volatile memory (APPLICATION bloc). */
            enum class DisableOperationOptionCode
            {
                DO_OPTION_0 = 0, /**< Disable drive function (switch-off the drive power stage). */
                DO_OPTION_1 = 1, /**< Slow down with slow down ramp; disable of the drive function. */
            };

            /** Indicates what action is performed when the halt function is executed.
             *  The slow down ramp is the deceleration value of the used mode of operations.
             *  NOTA :
             *  - Modification is not allowed in OPERATION_ENABLED, QUICK_STOP_ACTIVE and FAULT_REACTION_ACTIVE STATE
             *  - Changes will be applied at the next transition into OPERATION_ENABLED state.
             *  - Storing is possible into the non-volatile memory (APPLICATION bloc). */
            enum class HaltOptionCode
            {
                HA_OPTION_1 = 1, /**< Slow down on slow down ramp and stay in operation enabled. */
                HA_OPTION_2 = 2, /**< Slow down on quick stop ramp and stay in operation enabled. */
            };

            /** Indicates what action is performed when fault is detected in the PDS.
             *  The slow down ramp is the deceleration value of the used mode of operations.
             *  NOTA :
             *  - Modification is not allowed in OPERATION_ENABLED, QUICK_STOP_ACTIVE and FAULT_REACTION_ACTIVE STATE
             *  - Changes will be applied at the next transition into OPERATION_ENABLED state.
             *  - Storing is possible into the non-volatile memory (APPLICATION bloc). */
            enum class FaultReactionOptionCode
            {
                FR_OPTION_0 = 0, /**< Disable drive function, motor is free to rotate. */
                FR_OPTION_1 = 1, /**< Slow down on slow down ramp. */
                FR_OPTION_2 = 2, /**< Slow down on quick stop ramp. */
            };

            /** Indicates the operation mode when the SWD product is in the PDS FSA state operation enabled.
             *  NOTA :
             *  - The default mode is VL and the other modes are not implemented.
             *  - Storing is possible into the non-volatile memory (APPLICATION bloc). */
            enum class OperationMode
            {
                NO_MODE    = 0,  /**< No mode change/no mode assigned. */
                PP_MODE    = 1,  /**< Profile Position mode. */
                VL_MODE    = 2,  /**< Velocity mode. */
                PV_MODE    = 3,  /**< Profile Velocity mode. */
                TQ_MODE    = 4,  /**< Torque profile mode. */
                R_MODE     = 5,  /**< Reserved. */
                HM_MODE    = 6,  /**< Homing mode. */
                IP_MODE    = 7,  /**< Interpolated position mode. */
                CSP_MODE   = 8,  /**< Cyclic Sync Position mode. */
                CSV_MODE   = 9,  /**< Cyclic Sync Velocity mode. */
                CST_MODE   = 10, /**< Cyclic Sync Torque mode. */
                CSTCA_MODE = 11, /**< Cyclic Sync Torque mode with Commutation Angle. */
            };

            /** [CIA402-4] Indicates the configured SI units. */
            struct UnitParameters {
                uint32_t time_unit         = uint32_t{}; /*!< Indicates the configured SI unit used for time parameters. */
                uint32_t position_unit     = uint32_t{}; /*!< Indicates the configured SI unit used for position parameters. (not used). */
                uint32_t velocity_unit     = uint32_t{}; /*!< Indicates the configured SI unit used for velocity parameters. */
                uint32_t acceleration_unit = uint32_t{}; /*!< Indicates the configured SI unit used for acceleration and deceleration parameters. */
            };

            /** Indicates the polarity factors used by the SWD product.
             *      NOTA : The polarity factors have no impact on the following safety functions : SDIp and SDIn. */
            struct PolarityParameters {
                bool velocity_polarity = bool{}; /*!< Indicates if the velocity demand value shall be multiplied by 1 of by –1. (False = multiply by 1 and True = multiply by –1). */
                bool position_polarity = bool{}; /*!< Indicates if the motor revolution increments shall be multiplied by 1 of by –1. (False = multiply by 1 and True = multiply by –1). */
            };

            /**
             * @brief Retrieve the actual supported functions according to the PDS FSA state.
             *
             * @param pPeripheralStatus The supported functions.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getPeripheralStatus(PeripheralStatus &pPeripheralStatus) const = 0;

            /**
             * @brief Retrieve the PDS FSA state contains into the CIA402 statusword object (6041h).
             *
             * @param pPdsState The PDS FSA state.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getPDSState(PDSState &pPdsState) const = 0;

            /**
             * @brief Send disable voltage command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t disableVoltage() const = 0;

            /**
             * @brief Send shutdown command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t shutdown() const = 0;

            /**
             * @brief Send quick stop command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t quickStop() const = 0;

            /**
             * @brief Send switch on command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t switchOn() const = 0;

            /**
             * @brief Send enable operation command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t enableOperation() const = 0;

            /**
             * @brief Send disable operation command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t disableOperation() const = 0;

            /**
             * @brief Send fault reset command into CIA402 controlword object (6040h).
             *
             * @param pStatus True to set the fault reset bit else False to clear it.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t faultReset(const bool &pStatus) const = 0;

            /**
             * @brief Send all the commands needed to enter into FSA operation enabled state.
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t enterInOperationEnabledState() = 0;

            /**
             * @brief Retrieve the abort connection option code.
             *
             * @param pCode The abort connection option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getAbortConnectionOptionCode(AbortConnectionOptionCode &pCode) const = 0;

            /**
             * @brief Modify the abort connection option code.
             *
             * @param pCode The abort connection option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setAbortConnectionOptionCode(const AbortConnectionOptionCode &pCode) const = 0;

            /**
             * @brief Retrieve the quick stop option code.
             *
             * @param pCode The quick stop option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getQuickStopOptionCode(QuickStopOptionCode &pCode) const = 0;

            /**
             * @brief Modify the quick stop option code.
             *
             * @param pCode The quick stop option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setQuickStopOptionCode(const QuickStopOptionCode &pCode) const = 0;

            /**
             * @brief Retrieve the shutdown option code.
             *
             * @param pCode The shutdown option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getShutdownOptionCode(ShutdownOptionCode &pCode) const = 0;

            /**
             * @brief Modify the shutdown option code.
             *
             * @param pCode The shutdown option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setShutdownOptionCode(const ShutdownOptionCode &pCode) const = 0;

            /**
             * @brief Retrieve the disable operation option code.
             *
             * @param pCode The disable operation option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getDisableOperationOptionCode(DisableOperationOptionCode &pCode) const = 0;

            /**
             * @brief Modify the disable operation option code.
             *
             * @param pCode The disable operation option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setDisableOperationOptionCode(const DisableOperationOptionCode &pCode) const = 0;

            /**
             * @brief Retrieve the halt option code.
             *
             * @param pCode The halt option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getHaltOptionCode(HaltOptionCode &pCode) const = 0;

            /**
             * @brief Modify the halt option code.
             *
             * @param pCode The halt option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setHaltOptionCode(const HaltOptionCode &pCode) const = 0;

            /**
             * @brief Retrieve the fault reaction option code.
             *
             * @param pCode The fault reaction option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getFaultReactionOptionCode(FaultReactionOptionCode &pCode) const = 0;

            /**
             * @brief Modify the fault reaction option code.
             *
             * @param pCode The fault reaction option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setFaultReactionOptionCode(const FaultReactionOptionCode &pCode) const = 0;

            /**
             * @brief Retrieve the operation mode.
             *
             * @param pRequested The requested operation mode.
             * @param pActual The actual operation mode.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getOperationModes(OperationMode &pRequested, OperationMode &pActual) const = 0;

            /**
             * @brief Retrieve the supported state of the specified drive mode.
             *
             * @param pMode The drive mode.
             * @param pSupported True if the specified drive mode is supported.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t isDriveModeSupported(const OperationMode &pMode, bool &pSupported) const = 0;

            /**
             * @brief Retrieve the unit parameters.
             *
             * @param pParams The unit parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getUnitParameters(UnitParameters &pParams) const = 0;

            /**
             * @brief Modify the unit parameters.
             *
             * @param pParams The unit parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setUnitParameters(const UnitParameters &pParams) = 0;

            /**
             * @brief Retrieve the polarity factors parameters used by the SWD product.
             *
             * @param pParams The configured polarity parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getPolarityParameters(PolarityParameters &pParams) const = 0;

            /**
             * @brief Modify the polarity factors parameters used by the SWD product.
             *
             * @param pParams The new polarity parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setPolarityParameters(const PolarityParameters &pParams) = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_IPDSSERVICE_HPP */
