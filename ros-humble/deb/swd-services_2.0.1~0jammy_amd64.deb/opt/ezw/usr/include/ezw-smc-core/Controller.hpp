/**
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file Controller.hpp
 */

#ifndef EZW_SMCCORE_CONTROLLER_HPP
#define EZW_SMCCORE_CONTROLLER_HPP

/* Includes -------------------------------------------- */
#include "IService.hpp"

#include "ezw_log.h"
#include "ezw_types.h"

#include "ezw-tools/TimerThread.hpp"

#include <iostream>
#include <memory>
#include <string>
#include <thread>

/* Defines --------------------------------------------- */

/* Variable declaration -------------------------------- */

/* Class ----------------------------------------------- */
namespace ezw
{
    namespace tools
    {
        class EDSParser;
    }
    namespace smccore
    {
        class Config;
        class ICANOpenDispatcher;

        class Controller : public IService {
            static constexpr const char *mClassName = "Controller";
            static const int             UNDEFINED_VALUE;

          public:
            Controller();

            ~Controller() override;

            virtual ezw_error_t init(std::shared_ptr<Config> pConfig, std::shared_ptr<ICANOpenDispatcher> pCANOpenDispatcher);

            std::shared_ptr<Config> getConfig() const;

            // ICoreService
            ezw_error_t connect(const uint8_t &pNodeId) override;
            ezw_error_t disconnect() override;
            ezw_error_t getConnectionStatus(bool &pIsConnected, bool &pIsPdoInitSucceeded) override;
            ezw_error_t getConnectedNodeId(uint8_t &pNodeId) override;
            ezw_error_t getCanDevice(std::string &pCanDevice) override;
            ezw_error_t getCoreVersion(std::string &pCoreVersion) override;
            ezw_error_t switchMode(const ICoreService::ModeEnum &pMode) override;
            ezw_error_t loadSettingsFromDCF(const std::string &pDCFFile) override;
            ezw_error_t saveSettingsToDCF(const std::string &pDCFFile) override;
            ezw_error_t loadSettingsFromDevice() override;
            ezw_error_t saveSettingsToDevice() override;

            // IInternalService
            ezw_error_t _storeParameters(const _BlocId &pBlocId) override;
            ezw_error_t _restoreDefaultParameters(const _BlocId &pBlocId) override;
            ezw_error_t _setDeviceParameters(const _DeviceParameters &pParams) override;
            ezw_error_t _getSelfTestStatus(_SelfTestStatus &pSelfTestStatus) const override;
            ezw_error_t _simulateSelfTestError(const _SelfTestStatus &pSelfTestStatus) const override;
            ezw_error_t _getCalibrationParameters(_CalibrationParameters &pParams) const override;
            ezw_error_t _getSystemErrorConfig(_SystemErrorConfig &pConfig) const override;
            ezw_error_t _setSystemErrorConfig(const _SystemErrorConfig &pConfig) override;
            ezw_error_t _getLevel1Error(uint32_t &pLevel1Error) const override;

            // INMTService
            ezw_error_t getNMTState(NMTState &pNmtState) const override;
            ezw_error_t setNMTState(const NMTCommand &pNmtCommand) override;
            ezw_error_t broadcastNMTState(const NMTCommand &pNmtCommand) override;

            // IEMCYService
            ezw_error_t getErrorBehavior(const ErrorType &pErrorType, ErrorBehavior &pErrorBehavior) const override;
            ezw_error_t setErrorBehavior(const ErrorType &pErrorType, const ErrorBehavior &pErrorBehavior) override;
            ezw_error_t clearErrorList() override;
            ezw_error_t getErrorCount(int32_t &pErrorCount) const override;
            ezw_error_t getError(const int32_t &pIndex, uint32_t &pEmcyErrorCode) const override;
            ezw_error_t getErrorRegister(uint8_t &pErrorRegister) const override;

            // IPDSService
            ezw_error_t getPDSState(IService::PDSState &pState) const override;
            ezw_error_t disableVoltage() const override;
            ezw_error_t shutdown() const override;
            ezw_error_t quickStop() const override;
            ezw_error_t switchOn() const override;
            ezw_error_t enableOperation() const override;
            ezw_error_t disableOperation() const override;
            ezw_error_t faultReset(const bool &pStatus) const override;
            ezw_error_t getAbortConnectionOptionCode(AbortConnectionOptionCode &pCode) const override;
            ezw_error_t setAbortConnectionOptionCode(const AbortConnectionOptionCode &pCode) const override;
            ezw_error_t getQuickStopOptionCode(QuickStopOptionCode &pCode) const override;
            ezw_error_t setQuickStopOptionCode(const QuickStopOptionCode &pCode) const override;
            ezw_error_t getShutdownOptionCode(ShutdownOptionCode &pCode) const override;
            ezw_error_t setShutdownOptionCode(const ShutdownOptionCode &pCode) const override;
            ezw_error_t getDisableOperationOptionCode(DisableOperationOptionCode &pCode) const override;
            ezw_error_t setDisableOperationOptionCode(const DisableOperationOptionCode &pCode) const override;
            ezw_error_t getHaltOptionCode(HaltOptionCode &pCode) const override;
            ezw_error_t setHaltOptionCode(const HaltOptionCode &pCode) const override;
            ezw_error_t getFaultReactionOptionCode(FaultReactionOptionCode &pCode) const override;
            ezw_error_t setFaultReactionOptionCode(const FaultReactionOptionCode &pCode) const override;
            ezw_error_t getPeripheralStatus(IService::PeripheralStatus &pPeripheralStatus) const override;
            ezw_error_t enterInOperationEnabledState() override;
            ezw_error_t getOperationModes(OperationMode &pRequested, OperationMode &pActual) const override;
            ezw_error_t isDriveModeSupported(const OperationMode &pMode, bool &pSupported) const override;
            ezw_error_t getUnitParameters(UnitParameters &pParams) const override;
            ezw_error_t setUnitParameters(const UnitParameters &pParams) override;
            ezw_error_t getPolarityParameters(PolarityParameters &pParams) const override;
            ezw_error_t setPolarityParameters(const PolarityParameters &pParams) override;

            // ISafeMotionService
            ezw_error_t getSafetyControlWordMapping(const SafetyControlWordId &pSafetyControlWordId, SafetyWordMapping &pSafetyControlWordMapping) const override;
            ezw_error_t setSafetyControlWordMapping(const SafetyControlWordId &pSafetyControlWordId, const SafetyWordMapping &pSafetyControlWordMapping) override;

            ezw_error_t getSafetyStatusWordMapping(const SafetyStatusWordId &pSafetyStatusWordId, SafetyWordMapping &pSafetyStatusWordMapping) const override;
            ezw_error_t setSafetyStatusWordMapping(const SafetyStatusWordId &pSafetyStatusWordId, const SafetyWordMapping &pSafetyStatusWordMapping) override;

            ezw_error_t getSafetyFunctionCommand(const SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const override;
            ezw_error_t getSafetyFunctionStatus(const SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const override;

            ezw_error_t getSafetyControlWord(const SafetyControlWordId &pSafetyControlWordId, SafetyWordType &pSafetyControlWord) const override;
            ezw_error_t setSafetyControlWord(const SafetyControlWordId &pSafetyControlWordId, const SafetyWordType &pSafetyControlWord) override;

            ezw_error_t getSafetyStatusWord(const SafetyStatusWordId &pSafetyStatusWordId, SafetyWordType &pSafetyStatusWord) const override;

            ezw_error_t getSTOParameters(const STOId &pId, STOParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSTOParameters(const STOId &pId, const STOParameters &pParameters) override;

            ezw_error_t getSLSParameters(const SLSId &pId, SLSParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSLSParameters(const SLSId &pId, const SLSParameters &pParameters) override;

            ezw_error_t getSDIParameters(const SDIId &pId, SDIParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSDIParameters(const SDIId &pId, const SDIParameters &pParameters) override;

            ezw_error_t getSBCParameters(const SBCId &pId, SBCParameters &pParameters, uint16_t &pSignature) const override;

            ezw_error_t getSMSParameters(const SMSId &pId, SMSParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSMSParameters(const SMSId &pId, const SMSParameters &pParameters) override;

            ezw_error_t getSLSaParameters(const SLSaId &pId, SLSaParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSLSaParameters(const SLSaId &pId, const SLSaParameters &pParameters) override;

            ezw_error_t getSafetyFunctionOutput(const SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const override;
            ezw_error_t getSafetyFunctionOutputs(std::vector<SafetyFunctionOuputStatus> &pItems) const override;

            // ICommunicationService
            ezw_error_t storeParameters(const BlocId &pBlocId) override;
            ezw_error_t restoreDefaultParameters(const BlocId &pBlocId) override;
            ezw_error_t getIdentityParameters(IdentityParameters &pParams) const override;
            ezw_error_t getNetworkParameters(NetworkParameters &pParams) const override;
            ezw_error_t setNetworkParameters(const NetworkParameters &pParams) override;
            ezw_error_t getCommunicationParameters(CommunicationParameters &pParams) const override;
            ezw_error_t setCommunicationParameters(const CommunicationParameters &pParams) override;
            ezw_error_t getSDOCommunicationParameters(const SDOId &pId, SDOCommunicationParameters &pParams) const override;
            ezw_error_t setSDOCommunicationParameters(const SDOId &pId, const SDOCommunicationParameters &pParams) override;
            ezw_error_t getRPDOCommunicationParameters(const PDOId &pId, PDOCommunicationParameters &pParams) const override;
            ezw_error_t setRPDOCommunicationParameters(const PDOId &pId, const PDOCommunicationParameters &pParams) override;
            ezw_error_t getTPDOCommunicationParameters(const PDOId &pId, PDOCommunicationParameters &pParams) const override;
            ezw_error_t setTPDOCommunicationParameters(const PDOId &pId, const PDOCommunicationParameters &pParams) override;
            ezw_error_t getRPDOMappingParameters(const PDOId &pId, PDOMappingParameters &pParams) const override;
            ezw_error_t setRPDOMappingParameters(const PDOId &pId, const PDOMappingParameters &pParams) override;
            ezw_error_t getTPDOMappingParameters(const PDOId &pId, PDOMappingParameters &pParams) const override;
            ezw_error_t setTPDOMappingParameters(const PDOId &pId, const PDOMappingParameters &pParams) override;

            // IManufacturerService
            ezw_error_t getDeviceParameters(DeviceParameters &pParams) const override;
            ezw_error_t getSWDParameters(SWDParameters &pParams) const override;
            ezw_error_t setSWDParameters(const SWDParameters &pParams) override;
            ezw_error_t getSystemErrorState(SystemErrorStatus &pBatteryUv, SystemErrorStatus &pBatteryOv, SystemErrorStatus &pPhaseOc, SystemErrorStatus &pMosOt, SystemErrorStatus &pDrvOt) const override;
            ezw_error_t getSystemErrorProtectState(SystemErrorProtectState &pPrevState, SystemErrorProtectState &pCurrentState) const override;
            ezw_error_t getCalibrationValidity(bool &pIsvalid) const override;
            ezw_error_t getSWVersion(std::string &pSwVersion) const override;
            ezw_error_t getSWId(uint8_t &pSwId) const override;
            ezw_error_t getSWRef(std::string &pSoftwareRef) const override;
            ezw_error_t getHWVersion(uint32_t &pHWVersion) const override;
            ezw_error_t getHWId(uint32_t &pHwId) const override;
            ezw_error_t getProductId(uint32_t &pProductId) const override;
            ezw_error_t getProductRef(std::string &pProductRef) const override;
            ezw_error_t getOdometryValue(int32_t &pOdometryValue) const override;
            ezw_error_t getOdometryValueTS(int32_t &pOdometryValue, uint64_t &pTimestamp) const override;
            ezw_error_t getAccurateOdometryValue(int32_t &pAccurateOdometryValue) const override;
            ezw_error_t getAccurateOdometryValueTS(int32_t &AccurateOdometryValue, uint64_t &pTimestamp) const override;
            ezw_error_t getAccuratePositionValue(int32_t &pAccuratePositionValue) const override;
            ezw_error_t getAccuratePositionValueTS(int32_t &pAccuratePositionValue, uint64_t &pTimestamp) const override;
            ezw_error_t getOutputControl(const OutputSource &pOutputSource, bool &pControl) const override;
            ezw_error_t setOutputControl(const OutputSource &pOutputSource, const bool &pControl) override;
            ezw_error_t getOutputStatus(const OutputSource &pOutputSource, bool &pControl) const override;
            ezw_error_t setExternalBrakePresence(const bool &pExternalbrakepresence) override;
            ezw_error_t getExternalBrakePresence(bool &pExternalbrakepresence) const override;
            ezw_error_t getSystemErrorOutputs(std::vector<SystemErrorOutput> &pItems) const override;

            // IVelocityModeService
            ezw_error_t setTargetVelocity(const int16_t &pTargetVelocity) override;
            ezw_error_t getVelocityActualValue(int32_t &pVelocityActualValue) const override;
            ezw_error_t getVelocityActualValueTS(int32_t &pVelocityActualValue, uint64_t &pTimestamp) const override;
            ezw_error_t getTargetVelocity(int16_t &pTargetVelocity) const override;
            ezw_error_t getVelocityDemand(int16_t &pVelocityDemand) const override;
            ezw_error_t getPositionValue(int32_t &pPositionValue) const override;
            ezw_error_t getPositionValueTS(int32_t &pPositionValue, uint64_t &pTimestamp) const override;
            ezw_error_t getVelocityModeParameters(VelocityModeParameters &pParams) const override;
            ezw_error_t setVelocityModeParameters(const VelocityModeParameters &pParams) override;
            ezw_error_t getVelocityModeStatusword(VelocityModeStatusword &pParams) const override;
            ezw_error_t getVelocityModeControlword(VelocityModeControlword &pParams) const override;
            ezw_error_t setEnableRamp(const bool &pEnableRamp) override;
            ezw_error_t setUnlockRamp(const bool &pUnlockRamp) override;
            ezw_error_t setReferenceRamp(const bool &pReferenceRamp) override;
            ezw_error_t setHalt(const bool &pHalt) override;

            // ISRDOService
            ezw_error_t getSRDOParameters(const SRDOId &pId, SRDODirection &pDirection, SRDOParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSRDOParameters(const SRDOId &pId, const SRDOParameters &pParameters) override;
            ezw_error_t getSRDOMapping(const SRDOId &pId, SRDOMapping &pMapping) const override;
            ezw_error_t getSRDOConfigurationValidity(bool &pIsvalid) const override;
            ezw_error_t setSRDOConfigurationValidity() override;

            // ICANOpenService
            ezw_error_t getValueString(const uint32_t &pAddress, std::string &pData) const override;
            ezw_error_t setValueString(const uint32_t &pAddress, const std::string &pData) override;
            ezw_error_t getValueInt64(const uint32_t &pAddress, int64_t &pData) const override;
            ezw_error_t setValueInt64(const uint32_t &pAddress, const int64_t &pData) override;
            ezw_error_t getValueInt32(const uint32_t &pAddress, int32_t &pData) const override;
            ezw_error_t setValueInt32(const uint32_t &pAddress, const int32_t &pData) override;
            ezw_error_t getValueInt16(const uint32_t &pAddress, int16_t &pData) const override;
            ezw_error_t setValueInt16(const uint32_t &pAddress, const int16_t &pData) override;
            ezw_error_t getValueInt8(const uint32_t &pAddress, int8_t &pData) const override;
            ezw_error_t setValueInt8(const uint32_t &pAddress, const int8_t &pData) override;
            ezw_error_t getValueUInt64(const uint32_t &pAddress, uint64_t &pData) const override;
            ezw_error_t setValueUInt64(const uint32_t &pAddress, const uint64_t &pData) override;
            ezw_error_t getValueUInt32(const uint32_t &pAddress, uint32_t &pData) const override;
            ezw_error_t setValueUInt32(const uint32_t &pAddress, const uint32_t &pData) override;
            ezw_error_t getValueUInt16(const uint32_t &pAddress, uint16_t &pData) const override;
            ezw_error_t setValueUInt16(const uint32_t &pAddress, const uint16_t &pData) override;
            ezw_error_t getValueUInt8(const uint32_t &pAddress, uint8_t &pData) const override;
            ezw_error_t setValueUInt8(const uint32_t &pAddress, const uint8_t &pData) override;
            ezw_error_t getValueFloat(const uint32_t &pAddress, float &pData) const override;
            ezw_error_t setValueFloat(const uint32_t &pAddress, const float &pData) override;
            ezw_error_t getValueDouble(const uint32_t &pAddress, double &pData) const override;
            ezw_error_t setValueDouble(const uint32_t &pAddress, const double &pData) override;
            ezw_error_t getValueBool(const uint32_t &pAddress, bool &pData) const override;
            ezw_error_t setValueBool(const uint32_t &pAddress, const bool &pData) override;

          private:
            void run();

          private:
            std::shared_ptr<Config> mConfig;
            bool                    mIsRunning;
            bool                    mIsInitialized;

            std::shared_ptr<ICANOpenDispatcher> mCANOpenDispatcher;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_CONTROLLER_HPP */
