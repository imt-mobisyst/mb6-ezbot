/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file ISafeMotionService.hpp
 */

#ifndef EZW_SMCCORE_ISAFEMOTIONSERVICE_HPP
#define EZW_SMCCORE_ISAFEMOTIONSERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief [CIA402-4] Safety motion drive.
         * The activation of a security function can come from  :
         * - the safety inputs
         * - the CANopen safety control words
         * - a internal fault reaction
         * - the violation of a safety function
         * SCW CAN :
         * - to modify the CANopen safety control words in a safety context, it will be done with CANopen SRDO objects.
         * - each safety control word can command up to 8 safety functions (one function by bit).
         * - the association of the bit with the safety function is done into the safety control word mapping.
         * SSW CAN :
         * - each safety status words can monitor up to 8 safety functions (one function by bit).
         * - the association of the bit with the safety function is done into the safety status word mapping.
         * SWC SAFE_IN :
         * - the safety input control word can command up to 6 safety functions (one function by bit).
         * - the association of the bit with the safety function is done into the safety input control word mapping.
         * SSW SAFE_OUT :
         * - the safety output status word can monitor up to 4 safety functions (one function by bit).
         * - the association of the bit with the safety function is done into the safety output status word mapping.
         */
        class ISafeMotionService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~ISafeMotionService() = default;

            /** Indicates the safety control word id.
             *  NOTA :
             *  - Only CAN_X and PERMANENT_CAN_X safety control words are writable.
             *  - SAFEIN_1 corresponds to the safety inputs. */
            enum class SafetyControlWordId
            {
                CAN_1           = 0,  /**< Id of the CANopen safety control word CAN 1. */
                CAN_2           = 1,  /**< Id of the CANopen safety control word CAN 2. */
                CAN_3           = 2,  /**< Id of the CANopen safety control word CAN 3. */
                CAN_4           = 3,  /**< Id of the CANopen safety control word CAN 4. */
                CAN_5           = 4,  /**< Id of the CANopen safety control word CAN 5. */
                CAN_6           = 5,  /**< Id of the CANopen safety control word CAN 6. */
                CAN_7           = 6,  /**< Id of the CANopen safety control word CAN 7. */
                CAN_8           = 7,  /**< Id of the CANopen safety control word CAN 8. */
                SAFEIN_1        = 8,  /**< Id of the SafeInputs safety control word SAFEIN 1. */
                PERMANENT_CAN_1 = 9,  /**< Id of the Safety control word PERMANENT CAN 1. */
                PERMANENT_CAN_2 = 10, /**< Id of the Safety control word PERMANENT CAN 2. */
            };

            /** Indicates the safety status word id. */
            enum class SafetyStatusWordId
            {
                CAN_1           = 0,  /**< Id of the CANopen safety status word CAN 1. */
                CAN_2           = 1,  /**< Id of the CANopen safety status word CAN 2. */
                CAN_3           = 2,  /**< Id of the CANopen safety status word CAN 3. */
                CAN_4           = 3,  /**< Id of the CANopen safety status word CAN 4. */
                CAN_5           = 4,  /**< Id of the CANopen safety status word CAN 5. */
                CAN_6           = 5,  /**< Id of the CANopen safety status word CAN 6. */
                CAN_7           = 6,  /**< Id of the CANopen safety status word CAN 7. */
                CAN_8           = 7,  /**< Id of the CANopen safety status word CAN 8. */
                SAFEOUT         = 8,  /**< Id of the SafeOutputs safety status word SAFEOUT. */
                PERMANENT_CAN_1 = 9,  /**< Id of the Safety status word PERMANENT CAN 1. */
                PERMANENT_CAN_2 = 10, /**< Id of the Safety status word PERMANENT CAN 2. */
            };

            /** Id of the security function mappable into the safety control words.
             *  NOTA :
             *  - The enum shall be aligned with ezw_safety_word_fct_t enum order */
            enum class SafetyFunctionId
            {
                STO       = 0,  /**< Id of the safety security function STO (Safe Torque Off). */
                SBC_1     = 1,  /**< Id of the safety security function SBC 1 (Safe Brake Control). */
                SBC_2     = 2,  /**< Id of the safety security function SBC 2. */
                SBC_3     = 3,  /**< Id of the safety security function SBC 3. */
                SLS_1     = 4,  /**< Id of the safety security function SLS 1 (Safe Limit Speed). */
                SLS_2     = 5,  /**< Id of the safety security function SLS 2. */
                SLS_3     = 6,  /**< Id of the safety security function SLS 3. */
                SLS_4     = 7,  /**< Id of the safety security function SLS 4. */
                SLS_5     = 8,  /**< Id of the safety security function SLS 5. */
                SLS_6     = 9,  /**< Id of the safety security function SLS 6. */
                SLS_7     = 10, /**< Id of the safety security function SLS 7. */
                SLS_8     = 11, /**< Id of the safety security function SLS 8. */
                SDIP_1    = 12, /**< Id of the safety security function SDI Positive 1 (Safe Direction Indication). */
                SDIP_2    = 13, /**< Id of the safety security function SDI Positive 2. */
                SDIN_1    = 14, /**< Id of the safety security function SDI Negative 1. */
                SDIN_2    = 15, /**< Id of the safety security function SDI Negative 2. */
                ERROR_ACK = 16, /**< Id of the safety security function error acknowledge. */
                RST_ACK   = 17, /**< Id of the safety security function restart acknowledge. */
                SBU       = 18, /**< Id of the safety security function SBU (Safe Brake Unlock). */
                SMS_1     = 19, /**< Id of the safety security function SMS (Safe Maximum Speed). */
                SLSa_1    = 20, /**< Id of the safety security function SLSa 1 (Safe Limit Speed asymmetric). */
                SLSa_2    = 21, /**< Id of the safety security function SLSa 2. */
                SLSa_3    = 22, /**< Id of the safety security function SLSa 3. */
                SLSa_4    = 23, /**< Id of the safety security function SLSa 4. */
                SLSa_5    = 24, /**< Id of the safety security function SLSa 5. */
                SLSa_6    = 25, /**< Id of the safety security function SLSa 6. */
                SLSa_7    = 26, /**< Id of the safety security function SLSa 7. */
                SLSa_8    = 27, /**< Id of the safety security function SLSa 8. */
                NONE      = -1, /**< Id of the safety security function NONE. */
            };

            /** Represents a safety status/control word mapping (up to 8 functions : one function by bit). */
            struct SafetyWordMapping {
                SafetyFunctionId safety_function_0 = SafetyFunctionId{}; /*!< The safety function id mapped on the bit 0. */
                SafetyFunctionId safety_function_1 = SafetyFunctionId{}; /*!< The safety function id mapped on the bit 1. */
                SafetyFunctionId safety_function_2 = SafetyFunctionId{}; /*!< The safety function id mapped on the bit 2. */
                SafetyFunctionId safety_function_3 = SafetyFunctionId{}; /*!< The safety function id mapped on the bit 3. */
                SafetyFunctionId safety_function_4 = SafetyFunctionId{}; /*!< The safety function id mapped on the bit 4. */
                SafetyFunctionId safety_function_5 = SafetyFunctionId{}; /*!< The safety function id mapped on the bit 5. */
                SafetyFunctionId safety_function_6 = SafetyFunctionId{}; /*!< The safety function id mapped on the bit 6. */
                SafetyFunctionId safety_function_7 = SafetyFunctionId{}; /*!< The safety function id mapped on the bit 7. */
            };

            /** Represents a safety status/control word (up to 8 functions : one function by bit). */
            struct SafetyWordType {
                bool safety_function_0 = bool{}; /*!< The safety function state mapped on the bit 0. */
                bool safety_function_1 = bool{}; /*!< The safety function state mapped on the bit 1. */
                bool safety_function_2 = bool{}; /*!< The safety function state mapped on the bit 2. */
                bool safety_function_3 = bool{}; /*!< The safety function state mapped on the bit 3. */
                bool safety_function_4 = bool{}; /*!< The safety function state mapped on the bit 4. */
                bool safety_function_5 = bool{}; /*!< The safety function state mapped on the bit 5. */
                bool safety_function_6 = bool{}; /*!< The safety function state mapped on the bit 6. */
                bool safety_function_7 = bool{}; /*!< The safety function state mapped on the bit 7. */
            };

            /** Represents the STO safety application parameters. */
            struct STOParameters {
                bool     restart_acknowledge_behavior = bool{};     /*!< Indicates the configured STO restart acknowledge behavior. A value of TRUE shall Indicates that the STO restart is manual, and a value of FALSE shall Indicates that the STO restart is automatically performed. Default value : TRUE. */
                uint32_t activate_sbc                 = uint32_t{}; /*!< Indicate, which command shall be performed by means of a pointer (index and sub-index) to the command parameter e.g. 6688 0100h. A value of 0000 0000h shall Indicates that no brake shall be used. Default value : 0000 0000h. */
            };

            /** Id of the STO safety function. */
            enum class STOId
            {
                STO_1 = 1, /**< Id of the safety security function STO 1. */
            };

            /** Represents the SLS safety application parameters. */
            struct SLSParameters {
                uint16_t time_to_velocity_monitoring = uint16_t{}; /*!< Indicates the configured delay of activating the SLS function. */
                uint32_t velocity_limit_u32          = uint32_t{}; /*!< Indicates the configured speed limit. */
                uint16_t time_for_velocity_in_limits = uint16_t{}; /*!< Indicates the configured time for the velocity within the configured limits. */
                bool     sto_error_reaction          = bool{};     /*!< Indicates the configured SLS error reaction when the configured velocity or deceleration limits are exceeded.
                                                                    * - False means no reaction
                                                                    * - True means a STO reaction is required. */
            };

            /** Id of the SLS safety function. */
            enum class SLSId
            {
                SLS_1 = 1, /**< Id of the safety security function SLS 1. */
                SLS_2 = 2, /**< Id of the safety security function SLS 2. */
                SLS_3 = 3, /**< Id of the safety security function SLS 3. */
                SLS_4 = 4, /**< Id of the safety security function SLS 4. */
                SLS_5 = 5, /**< Id of the safety security function SLS 5. */
                SLS_6 = 6, /**< Id of the safety security function SLS 6. */
                SLS_7 = 7, /**< Id of the safety security function SLS 7. */
                SLS_8 = 8, /**< Id of the safety security function SLS 8. */
            };

            /** Represents the SDI safety application parameters. */
            struct SDIParameters {
                uint32_t velocity_zero_window_u32 = uint32_t{}; /*!< Indicates the configured velocity within the zero-window. */
            };

            /** Id of the SDI safety function. */
            enum class SDIId
            {
                SDI_1 = 1, /**< Id of the safety security function SDI 1. */
                SDI_2 = 2, /**< Id of the safety security function SDI 2. */
            };

            /** Represents the SBC safety application parameters. */
            struct SBCParameters {
                uint16_t brake_time_delay = uint16_t{}; /*!< Indicates the configured time to close the brake(s). */
            };

            /** Id of the SBC safety function. */
            enum class SBCId
            {
                SBC_1 = 1, /**< Id of the safety security function SBC 1. */
                SBC_2 = 2, /**< Id of the safety security function SBC 2. */
                SBC_3 = 3, /**< Id of the safety security function SBC 3. */
            };

            /** Represents the SMS safety application parameters. */
            struct SMSParameters {
                uint32_t velocity_maximum_positive_u32 = uint32_t{}; /*!< Indicates the configured maximum velocity in positive direction. Default value : 0. */
                uint32_t velocity_maximum_negative_u32 = uint32_t{}; /*!< Indicates the configured maximum velocity in negative direction. Default value : 0. */
                bool     sto_error_reaction            = bool{};     /*!< Indicates the configured SMS error reaction when the configured velocity limits are exceeded.
                                                                      * - False means no reaction
                                                                      * - True means a STO reaction is required. */
            };

            /** Id of the SMS safety function. */
            enum class SMSId
            {
                SMS_1 = 1, /**< Id of the safety security function SMS 1. */
            };

            /**  */
            struct SLSaParameters {
                uint16_t time_to_positive_velocity_monitoring = uint16_t{}; /*!< Indicates the configured delay of activating the positive SLSa function. */
                uint32_t positive_velocity_limit_u32          = uint32_t{}; /*!< Indicates the configured positive speed limit. */
                uint16_t time_for_positive_velocity_in_limits = uint16_t{}; /*!< Indicates the configured time for the positve velocity within the configured limits. */
                uint16_t time_to_negative_velocity_monitoring = uint16_t{}; /*!< Indicates the configured delay of activating the negative SLSa function. */
                uint32_t negative_velocity_limit_u32          = uint32_t{}; /*!< Indicates the configured negative speed limit. */
                uint16_t time_for_negative_velocity_in_limits = uint16_t{}; /*!< Indicates the configured time for the negative velocity within the configured limits. */
                bool     sto_error_reaction                   = bool{};     /*!< Indicates the configured SLSa error reaction when the configured velocity limits are exceeded.
                                                                             * - False means no reaction
                                                                             * - True means a STO reaction is required. */
            };

            /** Id of the SLSa safety function. */
            enum class SLSaId
            {
                SLSa_1 = 1, /**< Id of the safety security function SLSa 1. */
                SLSa_2 = 2, /**< Id of the safety security function SLSa 2. */
                SLSa_3 = 3, /**< Id of the safety security function SLSa 3. */
                SLSa_4 = 4, /**< Id of the safety security function SLSa 4. */
                SLSa_5 = 5, /**< Id of the safety security function SLSa 5. */
                SLSa_6 = 6, /**< Id of the safety security function SLSa 6. */
                SLSa_7 = 7, /**< Id of the safety security function SLSa 7. */
                SLSa_8 = 8, /**< Id of the safety security function SLSa 8. */
            };

            /** Indicates the consolidated status of a safety function. */
            struct SafetyFunctionOuputStatus {
                SafetyFunctionId safety_function_id = SafetyFunctionId{}; /*!< Id of the safety function. */
                bool             status             = bool{};             /*!< True if the consolidated safety function is enabled. */
            };

            /**
             * @brief Retrieve the safety control word mapping of the specified safety control word id.
             *
             * @param pSafetyControlWordId Id of the safety control word.
             * @param pSafetyControlWordMapping The safety control word mapping.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyControlWordMapping(const SafetyControlWordId &pSafetyControlWordId, SafetyWordMapping &pSafetyControlWordMapping) const = 0;

            /**
             * @brief Modify the safety control word mapping of the specified safety control word id.
             *
             * @param pSafetyControlWordId Id of the safety control word.
             * @param pSafetyControlWordMapping The safety control word mapping.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSafetyControlWordMapping(const SafetyControlWordId &pSafetyControlWordId, const SafetyWordMapping &pSafetyControlWordMapping) = 0;

            /**
             * @brief Retrieve the safety status word mapping of the specified safety status word id.
             *
             * @param pSafetyStatusWordId Id of the safety status word.
             * @param pSafetyStatusWordMapping The safety status word mapping.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyStatusWordMapping(const SafetyStatusWordId &pSafetyStatusWordId, SafetyWordMapping &pSafetyStatusWordMapping) const = 0;

            /**
             * @brief Modify the safety status word mapping of the specified safety status word id.
             *
             * @param pSafetyStatusWordId Id of the safety status word.
             * @param pSafetyStatusWordMapping The safety status word mapping.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSafetyStatusWordMapping(const SafetyStatusWordId &pSafetyStatusWordId, const SafetyWordMapping &pSafetyStatusWordMapping) = 0;

            /**
             * @brief Retrieve the safety function command of the specified safety function id.
             *
             * @param pSafetyFunctionId Id of the safety function.
             * @param pStatus False if the safety function command is enabled.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyFunctionCommand(const SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const = 0;

            /**
             * @brief Retrieve the safety function status of the specified safety function id.
             *
             * @param pSafetyFunctionId Id of the safety function.
             * @param pStatus True if the safety function status is enabled.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyFunctionStatus(const SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const = 0;

            /**
             * @brief Retrieve the safety control word of the specified safety control word id.
             *
             * @param pSafetyControlWordId Id of the safety control word.
             * @param pSafetyControlWord The safety control word.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyControlWord(const SafetyControlWordId &pSafetyControlWordId, SafetyWordType &pSafetyControlWord) const = 0;

            /**
             * @brief Modify the safety control word of the specified safety control word id.
             *
             * @param pSafetyControlWordId Id of the safety control word.
             * @param pSafetyControlWord The safety control word.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSafetyControlWord(const SafetyControlWordId &pSafetyControlWordId, const SafetyWordType &pSafetyControlWord) = 0;

            /**
             * @brief Retrieve the safety status word of the specified safety status word id.
             *
             * @param pSafetyStatusWordId Id of the safety status word.
             * @param pSafetyStatusWord The safety status word.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyStatusWord(const SafetyStatusWordId &pSafetyStatusWordId, SafetyWordType &pSafetyStatusWord) const = 0;

            /**
             * @brief Retrieve the STO safety application parameters of the specified STO id.
             *
             * @param pId Id of the STO.
             * @param pParameters The STO safety application parameters.
             * @param pSignature The STO safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSTOParameters(const STOId &pId, STOParameters &pParameters, uint16_t &pSignature) const = 0;

            /**
             * @brief Modify the safety function STO parameters of the specified STO id.
             *  NOTA : Modification is allowed only in NMT state Pre-operational.
             *
             * @param pId Id of the STO.
             * @param pParameters The STO safety application parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSTOParameters(const STOId &pId, const STOParameters &pParameters) = 0;

            /**
             * @brief Retrieve the SLS safety application parameters of the specified SLS id.
             *
             * @param pId Id of the SLS.
             * @param pParameters The SLS safety application parameters.
             * @param pSignature The SLS safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSLSParameters(const SLSId &pId, SLSParameters &pParameters, uint16_t &pSignature) const = 0;

            /**
             * @brief Modify the safety function SLS parameters of the specified SLS id.
             *  NOTA : Modification is allowed only in NMT state Pre-operational.
             *
             * @param pId Id of the SLS.
             * @param pParameters The SLS safety application parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSLSParameters(const SLSId &pId, const SLSParameters &pParameters) = 0;

            /**
             * @brief Retrieve the SDI safety application parameters of the specified SDI id.
             *
             * @param pId Id of the SDI.
             * @param pParameters The SDI safety application parameters.
             * @param pSignature The SDI safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSDIParameters(const SDIId &pId, SDIParameters &pParameters, uint16_t &pSignature) const = 0;

            /**
             * @brief Modify the safety function SDI parameters of the specified SDI id.
             *  NOTA : Modification is allowed only in NMT state Pre-operational.
             *
             * @param pId Id of the SDI.
             * @param pParameters The SDI safety application parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSDIParameters(const SDIId &pId, const SDIParameters &pParameters) = 0;

            /**
             * @brief Retrieve the SBC safety application parameters of the specified SBC id.
             *
             * @param pId Id of the SBC.
             * @param pParameters The SBC safety application parameters.
             * @param pSignature The SBC safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSBCParameters(const SBCId &pId, SBCParameters &pParameters, uint16_t &pSignature) const = 0;

            /**
             * @brief Retrieve the SMS safety application parameters of the specified SMS id.
             *
             * @param pId Id of the SMS.
             * @param pParameters The SMS safety application parameters.
             * @param pSignature The SMS safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSMSParameters(const SMSId &pId, SMSParameters &pParameters, uint16_t &pSignature) const = 0;

            /**
             * @brief Modify the safety function SMS parameters of the specified SMS id.
             *  NOTA : Modification is allowed only in NMT state Pre-operational.
             *
             * @param pId Id of the SMS.
             * @param pParameters The SMS safety application parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSMSParameters(const SMSId &pId, const SMSParameters &pParameters) = 0;

            /**
             * @brief Retrieve the SLSa safety application parameters of the specified SLSa id.
             *
             * @param pId Id of the SLSa.
             * @param pParameters The SLSa safety application parameters.
             * @param pSignature The SLSa safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSLSaParameters(const SLSaId &pId, SLSaParameters &pParameters, uint16_t &pSignature) const = 0;

            /**
             * @brief Modify the safety function SLSa parameters of the specified SLSa id.
             *  NOTA : Modification is allowed only in NMT state Pre-operational.
             *
             * @param pId Id of the SLSa.
             * @param pParameters The SLSa safety application parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSLSaParameters(const SLSaId &pId, const SLSaParameters &pParameters) = 0;

            /**
             * @brief Retrieve the consolidated safety function status of the specified safety function id.
             *
             * @param pSafetyFunctionId Id of the safety function.
             * @param pStatus True if the consolidated safety function is enabled.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyFunctionOutput(const SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const = 0;

            /**
             * @brief Retrieve all the consolidated safety function statuses.
             *
             * @param pItems Indicates all the consolidated safety function statuses.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyFunctionOutputs(std::vector<SafetyFunctionOuputStatus> &pItems) const = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_ISAFEMOTIONSERVICE_HPP */
