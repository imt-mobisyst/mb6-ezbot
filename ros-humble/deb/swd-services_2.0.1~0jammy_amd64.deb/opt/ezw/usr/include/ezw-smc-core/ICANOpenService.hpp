/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file ICANOpenService.hpp
 */

#ifndef EZW_SMCCORE_ICANOPENSERVICE_HPP
#define EZW_SMCCORE_ICANOPENSERVICE_HPP

#include "ezw_types.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace smccore
    {
        /**
         * @brief CANopen object dictionary services.
         */
        class ICANOpenService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~ICANOpenService() = default;

            /**
             * @brief Retrieve the value of the specified object address for a type string.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueString(const uint32_t &pAddress, std::string &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type string.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueString(const uint32_t &pAddress, const std::string &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type int64.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueInt64(const uint32_t &pAddress, int64_t &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type int64.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueInt64(const uint32_t &pAddress, const int64_t &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type int32.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueInt32(const uint32_t &pAddress, int32_t &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type int32.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueInt32(const uint32_t &pAddress, const int32_t &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type int16.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueInt16(const uint32_t &pAddress, int16_t &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type int16.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueInt16(const uint32_t &pAddress, const int16_t &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type int8.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueInt8(const uint32_t &pAddress, int8_t &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type int8.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueInt8(const uint32_t &pAddress, const int8_t &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type uint64.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueUInt64(const uint32_t &pAddress, uint64_t &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type uint64.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueUInt64(const uint32_t &pAddress, const uint64_t &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type uint32.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueUInt32(const uint32_t &pAddress, uint32_t &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type uint32.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueUInt32(const uint32_t &pAddress, const uint32_t &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type uint16.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueUInt16(const uint32_t &pAddress, uint16_t &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type uint16.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueUInt16(const uint32_t &pAddress, const uint16_t &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type uint8.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueUInt8(const uint32_t &pAddress, uint8_t &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type uint8.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueUInt8(const uint32_t &pAddress, const uint8_t &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type float.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueFloat(const uint32_t &pAddress, float &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type float.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueFloat(const uint32_t &pAddress, const float &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type double.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueDouble(const uint32_t &pAddress, double &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type double.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueDouble(const uint32_t &pAddress, const double &pData) = 0;

            /**
             * @brief Retrieve the value of the specified object address for a type boolean.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueBool(const uint32_t &pAddress, bool &pData) const = 0;

            /**
             * @brief Modify the value of the specified object address for a type boolean.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueBool(const uint32_t &pAddress, const bool &pData) = 0;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_ICANOPENSERVICE_HPP */
