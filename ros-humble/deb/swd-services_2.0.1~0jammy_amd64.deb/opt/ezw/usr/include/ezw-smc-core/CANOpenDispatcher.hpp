/**
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file CANOpenDispatcher.hpp
 */

#ifndef EZW_SMCCORE_CANOPENDISPATCHER_HPP
#define EZW_SMCCORE_CANOPENDISPATCHER_HPP

/* Includes -------------------------------------------- */
#include "Config.hpp"
#include "ICANOpenDispatcher.hpp"

#include "ezw-canopen-core/IService.hpp"

#include "ezw-tools/EDSParser.hpp"
#include "ezw-tools/expected.hpp"

#include "ezw_log.h"
#include "ezw_types.h"

extern "C"
{
#include "ezw-safe-common/ezw_cia402_control_word.h"
}

#include <future>
#include <memory>
#include <string>
#include <thread>

#include "ezw-canopen/gen_define.h"

#include "ezw-canopen/co_canopen.h"

/* Defines --------------------------------------------- */

/* Variable declaration -------------------------------- */

/* Class ----------------------------------------------- */
namespace ezw
{
    namespace smccore
    {
        class CANOpenDispatcher : public ICANOpenDispatcher {
            static constexpr const char *mClassName = "CANOpenDispatcher";

          public:
            CANOpenDispatcher(std::shared_ptr<Config> pConfig, std::shared_ptr<canopencore::IService> pCOSClient);

            ~CANOpenDispatcher() override;

            // ICANOpenDispatcher
            ezw_error_t            init() override;
            bool                   isConfigLoaded() const override;
            bool                   isClientInitialized() const override;
            bool                   isUpdatePdoTerminated() const override;
            ICoreService::ModeEnum getMode() const override;

            // SW Update
            ezw_error_t getSWVersion(uint32_t &pSWVersion) const override;
            ezw_error_t getHWConfig(uint32_t &pHWConfig) const override;

            // ICoreService
            ezw_error_t connect(const uint8_t &pNodeId) override;
            ezw_error_t disconnect() override;
            ezw_error_t getConnectionStatus(bool &pIsConnected, bool &pIsPdoInitSucceeded) override;
            ezw_error_t getConnectedNodeId(uint8_t &pNodeId) override;
            ezw_error_t getCanDevice(std::string &pCanDevice) override;
            ezw_error_t getCoreVersion(std::string &pCoreVersion) override;
            ezw_error_t switchMode(const ICoreService::ModeEnum &pMode) override;
            ezw_error_t loadSettingsFromDCF(const std::string &pDCFFile) override;
            ezw_error_t saveSettingsToDCF(const std::string &pDCFFile) override;
            ezw_error_t loadSettingsFromDevice() override;
            ezw_error_t saveSettingsToDevice() override;

            // IInternalService
            ezw_error_t _storeParameters(const _BlocId &pBlocId) override;
            ezw_error_t _restoreDefaultParameters(const _BlocId &pBlocId) override;
            ezw_error_t _setDeviceParameters(const _DeviceParameters &pParams) override;
            ezw_error_t _getSelfTestStatus(_SelfTestStatus &pSelfTestStatus) const override;
            ezw_error_t _simulateSelfTestError(const _SelfTestStatus &pSelfTestStatus) const override;
            ezw_error_t _getCalibrationParameters(_CalibrationParameters &pParams) const override;
            ezw_error_t _getSystemErrorConfig(_SystemErrorConfig &pConfig) const override;
            ezw_error_t _setSystemErrorConfig(const _SystemErrorConfig &pConfig) override;
            ezw_error_t _getLevel1Error(uint32_t &pLevel1Error) const override;

            // INMTService
            ezw_error_t getNMTState(NMTState &pNmtState) const override;
            ezw_error_t setNMTState(const NMTCommand &pNmtCommand) override;
            ezw_error_t broadcastNMTState(const NMTCommand &pNmtCommand) override;

            // IEMCYService
            ezw_error_t getErrorBehavior(const ErrorType &pErrorType, ErrorBehavior &pErrorBehavior) const override;
            ezw_error_t setErrorBehavior(const ErrorType &pErrorType, const ErrorBehavior &pErrorBehavior) override;
            ezw_error_t clearErrorList() override;
            ezw_error_t getErrorCount(int32_t &pErrorCount) const override;
            ezw_error_t getError(const int32_t &pIndex, uint32_t &pEmcyErrorCode) const override;
            ezw_error_t getErrorRegister(uint8_t &pErrorRegister) const override;

            // IPDSService
            ezw_error_t getPDSState(IService::PDSState &pState) const override;
            ezw_error_t disableVoltage() const override;
            ezw_error_t shutdown() const override;
            ezw_error_t quickStop() const override;
            ezw_error_t switchOn() const override;
            ezw_error_t enableOperation() const override;
            ezw_error_t disableOperation() const override;
            ezw_error_t faultReset(const bool &pStatus) const override;
            ezw_error_t getAbortConnectionOptionCode(AbortConnectionOptionCode &pCode) const override;
            ezw_error_t setAbortConnectionOptionCode(const AbortConnectionOptionCode &pCode) const override;
            ezw_error_t getQuickStopOptionCode(QuickStopOptionCode &pCode) const override;
            ezw_error_t setQuickStopOptionCode(const QuickStopOptionCode &pCode) const override;
            ezw_error_t getShutdownOptionCode(ShutdownOptionCode &pCode) const override;
            ezw_error_t setShutdownOptionCode(const ShutdownOptionCode &pCode) const override;
            ezw_error_t getDisableOperationOptionCode(DisableOperationOptionCode &pCode) const override;
            ezw_error_t setDisableOperationOptionCode(const DisableOperationOptionCode &pCode) const override;
            ezw_error_t getHaltOptionCode(HaltOptionCode &pCode) const override;
            ezw_error_t setHaltOptionCode(const HaltOptionCode &pCode) const override;
            ezw_error_t getFaultReactionOptionCode(FaultReactionOptionCode &pCode) const override;
            ezw_error_t setFaultReactionOptionCode(const FaultReactionOptionCode &pCode) const override;
            ezw_error_t getPeripheralStatus(IService::PeripheralStatus &pPeripheralStatus) const override;
            ezw_error_t enterInOperationEnabledState() override;
            ezw_error_t getOperationModes(OperationMode &pRequested, OperationMode &pActual) const override;
            ezw_error_t isDriveModeSupported(const OperationMode &pMode, bool &pSupported) const override;
            ezw_error_t getUnitParameters(UnitParameters &pParams) const override;
            ezw_error_t setUnitParameters(const UnitParameters &pParams) override;
            ezw_error_t getPolarityParameters(PolarityParameters &pParams) const override;
            ezw_error_t setPolarityParameters(const PolarityParameters &pParams) override;

            // ISafeMotionService
            ezw_error_t getSafetyControlWordMapping(const SafetyControlWordId &pSafetyControlWordId, SafetyWordMapping &pSafetyControlWordMapping) const override;
            ezw_error_t setSafetyControlWordMapping(const SafetyControlWordId &pSafetyControlWordId, const SafetyWordMapping &pSafetyControlWordMapping) override;

            ezw_error_t getSafetyStatusWordMapping(const SafetyStatusWordId &pSafetyStatusWordId, SafetyWordMapping &pSafetyStatusWordMapping) const override;
            ezw_error_t setSafetyStatusWordMapping(const SafetyStatusWordId &pSafetyStatusWordId, const SafetyWordMapping &pSafetyStatusWordMapping) override;

            ezw_error_t getSafetyFunctionCommand(const SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const override;
            ezw_error_t getSafetyFunctionStatus(const SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const override;

            ezw_error_t getSafetyControlWord(const SafetyControlWordId &pSafetyControlWordId, SafetyWordType &pSafetyControlWord) const override;
            ezw_error_t setSafetyControlWord(const SafetyControlWordId &pSafetyControlWordId, const SafetyWordType &pSafetyControlWord) override;

            ezw_error_t getSafetyStatusWord(const SafetyStatusWordId &pSafetyStatusWordId, SafetyWordType &pSafetyStatusWord) const override;

            ezw_error_t getSTOParameters(const STOId &pId, STOParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSTOParameters(const STOId &pId, const STOParameters &pParameters) override;

            ezw_error_t getSLSParameters(const SLSId &pId, SLSParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSLSParameters(const SLSId &pId, const SLSParameters &pParameters) override;

            ezw_error_t getSDIParameters(const SDIId &pId, SDIParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSDIParameters(const SDIId &pId, const SDIParameters &pParameters) override;

            ezw_error_t getSBCParameters(const SBCId &pId, SBCParameters &pParameters, uint16_t &pSignature) const override;

            ezw_error_t getSMSParameters(const SMSId &pId, SMSParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSMSParameters(const SMSId &pId, const SMSParameters &pParameters) override;

            ezw_error_t getSLSaParameters(const SLSaId &pId, SLSaParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSLSaParameters(const SLSaId &pId, const SLSaParameters &pParameters) override;

            ezw_error_t getSafetyFunctionOutput(const SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const override;
            ezw_error_t getSafetyFunctionOutputs(std::vector<SafetyFunctionOuputStatus> &pItems) const override;

            // ICommunicationService
            ezw_error_t storeParameters(const BlocId &pBlocId) override;
            ezw_error_t restoreDefaultParameters(const BlocId &pBlocId) override;
            ezw_error_t getIdentityParameters(IdentityParameters &pParams) const override;
            ezw_error_t getNetworkParameters(NetworkParameters &pParams) const override;
            ezw_error_t setNetworkParameters(const NetworkParameters &pParams) override;
            ezw_error_t getCommunicationParameters(CommunicationParameters &pParams) const override;
            ezw_error_t setCommunicationParameters(const CommunicationParameters &pParams) override;
            ezw_error_t getSDOCommunicationParameters(const SDOId &pId, SDOCommunicationParameters &pParams) const override;
            ezw_error_t setSDOCommunicationParameters(const SDOId &pId, const SDOCommunicationParameters &pParams) override;
            ezw_error_t getRPDOCommunicationParameters(const PDOId &pId, PDOCommunicationParameters &pParams) const override;
            ezw_error_t setRPDOCommunicationParameters(const PDOId &pId, const PDOCommunicationParameters &pParams) override;
            ezw_error_t getTPDOCommunicationParameters(const PDOId &pId, PDOCommunicationParameters &pParams) const override;
            ezw_error_t setTPDOCommunicationParameters(const PDOId &pId, const PDOCommunicationParameters &pParams) override;
            ezw_error_t getRPDOMappingParameters(const PDOId &pId, PDOMappingParameters &pParams) const override;
            ezw_error_t setRPDOMappingParameters(const PDOId &pId, const PDOMappingParameters &pParams) override;
            ezw_error_t getTPDOMappingParameters(const PDOId &pId, PDOMappingParameters &pParams) const override;
            ezw_error_t setTPDOMappingParameters(const PDOId &pId, const PDOMappingParameters &pParams) override;

            // IManufacturerService
            ezw_error_t getDeviceParameters(DeviceParameters &pParams) const override;
            ezw_error_t getSWDParameters(SWDParameters &pParams) const override;
            ezw_error_t setSWDParameters(const SWDParameters &pParams) override;
            ezw_error_t getSystemErrorState(SystemErrorStatus &pBatteryUv, SystemErrorStatus &pBatteryOv, SystemErrorStatus &pPhaseOc, SystemErrorStatus &pMosOt, SystemErrorStatus &pDrvOt) const override;
            ezw_error_t getSystemErrorProtectState(SystemErrorProtectState &pPrevState, SystemErrorProtectState &pCurrentState) const override;
            ezw_error_t getCalibrationValidity(bool &pIsvalid) const override;
            ezw_error_t getSWVersion(std::string &pSwVersion) const override;
            ezw_error_t getSWId(uint8_t &pSwId) const override;
            ezw_error_t getSWRef(std::string &pSoftwareRef) const override;
            ezw_error_t getHWVersion(uint32_t &pHWVersion) const override;
            ezw_error_t getHWId(uint32_t &pHwId) const override;
            ezw_error_t getProductId(uint32_t &pProductId) const override;
            ezw_error_t getProductRef(std::string &pProductRef) const override;
            ezw_error_t getOdometryValue(int32_t &pOdometryValue) const override;
            ezw_error_t getOdometryValueTS(int32_t &pOdometryValue, uint64_t &pTimestamp) const override;
            ezw_error_t getAccurateOdometryValue(int32_t &pAccurateOdometryValue) const override;
            ezw_error_t getAccurateOdometryValueTS(int32_t &AccurateOdometryValue, uint64_t &pTimestamp) const override;
            ezw_error_t getAccuratePositionValue(int32_t &pAccuratePositionValue) const override;
            ezw_error_t getAccuratePositionValueTS(int32_t &pAccuratePositionValue, uint64_t &pTimestamp) const override;
            ezw_error_t getOutputControl(const OutputSource &pOutputSource, bool &pControl) const override;
            ezw_error_t setOutputControl(const OutputSource &pOutputSource, const bool &pControl) override;
            ezw_error_t getOutputStatus(const OutputSource &pOutputSource, bool &pStatus) const override;
            ezw_error_t setExternalBrakePresence(const bool &pExternalbrakepresence) override;
            ezw_error_t getExternalBrakePresence(bool &pExternalbrakepresence) const override;
            ezw_error_t getSystemErrorOutputs(std::vector<SystemErrorOutput> &pItems) const override;

            // IVelocityModeService
            ezw_error_t setTargetVelocity(const int16_t &pTargetVelocity) override;
            ezw_error_t getVelocityActualValue(int32_t &pVelocityActualValue) const override;
            ezw_error_t getVelocityActualValueTS(int32_t &pVelocityActualValue, uint64_t &pTimestamp) const override;
            ezw_error_t getTargetVelocity(int16_t &pTargetVelocity) const override;
            ezw_error_t getVelocityDemand(int16_t &pVelocityDemand) const override;
            ezw_error_t getPositionValue(int32_t &pPositionValue) const override;
            ezw_error_t getPositionValueTS(int32_t &pPositionValue, uint64_t &pTimestamp) const override;
            ezw_error_t getVelocityModeParameters(VelocityModeParameters &pParams) const override;
            ezw_error_t setVelocityModeParameters(const VelocityModeParameters &pParams) override;
            ezw_error_t getVelocityModeStatusword(VelocityModeStatusword &pParams) const override;
            ezw_error_t getVelocityModeControlword(VelocityModeControlword &pParams) const override;
            ezw_error_t setEnableRamp(const bool &pEnableRamp) override;
            ezw_error_t setUnlockRamp(const bool &pUnlockRamp) override;
            ezw_error_t setReferenceRamp(const bool &pReferenceRamp) override;
            ezw_error_t setHalt(const bool &pHalt) override;

            // ISRDOService
            ezw_error_t getSRDOParameters(const SRDOId &pId, SRDODirection &pDirection, SRDOParameters &pParameters, uint16_t &pSignature) const override;
            ezw_error_t setSRDOParameters(const SRDOId &pId, const SRDOParameters &pParameters) override;
            ezw_error_t getSRDOMapping(const SRDOId &pId, SRDOMapping &pMapping) const override;
            ezw_error_t getSRDOConfigurationValidity(bool &pIsvalid) const override;
            ezw_error_t setSRDOConfigurationValidity() override;

            // ICANOpenService
            ezw_error_t getValueString(const uint32_t &pAddress, std::string &pData) const override;
            ezw_error_t setValueString(const uint32_t &pAddress, const std::string &pData) override;
            ezw_error_t getValueInt64(const uint32_t &pAddress, int64_t &pData) const override;
            ezw_error_t setValueInt64(const uint32_t &pAddress, const int64_t &pData) override;
            ezw_error_t getValueInt32(const uint32_t &pAddress, int32_t &pData) const override;
            ezw_error_t setValueInt32(const uint32_t &pAddress, const int32_t &pData) override;
            ezw_error_t getValueInt16(const uint32_t &pAddress, int16_t &pData) const override;
            ezw_error_t setValueInt16(const uint32_t &pAddress, const int16_t &pData) override;
            ezw_error_t getValueInt8(const uint32_t &pAddress, int8_t &pData) const override;
            ezw_error_t setValueInt8(const uint32_t &pAddress, const int8_t &pData) override;
            ezw_error_t getValueUInt64(const uint32_t &pAddress, uint64_t &pData) const override;
            ezw_error_t setValueUInt64(const uint32_t &pAddress, const uint64_t &pData) override;
            ezw_error_t getValueUInt32(const uint32_t &pAddress, uint32_t &pData) const override;
            ezw_error_t setValueUInt32(const uint32_t &pAddress, const uint32_t &pData) override;
            ezw_error_t getValueUInt16(const uint32_t &pAddress, uint16_t &pData) const override;
            ezw_error_t setValueUInt16(const uint32_t &pAddress, const uint16_t &pData) override;
            ezw_error_t getValueUInt8(const uint32_t &pAddress, uint8_t &pData) const override;
            ezw_error_t setValueUInt8(const uint32_t &pAddress, const uint8_t &pData) override;
            ezw_error_t getValueFloat(const uint32_t &pAddress, float &pData) const override;
            ezw_error_t setValueFloat(const uint32_t &pAddress, const float &pData) override;
            ezw_error_t getValueDouble(const uint32_t &pAddress, double &pData) const override;
            ezw_error_t setValueDouble(const uint32_t &pAddress, const double &pData) override;
            ezw_error_t getValueBool(const uint32_t &pAddress, bool &pData) const override;
            ezw_error_t setValueBool(const uint32_t &pAddress, const bool &pData) override;

          protected:
            ezw_error_t getCIA402StatusWord(uint16_t &pStatusWord) const;
            ezw_error_t sendCIA402ControlWord(const ezw_cia402_control_word_t *pControlWord) const;

          private:
            ezw_error_t get_address(const std::string &name, uint32_t &value) const;
            ezw_error_t updateCobIdSettings(bool isBlocking);

            ezw_error_t updatePdoCobIdSettings(std::vector<uint32_t> &pFilter, std::vector<uint8_t> &pPDONbrs, std::vector<uint32_t> &pPDOAddresses);

            template <typename T> ezw_error_t get_value_by_address(uint32_t address, T &value) const
            {
                ezw_error_t lError = ERROR_NONE;

                if (mMode == ICoreService::ModeEnum::REMOTE) {
                    lError = mCOSClient->getValue(mNodeId, address, value);
                } else {
                    auto lObjectEntry = mLocalModel->getObjectByAdress(address);

                    if (lObjectEntry == nullptr) {
                        EZW_LOG(mConfig->getContextId(), EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR((std::string("Object ") + std::to_string(address) + " not found !").c_str()));
                        return ERROR_INTERNAL;
                    }

                    lError = lObjectEntry->getValue(value) ? ERROR_NONE : ERROR_INTERNAL;
                }

                if (lError != ERROR_NONE) {
                    EZW_LOG(mConfig->getContextId(), EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("getValue nodeId=" + std::to_string(mNodeId) + " address=" + std::to_string(address)).c_str()));
                    return lError;
                }
                return lError;
            }

            template <typename T> ezw_error_t get_value_by_name(std::string const &name, T &value) const
            {
                ezw_error_t lError = ERROR_NONE;

                auto lObjectEntry = mLocalModel->getObjectByName(name);

                if (lObjectEntry == nullptr) {
                    EZW_LOG(mConfig->getContextId(), EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR((std::string("Object ") + name + " not found !").c_str()));
                    return ERROR_INTERNAL;
                }

                if (mMode == ICoreService::ModeEnum::REMOTE) {
                    auto address = lObjectEntry->getObjectAddress();
                    lError       = mCOSClient->getValue(mNodeId, address, value);
                } else {
                    lError = lObjectEntry->getValue(value) ? ERROR_NONE : ERROR_INTERNAL;
                }

                if (ERROR_NONE != lError) {
                    EZW_LOG(mConfig->getContextId(), EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("getValue nodeId=" + std::to_string(mNodeId) + " address=" + std::to_string(lObjectEntry->getObjectAddress()) + " (" + name + ") : failed !").c_str()));
                    return lError;
                }

                EZW_LOG(mConfig->getContextId(), EZW_LOG_DEBUG, EZW_STR(mClassName), EZW_STR(std::string("getValue nodeId=" + std::to_string(mNodeId) + " address=" + std::to_string(lObjectEntry->getObjectAddress()) + " (" + name + ")").c_str()));

                return ERROR_NONE;
            }

            template <typename T> ezw_error_t get_value_by_name_ts(std::string const &name, T &value, uint64_t &pTimestamp) const
            {
                ezw_error_t lError = ERROR_NONE;

                auto lObjectEntry = mLocalModel->getObjectByName(name);

                if (lObjectEntry == nullptr) {
                    EZW_LOG(mConfig->getContextId(), EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR((std::string("Object ") + name + " not found !").c_str()));
                    return ERROR_INTERNAL;
                }

                if (mMode == ICoreService::ModeEnum::REMOTE) {
                    auto address = lObjectEntry->getObjectAddress();
                    lError       = mCOSClient->getValue(mNodeId, address, value, pTimestamp);
                } else {
                    // FIXME pTimestamp
                    lError = lObjectEntry->getValue(value) ? ERROR_NONE : ERROR_INTERNAL;
                }

                if (ERROR_NONE != lError) {
                    EZW_LOG(mConfig->getContextId(), EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("getValue nodeId=" + std::to_string(mNodeId) + " address=" + std::to_string(lObjectEntry->getObjectAddress()) + " (" + name + ") : failed !").c_str()));
                    return lError;
                }

                EZW_LOG(mConfig->getContextId(), EZW_LOG_DEBUG, EZW_STR(mClassName), EZW_STR(std::string("getValue nodeId=" + std::to_string(mNodeId) + " address=" + std::to_string(lObjectEntry->getObjectAddress()) + " (" + name + ")").c_str()));

                return ERROR_NONE;
            }

            ezw_error_t updateSignature_STO(STOId const pId, STOParameters const pParameters);
            ezw_error_t updateSignature_SDI(SDIId const pId, SDIParameters const pParameters);
            ezw_error_t updateSignature_SLS(SLSId const pId, SLSParameters const pParameters);
            ezw_error_t updateSignature_SBC(SBCId const pId, SBCParameters const pParameters);
            ezw_error_t updateSignature_SMS(SMSId const pId, SMSParameters const pParameters);
            ezw_error_t updateSignature_SLSa(SLSaId const pId, SLSaParameters const pParameters);

            ezw_error_t computeMappingSignature(uint16_t pInputCrc, uint16_t &pOutputCrc);
            ezw_error_t updateAllSafetySignatures();

            template <typename T> uint16_t crcComputation(int crc, T &data)
            {
                static const uint16_t CRC_PRECOMPUTED_VALUE[256] = {0x0000u, 0x1021u, 0x2042u, 0x3063u, 0x4084u, 0x50a5u, 0x60c6u, 0x70e7u, 0x8108u, 0x9129u, 0xa14au, 0xb16bu, 0xc18cu, 0xd1adu, 0xe1ceu, 0xf1efu, 0x1231u, 0x0210u, 0x3273u, 0x2252u, 0x52b5u, 0x4294u, 0x72f7u, 0x62d6u, 0x9339u, 0x8318u, 0xb37bu, 0xa35au, 0xd3bdu, 0xc39cu, 0xf3ffu, 0xe3deu, 0x2462u, 0x3443u, 0x0420u, 0x1401u, 0x64e6u, 0x74c7u, 0x44a4u, 0x5485u, 0xa56au, 0xb54bu, 0x8528u,
                                                                    0x9509u, 0xe5eeu, 0xf5cfu, 0xc5acu, 0xd58du, 0x3653u, 0x2672u, 0x1611u, 0x0630u, 0x76d7u, 0x66f6u, 0x5695u, 0x46b4u, 0xb75bu, 0xa77au, 0x9719u, 0x8738u, 0xf7dfu, 0xe7feu, 0xd79du, 0xc7bcu, 0x48c4u, 0x58e5u, 0x6886u, 0x78a7u, 0x0840u, 0x1861u, 0x2802u, 0x3823u, 0xc9ccu, 0xd9edu, 0xe98eu, 0xf9afu, 0x8948u, 0x9969u, 0xa90au, 0xb92bu, 0x5af5u, 0x4ad4u, 0x7ab7u, 0x6a96u, 0x1a71u, 0x0a50u,
                                                                    0x3a33u, 0x2a12u, 0xdbfdu, 0xcbdcu, 0xfbbfu, 0xeb9eu, 0x9b79u, 0x8b58u, 0xbb3bu, 0xab1au, 0x6ca6u, 0x7c87u, 0x4ce4u, 0x5cc5u, 0x2c22u, 0x3c03u, 0x0c60u, 0x1c41u, 0xedaeu, 0xfd8fu, 0xcdecu, 0xddcdu, 0xad2au, 0xbd0bu, 0x8d68u, 0x9d49u, 0x7e97u, 0x6eb6u, 0x5ed5u, 0x4ef4u, 0x3e13u, 0x2e32u, 0x1e51u, 0x0e70u, 0xff9fu, 0xefbeu, 0xdfddu, 0xcffcu, 0xbf1bu, 0xaf3au, 0x9f59u, 0x8f78u, 0x9188u,
                                                                    0x81a9u, 0xb1cau, 0xa1ebu, 0xd10cu, 0xc12du, 0xf14eu, 0xe16fu, 0x1080u, 0x00a1u, 0x30c2u, 0x20e3u, 0x5004u, 0x4025u, 0x7046u, 0x6067u, 0x83b9u, 0x9398u, 0xa3fbu, 0xb3dau, 0xc33du, 0xd31cu, 0xe37fu, 0xf35eu, 0x02b1u, 0x1290u, 0x22f3u, 0x32d2u, 0x4235u, 0x5214u, 0x6277u, 0x7256u, 0xb5eau, 0xa5cbu, 0x95a8u, 0x8589u, 0xf56eu, 0xe54fu, 0xd52cu, 0xc50du, 0x34e2u, 0x24c3u, 0x14a0u, 0x0481u,
                                                                    0x7466u, 0x6447u, 0x5424u, 0x4405u, 0xa7dbu, 0xb7fau, 0x8799u, 0x97b8u, 0xe75fu, 0xf77eu, 0xc71du, 0xd73cu, 0x26d3u, 0x36f2u, 0x0691u, 0x16b0u, 0x6657u, 0x7676u, 0x4615u, 0x5634u, 0xd94cu, 0xc96du, 0xf90eu, 0xe92fu, 0x99c8u, 0x89e9u, 0xb98au, 0xa9abu, 0x5844u, 0x4865u, 0x7806u, 0x6827u, 0x18c0u, 0x08e1u, 0x3882u, 0x28a3u, 0xcb7du, 0xdb5cu, 0xeb3fu, 0xfb1eu, 0x8bf9u, 0x9bd8u, 0xabbbu,
                                                                    0xbb9au, 0x4a75u, 0x5a54u, 0x6a37u, 0x7a16u, 0x0af1u, 0x1ad0u, 0x2ab3u, 0x3a92u, 0xfd2eu, 0xed0fu, 0xdd6cu, 0xcd4du, 0xbdaau, 0xad8bu, 0x9de8u, 0x8dc9u, 0x7c26u, 0x6c07u, 0x5c64u, 0x4c45u, 0x3ca2u, 0x2c83u, 0x1ce0u, 0x0cc1u, 0xef1fu, 0xff3eu, 0xcf5du, 0xdf7cu, 0xaf9bu, 0xbfbau, 0x8fd9u, 0x9ff8u, 0x6e17u, 0x7e36u, 0x4e55u, 0x5e74u, 0x2e93u, 0x3eb2u, 0x0ed1u, 0x1ef0u};

                uint16_t lCrc = crc;

                int byteCount = 0;

                // Compute Crc bytes by bytes
                for (long unsigned int currentByte = 0; currentByte < sizeof(T); currentByte++) {
                    byteCount++;
                    // Extract currentByte from data
                    uint8_t lByteData = (data >> (currentByte * 8)) & 0xFF;

                    // Find crcIndex
                    unsigned short lindex = ((lCrc >> 8) & 0xFF) ^ lByteData;

                    // Compute newCrc
                    lCrc = ((lCrc << 8) & 0xFFFF) ^ CRC_PRECOMPUTED_VALUE[lindex];
                }
                // printf("Data : %x\tCounted bytes : %i\n", data, byteCount);

                return lCrc;
            }

            template <typename T, typename = std::is_scalar<T>> void log_set_success(const std::string &name, uint32_t address, const T &value) const
            {
                log_set_success(name, address, std::to_string(value));
            }

            template <typename T, typename = std::is_scalar<T>> void log_set_success_address(uint32_t address, const T &value) const
            {
                log_set_success_address(address, std::to_string(value));
            }

            void log_set_success(const std::string &name, uint32_t address, const std::string &value) const;
            void log_set_success_address(uint32_t address, const std::string &value) const;

            template <typename T> ezw_error_t set_value_by_address(uint32_t address, const T &value) const
            {
                ezw_error_t lError = ERROR_NONE;

                if (mMode == ICoreService::ModeEnum::REMOTE) {
                    lError = mCOSClient->setValue(mNodeId, address, value);
                } else {
                    auto lObjectEntry = mLocalModel->getObjectByAdress(address);

                    if (lObjectEntry == nullptr) {
                        EZW_LOG(mConfig->getContextId(), EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR((std::string("Object ") + std::to_string(address) + " not found !").c_str()));
                        return ERROR_INTERNAL;
                    }

                    lError = lObjectEntry->setValue(value) ? ERROR_NONE : ERROR_INTERNAL;
                }

                if (ERROR_NONE != lError) {
                    EZW_LOG(mConfig->getContextId(), EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("setValue nodeId=" + std::to_string(mNodeId) + " address=" + std::to_string(address) + " : failed !").c_str()));
                    return lError;
                }
                log_set_success_address(address, value);
                return ERROR_NONE;
            }

            template <typename T> ezw_error_t set_value_by_name(std::string const &name, const T &value) const
            {
                ezw_error_t lError = ERROR_NONE;

                auto lObjectEntry = mLocalModel->getObjectByName(name);

                if (lObjectEntry == nullptr) {
                    EZW_LOG(mConfig->getContextId(), EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR((std::string("Object ") + name + " not found !").c_str()));
                    return ERROR_INTERNAL;
                }

                auto address = lObjectEntry->getObjectAddress();

                if (mMode == ICoreService::ModeEnum::REMOTE) {
                    lError = mCOSClient->setValue(mNodeId, address, value);
                } else {
                    lError = lObjectEntry->setValue(value) ? ERROR_NONE : ERROR_INTERNAL;
                }

                if (ERROR_NONE != lError) {
                    EZW_LOG(mConfig->getContextId(), EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("setValue nodeId=" + std::to_string(mNodeId) + " address=" + std::to_string(lObjectEntry->getObjectAddress()) + " (" + name + ") : failed !").c_str()));
                    return lError;
                }
                log_set_success(name, address, value);
                return ERROR_NONE;
            }

            ezw_error_t getPDOCommunicationParameters(PDOCommunicationParameters &pParams, uint32_t pIndex) const;
            ezw_error_t setPDOCommunicationParameters(const PDOCommunicationParameters &pParams, uint32_t pIndex);

            static COBID    cobIdFromRaw(uint32_t pRawCobId);
            static uint32_t cobIdToRaw(const COBID &pCobId);
            static uint32_t cobIdToRaw(bool pValidity, bool pFlag, uint32_t pCanId);

            ezw_error_t isSWVersionGreaterOrEquals(uint32_t lVersionMajor, uint32_t lVersionMinor, uint32_t lVersionPatch, bool &pResult) const;
            ezw_error_t isSWVersionEquals(uint32_t lVersionMajor, uint32_t lVersionMinor, uint32_t lVersionPatch, bool &pResult) const;

            bool mIsConfigLoaded;

            std::shared_ptr<canopencore::IService> mCOSClient;
            std::shared_ptr<Config>                mConfig;

            std::unique_ptr<tools::EDSParser> mLocalModel;
            ICoreService::ModeEnum            mMode;

            int  mRequestedNodeId;
            int  mNodeId;
            bool mUpdatePDORequested;

            std::thread       mUpdatePdoCobIdThread;
            std::atomic<bool> mUpdatePdoTerminated;
            std::atomic<bool> mUpdatePdoSucceeded;

            std::map<uint32_t, int32_t *>  mDataInt32;
            std::map<uint32_t, int16_t *>  mDataInt16;
            std::map<uint32_t, int8_t *>   mDataInt8;
            std::map<uint32_t, uint32_t *> mDataUInt32;
            std::map<uint32_t, uint16_t *> mDataUInt16;
            std::map<uint32_t, uint8_t *>  mDataUInt8;
        };
    } // namespace smccore
} // namespace ezw

#endif /* EZW_SMCCORE_CANOPENDISPATCHER_HPP */
