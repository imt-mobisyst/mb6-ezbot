/*
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file ezw_cia402_status_word.h
 * @brief Helper for SMC's status word manipulation
 */

#ifndef EZW_CIA402_STATUS_WORD_H
#define EZW_CIA402_STATUS_WORD_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "ezw_types.h"

/** @defgroup ezw-cia402-common common
 * Common API functions.
 * @ingroup ezw-cia402
 * @{
 */

/** @defgroup ezw-cia402-common-defines defines
 * @ingroup ezw-cia402-common
 * @{
 * CIA402: Controlword masks definitions
 */

/** @brief CIA402: statusword masks definitions
 */
#define EZW_CIA402_SW_RTSO 0x0001u /*!< Mask for bit ready to switch on    */
#define EZW_CIA402_SW_SO   0x0002u /*!< Mask for bit switched on           */
#define EZW_CIA402_SW_OE   0x0004u /*!< Mask for bit operation enabled     */
#define EZW_CIA402_SW_F    0x0008u /*!< Mask for bit fault                 */
#define EZW_CIA402_SW_VE   0x0010u /*!< Mask for bit voltage enabled       */
#define EZW_CIA402_SW_QS   0x0020u /*!< Mask for bit quick stop            */
#define EZW_CIA402_SW_SOD  0x0040u /*!< Mask for bit switch on disabled    */
#define EZW_CIA402_SW_W    0x0080u /*!< Mask for bit warning               */
#define EZW_CIA402_SW_RM   0x0200u /*!< Mask for bit remote                */
#define EZW_CIA402_SW_TR   0x0400u /*!< Mask for bit target reached        */
#define EZW_CIA402_SW_ILA  0x0800u /*!< Mask for bit internal limit active */
/** @} */

/** @defgroup ezw-cia402-common-typedefs typedefs
 * @ingroup ezw-cia402-common
 * @{
 */

/** @brief CIA402: status word specifications
 */
typedef struct {
    uint8_t rtso; /*!< ready to switch on */
    uint8_t so;   /*!< switched on */
    uint8_t oe;   /*!< operation enabled */
    uint8_t f;    /*!< fault */
    uint8_t ve;   /*!< voltage enabled */
    uint8_t qs;   /*!< quick stop */
    uint8_t sod;  /*!< switch on disabled */
    uint8_t w;    /*!< warning */
    uint8_t rm;   /*!< remote */
    uint8_t tr;   /*!< target reached */
    uint8_t ila;  /*!< internal limit active */
} ezw_cia402_status_word_t;
/** @} */

/** @defgroup ezw-cia402-common-functions functions
 * @ingroup ezw-cia402-common
 * @{
 */

/**
 * @brief       Encode status word structure into the pointed uint16_t variable
 * @param[in]   status_word_struct     The pointer to the structure encoding the status word
 * @param[out]  out                    The uint16_t pointer to which encoding the status word
 * @return      error code             ERROR_NONE if no error occurred
 */
ezw_error_t ezw_cia402_encode_status_word(const ezw_cia402_status_word_t *status_word_struct, uint16_t * const out);

/**
 * @brief       Decode the uint16_t status word into the pointed cia402_status_word structure
 * @param[in]   status_word            The uint16_t status word to be decoded
 * @param[out]  out                    The pointer to the ezw_cia402_status_word structure
 * @return      error code             ERROR_NONE if no error occurred
 */
ezw_error_t ezw_cia402_decode_status_word(const uint16_t status_word, ezw_cia402_status_word_t * const out);

/** @} */

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @} */

#endif /* EZW_CIA402_STATUS_WORD_H */
