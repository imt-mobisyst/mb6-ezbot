/*
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file ezw_hall.h
 * @brief Helper for hall configuration
 */

#ifndef EZW_HALL_COMMON_H
#define EZW_HALL_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "ezw_types.h"

/* Defines --------------------------------------------- */

/* Typedefs -------------------------------------------- */
typedef struct {
    int32_t                 adc_offset_mv;
    float                   gain;
    int32_t                 angle_offset_mdeg;
} ezw_hall_sincos_norm_coef_t;

typedef struct __attribute__((__packed__)) {
    uint8_t                         is_valid;
    ezw_hall_sincos_norm_coef_t     cos_norm_coef;
    ezw_hall_sincos_norm_coef_t     sin_norm_coef;
} ezw_hall_public_config_t;

/* Functions ------------------------------------------- */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* EZW_HALL_COMMON_H */
