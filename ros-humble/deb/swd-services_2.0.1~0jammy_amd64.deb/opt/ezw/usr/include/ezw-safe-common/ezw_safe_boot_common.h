/*
 * Copyright (C) 2023 ez-Wheel S.A.S.
 *
 * @file ezw_safe_boot_common.h
 */

#ifndef EZW_SAFE_BOOT_COMMON_H
#define EZW_SAFE_BOOT_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "ezw_types.h"

/* Defines --------------------------------------------- */

/* Typedefs -------------------------------------------- */

extern char_t *tab_sw_ref [];

/* Functions ------------------------------------------- */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* EZW_SAFE_BOOT_COMMON_H */
