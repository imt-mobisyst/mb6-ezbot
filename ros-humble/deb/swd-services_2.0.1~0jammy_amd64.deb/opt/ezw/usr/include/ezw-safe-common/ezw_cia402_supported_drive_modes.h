/*
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file ezw_cia402_supported_drive_modes.h
 * @brief Helper for SMC's drive_modes manipulation
 */
#ifndef EZW_COMMON_CIA402_SUPPORTED_DRIVE_MODES_H
#define EZW_COMMON_CIA402_SUPPORTED_DRIVE_MODES_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "ezw_types.h"

/** @defgroup ezw-cia402-common common
 * Common API functions.
 * @ingroup ezw-cia402
 * @{
 */

/** @defgroup ezw-cia402-common-defines defines
 * @ingroup ezw-cia402-common
 * @{
 * CIA402: Controlword masks definitions
 */

/** @brief CIA402: Supported drive modes masks definitions
 */
#define EZW_CIA402_06502_DRIVE_MODE_PP    0x00000001u /*!< Mask for bit Profile position mode                          */
#define EZW_CIA402_06502_DRIVE_MODE_VL    0x00000002u /*!< Mask for bit Velocity mode                                  */
#define EZW_CIA402_06502_DRIVE_MODE_PV    0x00000004u /*!< Mask for bit Profile velocity mode                          */
#define EZW_CIA402_06502_DRIVE_MODE_TQ    0x00000008u /*!< Mask for bit Torque profile mode                            */
#define EZW_CIA402_06502_DRIVE_MODE_R     0x00000010u /*!< Mask for bit Reserved                                       */
#define EZW_CIA402_06502_DRIVE_MODE_HM    0x00000020u /*!< Mask for bit Homing mode                                    */
#define EZW_CIA402_06502_DRIVE_MODE_IP    0x00000040u /*!< Mask for bit Interpolated position mode                     */
#define EZW_CIA402_06502_DRIVE_MODE_CSP   0x00000080u /*!< Mask for bit Cyclic sync position mode                      */
#define EZW_CIA402_06502_DRIVE_MODE_CSV   0x00000100u /*!< Mask for bit Cyclic sync velocity mode                      */
#define CIA402_06502_DRIVE_MODE_CST   0x00000200u /*!< Mask for bit Cyclic sync torque mode                        */
#define EZW_CIA402_06502_DRIVE_MODE_CSTCA 0x00000400u /*!< Mask for bit Cyclic sync torque mode with commutation angle */
/** @} */

/** @defgroup ezw-cia402-common-typedefs typedefs
 * @ingroup ezw-cia402-common
 * @{
 */

/** @brief CIA402: supported drive modes
 */
typedef struct {
    uint8_t pp;    /*!< Profile position mode                          */
    uint8_t vl;    /*!< Velocity mode                                  */
    uint8_t pv;    /*!< Profile velocity mode                          */
    uint8_t tq;    /*!< Torque profile mode                            */
    uint8_t r;     /*!< Reserved                                       */
    uint8_t hm;    /*!< Homing mode                                    */
    uint8_t ip;    /*!< Interpolated position mode                     */
    uint8_t csp;   /*!< Cyclic sync position mode                      */
    uint8_t csv;   /*!< Cyclic sync velocity mode                      */
    uint8_t cst;   /*!< Cyclic sync torque mode                        */
    uint8_t cstca; /*!< Cyclic sync torque mode with commutation angle */
} ezw_cia402_supported_drive_modes_t;
/** @} */

/** @defgroup ezw-cia402-common-functions functions
 * @ingroup ezw-cia402-common
 * @{
 */

/**
 * @brief Encodes a supported drive mode structure into a uint32_t
 * @param[in]  supported_drive_modes_struct pointer to structure
 * @param[out] out pointer to supported drive mode output
 * @return error_code
 */
ezw_error_t ezw_cia402_encode_supported_drive_modes(const ezw_cia402_supported_drive_modes_t *supported_drive_modes_struct, uint32_t * const out);

/**
 * @brief decodes a supported_drive_modes uint32_t into a structure
 * @param[in]  supported_drive_modes supported_drive_modes word
 * @param[out] out to ezw_cia402_supported_drive_modes_t structure
 * @return error_code
 */
ezw_error_t ezw_cia402_decode_supported_drive_modes(const uint32_t supported_drive_modes, ezw_cia402_supported_drive_modes_t * const out);

/** @} */

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @} */

#endif /* EZW_COMMON_CIA402_SUPPORTED_DRIVE_MODES_H */
