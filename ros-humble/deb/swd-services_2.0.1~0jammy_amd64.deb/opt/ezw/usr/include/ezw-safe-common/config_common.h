/*
 * Copyright (C) 2023 ez-Wheel S.A.S.
 *
 * @file config_common.h
 */

#ifndef CONFIG_COMMON_H
#define CONFIG_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "ezw_types.h"

/* Defines --------------------------------------------- */

#define NUMOF_PRODUCT_ID (37U)

/* Typedefs -------------------------------------------- */

typedef struct
{
    char_t *product_ref;
    ezw_bool_t brake_present;
    uint32_t gear_ratio_motor_rev;
    uint32_t gear_ratio_shaft_rev;
    uint32_t product_code;
} tab_od_info_t;
extern tab_od_info_t tab_od_info[NUMOF_PRODUCT_ID];

/* Functions ------------------------------------------- */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* CONFIG_COMMON_H */
