/*
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file ezw_cia402_control_word.h
 * @brief Helper for SMC's control word manipulation
 */

#ifndef EZW_CIA402_CONTROL_WORD_H_INCLUDED
#define EZW_CIA402_CONTROL_WORD_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "ezw_types.h"

/** @defgroup ezw-cia402-common common
 * Common API functions.
 * @ingroup ezw-cia402
 * @{
 */

/** @defgroup ezw-cia402-common-defines defines
 * @ingroup ezw-cia402-common
 * @{
 * CIA402: Controlword masks definitions
 */
#define EZW_CIA402_CW_SO 0x0001u /*!< Mask for bit switch on        */
#define EZW_CIA402_CW_EV 0x0002u /*!< Mask for bit enable voltage   */
#define EZW_CIA402_CW_QS 0x0004u /*!< Mask for bit quick stop       */
#define EZW_CIA402_CW_EO 0x0008u /*!< Mask for bit enable operation */
#define EZW_CIA402_CW_FR 0x0080u /*!< Mask for bit fault reset      */
#define EZW_CIA402_CW_H  0x0100u /*!< Mask for bit halt             */
/** @} */

/** @defgroup ezw-cia402-common-typedefs typedefs
 * @ingroup ezw-cia402-common
 * @{
 */

/** @brief CIA402: Control word specifications
 */
typedef struct {
    uint8_t so; /*!< switch on        */
    uint8_t ev; /*!< enable voltage   */
    uint8_t qs; /*!< quick stop       */
    uint8_t eo; /*!< enable operation */
    uint8_t fr; /*!< fault reset      */
    uint8_t h;  /*!< halt             */
} ezw_cia402_control_word_t;
/** @} */

/** @defgroup ezw-cia402-common-functions functions
 * @ingroup ezw-cia402-common
 * @{
 */

/**
 * @brief       Encode control word structure into the pointed uint16_t variable
 * @param[in]   control_word_struct         The pointer to the structure encoding the control word
 * @param[out]  out                         The uint16_t pointer to which encoding the control word
 * @return      error code                  ERROR_NONE if no error occurred
 */
ezw_error_t ezw_cia402_encode_control_word(const ezw_cia402_control_word_t *control_word_struct, uint16_t * const out);

/**
 * @brief       Decode the uint16_t control word into the pointed cia402_control_word structure
 * @param[in]   control_word            The uint16_t control word to be decoded
 * @param[out]  out                     The pointer to the ezw_cia402_control_word structure
 * @return      error code              ERROR_NONE if no error occurred
 */
ezw_error_t ezw_cia402_decode_control_word(const uint16_t control_word, ezw_cia402_control_word_t * const out);

/**
 * @brief       Check if two controlwords are the same
 * @param[in]   cw_left     First controlword structure
 * @param[in]   cw_right    Second controlword structure
 * @return      bool        True if controlword are the same, false if input are invalid or controlword are different
 */
ezw_bool_t ezw_cia402_control_word_is_same(const ezw_cia402_control_word_t * const cw_left, const ezw_cia402_control_word_t * const cw_right);

/** @} */

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @} */

#endif /* EZW_CIA402_CONTROL_WORD_H_INCLUDED */
