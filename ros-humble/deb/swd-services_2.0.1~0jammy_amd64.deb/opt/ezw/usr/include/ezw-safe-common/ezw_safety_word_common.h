/*
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file ezw_safety_word_common.h
 * @brief Helper for mapping control/statusword bits to functions
 */

#ifndef EZW_SAFETY_WORD_COMMON_H
#define EZW_SAFETY_WORD_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "ezw_types.h"

/** @defgroup ezw-safety-word-common common
 * Common API functions.
 * @ingroup ezw-safety-word
 * @{
 */

/* Defines --------------------------------------------- */

/* Typedefs -------------------------------------------- */
/** @brief Security functions enum */
typedef enum {
    EZW_SAFETY_WORD_FCT_STO = 0,        /*!< Safe Torque Off function           */
    EZW_SAFETY_WORD_FCT_SBC_1,          /*!< Safe Brake Command type 1          */
    EZW_SAFETY_WORD_FCT_SBC_2,          /*!< Safe Brake Command type 2          */
    EZW_SAFETY_WORD_FCT_SBC_3,          /*!< Safe Brake Command type 3          */
    EZW_SAFETY_WORD_FCT_SLS_1,          /*!< Safe Limit Speed type 1            */
    EZW_SAFETY_WORD_FCT_SLS_2,          /*!< Safe Limit Speed type 2            */
    EZW_SAFETY_WORD_FCT_SLS_3,          /*!< Safe Limit Speed type 3            */
    EZW_SAFETY_WORD_FCT_SLS_4,          /*!< Safe Limit Speed type 4            */
    EZW_SAFETY_WORD_FCT_SLS_5,          /*!< Safe Limit Speed type 5            */
    EZW_SAFETY_WORD_FCT_SLS_6,          /*!< Safe Limit Speed type 6            */
    EZW_SAFETY_WORD_FCT_SLS_7,          /*!< Safe Limit Speed type 7            */
    EZW_SAFETY_WORD_FCT_SLS_8,          /*!< Safe Limit Speed type 8            */
    EZW_SAFETY_WORD_FCT_SDI_P_1,        /*!< Safe Direction Positive 1          */
    EZW_SAFETY_WORD_FCT_SDI_P_2,        /*!< Safe Direction Positive 2          */
    EZW_SAFETY_WORD_FCT_SDI_N_1,        /*!< Safe Direction Negative 1          */
    EZW_SAFETY_WORD_FCT_SDI_N_2,        /*!< Safe Direction Negative 2          */
    EZW_SAFETY_WORD_FCT_ERROR_ACK,      /*!< Safe Error Ack                     */
    EZW_SAFETY_WORD_FCT_RESTART_ACK,    /*!< Safe Restart Ack                   */
    EZW_SAFETY_WORD_FCT_SBU,            /*!< Safe Brake Unlock                  */
    EZW_SAFETY_WORD_FCT_SMS,            /*!< Safe Maximum Speed                 */
    EZW_SAFETY_WORD_FCT_SLSa_1,         /*!< Safe Limit Speed asymmetric type 1 */
    EZW_SAFETY_WORD_FCT_SLSa_2,         /*!< Safe Limit Speed asymmetric type 2 */
    EZW_SAFETY_WORD_FCT_SLSa_3,         /*!< Safe Limit Speed asymmetric type 3 */
    EZW_SAFETY_WORD_FCT_SLSa_4,         /*!< Safe Limit Speed asymmetric type 4 */
    EZW_SAFETY_WORD_FCT_SLSa_5,         /*!< Safe Limit Speed asymmetric type 5 */
    EZW_SAFETY_WORD_FCT_SLSa_6,         /*!< Safe Limit Speed asymmetric type 6 */
    EZW_SAFETY_WORD_FCT_SLSa_7,         /*!< Safe Limit Speed asymmetric type 7 */
    EZW_SAFETY_WORD_FCT_SLSa_8,         /*!< Safe Limit Speed asymmetric type 8 */
    NUMBER_OF_SAFETY_WORD_FCT
} ezw_safety_word_fct_t;

/** @brief Controlword enum */
typedef enum {
    EZW_SAFETY_WORD_SCW_CAN_1,              /*!< Safety control word can 1              */
    EZW_SAFETY_WORD_SCW_CAN_2,              /*!< Safety control word can 2              */
    EZW_SAFETY_WORD_SCW_CAN_3,              /*!< Safety control word can 3              */
    EZW_SAFETY_WORD_SCW_CAN_4,              /*!< Safety control word can 4              */
    EZW_SAFETY_WORD_SCW_CAN_5,              /*!< Safety control word can 5              */
    EZW_SAFETY_WORD_SCW_CAN_6,              /*!< Safety control word can 6              */
    EZW_SAFETY_WORD_SCW_CAN_7,              /*!< Safety control word can 7              */
    EZW_SAFETY_WORD_SCW_CAN_8,              /*!< Safety control word can 8              */
    EZW_SAFETY_WORD_SCW_SAFE_IN,            /*!< Safety control word safe inputs        */
    EZW_SAFETY_WORD_SCW_SYSTEM,             /*!< Safety control word system             */
    EZW_SAFETY_WORD_SCW_SAFEMOTION,         /*!< Safety control word motion             */
    EZW_SAFETY_WORD_SCW_PERMANENT_CAN_1,    /*!< Safety control word permanent can 1    */
    EZW_SAFETY_WORD_SCW_PERMANENT_CAN_2,    /*!< Safety control word permanent can 2    */
    NUMBER_OF_SAFETY_WORD_SAFETY_SCW
} ezw_safety_word_scw_type_t;

/** @brief Statusword enum */
typedef enum {
    EZW_SAFETY_WORD_SSW_CAN_1,              /*!< Safety status word can 1           */
    EZW_SAFETY_WORD_SSW_CAN_2,              /*!< Safety status word can 2           */
    EZW_SAFETY_WORD_SSW_CAN_3,              /*!< Safety status word can 3           */
    EZW_SAFETY_WORD_SSW_CAN_4,              /*!< Safety status word can 4           */
    EZW_SAFETY_WORD_SSW_CAN_5,              /*!< Safety status word can 5           */
    EZW_SAFETY_WORD_SSW_CAN_6,              /*!< Safety status word can 6           */
    EZW_SAFETY_WORD_SSW_CAN_7,              /*!< Safety status word can 7           */
    EZW_SAFETY_WORD_SSW_CAN_8,              /*!< Safety status word can 8           */
    EZW_SAFETY_WORD_SSW_SAFEOUT,            /*!< Safety status word safe output     */
    NUMBER_OF_SAFETY_WORD_SAFETY_SSW
} ezw_safety_word_ssw_type_t;

typedef uint32_t ezw_safety_word_dico_obj_t;

/** @brief Security function command objects indexes enum */
typedef enum {
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_RESTART_ACK = 0x66300000U, /*!< Restart acknowledge object command index                  */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_ERROR_ACK   = 0x66320000U, /*!< Error acknowledge object command index                    */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_STO         = 0x66400000U, /*!< Safe Torque Off object command index                      */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SBC_1       = 0x66600100U, /*!< Safe Brake Command type 1 object command index            */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SBC_2       = 0x66600200U, /*!< Safe Brake Command type 2 object command index            */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SBC_3       = 0x66600300U, /*!< Safe Brake Command type 3 object command index            */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLS_1       = 0x66900100U, /*!< Safe Limit Speed type 1 object command index              */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLS_2       = 0x66900200U, /*!< Safe Limit Speed type 2 object command index              */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLS_3       = 0x66900300U, /*!< Safe Limit Speed type 3 object command index              */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLS_4       = 0x66900400U, /*!< Safe Limit Speed type 4 object command index              */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLS_5       = 0x66900500U, /*!< Safe Limit Speed type 5 object command index              */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLS_6       = 0x66900600U, /*!< Safe Limit Speed type 6 object command index              */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLS_7       = 0x66900700U, /*!< Safe Limit Speed type 7 object command index              */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLS_8       = 0x66900800U, /*!< Safe Limit Speed type 8 object command index              */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SDI_P_1     = 0x66d00100U, /*!< Safe Direction Positive 1 object command index            */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SDI_P_2     = 0x66d00200U, /*!< Safe Direction Positive 2 object command index            */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SDI_N_1     = 0x66d10100U, /*!< Safe Direction Negative 1 object command index            */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SDI_N_2     = 0x66d10200U, /*!< Safe Direction Negative 2 object command index            */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SBU         = 0x30400000U, /*!< Safe Brake Unlock object command index                    */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLSa_1      = 0x30500100U, /*!< Safe Limit Speed asymmetric type 1 object command index   */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLSa_2      = 0x30500200U, /*!< Safe Limit Speed asymmetric type 2 object command index   */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLSa_3      = 0x30500300U, /*!< Safe Limit Speed asymmetric type 3 object command index   */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLSa_4      = 0x30500400U, /*!< Safe Limit Speed asymmetric type 4 object command index   */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLSa_5      = 0x30500500U, /*!< Safe Limit Speed asymmetric type 5 object command index   */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLSa_6      = 0x30500600U, /*!< Safe Limit Speed asymmetric type 6 object command index   */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLSa_7      = 0x30500700U, /*!< Safe Limit Speed asymmetric type 7 object command index   */
    EZW_SAFETY_WORD_FCT_COMMAND_INDEX_SLSa_8      = 0x30500800U, /*!< Safe Limit Speed asymmetric type 8 object command index   */
} ezw_safety_word_fct_command_index_t;

/** @brief Security function status objects indexes enum */
typedef enum {
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_RESTART_ACK  = 0x66310000U, /*!< Error ack object status index                             */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_ERROR_ACK    = 0x66330000U, /*!< Error ack object status index                             */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_STO          = 0x66440000U, /*!< Safe Torque Off object status index                       */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SBC_1        = 0x66670100U, /*!< Safe Brake Command type 1 object status index             */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SBC_2        = 0x66670200U, /*!< Safe Brake Command type 2 object status index             */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SBC_3        = 0x66670300U, /*!< Safe Brake Command type 3 object status index             */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLS_1        = 0x669f0100U, /*!< Safe Limit Speed type 1 object status index               */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLS_2        = 0x669f0200U, /*!< Safe Limit Speed type 2 object status index               */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLS_3        = 0x669f0300U, /*!< Safe Limit Speed type 3 object status index               */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLS_4        = 0x669f0400U, /*!< Safe Limit Speed type 4 object status index               */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLS_5        = 0x669f0500U, /*!< Safe Limit Speed type 5 object status index               */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLS_6        = 0x669f0600U, /*!< Safe Limit Speed type 6 object status index               */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLS_7        = 0x669f0700U, /*!< Safe Limit Speed type 7 object status index               */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLS_8        = 0x669f0800U, /*!< Safe Limit Speed type 8 object status index               */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SDI_P_1      = 0x66de0100U, /*!< Safe Direction Positive 1 object status index             */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SDI_P_2      = 0x66de0200U, /*!< Safe Direction Positive 2 object status index             */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SDI_N_1      = 0x66df0100U, /*!< Safe Direction Negative 1 object status index             */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SDI_N_2      = 0x66df0200U, /*!< Safe Direction Negative 2 object status index             */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SBU          = 0x30410000U, /*!< Safe Brake Unlock object status index                     */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SMS          = 0x66a80100U, /*!< Safe Maximum Speed object status index                    */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLSa_1       = 0x30590100U, /*!< Safe Limit Asymmetric Speed type 1 object status index    */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLSa_2       = 0x30590200U, /*!< Safe Limit Asymmetric Speed type 2 object status index    */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLSa_3       = 0x30590300U, /*!< Safe Limit Asymmetric Speed type 3 object status index    */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLSa_4       = 0x30590400U, /*!< Safe Limit Asymmetric Speed type 4 object status index    */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLSa_5       = 0x30590500U, /*!< Safe Limit Asymmetric Speed type 5 object status index    */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLSa_6       = 0x30590600U, /*!< Safe Limit Asymmetric Speed type 6 object status index    */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLSa_7       = 0x30590700U, /*!< Safe Limit Asymmetric Speed type 7 object status index    */
    EZW_SAFETY_WORD_FCT_STATUS_INDEX_SLSa_8       = 0x30590800U, /*!< Safe Limit Asymmetric Speed type 8 object status index    */
} ezw_safety_word_fct_status_index_t;

extern const ezw_safety_word_dico_obj_t ezw_safety_word_fct_to_dico_cmd[NUMBER_OF_SAFETY_WORD_FCT];
extern const ezw_safety_word_dico_obj_t ezw_safety_word_fct_to_dico_status[NUMBER_OF_SAFETY_WORD_FCT];

/* Functions ------------------------------------------- */

/**
 * @brief Getter for the function associated to a status object index
 *
 * @param status_dico_obj: Object index of the status function
 * @param *fct:  Pointer to store the safety word function enumeration number
 * @return error code: \n
 * ERROR_NONE if no error occurred \n
 * ERROR_ARGUMENT if safety function was not found
 */
ezw_error_t ezw_safety_word_status_get_fct(ezw_safety_word_dico_obj_t status_dico_obj, ezw_safety_word_fct_t *fct);

/**
 * @brief Getter for the function associated to a command object index
 *
 * @param cmd_dico_obj: Object index of the command function
 * @param *fct:  Pointer to store the safety word function enumeration number
 * @return error code: \n
 * ERROR_NONE if no error occurred \n
 * ERROR_ARGUMENT if safety function was not found
 */
ezw_error_t ezw_safety_word_command_get_fct(ezw_safety_word_dico_obj_t cmd_dico_obj, ezw_safety_word_fct_t *fct);

/** @} */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* EZW_SAFETY_WORD_COMMON_H */
