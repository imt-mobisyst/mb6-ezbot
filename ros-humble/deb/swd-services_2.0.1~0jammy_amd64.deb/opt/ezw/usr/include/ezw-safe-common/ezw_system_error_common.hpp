/*
 * Copyright (C) 2023 ez-Wheel S.A.S.
 *
 * @file ezw_system_error_common.h
 */

#ifndef EZW_SYSTEM_ERROR_COMMON_H
#define EZW_SYSTEM_ERROR_COMMON_H

/* Includes -------------------------------------------- */
#include "ezw_types.h"

#include <string>
#include <map>

/* Defines --------------------------------------------- */

/* Typedefs -------------------------------------------- */

extern const std::map<int32_t, std::pair<std::string, std::string>> ezw_system_error_code;

/* Functions ------------------------------------------- */

#endif /* EZW_SYSTEM_ERROR_COMMON_H */
