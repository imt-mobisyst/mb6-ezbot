/*
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file ezw_system_error_common.h
 * @brief Helper for system error thresholds
 */

#ifndef EZW_SYSTEM_ERROR_COMMON_H
#define EZW_SYSTEM_ERROR_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "ezw_types.h"

/** @defgroup ezw-system-error-common common
 * Common API functions.
 * @ingroup ezw-system-error
 * @{
 */

/** @defgroup ezw-system-error-common-typedefs typedefs
 * @ingroup ezw-system-error-common
 * @{
 */
typedef enum {
    EZW_SAFETY_CHECK_NORMAL  = 0U, /*!< Safety check OK status      */
    EZW_SAFETY_CHECK_WARNING = 1U, /*!< Safety check warning status */
    EZW_SAFETY_CHECK_ERROR   = 2U, /*!< Safety check error status   */
} ezw_system_error_status_t;

typedef enum {
    EZW_PROTECT_NONE                = 0U, /*!< No protection required                */
    EZW_PROTECT_ZERO_TORQUE_PROTECT = 1U, /*!< Disconnect torque protection required */
    EZW_PROTECT_BRAKE_CC_PROTECT    = 2U, /*!< Shunt brake required                  */
    EZW_PROTECT_APPLY_SBC_CONFIG    = 3U, /*!< Safe Brake Control protection         */
} ezw_system_error_protect_state_t;

typedef struct {
    uint8_t battery_uv;         /*!< Battery under voltage status         */
    uint8_t battery_ov;         /*!< Battery over voltage status          */
    uint8_t phase_oc;           /*!< Battery over current status          */
    uint8_t mos_ot;             /*!< MOS over temperature status          */
    uint8_t brake_mos_ot;       /*!< Internal brake MOS ot                */
    uint8_t drv_ot;             /*!< Driver motor over temperature status */
    uint8_t vsafe_uv;           /*!< VSafe undervoltage status */
} ezw_system_error_states_status_t;

typedef struct {
    int32_t  temp_hysteresis_rise_mos1;     /*!< Threshold temperature for motor MOS1 rise               */
    int32_t  temp_hysteresis_rise_mos2;     /*!< Threshold temperature for motor MOS2 rise               */
    int32_t  temp_hysteresis_rise_brake;    /*!< Threshold temperature for internal brake MOS rise       */
    int32_t  temp_hysteresis_fall_mos1;     /*!< Threshold temperature for motor MOS1 fall               */
    int32_t  temp_hysteresis_fall_mos2;     /*!< Threshold temperature for motor MOS2 fall               */
    int32_t  temp_hysteresis_fall_brake;    /*!< Threshold temperature for internal brake MOS fall       */
    uint32_t time_ms_zero_torque_protect;   /*!< Timeout for zero torque protection, triggers brake cc   */
    uint32_t time_ms_brake_cc_protect;      /*!< Timeout for cc brake, triggers SBC brake                */
    int32_t  battery_uv_warning;            /*!< Threshold for battery under voltage warning             */
    int32_t  battery_uv_error;              /*!< Threshold for battery under voltage error               */
    int32_t  battery_ov_warning;            /*!< Threshold for battery over voltage warning              */
    int32_t  battery_ov_error;              /*!< Threshold for battery over voltage error                */
    int32_t  phase_oc_warning;              /*!< Threshold for motor phase over current warning          */
    int32_t  phase_oc_error;                /*!< Threshold for motor phase over current error            */
    uint32_t battery_uv_warning_timeout_ms; /*!< Timeout for battery under voltage warning               */
    uint32_t battery_ov_warning_timeout_ms; /*!< Timeout for battery over voltage warning                */
    uint32_t phase_oc_warning_timeout_ms;   /*!< Timeout for motor phase over current warning            */
    float_t  phase_over_board_factor;       /*!< Mean current gain to apply to motor phase               */
} ezw_system_error_public_config_t;
/** @} */

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @} */

#endif /* EZW_SYSTEM_ERROR_COMMON_H */
