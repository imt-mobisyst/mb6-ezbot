/*
 * Copyright (C) 2018 EZ-Wheel S.A.S.
 *
 * This is a simple logging API meant for both system-level (linux)
 * or firmware level, attempting to keep compatible with
 * MISRA checking and tiny footprints. On Linux it will make use
 * or DLT if configured and available.
 *
 * @file ezw_log.h
 * @brief ezwLog API public header
 */

#ifndef EZW_LOG_H
#define EZW_LOG_H

#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "ezw_log_macro.h"

#ifdef ENABLE_DLT

#include <pthread.h>
#include <dlt/dlt.h>

#else

#include "ezw_log_msg.h"
#include "ezw_log_msg_encode.h"
#include "ezw_log_msg_decode.h"

#endif

#include "ezw_log_context.h"
#include "ezw_log_level.h"

/** @defgroup ezwlog ezwlog
 * EZWLOG module.
 */

/* Size for names buffers */
#define EZW_LOG_NAME_SZ 5

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief The Init routine, called once by each parent app.
 * do the one-time per app registration:
 * @see DLT_REGISTER_APP
 * @see DLT_REGISTER_CONTEXT for the default contexts
 * @return This function does not return a value.
 */
void ezw_log_init(const char app_key[EZW_LOG_NAME_SZ], const char* app_name);

/**
 * @brief The Exit routine, must be called once by each parent app.
 * call the onetime per app release stuff:
 * @see DLT_UNREGISTER_CONTEXT for the default contexts
 * @see DLT_UNREGISTER_APP
 * @return This function does not return a value.
 */
void ezw_log_exit(void);

/**
 * @brief Disable log.
 *
 */
void ezw_log_disable_log();

/**
 * @brief Enable log.
 *
 */
void ezw_log_enable_log();

/**
 * @brief Check if log enable.
 *
 */
bool ezw_log_is_enabled();

/**
 * @brief Limit for all ctx the print level.
 *
 * @param level maximal allowed print level
 */
void ezw_log_set_maximum_print_level(ezw_log_level_t level);

/**
 * @brief Limit for all ctx the print level.
 *
 * @param level maximal allowed print level
 */
void ezw_log_set_maximum_log_level(ezw_log_level_t level);

/**
 * @brief A simple string output function.
 * reduced log API to remain close to MISRA, no variadic routine, on purpose.
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text a string to output
 * @return This function does not return a value.
 */
void ezw_log_string(uint32_t contextid, ezw_log_level_t level,
                    const char* text);

/**
 * @brief A dual string output function.
 * reduced log API to remain close to MISRA, no variadic routine, on purpose.
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text1 a string to output
 * @param text2 a string to output
 * @return This function does not return a value.
 */
void ezw_log_string_string(uint32_t contextid, ezw_log_level_t level,
                           const char *text1, const char *text2);

/**
 * @brief A commented uint32 value.
 *
 * Integer values passed with this API remain typped in DLT viewer and
 * can be extracted and post-processed as such. This will not be degenerated
 * into a string.
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text a string to output, as a comment
 * @param val an integer value (uint32) to be monitored
 * @return This function does not return a value.
 */
void ezw_log_string_uint32(uint32_t contextid, ezw_log_level_t level,
                           uint32_t val, const char* text);

/**
 * @brief A commented int32 value.
 *
 * Integer values passed with this API remain typped in DLT viewer and
 * can be extracted and post-processed as such. This will not be degenerated
 * into a string.
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text a string to output, as a comment
 * @param val an integer value (int32) to be monitored
 * @return This function does not return a value.
 */
void ezw_log_string_int32(uint32_t contextid, ezw_log_level_t level,
                          int32_t val, const char* text);

/**
 * @brief A commented uint32 value, in hex display form.
 *
 * Integer values passed with this API remain typped in DLT viewer and
 * can be extracted and post-processed as such. This will not be degenerated
 * into a string.
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text a string to output, as a comment
 * @param val an integer value (uint32) to be monitored
 * @return This function does not return a value.
 */
void ezw_log_string_hex32(uint32_t contextid, ezw_log_level_t level,
                          uint32_t val, const char* text);

/**
 * @brief A commented float32 value.
 *
 * A float32 value passed with this API remains typped in DLT viewer and
 * can be extracted and post-processed as such. This will not be degenerated
 * into a string.
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text a string to output, as a comment
 * @param val a float (float32) value to be monitored
 * @return This function does not return a value.
 */
void ezw_log_string_float32(uint32_t contextid, ezw_log_level_t level,
                            float32_t val, const char* text);

/**
 * @brief A commented float64 value.
 *
 * A float64 value passed with this API remains typped in DLT viewer and
 * can be extracted and post-processed as such. This will not be degenerated
 * into a string.
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text a string to output, as a comment
 * @param val a float (float64) value to be monitored
 * @return This function does not return a value.
 */
void ezw_log_string_float64(uint32_t contextid, ezw_log_level_t level,
                            float64_t val, const char* text);

/**
 * @brief Routine setting thresholds for a context.
 *
 * For a given context (identified by its id), set the print threshold and log
 * threshold to the given values. If default value is given, no change is done.
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param print_threshold a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param log_threshold a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @return This function does not return a value.
 */
void ezw_log_set_context_thresholds(uint32_t contextid,
                                    ezw_log_level_t print_threshold, ezw_log_level_t log_threshold);

/**
 * @brief A commented uint64 value.
 *
 * Integer values passed with this API remain typped in DLT viewer and
 * can be extracted and post-processed as such. This will not be degenerated
 * into a string.
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text a string to output, as a comment
 * @param val an integer value (uint64) to be monitored
 * @return This function does not return a value.
 */
void ezw_log_string_uint64(uint32_t contextid, ezw_log_level_t level,
                           uint64_t val, const char* text);

/**
 * @brief A commented int64 value.
 *
 * Integer values passed with this API remain typped in DLT viewer and
 * can be extracted and post-processed as such. This will not be degenerated
 * into a string.
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text a string to output, as a comment
 * @param val an integer value (int64) to be monitored
 * @return This function does not return a value.
 */
void ezw_log_string_int64(uint32_t contextid, ezw_log_level_t level,
                          int64_t val, const char* text);

/**
 * @brief A commented uint64 value, in hex display form.
 *
 * Integer values passed with this API remain typped in DLT viewer and
 * can be extracted and post-processed as such. This will not be degenerated
 * into a string.
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text a string to output, as a comment
 * @param val an integer value (uint64) to be monitored
 * @return This function does not return a value.
 */
void ezw_log_string_hex64(uint32_t contextid, ezw_log_level_t level,
                          uint64_t val, const char* text);

/**
 * @brief A commented ezw_error_t value, in hex display form.
 *
 * Integer values passed with this API remain typped in DLT viewer and
 * can be extracted and post-processed as such. This will not be degenerated
 * into a string.
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param text a string to output, as a comment
 * @param err a ezw_error_t error to be monitored
 * @return This function does not return a value.
 */
void ezw_log_string_err(uint32_t contextid,
                        ezw_log_level_t level,
                        const char *function_name,
                        uint64_t file_line,
                        ezw_error_t err,
                        const char *detail);

#ifndef ENABLE_DLT

/**
 * @brief Send a log message either to the out_channel, or in the ring_buffer
 *
 * @param contextid the context ID, {@link CON_APP} and other possible values.
 * @param level a log level amongst {@link EZW_LOG_VERBOSE} and other values ({@link EZW_LOG_INFO} etc...)
 * @param msg the log message to send
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_send_msg(const uint32_t contextid, const ezw_log_level_t level, const ezw_log_msg_t* const msg);


/** @brief get log message buffer
 */
ezw_log_msg_t *ezw_log_msg_get_new_buffer();

/** @brief get log message free
 */
void ezw_log_msg_free_buffer(ezw_log_msg_t* msg_buffer);

/** @brief get log message size */
ezw_error_t ezw_log_msg_get_size(const ezw_log_msg_t * const msg, uint16_t * const size);

#if defined(HS_SERIAL)

#define BLOCK_SIZE 64
#define NUM_BLOCK 16

void ezw_log_serial_send_data_u8(uint8_t data);
void ezw_log_serial_send_data_u16(uint16_t data);
void ezw_log_serial_send_data_u32(uint32_t data);
void ezw_log_serial_send_data_i16(int16_t data);
void ezw_log_serial_send_data_i32(int32_t data);

#endif

#endif

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* EZW_LOG_H */
