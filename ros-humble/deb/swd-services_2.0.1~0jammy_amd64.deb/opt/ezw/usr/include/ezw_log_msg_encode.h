/*
 * Copyright (C) 2018 EZ-Wheel S.A.S.
 *
 * @brief ezw-log message encoding API public header
 */

#ifndef EZW_LOG_MSG_ENCODE_H
#define EZW_LOG_MSG_ENCODE_H

#include "ezw_log_msg.h"
#include "ezw_log_level.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/**
 * @brief initialize the message structure to enable encoding
 * @param[out] msg : message structure
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_begin(ezw_log_msg_t* const msg);

/**
 * @brief finalize the message structure to enable sending
 * @param[out] msg : message structure
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_end(ezw_log_msg_t* const msg);

/**
 * @brief encodes raw bytes (uint8_t) with type and size
 * @param[out] msg : message structure
 * @param[in] type : data type
 * @param[in] data : data to encode
 * @param[in] size : data size
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_raw(ezw_log_msg_t* const msg, const ezw_log_type_t type, const uint8_t* const data, const uint8_t size);

/**
 * @brief encodes a \0 terminated string, with a maximum size of 127
 * @param[out] msg : message structure
 * @param[in] str : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_str(ezw_log_msg_t* const msg, const char* const str);

/**
 * @brief encodes an int8_t value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_int8(ezw_log_msg_t* const msg, const int8_t val);

/**
 * @brief encodes an int16_t value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_int16(ezw_log_msg_t* const msg, const int16_t val);

/**
 * @brief encodes an int32_t value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_int32(ezw_log_msg_t* const msg, const int32_t val);

/**
 * @brief encodes an int64_t value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_int64(ezw_log_msg_t* const msg, const int64_t val);

/**
 * @brief encodes an uint8_t value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_uint8(ezw_log_msg_t* const msg, const uint8_t val);

/**
 * @brief encodes an uint16_t value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_uint16(ezw_log_msg_t* const msg, const uint16_t val);

/**
 * @brief encodes an uint32_t value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_uint32(ezw_log_msg_t* const msg, const uint32_t val);

/**
 * @brief encodes an uint64_t value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_uint64(ezw_log_msg_t* const msg, const uint64_t val);

/**
 * @brief encodes an unsigned value, with minimum size
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_uint(ezw_log_msg_t* const msg, const uint64_t val);

/**
 * @brief encodes a signed value, with minimum size
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_int(ezw_log_msg_t* const msg, const int64_t val);

/**
 * @brief encodes a float32_t value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_float32(ezw_log_msg_t* const msg, const float32_t val);

/**
 * @brief encodes a float64_t value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_float64(ezw_log_msg_t* const msg, const float64_t val);

/**
 * @brief encodes a float value, with minimum size
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_float(ezw_log_msg_t* const msg, const float64_t val);

/**
 * @brief encodes minimal header
 * @param[out] msg : message structure
 * @param[in] ctx : log context
 * @param[in] lvl : log level
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_header(ezw_log_msg_t* const msg, const uint32_t ctx, const ezw_log_level_t lvl);

/**
 * @brief encodes minimal error name
 * @param[out] msg : message structure
 * @param[in]  err : error level
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_err(ezw_log_msg_t* const msg, const ezw_error_t err);

/**
 * @brief encodes to hexadecimal value
 * @param[out] msg : message structure
 * @param[in] val : data to encode
 * @param[in] length : data length to encode
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_encode_hex(ezw_log_msg_t* const msg, const int64_t val, const size_t length);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif/*EZW_LOG_MSG_ENCODE_H*/
