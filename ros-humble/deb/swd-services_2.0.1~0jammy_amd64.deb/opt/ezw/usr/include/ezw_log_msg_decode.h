/*
 * Copyright (C) 2018 EZ-Wheel S.A.S.
 *
 * @brief ezw-log message decoding API public header
 */

#ifndef EZW_LOG_MSG_DECODE_H
#define EZW_LOG_MSG_DECODE_H

#include "ezw_log_msg.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/**
 * @brief initialize the index of the decoding sequence
 * @param[in] msg : message structure
 * @param[out] index : index (offset) of the decoding sequence
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_begin(const ezw_log_msg_t* const msg, uint8_t* const index);

/**
 * @brief gives the ending index of the decoding sequence, enabling iterator-like comparison
 * @param[in] msg : message structure
 * @param[out] index : index (offset) of the decoding sequence
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_end(const ezw_log_msg_t* const msg, uint8_t* const index);

/**
 * @brief gives the next index of the decoding sequence
 * @param[in] msg : message structure
 * @param[out] index : index (offset) of the decoding sequence
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_next(const ezw_log_msg_t* const msg, uint8_t* const index);

/**
 * @brief give the current message field's type
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] type : field's type
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_type(const ezw_log_msg_t* const msg, const uint8_t* const index, ezw_log_type_t* const type);

/**
 * @brief give the current message field's size
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] size : field's size
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_size(const ezw_log_msg_t* const msg, const uint8_t* const index, uint8_t* const size);

/**
 * @brief decodes raw value of the current field, checking type and size
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[in] type : field's type
 * @param[out] out : data buffer to be filled
 * @param[in] size : field's size
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_raw(const ezw_log_msg_t* const msg, const uint8_t* const index, const ezw_log_type_t type, uint8_t* const out, const uint8_t size);

/**
 * @brief decodes a string
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : string buffer to be filled
 * @param[in] out_size : string size
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_str(const ezw_log_msg_t* const msg, const uint8_t* const index, char* const out, const uint8_t out_size);

/**
 * @brief decodes an int8_t
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_int8(const ezw_log_msg_t* const msg, const uint8_t* const index, int8_t* const out);

/**
 * @brief decodes an int16_t
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_int16(const ezw_log_msg_t* const msg, const uint8_t* const index, int16_t* const out);

/**
 * @brief decodes an int32_t
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_int32(const ezw_log_msg_t* const msg, const uint8_t* const index, int32_t* const out);

/**
 * @brief decodes an int64_t
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_int64(const ezw_log_msg_t* const msg, const uint8_t* const index, int64_t* const out);

/**
 * @brief decodes an uint8_t
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_uint8(const ezw_log_msg_t* const msg, const uint8_t* const index, uint8_t* const out);

/**
 * @brief decodes an uint16_t
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_uint16(const ezw_log_msg_t* const msg, const uint8_t* const index, uint16_t* const out);

/**
 * @brief decodes an uint32_t
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_uint32(const ezw_log_msg_t* const msg, const uint8_t* const index, uint32_t* const out);

/**
 * @brief decodes an uint64_t
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_uint64(const ezw_log_msg_t* const msg, const uint8_t* const index, uint64_t* const out);

/**
 * @brief decodes an unsigned integer of any size (uint64_t being the max)
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_uint(const ezw_log_msg_t* const msg, const uint8_t* const index, uint64_t* const out);

/**
 * @brief decodes an signed integer of any size (int64_t being the max)
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_int(const ezw_log_msg_t* const msg, const uint8_t* const index, int64_t* const out);

/**
 * @brief decodes a float32_t
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_float32(const ezw_log_msg_t* const msg, const uint8_t* const index, float32_t* const out);

/**
 * @brief decodes a float64_t
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_float64(const ezw_log_msg_t* const msg, const uint8_t* const index, float64_t* const out);

/**
 * @brief decodes a float of any size (float64_t being the max)
 * @param[in] msg : message structure
 * @param[in] index : index (offset) of the deconding sequence
 * @param[out] out : pointer to data to be filled
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_log_msg_decode_float(const ezw_log_msg_t* const msg, const uint8_t* const index, float64_t* const out);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif/*EZW_LOG_MSG_DECODE_H*/
