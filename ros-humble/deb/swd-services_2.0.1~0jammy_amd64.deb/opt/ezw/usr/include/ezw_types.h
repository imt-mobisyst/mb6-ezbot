/*
 * Copyright (C) 2018 EZ-Wheel S.A.S
 *
 * @brief types definitions header
 */

#ifndef EZW_TYPES_H
#define EZW_TYPES_H

#include <stdint.h>
#include <stdbool.h>

/** @defgroup ezw-types-public-typedefs typedefs
 * @ingroup ezw-types-public
 * @{
 */

/** @brief Error type definition
 */
typedef enum {
    /**
     * @brief Not initialized error
     *
     * Must be returned when a module has not been initialized.
     * This error should not be forwarded.
     */
    ERROR_NOT_INITIALIZED,

    /**
     * @brief No error occurred
     *
     * Must be returned when no error happened.
     * This error can be forwarded.
     */
    ERROR_NONE,

    /**
     * @brief Hardware error
     *
     * Must be returned when a peripheral is in an invalid state.
     * This error can be forwarded.
     */
    ERROR_HARDWARE,

    /**
     * @brief Config error
     *
     * Must be returned when a module configuration is invalid.
     * This error can be forwarded.
     */
    ERROR_CONFIG,

    /**
     * @brief Argument error
     *
     * Must be returned when the function detect that at least one of it's arguments is invalid.
     * This error must not be forwarded, ERROR_INTERNAL may be forwarded instead.
     */
    ERROR_ARGUMENT,

    /**
     * @brief Internal error
     *
     * May be returned if a call to a function has returned ERROR_INVALID_ARG.
     * This error can be forwarded.
     */
    ERROR_INTERNAL,

    /**
     * @brief External error
     *
     * May be returned if a call to an other module has returned an error.
     * Must not be returned if the call has returned ERROR_INVALID_ARG.
     * This error can be forwarded.
     */
    ERROR_EXTERNAL,
} ezw_error_t;

/** @brief Time type (in seconds)
 */
typedef uint32_t time_s_t;

/** @brief Time type (in microseconds)
 */
typedef uint32_t time_us_t;

/** @brief Frequence type (in hertz)
 */
typedef uint32_t freq_hz_t;

/** @brief Angle type (in millidegrees)
 */
typedef int32_t angle_mdeg_t;

/** @brief Angular Speed type (in millidegrees per seconds)
 */
typedef int32_t angular_speed_mdeg_per_s_t;

/** @brief Normalized sin or cos value [-1,1]
 */
typedef float sin_cos_value_t;

/** @brief 64 bit tick count type definition
 */
typedef uint64_t tick_t;

/** @brief millisecond type definition
 */
typedef uint32_t time_ms_t;

/** @brief Day type definition
 */
typedef uint16_t time_day_t;

/** @brief SW time type definition
 */
typedef struct {
    time_day_t days;   /*!< milliseconds after midnight */
    time_ms_t  ms;     /*!< days since 01/01/1984       */
} sys_time_t;

/** @brief Float definition
 */
typedef float float_t;

/** @brief Char definition
 */
typedef char char_t;

/** @brief Application state type definition
 */
typedef enum _app_state {
    EZW_APPSTATE_UNKNOWN      = 0, /*!< Application state unknown      */
    EZW_APPSTATE_INITIALIZING = 1, /*!< Application state initializing */
    EZW_APPSTATE_ACTIVE       = 2, /*!< Application state active       */
    EZW_APPSTATE_ERROR        = 3, /*!< Application state error        */
    EZW_APPSTATE_WARNING      = 4, /*!< Application state warning      */
} ezw_app_state_t;

/** @brief Boolean type definition
 */
typedef enum {
    EZW_FALSE = 0U, /*!< ezw boolean value definition for false */
    EZW_TRUE = 1U,  /*!< ezw boolean value definition for true  */
} ezw_bool_t;

/** @} */

/** @defgroup ezw-types-public-defines defines
 * @ingroup ezw-types-public
 * @{
 */

#ifndef NULL
    #define NULL ((void *) 0U) /*!< Pointer NULL definition */
#endif

/** @} */

#endif /*EZW_TYPES_H*/
