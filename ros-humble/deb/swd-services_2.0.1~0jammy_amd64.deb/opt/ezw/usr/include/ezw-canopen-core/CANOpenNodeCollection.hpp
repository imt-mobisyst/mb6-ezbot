/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file CANOpenNodeCollection.hpp
 */

#ifndef EZW_CANOPENCORE_CANOPENNODECOLLECTION_HPP
#define EZW_CANOPENCORE_CANOPENNODECOLLECTION_HPP

/* Includes -------------------------------------------- */
#include <map>
#include <string>
#include <vector>

/* Defines --------------------------------------------- */

/* Class definition ------------------------------------ */
namespace ezw
{
    namespace canopencore
    {
        class CANOpenNode;

        class CANOpenNodeCollection {
          public:
            CANOpenNodeCollection(const std::map<std::string, CANOpenNode *> &pNodes);
            virtual ~CANOpenNodeCollection();

            /* Getters */
            CANOpenNode *              node(const std::string &pNodeName) const;
            CANOpenNode *              node(const uint8_t &pNodeID) const;
            std::vector<CANOpenNode *> nodes() const;

            /* Setters */

            /* Info/Status */
            size_t size() const;
            bool   empty() const;
            void   print() const;

          protected:
            std::map<std::string, CANOpenNode *> mNodes;
        };
    } // namespace canopencore
} // namespace ezw

#endif /* EZW_CANOPENCORE_CANOPENNODECOLLECTION_HPP */
