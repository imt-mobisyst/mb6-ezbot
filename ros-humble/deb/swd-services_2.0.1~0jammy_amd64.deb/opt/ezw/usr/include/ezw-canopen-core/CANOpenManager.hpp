/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file CANOpenManager.hpp
 */

#ifndef EZW_CANOPENCORE_CANOPENMANAGER_HPP
#define EZW_CANOPENCORE_CANOPENMANAGER_HPP

/* Includes -------------------------------------------- */
#include "CANOpenNodeCollection.hpp"

#include "ezw_log.h"

#include <map>
#include <string>

/* Defines --------------------------------------------- */

/* Class definition ------------------------------------ */
namespace ezw
{
    namespace canopencore
    {
        class CANOpenNode;

        class CANOpenManager : public CANOpenNodeCollection {
            static constexpr const char *mClassName = "CANOpenManager";

          public:
            CANOpenManager(const std::map<std::string, CANOpenNode *> &pNodes);
            virtual ~CANOpenManager();

            ezw_error_t initPDO(uint8_t pNodeID, const std::vector<uint8_t> &pPDONbrs, const std::vector<uint32_t> &pPDOAddresses);

            CANOpenNode *masterNode() const;
            bool         isCANBusOn() const;

            void setMasterNode(CANOpenNode *const pMasterNode);

            std::vector<std::pair<uint8_t, uint32_t>> getPDOAddresses(uint8_t pNodeID, uint32_t pAddress) const;

          private:
            CANOpenNode *                                                             mMasterNode;
            std::multimap<std::pair<uint8_t, uint32_t>, std::pair<uint8_t, uint32_t>> mPDOMapping;
        };
    } // namespace canopencore
} // namespace ezw

#endif /* EZW_CANOPENCORE_CANOPENMANAGER_HPP */
