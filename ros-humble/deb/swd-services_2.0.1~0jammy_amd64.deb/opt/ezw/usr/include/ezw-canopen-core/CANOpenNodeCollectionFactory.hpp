/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file CANOpenNodeCollectionFactory.hpp
 */

#ifndef EZW_CANOPENCORE_CANOPENNODECOLLECTIONFACTORY_HPP
#define EZW_CANOPENCORE_CANOPENNODECOLLECTIONFACTORY_HPP

/* Includes -------------------------------------------- */
#include <map>
#include <string>

/* Defines --------------------------------------------- */

/* Class definition ------------------------------------ */
namespace ezw
{
    namespace canopencore
    {
        class CANOpenNode;

        class CANOpenNodeCollectionFactory {
            static constexpr const char *mClassName = "CANOpenNodeCollectionFactory";

          public:
            /* Configuration parser */
            static std::map<std::string, CANOpenNode *> loadNodes(const std::string &pFilePath);
        };
    } // namespace canopencore
} // namespace ezw

#endif /* EZW_CANOPENCORE_CANOPENNODECOLLECTIONFACTORY_HPP */
