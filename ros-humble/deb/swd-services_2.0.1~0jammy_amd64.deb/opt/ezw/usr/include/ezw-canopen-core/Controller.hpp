/**
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file Controller.hpp
 */

#ifndef EZW_CANOPENCORE_CONTROLLER_HPP
#define EZW_CANOPENCORE_CONTROLLER_HPP

/* Includes -------------------------------------------- */
#include "CANOpenManager.hpp"
#include "IService.hpp"

#include "CANOpenNode.hpp"
#include "SDOResponse.hpp"

#include "ezw-canopen/gen_define.h"

#include "ezw-tools/TimerThread.hpp"

#include "ezw_log.h"
#include "ezw_types.h"

#include <memory>
#include <mutex>
#include <sstream> // std::stringstream
#include <string>
#include <sys/time.h> /* for gettimeofday */
#include <thread>

/* Defines --------------------------------------------- */
#define INDEX(A)     (A >> 16) & 0xFFFF
#define SUB_INDEX(A) (A >> 8) & 0xFF
#define LEN(A)       (A & 0xFF)
#define HEX(V)       toHex(V)

/**
 * function call to lock object dictionary
 */
#ifndef CO_OS_LOCK_OD
#define CO_OS_LOCK_OD
#endif /* CO_OS_LOCK_OD */

/**
 * function call to unlock object dictionary
 */
#ifndef CO_OS_UNLOCK_OD
#define CO_OS_UNLOCK_OD
#endif /* CO_OS_LOCK_OD */

/* Variable declaration -------------------------------- */

std::string toHex(uint32_t pValue);

/* Class ----------------------------------------------- */
namespace ezw
{
    namespace canopencore
    {
        class Controller : public IService {
            static constexpr const char *mClassName = "Controller";

          public:
            Controller();

            ~Controller() override;

            ezw_error_t init(const std::string &pNodeFile, bool pIsMaster = true);
            ezw_error_t initPDO(uint8_t pNodeID, const std::vector<uint8_t> &pPDONbrs, const std::vector<uint32_t> &pPDOAddresses) override;

            ezw_error_t can_init(const std::string &pCanSocketName = "can0", const std::vector<uint32_t> &pCanSocketFilter = {}) override;
            ezw_error_t can_close(const std::string &pCanSocketName = "can0") override;

            bool isInitialized() const override;

            ezw_error_t process() override;

            ezw_error_t getNmtState(const uint8_t &pNodeid, ezw_nmt_state_t &pNmtstate) override;
            ezw_error_t setNmtState(const uint8_t &pNodeid, const ezw_nmt_command_t &pNmtstate) override;

            // ------------------------------------
            // Get/Set value with targetName and dataName
            // ------------------------------------

            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, std::string &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const std::string &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, int64_t &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const int64_t &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, int32_t &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const int32_t &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, int16_t &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const int16_t &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, int8_t &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const int8_t &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, uint64_t &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const uint64_t &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, uint32_t &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const uint32_t &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, uint16_t &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const uint16_t &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, uint8_t &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const uint8_t &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, float &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const float &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, double &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const double &pData) override;
            ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, bool &pData) override;
            ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const bool &pData) override;

            // ------------------------------------
            // Get/Set value with object address
            // ------------------------------------

            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, std::string &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, std::string &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const std::string &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int64_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int64_t &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const int64_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int32_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int32_t &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const int32_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int16_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int16_t &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const int16_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int8_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int8_t &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const int8_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint64_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint64_t &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const uint64_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint32_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint32_t &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const uint32_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint16_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint16_t &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const uint16_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint8_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint8_t &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const uint8_t &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, float &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, float &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const float &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, double &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, double &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const double &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, bool &pData) override;
            ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, bool &pData, uint64_t &pTimestamp) override;
            ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const bool &pData) override;

            ezw_error_t getNodeId(uint8_t &pNodeid) override;

            // ------------------------------------

            ezw_error_t syncReset();
            ezw_error_t hbReset();

          protected:
            template <typename T> ezw_error_t readObject(const std::string &pTargetname, const std::string &pDataname, T *pData)
            {
                ezw_error_t lError = ERROR_NONE;

                // Check if bus is ON
                if (!mCANOpenManager->isCANBusOn()) {
                    return ERROR_INTERNAL;
                }

                const canopencore::CANOpenNode *const lNode = mCANOpenManager->node(pTargetname);

                if (nullptr == lNode) {
                    EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Requested for a value in a non-existant CANOpen node (" + pTargetname + ") !").c_str()));
                    lError = ERROR_ARGUMENT;
                }

                if (ERROR_NONE == lError) {
                    lError = lNode->getValue(pDataname, pData);
                    if (ERROR_NONE != lError) {
                        EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("lNode->getValue() failed !").c_str()));
                    } else {
                        std::ostringstream lStr;
                        lStr << *pData;

                        EZW_LOG(mContextId, EZW_LOG_DEBUG, EZW_STR(mClassName), EZW_STR(std::string("ReadObject (" + pTargetname + ", " + pDataname + ") = " + lStr.str()).c_str()));
                    }
                }

                return lError;
            }

            template <typename T> ezw_error_t writeObject(const std::string &pTargetname, const std::string &pDataname, T pData)
            {
                ezw_error_t lError = ERROR_NONE;

                // Check if bus is ON
                if (!mCANOpenManager->isCANBusOn()) {
                    return ERROR_INTERNAL;
                }

                const canopencore::CANOpenNode *const lNode = mCANOpenManager->node(pTargetname);

                if (nullptr == lNode) {
                    EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Attempting to set a value in a non-existant CANOpen node (" + pTargetname + ") !").c_str()));
                    lError = ERROR_ARGUMENT;
                }

                if (ERROR_NONE == lError) {
                    lError = lNode->setValue(pDataname, pData);
                    if (ERROR_NONE != lError) {
                        EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("lNode->setValue() failed !").c_str()));
                    } else {
                        std::ostringstream lStr;
                        lStr << pData;

                        EZW_LOG(mContextId, EZW_LOG_DEBUG, EZW_STR(mClassName), EZW_STR(std::string("WriteObject (" + pTargetname + ", " + pDataname + ") = " + lStr.str()).c_str()));
                    }
                }

                return lError;
            }

            template <typename T> ezw_error_t readObject(int pNodeId, int pAddress, T *pData, size_t pLen = sizeof(T))
            {
                ezw_error_t     lError    = ERROR_NONE;
                ezw_nmt_state_t lNmtState = EZW_CO_NMT_STATE_UNKNOWN;

                // Check if bus is ON
                if (!mCANOpenManager->isCANBusOn()) {
                    return ERROR_INTERNAL;
                }

                // Check if data is Mapped to PDO
                auto lPDOAddresses = mCANOpenManager->getPDOAddresses(pNodeId, pAddress);

                // Check if device is in OPER
                if (ERROR_NONE != ezw_canopen_get_nmt_state(pNodeId, &lNmtState)) {
                    EZW_LOG(CON_COS, EZW_LOG_ERROR, EZW_STR(("ezw_canopen_get_nmt_state with node " + std::to_string(pNodeId) + " failed !").c_str()));
                    return ERROR_INTERNAL;
                }

                if (lPDOAddresses.empty() || lNmtState != EZW_CO_NMT_STATE_OPER) {
                    /* The node is remote or remote is not in OPER, a SDO request is required */
                    lError = sendSDOReadRequest(pNodeId, INDEX(pAddress), SUB_INDEX(pAddress), pLen, pData);
                    if (ERROR_NONE != lError) {
                        EZW_LOG(CON_COS, EZW_LOG_ERROR, EZW_UINT(lError), EZW_STR(("sendSDOReadRequest nodeId=" + std::to_string(pNodeId) + " index=" + HEX(INDEX(pAddress)) + " subindex=" + HEX(SUB_INDEX(pAddress)) + " failed !").c_str()));
                    }
                    EZW_LOG(CON_COS, EZW_LOG_DEBUG, EZW_UINT(lError), EZW_STR(("sendSDOReadRequest nodeId=" + std::to_string(pNodeId) + " address=" + HEX(pAddress) + " index=" + HEX(INDEX(pAddress)) + " subindex=" + HEX(SUB_INDEX(pAddress))).c_str()));
                } else {
                    /* The node is local, an OD access is required */
                    /* Get a pointer to the value */
                    void *      ptr         = nullptr;
                    const void *const_ptr   = ptr;
                    uint32_t    lPDOAddress = lPDOAddresses.front().second;
                    lError                  = ezw_canopen_get_read_ptr(INDEX(lPDOAddress), SUB_INDEX(lPDOAddress), &const_ptr);
                    if (ERROR_NONE == lError) {
                        CO_OS_LOCK_OD
                        *pData = *(const T *)const_ptr;
                        CO_OS_UNLOCK_OD
                    } else {
                        EZW_LOG(CON_COS, EZW_LOG_ERROR, EZW_UINT(lError), EZW_STR(("ezw_canopen_get_read_ptr index=" + HEX(INDEX(lPDOAddress)) + " subindex=" + HEX(SUB_INDEX(lPDOAddress)) + " failed !").c_str()));
                    }

                    // std::ostringstream lStr;
                    // lStr << *pData;

                    // EZW_LOG(CON_COS, EZW_LOG_DEBUG, EZW_UINT(lError), EZW_STR(("PDO read nodeId=" + std::to_string(pNodeId) + " data=" + lStr.str() + " address=" + HEX(lPDOAddress) + " index=" + HEX(INDEX(lPDOAddress)) + " subindex=" + HEX(SUB_INDEX(lPDOAddress))).c_str()));
                }

                return lError;
            }

            template <typename T> ezw_error_t readObjectTS(int pNodeId, int pAddress, T *pData, uint64_t &pTimestamp, size_t pLen = sizeof(T))
            {
                ezw_error_t     lError    = ERROR_NONE;
                ezw_nmt_state_t lNmtState = EZW_CO_NMT_STATE_UNKNOWN;

                // Check if bus is ON
                if (!mCANOpenManager->isCANBusOn()) {
                    return ERROR_INTERNAL;
                }

                // Check if data is Mapped to PDO
                auto lPDOAddresses = mCANOpenManager->getPDOAddresses(pNodeId, pAddress);

                // Check if device is in OPER
                if (ERROR_NONE != ezw_canopen_get_nmt_state(pNodeId, &lNmtState)) {
                    EZW_LOG(CON_COS, EZW_LOG_ERROR, EZW_STR(("ezw_canopen_get_nmt_state with node " + std::to_string(pNodeId) + " failed !").c_str()));
                    return ERROR_INTERNAL;
                }

                if (lPDOAddresses.empty() || lNmtState != EZW_CO_NMT_STATE_OPER) {
                    /* The node is remote or remote is not in OPER, a SDO request is required */
                    lError = sendSDOReadRequest(pNodeId, INDEX(pAddress), SUB_INDEX(pAddress), pLen, pData);
                    if (ERROR_NONE == lError) {
                        struct timeval tv;
                        gettimeofday(&tv, NULL);
                        pTimestamp = tv.tv_sec * 1000000 + tv.tv_usec;
                        EZW_LOG(CON_COS, EZW_LOG_WARN, EZW_UINT(lError), EZW_STR(("readObjectTS nodeId=" + std::to_string(pNodeId) + " index=" + HEX(INDEX(pAddress)) + " subindex=" + HEX(SUB_INDEX(pAddress)) + " not sent with TPDO !").c_str()));
                    }
                    EZW_LOG(CON_COS, EZW_LOG_DEBUG, EZW_UINT(lError), EZW_STR(("sendSDOReadRequest nodeId=" + std::to_string(pNodeId) + " address=" + HEX(pAddress) + " index=" + HEX(INDEX(pAddress)) + " subindex=" + HEX(SUB_INDEX(pAddress))).c_str()));
                } else {
                    /* The node is local, an OD access is required */
                    /* Get a pointer to the value */
                    void *      ptr       = nullptr;
                    const void *const_ptr = ptr;

                    uint8_t  lPDONbr     = 0;
                    uint32_t lPDOAddress = 0;
                    uint64_t lTimestamp  = 0;
                    pTimestamp           = 0;
                    for (auto &elt : lPDOAddresses) {
                        lPDONbr     = elt.first;
                        lPDOAddress = elt.second;

                        lError = ezw_canopen_get_read_ptr_ts(INDEX(lPDOAddress), SUB_INDEX(lPDOAddress), lPDONbr, &const_ptr, &lTimestamp);
                        if (ERROR_NONE == lError) {
                            if (lTimestamp > pTimestamp) {
                                // The value is more recent
                                pTimestamp = lTimestamp;

                                // CO_OS_LOCK_OD
                                *pData = *(const T *)const_ptr;
                                // CO_OS_UNLOCK_OD
                            }
                        } else {
                            EZW_LOG(CON_COS, EZW_LOG_ERROR, EZW_UINT(lError), EZW_STR(("ezw_canopen_get_read_ptr index=" + HEX(INDEX(lPDOAddress)) + " subindex=" + HEX(SUB_INDEX(lPDOAddress)) + " pdo_nbr=" + std::to_string(lPDONbr) + " failed !").c_str()));
                        }
                    }

                    // std::ostringstream lStr;
                    // lStr << *pData;

                    // EZW_LOG(CON_COS, EZW_LOG_DEBUG, EZW_UINT(lError), EZW_STR(("PDO read nodeId=" + std::to_string(pNodeId) + " data=" + lStr.str() + " address=" + HEX(lPDOAddress) + " index=" + HEX(INDEX(lPDOAddress)) + " subindex=" + HEX(SUB_INDEX(lPDOAddress))).c_str()));
                }

                return lError;
            }

            template <typename T> ezw_error_t writeObject(int pNodeId, int pAddress, T pData)
            {
                ///////////////////////////////////////////////////
                // Write PDO :
                //     - If mapping exist data shall be written to local object
                //       and will be sent to distant object via PDO
                //
                // Write SDO :
                //     - If mapping do not exist, data shall be sent to distant
                //       object via SDO
                //     - If target is not in NMT:OPER data shall be sent to
                //       distant object via SDO because PDO are ONLY active in
                //       NMT:OPER

                ezw_error_t     lError    = ERROR_NONE;
                ezw_nmt_state_t lNmtState = EZW_CO_NMT_STATE_UNKNOWN;

                // Check if bus is ON
                if (!mCANOpenManager->isCANBusOn()) {
                    return ERROR_INTERNAL;
                }

                // Check if data is Mapped to PDO
                auto lPDOAddresses = mCANOpenManager->getPDOAddresses(pNodeId, pAddress);

                // Check if device is in OPER
                if (ERROR_NONE != ezw_canopen_get_nmt_state(pNodeId, &lNmtState)) {
                    EZW_LOG(CON_COS, EZW_LOG_ERROR, EZW_STR(("ezw_canopen_get_nmt_state with node " + std::to_string(pNodeId) + " failed !").c_str()));
                    return ERROR_INTERNAL;
                }

                ///////////////////////////////////////////////////
                // Write PDO :
                if (!lPDOAddresses.empty()) {
                    uint32_t lPDOAddress = lPDOAddresses.front().second;

                    std::ostringstream lStr;
                    lStr << pData;
                    EZW_LOG(CON_COS, EZW_LOG_DEBUG, EZW_UINT(lError), EZW_STR(("PDO write nodeId=" + std::to_string(pNodeId) + " data=" + lStr.str() + " address=" + HEX(lPDOAddress) + " index=" + HEX(INDEX(lPDOAddress)) + " subindex=" + HEX(SUB_INDEX(lPDOAddress))).c_str()));

                    /* The node is local, an OD access is required */
                    /* Get a pointer to the value */
                    void *ptr = nullptr;
                    lError    = ezw_canopen_get_write_ptr(INDEX(lPDOAddress), SUB_INDEX(lPDOAddress), &ptr);
                    if (ERROR_NONE == lError) {
                        CO_OS_LOCK_OD
                        *(T *)ptr = pData;
                        CO_OS_UNLOCK_OD
                    } else {
                        EZW_LOG(CON_COS, EZW_LOG_ERROR, EZW_UINT(lError), EZW_STR(("ezw_canopen_get_write_ptr index=" + HEX(INDEX(lPDOAddress)) + " subindex=" + HEX(SUB_INDEX(lPDOAddress)) + " failed !").c_str()));
                    }
                }
                // NOTA : Do not make a else with the "Write SDO" block
                // => it allows in some case to write value in both local (PDO) and remote (SDO) dictionnaries

                ///////////////////////////////////////////////////
                // Write SDO :
                if (lPDOAddresses.empty() || (pNodeId != 1 && lNmtState != EZW_CO_NMT_STATE_OPER)) {
                    lError = sendSDOWriteRequest(pNodeId, INDEX(pAddress), SUB_INDEX(pAddress), sizeof(pData), &pData);
                    if (ERROR_NONE != lError) {
                        EZW_LOG(CON_COS, EZW_LOG_ERROR, EZW_UINT(lError), EZW_STR(("sendSDOWriteRequest nodeId=" + std::to_string(pNodeId) + " index=" + HEX(INDEX(pAddress)) + " subindex=" + HEX(SUB_INDEX(pAddress)) + " failed !").c_str()));
                    }
                    EZW_LOG(CON_COS, EZW_LOG_DEBUG, EZW_UINT(lError), EZW_STR(("sendSDOWriteRequest nodeId=" + std::to_string(pNodeId) + " address=" + HEX(pAddress) + " index=" + HEX(INDEX(pAddress)) + " subindex=" + HEX(SUB_INDEX(pAddress))).c_str()));
                }

                return lError;
            }

          private:
            bool mInitialized;
            int  mContextId;

            tools::TimerThread mTimerThread;
            tools::TimerThread mTransmitThread;

            std::unique_ptr<CANOpenManager> mCANOpenManager;
        };
    } // namespace canopencore
} // namespace ezw

#endif /* EZW_CANOPENCORE_CONTROLLER_HPP */
