/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file CANOpenDictionaryEntry.hpp
 */

#ifndef EZW_CANOPENCORE_CANOPENDICTIONARYENTRY_HPP
#define EZW_CANOPENCORE_CANOPENDICTIONARYENTRY_HPP

/* Includes -------------------------------------------- */
#include "ezw_types.h"

#include <string>

/* Defines --------------------------------------------- */

/* Class definition ------------------------------------ */
namespace ezw
{
    namespace canopencore
    {
        typedef enum
        {
            // CO_CSV_UNKNOWN_ACCESS_RIGHTS,
            CO_CSV_RDONLY,
            CO_CSV_WRONLY,
            CO_CSV_RDWR,
            CO_CSV_RDWRRD,
            CO_CSV_RDWRWR,
            CO_CSV_CONST
        } CO_CSV_ACCESS_RIGHTS_t;

        typedef enum
        {
            // CO_CSV_IMPL_TYPE_UNKNOWN,
            CO_CSV_IMPL_TYPE_MANAGED_CONST,
            CO_CSV_IMPL_TYPE_MANAGED_VAR,
            CO_CSV_IMPL_TYPE_VAR,
        } CO_CSV_IMPL_TYPE_t;

        typedef enum
        {
            // CO_CSV_IMPL_TYPE_UNKNOWN,
            CO_CSV_DEFAULT_IN_EDS_NO               = 0,
            CO_CSV_DEFAULT_IN_EDS_AS_DEFAULT_VALUE = 1,
            CO_CSV_DEFAULT_IN_EDS_YES              = 2,
        } CO_CSV_DEFAULT_IN_EDS_t;

        typedef struct {
            uint16_t index;
            uint8_t  subIndex;
        } CO_OBJ_ADDR_t;

        class CANOpenDictionaryEntry {
          public:
            CANOpenDictionaryEntry();
            virtual ~CANOpenDictionaryEntry();

            /* Getters */
            std::string        entryAddress() const;
            static std::string entryAddress(const uint16_t &pIndex, const uint8_t &pSub);

            uint16_t                index() const;
            uint8_t                 sub() const;
            std::string             entryName() const;
            std::string             datatype() const;
            CO_CSV_ACCESS_RIGHTS_t  access() const;
            std::string             value() const;
            std::string             varname() const;
            std::string             lowLimit() const;
            std::string             upLimit() const;
            bool                    hasDefault() const;
            bool                    hasLimit() const;
            bool                    refuseRead() const;
            bool                    refuseWrite() const;
            CO_CSV_DEFAULT_IN_EDS_t defaultInEDS() const;
            CO_CSV_IMPL_TYPE_t      implType() const;
            size_t                  size() const;
            std::string             objectCode() const;
            std::string             mapable() const;
            bool                    validity() const;
            void *                  coptr() const;

            /* Setters */
            void setIndex(const uint16_t &pIndex);
            void setSub(const uint8_t &pSub);
            void setEntryName(const std::string &pEntryName);
            void setDatatype(const std::string &pDataType);
            void setAccess(const CO_CSV_ACCESS_RIGHTS_t &pAccess);
            void setValue(const std::string &pValue);
            void setVarname(const std::string &pVarName);
            void setLowLimit(const std::string &pLowLimit);
            void setUpLimit(const std::string &pUpLimit);
            void setHasDefault(const bool &pHasDefault);
            void setHasLimit(const bool &pHasLimit);
            void setRefuseRead(const bool &pRefuseRead);
            void setRefuseWrite(const bool &pRefuseWrite);
            void setDefaultInEDS(const CO_CSV_DEFAULT_IN_EDS_t &pDefaultInEDS);
            void setImplementationType(const CO_CSV_IMPL_TYPE_t &pImplType);
            void setSize(const size_t &pSize);
            void setObjectCode(const std::string &pObjectCode);
            void setMapable(const std::string &pMapable);
            void setValidity(const bool &pValidity);

            void setCoptr(void *pcoptr);

            /* Print */
            void print() const;

          private:
            // type_t setVar // <CSV entry equivalent>
            uint16_t                mIndex;        // Index
            uint8_t                 mSub;          // Sub
            std::string             mEntryName;    // EDSName
            std::string             mDatatype;     // Datatype
            CO_CSV_ACCESS_RIGHTS_t  mAccess;       // Access
            std::string             mValue;        // Value
            std::string             mVarname;      // Varname
            std::string             mLowLimit;     // LowLimit
            std::string             mUpLimit;      // UpLimit
            bool                    mHasDefault;   // HasDefault
            bool                    mHasLimit;     // HasLimit
            bool                    mRefuseRead;   // RefuseRead
            bool                    mRefuseWrite;  // RefuseWrite
            CO_CSV_DEFAULT_IN_EDS_t mDefaultInEDS; // DefaultInEDS
            CO_CSV_IMPL_TYPE_t      mImplType;     // ImplementationType
            size_t                  mSize;         // Size
            std::string             mObjectCode;   // ObjectCode
            std::string             mMapable;      // Mapable

            void *mCoptr;

            bool mValidity; // Is this dictionary entry valid ? Set by Factory.
        };
    } // namespace canopencore
} // namespace ezw

#endif /* EZW_CANOPENCORE_CANOPENDICTIONARYENTRY_HPP */
