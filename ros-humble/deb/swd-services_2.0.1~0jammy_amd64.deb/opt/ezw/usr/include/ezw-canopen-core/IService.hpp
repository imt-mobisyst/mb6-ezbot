/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file IService.hpp
 */

#ifndef EZW_CANOPENCORE_ISERVICE_HPP
#define EZW_CANOPENCORE_ISERVICE_HPP

#include "ezw_types.h"

#include "ezw-canopen/ezw_canopen.h"

#include <memory>
#include <string>
#include <vector>

namespace ezw
{
    namespace canopencore
    {
        class IService {
          public:
            // Make a virtual destructor in case we delete an I<pointer>, so the proper derived destructor is called
            virtual ~IService() = default;

            virtual ezw_error_t initPDO(uint8_t pNodeID, const std::vector<uint8_t> &pPDONbrs, const std::vector<uint32_t> &pPDOAddresses) = 0;

            virtual ezw_error_t can_init(const std::string &pCanSocketName = "can0", const std::vector<uint32_t> &pCanSocketFilter = {}) = 0;
            virtual ezw_error_t can_close(const std::string &pCanSocketName = "can0")                                                    = 0;

            virtual bool isInitialized() const = 0;

            virtual ezw_error_t process() = 0;

            virtual ezw_error_t getNmtState(const uint8_t &pNodeid, ezw_nmt_state_t &pNmtstate)         = 0;
            virtual ezw_error_t setNmtState(const uint8_t &pNodeid, const ezw_nmt_command_t &pNmtstate) = 0;

            virtual ezw_error_t getNodeId(uint8_t &pNodeid) = 0;

            // ------------------------------------
            // Get/Set value with targetName and dataName
            // ------------------------------------

            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, std::string &pData)       = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const std::string &pData) = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, int64_t &pData)           = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const int64_t &pData)     = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, int32_t &pData)           = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const int32_t &pData)     = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, int16_t &pData)           = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const int16_t &pData)     = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, int8_t &pData)            = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const int8_t &pData)      = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, uint64_t &pData)          = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const uint64_t &pData)    = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, uint32_t &pData)          = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const uint32_t &pData)    = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, uint16_t &pData)          = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const uint16_t &pData)    = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, uint8_t &pData)           = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const uint8_t &pData)     = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, float &pData)             = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const float &pData)       = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, double &pData)            = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const double &pData)      = 0;
            virtual ezw_error_t getValue(const std::string &pTargetname, const std::string &pDataname, bool &pData)              = 0;
            virtual ezw_error_t setValue(const std::string &pTargetname, const std::string &pDataname, const bool &pData)        = 0;

            // ------------------------------------
            // Get/Set value with object address
            // ------------------------------------

            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, std::string &pData)                       = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, std::string &pData, uint64_t &pTimestamp) = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const std::string &pData)                 = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int64_t &pData)                           = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int64_t &pData, uint64_t &pTimestamp)     = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const int64_t &pData)                     = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int32_t &pData)                           = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int32_t &pData, uint64_t &pTimestamp)     = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const int32_t &pData)                     = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int16_t &pData)                           = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int16_t &pData, uint64_t &pTimestamp)     = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const int16_t &pData)                     = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int8_t &pData)                            = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, int8_t &pData, uint64_t &pTimestamp)      = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const int8_t &pData)                      = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint64_t &pData)                          = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint64_t &pData, uint64_t &pTimestamp)    = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const uint64_t &pData)                    = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint32_t &pData)                          = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint32_t &pData, uint64_t &pTimestamp)    = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const uint32_t &pData)                    = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint16_t &pData)                          = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint16_t &pData, uint64_t &pTimestamp)    = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const uint16_t &pData)                    = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint8_t &pData)                           = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, uint8_t &pData, uint64_t &pTimestamp)     = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const uint8_t &pData)                     = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, float &pData)                             = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, float &pData, uint64_t &pTimestamp)       = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const float &pData)                       = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, double &pData)                            = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, double &pData, uint64_t &pTimestamp)      = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const double &pData)                      = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, bool &pData)                              = 0;
            virtual ezw_error_t getValue(const uint8_t &pNodeid, const uint32_t &pAddress, bool &pData, uint64_t &pTimestamp)        = 0;
            virtual ezw_error_t setValue(const uint8_t &pNodeid, const uint32_t &pAddress, const bool &pData)                        = 0;
        };
    } // namespace canopencore
} // namespace ezw

#endif /* EZW_CANOPENCORE_ISERVICE_HPP */
