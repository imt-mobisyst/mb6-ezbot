/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file SDOResponse.hpp
 */

#ifndef EZW_CANOPENCORE_SDORESPONSE_HPP
#define EZW_CANOPENCORE_SDORESPONSE_HPP

/* Includes -------------------------------------------- */
#include "ezw-canopen/ezw_canopen.h"

#include "ezw_log.h"

#include "ezw_types.h"

/* Defines --------------------------------------------- */

/* Functions ------------------------------------------- */
namespace ezw
{
    namespace canopencore
    {
        ezw_error_t sendSDOReadRequest(uint8_t pNodeID, uint16_t pIndex, uint8_t pSubIndex, size_t pLen, void *const out);
        ezw_error_t sendSDOWriteRequest(uint8_t pNodeID, uint16_t pIndex, uint8_t pSubIndex, size_t pLen, const void *const in);
    } // namespace canopencore
} // namespace ezw

#endif /* EZW_CANOPENCORE_SDORESPONSE_HPP */
