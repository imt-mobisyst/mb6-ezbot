/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file CANOpenNode.hpp
 */

#ifndef EZW_CANOPENCORE_CANOPENNODE_HPP
#define EZW_CANOPENCORE_CANOPENNODE_HPP

/* Includes -------------------------------------------- */
#include "ezw_types.h"

#include "ezw-canopen/ezw_canopen.h"

#include <map>
#include <string>
#include <vector>

/* Defines --------------------------------------------- */

/* Class definition ------------------------------------ */
namespace ezw
{
    namespace canopencore
    {
        class CANOpenDictionaryEntry;

        class CANOpenNode {
          public:
            CANOpenNode();
            CANOpenNode(const uint8_t pNodeID, const std::string &pName, const bool &pIsRemote = false);
            CANOpenNode(const uint8_t pNodeID, const std::string &pName, const std::map<std::string, CANOpenDictionaryEntry *> pMap, const bool &pIsRemote = false);
            virtual ~CANOpenNode();

            /* Getters */
            uint8_t     nodeID() const;
            std::string name() const;
            bool        isRemote() const;
            bool        validity() const;

            const CANOpenDictionaryEntry *getEntryByIndexSubindex(const uint16_t &pIndex, const uint8_t &pSub) const;

            /* [get/set]Value by Index & SubIndex */
            /* String */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, std::string *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, std::string *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const std::string &in) const;

            /* Int64 */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, int64_t *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, int64_t *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const int64_t &in) const;

            /* Int32 */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, int32_t *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, int32_t *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const int32_t &in) const;

            /* Int16 */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, int16_t *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, int16_t *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const int16_t &in) const;

            /* Int8 */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, int8_t *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, int8_t *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const int8_t &in) const;

            /* UInt64 */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, uint64_t *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, uint64_t *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const uint64_t &in) const;

            /* UInt32 */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, uint32_t *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, uint32_t *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const uint32_t &in) const;

            /* UInt16 */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, uint16_t *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, uint16_t *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const uint16_t &in) const;

            /* UInt8 */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, uint8_t *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, uint8_t *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const uint8_t &in) const;

            /* Float */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, float *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, float *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const float &in) const;

            /* Double */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, double *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, double *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const double &in) const;

            /* Bool */
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, bool *const out) const;
            ezw_error_t getValue(const uint16_t &pIndex, const uint8_t &pSub, bool *const out, uint64_t *const pTimestamp) const;
            ezw_error_t setValue(const uint16_t &pIndex, const uint8_t &pSub, const bool &in) const;

            /* [get/set]Value by data name/EDSName */
            /* String */
            ezw_error_t getValue(const std::string &pDataName, std::string *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const std::string &in) const;

            /* Int64 */
            ezw_error_t getValue(const std::string &pDataName, int64_t *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const int64_t &in) const;

            /* Int32 */
            ezw_error_t getValue(const std::string &pDataName, int32_t *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const int32_t &in) const;

            /* Int16 */
            ezw_error_t getValue(const std::string &pDataName, int16_t *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const int16_t &in) const;

            /* Int8 */
            ezw_error_t getValue(const std::string &pDataName, int8_t *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const int8_t &in) const;

            /* UInt64 */
            ezw_error_t getValue(const std::string &pDataName, uint64_t *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const uint64_t &in) const;

            /* UInt32 */
            ezw_error_t getValue(const std::string &pDataName, uint32_t *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const uint32_t &in) const;

            /* UInt16 */
            ezw_error_t getValue(const std::string &pDataName, uint16_t *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const uint16_t &in) const;

            /* UInt8 */
            ezw_error_t getValue(const std::string &pDataName, uint8_t *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const uint8_t &in) const;

            /* Float */
            ezw_error_t getValue(const std::string &pDataName, float *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const float &in) const;

            /* Double */
            ezw_error_t getValue(const std::string &pDataName, double *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const double &in) const;

            /* Bool */
            ezw_error_t getValue(const std::string &pDataName, bool *const out) const;
            ezw_error_t setValue(const std::string &pDataName, const bool &in) const;

            /* Setters */
            ezw_error_t setNodeID(const uint8_t &pNodeID);
            void        setName(const std::string &pName);
            void        setIsRemote(const bool &pIsRemote);
            void        setContents(const std::map<std::string, CANOpenDictionaryEntry *> &pDictionary);
            void        setValidity(const bool &pValidity);

            /* Info/Status */
            bool                                  empty() const;
            size_t                                size() const;
            void                                  print() const;
            std::vector<CANOpenDictionaryEntry *> entries() const;

          private:
            uint8_t                                         mNodeID;
            std::string                                     mName;
            bool                                            mIsRemote;
            std::map<std::string, CANOpenDictionaryEntry *> mDictionary;

            bool mValidity; // Is this node entry valid ? Set by Factory.
        };
    } // namespace canopencore
} // namespace ezw

#endif /* EZW_CANOPENCORE_CANOPENNODE_HPP */
