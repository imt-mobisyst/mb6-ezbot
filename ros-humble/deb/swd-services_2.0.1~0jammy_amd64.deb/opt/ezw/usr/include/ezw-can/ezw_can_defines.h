/*
 * Copyright (C) 2018 EZ-Wheel S.A.S
 *
 * @brief defines definitions header
 */

#ifndef EZW_DEFINES_H_
#define EZW_DEFINES_H_

/* Defines --------------------------------------------- */
#define EZW_CAN_NUMOF            1U
#define EZW_CAN_SOCKET_PATH_SZ   128
#define EZW_CAN_SOCKET_FILTER_SZ 32

#endif /* EZW_DEFINES_H_ */
