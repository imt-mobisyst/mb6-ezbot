/**
 * Copyright (C) 2018 EZ-Wheel S.A.S.
 *
 * @file ezw_can.h
 * @brief EZW CAN main source code header
 */

#ifndef EZW_CAN_H
#define EZW_CAN_H

/* Includes -------------------------------------------- */
#include "ezw_can_defines.h"
#include "ezw_types.h"

/* Defines --------------------------------------------- */
#define EZW_CAN_DATA_SZ 8U

/** @defgroup ezw-can ezw-can
 * @brief EZ-Wheel CAN module.
 *
 * Related Files :
 * - ezw_can.h
 * - ezw_can.c
 *
 * @addtogroup ezw-can
 * @{
 */

/* Typedefs -------------------------------------------- */
/** @typedef typedef uint32_t ezw_can_id_t
 * @brief Instance identifier in a private global table of objects
 */
typedef uint32_t ezw_can_id_t;

/** @typedef typedef struct ezw_can_msg_t
 * @brief This structure defines the CAN message used in
 * the EZW CAN module
 */
typedef struct {
    uint32_t msg_id;
    uint8_t  data_sz;
    uint8_t  data[EZW_CAN_DATA_SZ];
    uint8_t  flags;
    uint64_t timestamp; /* in µsec */
} ezw_can_msg_t;

/** @typedef typedef struct ezw_can_error_level_t
 * @brief This structure defines the CAN bus error levels
 */
typedef enum _can_error_level
{
    EZW_CAN_ACTIVE  = 0x00, /* When RX- and TX error counters are below 96 */
    EZW_CAN_WARNING = 0x40, /* When RX- or TX error counter are between 96 and 127 */
    EZW_CAN_PASSIVE = 0x20, /* When RX- or TX error counter are between 128 and 255 */
    EZW_CAN_BUS_OFF = 0x80, /* When RX- or TX error counter are above 255 */
} ezw_can_error_level_t;

/** @typedef typedef struct ezw_can_error_type_t
 * @brief This structure defines the CAN bus error types
 */
typedef enum _can_error_type
{
    EZW_CAN_ERROR_OK          = 0, /* When no CAN error occurred */
    EZW_CAN_ERROR_STUFF       = 1, /* When a stuff error occurred on RX message */
    EZW_CAN_ERROR_FORMAT      = 2, /* When a form/format error occurred on RX message */
    EZW_CAN_ERROR_ACKNOWLEDGE = 3, /* When a TX message wasn't acknowledged */
    EZW_CAN_ERROR_BIT1        = 4, /* When a TX message monitored dominant level where recessive is expected */
    EZW_CAN_ERROR_BIT0        = 5, /* When a TX message monitored recessive level where dominant is expected */
    EZW_CAN_ERROR_CRC         = 6, /* When a RX message has wrong CRC value */
    EZW_CAN_ERROR_HARDWARE    = 7, /* When a tranceiver/hardware error occurred */
    EZW_CAN_ERROR_NO          = 8, /* When no error occurred since last call of this function */
    EZW_CAN_ERROR_RECOVERY    = 9, /* When no error occurred since last call of this function */
} ezw_can_error_type_t;

/* Variable declaration -------------------------------- */

/* Initiation functions -------------------------------- */
/** @fn bool ezw_can_is_connected(const ezw_can_id_t ezw_can_id)
 * @brief Check if ezw_can module is connected
 * @param[in] ezw_can_id   The id of the ezw-can module being used
 * @return Bool : 0 if not inited, 1 elsewise
 */
bool ezw_can_is_connected(const ezw_can_id_t ezw_can_id);

/** @fn ezw_error_t ezw_can_init(const ezw_can_id_t ezw_can_id)
 * @brief Initialize ezw_can instance specified with index
 * @param[in] ezw_can_id   The id of the ezw-can module being used
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_init(const ezw_can_id_t ezw_can_id);

/**
 * @brief Close the ezw_can instance specified with index
 *
 * @param ezw_can_id    The id of the ezw-can module being used
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_close(const ezw_can_id_t ezw_can_id);

/* Getters --------------------------------------------- */
/** @fn ezw_error_t ezw_can_is_bus_on(const ezw_can_id_t ezw_can_id, bool * const out)
 * @brief Get the status of the CAN bus (ON/OFF)
 * @param[in]   ezw_can_id  The id of the ezw-can module being used
 * @param[in]   out         Pointer to the variable use to store the result
 *                          true  : bus is ON
 *                          false : bus is OFF
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_is_bus_on(const ezw_can_id_t ezw_can_id, bool *const out);

/** @fn ezw_error_t ezw_can_is_transmission_active(const ezw_can_id_t ezw_can_id, uint64_t * const out)
 * @brief Checks if there are any active transmissions occuring
 * @param[in]   ezw_can_id  The id of the ezw-can module being used
 * @param[in]   out         Pointer to the variable use to store the result
 *                           = 0 : No transmission in active
 *                           > 0 : Transmission is active.
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_is_transmission_active(const ezw_can_id_t ezw_can_id, uint64_t *const out);

/* Setters --------------------------------------------- */
/** @fn ezw_error_t ezw_can_bus_on(const ezw_can_id_t ezw_can_id)
 * @brief Sets the CAN bus to the ON status (restarts it)
 * @param[in]   ezw_can_id  The id of the ezw-can module being used
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_bus_on(const ezw_can_id_t ezw_can_id);

/** @fn ezw_error_t ezw_can_bus_off(const ezw_can_id_t ezw_can_id)
 * @brief Sets the CAN bus to the OFF status (shuts it down)
 * @param[in]   ezw_can_id  The id of the ezw-can module being used
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_bus_off(const ezw_can_id_t ezw_can_id);

/* Senders --------------------------------------------- */
/** @fn ezw_error_t ezw_can_send(const ezw_can_id_t ezw_can_id, ezw_can_msg_t message)
 * @brief ezw_can Send message on CAN socket.
 * @param[in]   ezw_can_id     The id of the ezw-can module being used
 * @param[in]   message        Message to send through CAN socket
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_send(const ezw_can_id_t ezw_can_id, const ezw_can_msg_t *const message);

/* Receivers ------------------------------------------- */
/** @fn ezw_error_t ezw_can_recv(const ezw_can_id_t ezw_can_id, ezw_can_msg_t *message)
 * @brief Read message from CAN socket. Warning might be a blocking function.
 * @param[in]   ezw_can_id     The id of the ezw-can module being used
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_recv(const ezw_can_id_t ezw_can_id, ezw_can_msg_t *message);
/* Resetters ------------------------------------------- */

/* Process --------------------------------------------- */
/** @fn ezw_error_t ezw_can_process(const ezw_can_id_t ezw_can_id)
 * @brief ezw_can computations, will be called in main loop
 * @param[in]   ezw_can_id     The id of the ezw-can module being used
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_process(const ezw_can_id_t ezw_can_id);

/* Error handling -------------------------------------- */
/** @fn ezw_error_t ezw_can_get_error_level(const ezw_can_id_t ezw_can_id, ezw_can_error_level_t * const out)
 * @brief Get the last error level received from the CAN bus.
 * @param[in]   ezw_can_id  The id of the ezw-can module being used
 * @param[in]   out         Pointer to the variable use to store the result
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_get_error_level(const ezw_can_id_t ezw_can_id, ezw_can_error_level_t *const out);

/** @fn ezw_error_t ezw_can_get_error_type(const ezw_can_id_t ezw_can_id, ezw_can_error_type_t * const out)
 * @brief Get the last error type received from the CAN bus.
 * @param[in]   ezw_can_id  The id of the ezw-can module being used
 * @param[in]   out         Pointer to the variable use to store the result
 * @return error code, ERROR_NONE if no error occurred
 */
ezw_error_t ezw_can_get_error_type(const ezw_can_id_t ezw_can_id, ezw_can_error_type_t *const out);

/* Other functions ------------------------------------- */

/**@}*/

#endif /* EZW_CAN_H */
