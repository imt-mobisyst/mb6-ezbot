/**
 * Copyright (C) 2018 EZ-Wheel S.A.S.
 *
 * @file ezw_can_config.h
 * @brief EZW CAN configuration declaration header
 */

#ifndef EZW_CAN_CONFIG_H
#define EZW_CAN_CONFIG_H

/* Includes -------------------------------------------- */
#include "ezw_can.h"

/* Defines --------------------------------------------- */

/** @addtogroup ezw-can
 * @{
 */

/* Typedefs -------------------------------------------- */
/** @brief HAL configuration
 */
typedef struct {
    char     can_socket_name[EZW_CAN_SOCKET_PATH_SZ];
    uint32_t can_socket_filter_size;
    uint32_t can_socket_filter[EZW_CAN_SOCKET_FILTER_SZ];
    uint8_t *(*GetBufferFunct)(uint32_t, uint8_t, uint8_t, uint64_t);
    void (*BufferIsFilledFunct)(void);
} ezw_can_config_hal_t;

/* Extern variables ------------------------------------ */
/** @brief Configuration table that must be defined by the application
 */
extern ezw_can_config_hal_t ezw_can_config_hal[EZW_CAN_NUMOF];

/**@}*/

#endif /* EZW_CAN_CONFIG_H */
