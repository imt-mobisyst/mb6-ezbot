/**
 * This file is auto-generated with fidl-code-gen, don't try to modify it.
 */

/**
 * Copyright (C) 2023 EZ-Wheel S.A.S.
 *
 * @file DBusClient.hpp
 */

#ifndef EZW_SMCSERVICE_DBUSCLIENT_HPP
#define EZW_SMCSERVICE_DBUSCLIENT_HPP

#include "ezw-smc-core/IService.hpp"

#include "ezw_types.h"

#include "ezw-tools/DBusClientDelegate.hpp"

#include <memory>
#include <string>
#include <vector>

namespace v1
{
    namespace commonapi
    {
        namespace SmcService
        {
            template <typename... _AttributeExtensions> class CoreProxy;

            template <typename... _AttributeExtensions> class InternalProxy;

            template <typename... _AttributeExtensions> class NMTProxy;

            template <typename... _AttributeExtensions> class EMCYProxy;

            template <typename... _AttributeExtensions> class PDSProxy;

            template <typename... _AttributeExtensions> class SafeMotionProxy;

            template <typename... _AttributeExtensions> class CommunicationProxy;

            template <typename... _AttributeExtensions> class ManufacturerProxy;

            template <typename... _AttributeExtensions> class VelocityModeProxy;

            template <typename... _AttributeExtensions> class SRDOProxy;

            template <typename... _AttributeExtensions> class CANOpenProxy;
        } // namespace SmcService
    }     // namespace commonapi
} // namespace v1

namespace ezw
{
    namespace smcservice
    {
        class DBusClient : public smccore::IService {
            static constexpr const char *mClassName = "DBusClient";

          public:
            /**
             * @brief Construct a new DBusClient object
             *
             */
            DBusClient();

            /**
             * @brief Destroy the DBusClient object
             *
             */
            virtual ~DBusClient();

            /**
             * @brief Initialize the DBusClient object
             *
             * @param pContextId Id of the client (ie : canopen node Id)
             * @param pDomainName DBus Domain name (ie: "local")
             * @param pInstanceName DBus Instance name (ie : "commonapi.ezw.smcservice.smc_drive")
             * @return ezw_error_t
             */
            virtual ezw_error_t init(uint32_t pContextId, const std::string &pDomainName, const std::string &pInstanceName);

            /*************************
             * ICoreService
             *************************/

            /**
             * @brief Connect to the canopen device with the node id specifed.
             *
             * @param pNodeId The node id of the device : from 1 to 127.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t connect(const uint8_t &pNodeId) override;

            /**
             * @brief Disconnect from the canopen device.
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t disconnect() override;

            /**
             * @brief Retrieve the core status connection.
             *
             * @param pIsConnected The connection status.
             * @param pIsPdoInitSucceeded The PDO status.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getConnectionStatus(bool &pIsConnected, bool &pIsPdoInitSucceeded) override;

            /**
             * @brief Get the connected node id.
             *
             * @param pNodeId The node id of the connected device : from 1 to 127.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getConnectedNodeId(uint8_t &pNodeId) override;

            /**
             * @brief Get the CAN device.
             *
             * @param pCanDevice The CAN device. (ie "can0")
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getCanDevice(std::string &pCanDevice) override;

            /**
             * @brief Retrieve the SWD core services version. Ex : 0.2.8
             *
             * @param pCoreVersion The core version.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getCoreVersion(std::string &pCoreVersion) override;

            /**
             * @brief Switch into the specified canopen object dictionary mode.
             *
             * @param pMode The new mode.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t switchMode(const ICoreService::ModeEnum &pMode) override;

            /**
             * @brief Load settings from DCF file.
             *
             * @param pDcfFile Indicates the DCF file.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t loadSettingsFromDCF(const std::string &pDcfFile) override;

            /**
             * @brief Save settings to DCF file.
             *
             * @param pDcfFile Indicates the DCF file.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t saveSettingsToDCF(const std::string &pDcfFile) override;

            /**
             * @brief Load settings from the device.
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t loadSettingsFromDevice() override;

            /**
             * @brief Save settings to the device.
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t saveSettingsToDevice() override;

            /*************************
             * IInternalService
             *************************/

            /**
             * @brief Store the internal parameters of the specified bloc id into the non-volatile memory.
             *
             * @param pBlocId The internal bloc id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _storeParameters(const IInternalService::_BlocId &pBlocId) override;

            /**
             * @brief Restore the internal default parameters of the specified bloc id. Restoring is done by declaring the stored parameters in NVM as invalid.
             *  The function does not load the internal default parameters.
             *  The internal default values shall be set valid after the CANopen device is reset (NMT service reset node for sub-index from 01h to 7Fh, NMT service reset communication for sub-index 02h) or power cycled.
             * .
             *
             * @param pBlocId The internal bloc id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _restoreDefaultParameters(const IInternalService::_BlocId &pBlocId) override;

            /**
             * @brief Modify the device parameters.
             *
             * @param pParams The device parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _setDeviceParameters(const IInternalService::_DeviceParameters &pParams) override;

            /**
             * @brief Retrieve the self tests status.
             *
             * @param pSelfTestStatus The self tests status.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _getSelfTestStatus(IInternalService::_SelfTestStatus &pSelfTestStatus) const override;

            /**
             * @brief Simulate self test status.
             *
             * @param pSelfTestStatus The self tests status to simulate.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _simulateSelfTestError(const IInternalService::_SelfTestStatus &pSelfTestStatus) const override;

            /**
             * @brief Retrieve the calibration parameters used by the system.
             *
             * @param pParams The calibration parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _getCalibrationParameters(IInternalService::_CalibrationParameters &pParams) const override;

            /**
             * @brief Retrieve the system error configuration.
             *
             * @param pConfig The system error configuration.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _getSystemErrorConfig(IInternalService::_SystemErrorConfig &pConfig) const override;

            /**
             * @brief Modify the system error configuration.
             *
             * @param pConfig The system error configuration.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _setSystemErrorConfig(const IInternalService::_SystemErrorConfig &pConfig) override;

            /**
             * @brief Indicates the level1 error:
             *      VELOCITY_INVALID_VELOCITY_UPDATE    = 0x00000001
             *      FACADE00_MOTOR_FORCE_ANGLE          = 0x00000002
             *      FACADE00_MOTOR_SET_RATIO            = 0x00000004
             *      FACADE01_MOTOR_FORCE_ANGLE          = 0x00000008
             *      FACADE01_MOTOR_SET_RATIO            = 0x00000010
             *      DEADBEEF                            = 0x00000020
             *      VELOCITY_UPDATE                     = 0x00000040
             *      SET_ANGULAR_SPEED                   = 0x00000080
             *      TEMPSFTY_GET_SAFETY_FLAGS           = 0x00000100
             *      TEMPSFTY_GET_TEMPERATURE_MOS1       = 0x00000200
             *      TEMPSFTY_GET_TEMPERATURE_MOS2       = 0x00000400
             *      TEMPSFTY_GET_TEMPERATURE_PIN_DRIVER = 0x00000800
             *      MOTCTRL_BRAKE_GROUND                = 0x00001000
             *      HALL_GET_MOTOR_SPEED                = 0x00002000
             *      HALL_GET_SINCOS_INCREMENTS          = 0x00004000
             *      TEMPSFTY_PROCESS                    = 0x00008000
             *      MOTCTRL_PROCESS                     = 0x00010000
             *      DRV_OFF                             = 0x00020000
             *      ERROR_MANAGER                       = 0x00040000
             *      SAFE_SPEED_MANAGER                  = 0x00080000
             *
             * @param pLevel1Error The level1 error.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t _getLevel1Error(uint32_t &pLevel1Error) const override;

            /**
             * @brief Retrieve all the system error code statuses.
             *
             * @param pItems Indicates all the system error code statuses.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSystemErrorOutputs(std::vector<IInternalService::SystemErrorOutput> &pItems) const override;

            /*************************
             * INMTService
             *************************/

            /**
             * @brief Retrieve the NMT state of the SWD product.
             *
             * @param pNmtState The NMT state.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getNMTState(INMTService::NMTState &pNmtState) const override;

            /**
             * @brief Modify the NMT state of the SWD product.
             *
             * @param pNmtCommand The new NMT state.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setNMTState(const INMTService::NMTCommand &pNmtCommand) override;

            /**
             * @brief Broadcast the NMT state to all CANopen nodes.
             *
             * @param pNmtCommand The new NMT state.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t broadcastNMTState(const INMTService::NMTCommand &pNmtCommand) override;

            /*************************
             * IEMCYService
             *************************/

            /**
             * @brief Retrieve the ErrorBehavior of selected ErrorType.
             *
             * @param pErrorType Selected ErrorType.
             * @param pErrorBehavior ErrorBehavior of selected ErrorType.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getErrorBehavior(const IEMCYService::ErrorType &pErrorType, IEMCYService::ErrorBehavior &pErrorBehavior) const override;

            /**
             * @brief Set the ErrorBehavior of selected ErrorType.
             *
             * @param pErrorType Selected ErrorType.
             * @param pErrorBehavior ErrorBehavior of selected ErrorType.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setErrorBehavior(const IEMCYService::ErrorType &pErrorType, const IEMCYService::ErrorBehavior &pErrorBehavior) override;

            /**
             * @brief Clear all previous error stored in the pre-defined error array.
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t clearErrorList() override;

            /**
             * @brief Return the number of error present in the pre-defined error array.
             *
             * @param pErrorCount Number of errors.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getErrorCount(int32_t &pErrorCount) const override;

            /**
             * @brief Return error register.
             *      Error Register is made of 8 bits indicating the type of error that happend:
             *      - [0] Generic
             *      - [1] Current
             *      - [2] Voltage
             *      - [3] Temperature
             *      - [4] Communication
             *      - [5] Device profile specific
             *      - [6] 0 (Reserved)
             *      - [7] Manufacturer
             *
             * @param pErrorRegister 8 bits error register.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getErrorRegister(uint8_t &pErrorRegister) const override;

            /**
             * @brief Return EMCY_ERROR_CODE (as UInt32) at index in the pre-defined error array.
             *
             * @param pIndex Selected index.
             * @param pEmcyErrorCode cf EMCY_ERROR_CODE.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getError(const int32_t &pIndex, uint32_t &pEmcyErrorCode) const override;

            /*************************
             * IPDSService
             *************************/

            /**
             * @brief Retrieve the actual supported functions according to the PDS FSA state.
             *
             * @param pPeripheralStatus The supported functions.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getPeripheralStatus(IPDSService::PeripheralStatus &pPeripheralStatus) const override;

            /**
             * @brief Retrieve the PDS FSA state contains into the CIA402 statusword object (6041h).
             *
             * @param pPdsState The PDS FSA state.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getPDSState(IPDSService::PDSState &pPdsState) const override;

            /**
             * @brief Send disable voltage command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t disableVoltage() const override;

            /**
             * @brief Send shutdown command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t shutdown() const override;

            /**
             * @brief Send quick stop command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t quickStop() const override;

            /**
             * @brief Send switch on command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t switchOn() const override;

            /**
             * @brief Send enable operation command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t enableOperation() const override;

            /**
             * @brief Send disable operation command into CIA402 controlword object (6040h).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t disableOperation() const override;

            /**
             * @brief Send fault reset command into CIA402 controlword object (6040h).
             *
             * @param pStatus True to set the fault reset bit else False to clear it.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t faultReset(const bool &pStatus) const override;

            /**
             * @brief Send all the commands needed to enter into FSA operation enabled state.
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t enterInOperationEnabledState() override;

            /**
             * @brief Retrieve the abort connection option code.
             *
             * @param pCode The abort connection option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getAbortConnectionOptionCode(IPDSService::AbortConnectionOptionCode &pCode) const override;

            /**
             * @brief Modify the abort connection option code.
             *
             * @param pCode The abort connection option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setAbortConnectionOptionCode(const IPDSService::AbortConnectionOptionCode &pCode) const override;

            /**
             * @brief Retrieve the quick stop option code.
             *
             * @param pCode The quick stop option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getQuickStopOptionCode(IPDSService::QuickStopOptionCode &pCode) const override;

            /**
             * @brief Modify the quick stop option code.
             *
             * @param pCode The quick stop option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setQuickStopOptionCode(const IPDSService::QuickStopOptionCode &pCode) const override;

            /**
             * @brief Retrieve the shutdown option code.
             *
             * @param pCode The shutdown option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getShutdownOptionCode(IPDSService::ShutdownOptionCode &pCode) const override;

            /**
             * @brief Modify the shutdown option code.
             *
             * @param pCode The shutdown option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setShutdownOptionCode(const IPDSService::ShutdownOptionCode &pCode) const override;

            /**
             * @brief Retrieve the disable operation option code.
             *
             * @param pCode The disable operation option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getDisableOperationOptionCode(IPDSService::DisableOperationOptionCode &pCode) const override;

            /**
             * @brief Modify the disable operation option code.
             *
             * @param pCode The disable operation option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setDisableOperationOptionCode(const IPDSService::DisableOperationOptionCode &pCode) const override;

            /**
             * @brief Retrieve the halt option code.
             *
             * @param pCode The halt option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getHaltOptionCode(IPDSService::HaltOptionCode &pCode) const override;

            /**
             * @brief Modify the halt option code.
             *
             * @param pCode The halt option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setHaltOptionCode(const IPDSService::HaltOptionCode &pCode) const override;

            /**
             * @brief Retrieve the fault reaction option code.
             *
             * @param pCode The fault reaction option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getFaultReactionOptionCode(IPDSService::FaultReactionOptionCode &pCode) const override;

            /**
             * @brief Modify the fault reaction option code.
             *
             * @param pCode The fault reaction option code.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setFaultReactionOptionCode(const IPDSService::FaultReactionOptionCode &pCode) const override;

            /**
             * @brief Retrieve the operation mode.
             *
             * @param pRequested The requested operation mode.
             * @param pActual The actual operation mode.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getOperationModes(IPDSService::OperationMode &pRequested, IPDSService::OperationMode &pActual) const override;

            /**
             * @brief Retrieve the supported state of the specified drive mode.
             *
             * @param pMode The drive mode.
             * @param pSupported True if the specified drive mode is supported.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t isDriveModeSupported(const IPDSService::OperationMode &pMode, bool &pSupported) const override;

            /**
             * @brief Retrieve the unit parameters.
             *
             * @param pParams The unit parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getUnitParameters(IPDSService::UnitParameters &pParams) const override;

            /**
             * @brief Modify the unit parameters.
             *
             * @param pParams The unit parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setUnitParameters(const IPDSService::UnitParameters &pParams) override;

            /**
             * @brief Retrieve the polarity factors parameters used by the SWD product.
             *
             * @param pParams The configured polarity parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getPolarityParameters(IPDSService::PolarityParameters &pParams) const override;

            /**
             * @brief Modify the polarity factors parameters used by the SWD product.
             *
             * @param pParams The new polarity parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setPolarityParameters(const IPDSService::PolarityParameters &pParams) override;

            /*************************
             * ISafeMotionService
             *************************/

            /**
             * @brief Retrieve the safety control word mapping of the specified safety control word id.
             *
             * @param pSafetyControlWordId Id of the safety control word.
             * @param pSafetyControlWordMapping The safety control word mapping.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyControlWordMapping(const ISafeMotionService::SafetyControlWordId &pSafetyControlWordId, ISafeMotionService::SafetyWordMapping &pSafetyControlWordMapping) const override;

            /**
             * @brief Modify the safety control word mapping of the specified safety control word id.
             *
             * @param pSafetyControlWordId Id of the safety control word.
             * @param pSafetyControlWordMapping The safety control word mapping.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSafetyControlWordMapping(const ISafeMotionService::SafetyControlWordId &pSafetyControlWordId, const ISafeMotionService::SafetyWordMapping &pSafetyControlWordMapping) override;

            /**
             * @brief Retrieve the safety status word mapping of the specified safety status word id.
             *
             * @param pSafetyStatusWordId Id of the safety status word.
             * @param pSafetyStatusWordMapping The safety status word mapping.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyStatusWordMapping(const ISafeMotionService::SafetyStatusWordId &pSafetyStatusWordId, ISafeMotionService::SafetyWordMapping &pSafetyStatusWordMapping) const override;

            /**
             * @brief Modify the safety status word mapping of the specified safety status word id.
             *
             * @param pSafetyStatusWordId Id of the safety status word.
             * @param pSafetyStatusWordMapping The safety status word mapping.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSafetyStatusWordMapping(const ISafeMotionService::SafetyStatusWordId &pSafetyStatusWordId, const ISafeMotionService::SafetyWordMapping &pSafetyStatusWordMapping) override;

            /**
             * @brief Retrieve the safety function command of the specified safety function id.
             *
             * @param pSafetyFunctionId Id of the safety function.
             * @param pStatus False if the safety function command is enabled.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyFunctionCommand(const ISafeMotionService::SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const override;

            /**
             * @brief Retrieve the safety function status of the specified safety function id.
             *
             * @param pSafetyFunctionId Id of the safety function.
             * @param pStatus True if the safety function status is enabled.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyFunctionStatus(const ISafeMotionService::SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const override;

            /**
             * @brief Retrieve the safety control word of the specified safety control word id.
             *
             * @param pSafetyControlWordId Id of the safety control word.
             * @param pSafetyControlWord The safety control word.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyControlWord(const ISafeMotionService::SafetyControlWordId &pSafetyControlWordId, ISafeMotionService::SafetyWordType &pSafetyControlWord) const override;

            /**
             * @brief Modify the safety control word of the specified safety control word id.
             *
             * @param pSafetyControlWordId Id of the safety control word.
             * @param pSafetyControlWord The safety control word.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSafetyControlWord(const ISafeMotionService::SafetyControlWordId &pSafetyControlWordId, const ISafeMotionService::SafetyWordType &pSafetyControlWord) override;

            /**
             * @brief Retrieve the safety status word of the specified safety status word id.
             *
             * @param pSafetyStatusWordId Id of the safety status word.
             * @param pSafetyStatusWord The safety status word.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyStatusWord(const ISafeMotionService::SafetyStatusWordId &pSafetyStatusWordId, ISafeMotionService::SafetyWordType &pSafetyStatusWord) const override;

            /**
             * @brief Retrieve the STO safety application parameters of the specified STO id.
             *
             * @param pId Id of the STO.
             * @param pParameters The STO safety application parameters.
             * @param pSignature The STO safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSTOParameters(const ISafeMotionService::STOId &pId, ISafeMotionService::STOParameters &pParameters, uint16_t &pSignature) const override;

            /**
             * @brief Modify the safety function STO parameters of the specified STO id.
             *  NOTA : Modification is allowed only in NMT state Pre-operational.
             *
             * @param pId Id of the STO.
             * @param pParameters The STO safety application parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSTOParameters(const ISafeMotionService::STOId &pId, const ISafeMotionService::STOParameters &pParameters) override;

            /**
             * @brief Retrieve the SLS safety application parameters of the specified SLS id.
             *
             * @param pId Id of the SLS.
             * @param pParameters The SLS safety application parameters.
             * @param pSignature The SLS safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSLSParameters(const ISafeMotionService::SLSId &pId, ISafeMotionService::SLSParameters &pParameters, uint16_t &pSignature) const override;

            /**
             * @brief Modify the safety function SLS parameters of the specified SLS id.
             *  NOTA : Modification is allowed only in NMT state Pre-operational.
             *
             * @param pId Id of the SLS.
             * @param pParameters The SLS safety application parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSLSParameters(const ISafeMotionService::SLSId &pId, const ISafeMotionService::SLSParameters &pParameters) override;

            /**
             * @brief Retrieve the SDI safety application parameters of the specified SDI id.
             *
             * @param pId Id of the SDI.
             * @param pParameters The SDI safety application parameters.
             * @param pSignature The SDI safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSDIParameters(const ISafeMotionService::SDIId &pId, ISafeMotionService::SDIParameters &pParameters, uint16_t &pSignature) const override;

            /**
             * @brief Modify the safety function SDI parameters of the specified SDI id.
             *  NOTA : Modification is allowed only in NMT state Pre-operational.
             *
             * @param pId Id of the SDI.
             * @param pParameters The SDI safety application parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSDIParameters(const ISafeMotionService::SDIId &pId, const ISafeMotionService::SDIParameters &pParameters) override;

            /**
             * @brief Retrieve the SBC safety application parameters of the specified SBC id.
             *
             * @param pId Id of the SBC.
             * @param pParameters The SBC safety application parameters.
             * @param pSignature The SBC safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSBCParameters(const ISafeMotionService::SBCId &pId, ISafeMotionService::SBCParameters &pParameters, uint16_t &pSignature) const override;

            /**
             * @brief Retrieve the SMS safety application parameters of the specified SMS id.
             *
             * @param pId Id of the SMS.
             * @param pParameters The SMS safety application parameters.
             * @param pSignature The SMS safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSMSParameters(const ISafeMotionService::SMSId &pId, ISafeMotionService::SMSParameters &pParameters, uint16_t &pSignature) const override;

            /**
             * @brief Modify the safety function SMS parameters of the specified SMS id.
             *  NOTA : Modification is allowed only in NMT state Pre-operational.
             *
             * @param pId Id of the SMS.
             * @param pParameters The SMS safety application parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSMSParameters(const ISafeMotionService::SMSId &pId, const ISafeMotionService::SMSParameters &pParameters) override;

            /**
             * @brief Retrieve the SLSa safety application parameters of the specified SLSa id.
             *
             * @param pId Id of the SLSa.
             * @param pParameters The SLSa safety application parameters.
             * @param pSignature The SLSa safety application configuration signature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSLSaParameters(const ISafeMotionService::SLSaId &pId, ISafeMotionService::SLSaParameters &pParameters, uint16_t &pSignature) const override;

            /**
             * @brief Modify the safety function SLSa parameters of the specified SLSa id.
             *  NOTA : Modification is allowed only in NMT state Pre-operational.
             *
             * @param pId Id of the SLSa.
             * @param pParameters The SLSa safety application parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSLSaParameters(const ISafeMotionService::SLSaId &pId, const ISafeMotionService::SLSaParameters &pParameters) override;

            /**
             * @brief Retrieve the consolidated safety function status of the specified safety function id.
             *
             * @param pSafetyFunctionId Id of the safety function.
             * @param pStatus True if the consolidated safety function is enabled.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyFunctionOutput(const ISafeMotionService::SafetyFunctionId &pSafetyFunctionId, bool &pStatus) const override;

            /**
             * @brief Retrieve all the consolidated safety function statuses.
             *
             * @param pItems Indicates all the consolidated safety function statuses.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSafetyFunctionOutputs(std::vector<ISafeMotionService::SafetyFunctionOuputStatus> &pItems) const override;

            /*************************
             * ICommunicationService
             *************************/

            /**
             * @brief Store the parameters of the specified bloc id into the non-volatile memory.
             *
             * @param pBlocId The bloc id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t storeParameters(const ICommunicationService::BlocId &pBlocId) override;

            /**
             * @brief Restore the default parameters of the specified bloc id. Restoring is done by declaring the stored parameters in NVM as invalid.
             *  The function does not load the default parameters.
             *  The default values shall be set valid after the CANopen device is reset (NMT service reset node for sub-index from 01h to 7Fh, NMT service reset communication for sub-index 02h) or power cycled.
             * .
             *
             * @param pBlocId The bloc id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t restoreDefaultParameters(const ICommunicationService::BlocId &pBlocId) override;

            /**
             * @brief Retrieve the device parameters.
             *
             * @param pParams The device parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getIdentityParameters(ICommunicationService::IdentityParameters &pParams) const override;

            /**
             * @brief Retrieve the network parameters.
             *
             * @param pParams The network parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getNetworkParameters(ICommunicationService::NetworkParameters &pParams) const override;

            /**
             * @brief Modify the network parameters.
             *
             * @param pParams The new network parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setNetworkParameters(const ICommunicationService::NetworkParameters &pParams) override;

            /**
             * @brief Retrieve the communication parameters.
             *
             * @param pParams The communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getCommunicationParameters(ICommunicationService::CommunicationParameters &pParams) const override;

            /**
             * @brief Modify the communication parameters.
             *
             * @param pParams The communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setCommunicationParameters(const ICommunicationService::CommunicationParameters &pParams) override;

            /**
             * @brief Retrieve the SDO communication parameters of the specified SDO id.
             *
             * @param pId The SDO id.
             * @param pParams The communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSDOCommunicationParameters(const ICommunicationService::SDOId &pId, ICommunicationService::SDOCommunicationParameters &pParams) const override;

            /**
             * @brief Modify the SDO communication parameters of the specified SDO id.
             *
             * @param pId The SDO id.
             * @param pParams The new communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSDOCommunicationParameters(const ICommunicationService::SDOId &pId, const ICommunicationService::SDOCommunicationParameters &pParams) override;

            /**
             * @brief Retrieve the communication parameters of the specified RPDO id (PDO the CANopen device is able to receive).
             *
             * @param pId The PDO id.
             * @param pParams The communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getRPDOCommunicationParameters(const ICommunicationService::PDOId &pId, ICommunicationService::PDOCommunicationParameters &pParams) const override;

            /**
             * @brief Modify the communication parameters of the specified RPDO id (PDO the CANopen device is able to receive).
             *
             * @param pId The PDO id.
             * @param pParams The new communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setRPDOCommunicationParameters(const ICommunicationService::PDOId &pId, const ICommunicationService::PDOCommunicationParameters &pParams) override;

            /**
             * @brief Retrieve the communication parameters of the specified TPDO id (PDO the CANopen device is able to transmit).
             *
             * @param pId The PDO id.
             * @param pParams The communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getTPDOCommunicationParameters(const ICommunicationService::PDOId &pId, ICommunicationService::PDOCommunicationParameters &pParams) const override;

            /**
             * @brief Modify the communication parameters of the specified TPDO id (PDO the CANopen device is able to transmit).
             *
             * @param pId The PDO id.
             * @param pParams The new communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setTPDOCommunicationParameters(const ICommunicationService::PDOId &pId, const ICommunicationService::PDOCommunicationParameters &pParams) override;

            /**
             * @brief Retrieve the mapping parameters of the specified RPDO id (PDO the CANopen device is able to receive).
             *
             * @param pId The PDO id.
             * @param pParams The mapping parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getRPDOMappingParameters(const ICommunicationService::PDOId &pId, ICommunicationService::PDOMappingParameters &pParams) const override;

            /**
             * @brief Modify the mapping parameters of the specified RPDO id (PDO the CANopen device is able to receive).
             *
             * @param pId The PDO id.
             * @param pParams The new mapping parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setRPDOMappingParameters(const ICommunicationService::PDOId &pId, const ICommunicationService::PDOMappingParameters &pParams) override;

            /**
             * @brief Retrieve the mapping parameters of the specified TPDO id (PDO the CANopen device is able to transmit).
             *
             * @param pId The PDO id.
             * @param pParams The mapping parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getTPDOMappingParameters(const ICommunicationService::PDOId &pId, ICommunicationService::PDOMappingParameters &pParams) const override;

            /**
             * @brief Modify the Mapping parameters of the specified TPDO id (PDO the CANopen device is able to transmit).
             *
             * @param pId The PDO id.
             * @param pParams The new mapping parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setTPDOMappingParameters(const ICommunicationService::PDOId &pId, const ICommunicationService::PDOMappingParameters &pParams) override;

            /*************************
             * IManufacturerService
             *************************/

            /**
             * @brief Retrieve the device parameters.
             *
             * @param pParams The device parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getDeviceParameters(IManufacturerService::DeviceParameters &pParams) const override;

            /**
             * @brief Retrieve the SWD product parameters.
             *
             * @param pParams The SWD product parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSWDParameters(IManufacturerService::SWDParameters &pParams) const override;

            /**
             * @brief Modify the SWD product parameters.
             *  NOTA :
             *  - Changes will be applied at the next transition into OPERATION_ENABLED state.
             *  - Storing is possible into the non-volatile memory (MANUFACTURER bloc).
             *
             * @param pParams The new SWD product parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSWDParameters(const IManufacturerService::SWDParameters &pParams) override;

            /**
             * @brief Retrieve the validity of the calibration in non volatile memory.
             *
             * @param pIsvalid The calibration validity.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getCalibrationValidity(bool &pIsvalid) const override;

            /**
             * @brief Retrieve the system error states.
             *
             * @param pBatteryUv Indicates the state of a battery under voltage.
             * @param pBatteryOv Indicates the state of a battery over voltage.
             * @param pPhaseOc Indicates the state of a phase over current.
             * @param pMosOt Indicates the state of a MOS over temperature.
             * @param pDrvOt Indicates the state of a driver over temperature.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSystemErrorState(IManufacturerService::SystemErrorStatus &pBatteryUv, IManufacturerService::SystemErrorStatus &pBatteryOv, IManufacturerService::SystemErrorStatus &pPhaseOc, IManufacturerService::SystemErrorStatus &pMosOt, IManufacturerService::SystemErrorStatus &pDrvOt) const override;

            /**
             * @brief Retrieve the system error protection state.
             *
             * @param pPrevState The previous system error protect state.
             * @param pCurrentState The actual system error protect state.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSystemErrorProtectState(IManufacturerService::SystemErrorProtectState &pPrevState, IManufacturerService::SystemErrorProtectState &pCurrentState) const override;

            /**
             * @brief Retrieve the SWD product software version. Ex : 1.0.1
             *
             * @param pSwVersion The software version.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSWVersion(std::string &pSwVersion) const override;

            /**
             * @brief Retrieve the SWD product software id. Ex : 2
             *      NOTA
             *      [
             *          FW_UNKNOWN = 0U
             *          FW_SWD_RECOVERY =1U
             *          FW_SWD_CORE = 2U
             *          FW_SWD_150 = 3U
             *          ...
             *          Maintenance = 255U
             *      ]
             *
             * @param pSwId The software id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSWId(uint8_t &pSwId) const override;

            /**
             * @brief Retrieve the SWD product software reference. Ex : FW_SWD_CORE
             *
             * @param pSoftwareRef The software reference.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSWRef(std::string &pSoftwareRef) const override;

            /**
             * @brief Retrieve the SWD product hardware version. Ex : 5
             *      NOTA
             *      [
             *          0 = Hardware version init
             *          1 = A
             *          2 = B
             *          3 = C
             *          4 = D
             *          5 = E
             *          6 = F
             *          7 = G
             *          8 = H
             *          9 = I
             *          10 = J
             *          ...
             *      ]
             *
             * @param pHwVersion The hardware version.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getHWVersion(uint32_t &pHwVersion) const override;

            /**
             * @brief Retrieve the SWD product hardware id. Ex : 777
             *      NOTA
             *      [
             *          727 = SWD150
             *          777 = SWDCore or SWD125
             *          ...
             *      ]
             *
             * @param pHwId The hardware id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getHWId(uint32_t &pHwId) const override;

            /**
             * @brief Retrieve the SWD product id. Ex : 15
             *      NOTA
             *      [
             *          NO_PRODUCT_REF = 0U
             *          ezSWD125IM.14/C = 1U
             *          ezSWD125IM.14B/C = 2U
             *          ezSWD125IM.25/C = 3U
             *          ezSWD125IM.25B/C = 4U
             *          ezSWD125IM.4/C = 5U
             *          ezSWD125IM.4B/C = 6U
             *          ...
             *          ezSWD150IH.14/C-0 = 7U
             *          ezSWD150IH.14/C-1 = 8U
             *          ezSWD150IH.14B/C-0 = 9U
             *          ezSWD150IH.14B/C-1 = 10U
             *          ezSWD150IH.25/C-0 = 11U
             *          ezSWD150IH.25/C-1 = 12U
             *          ezSWD150IH.25B/C-0 = 13U
             *          ezSWD150IH.25B/C-1 = 14U
             *          ...
             *          ezSWDcore.14/C = 15U
             *          ezSWDcore.14B/C = 16U
             *          ezSWDcore.25/C = 17U
             *          ezSWDcore.25B/C = 18U
             *          ezSWDcore.4/C = 19U
             *          ezSWDcore.4B/C = 20U
             *          ezSWDcore.0/C = 21U
             *          ...
             *      ]
             *
             * @param pProductId The product id.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getProductId(uint32_t &pProductId) const override;

            /**
             * @brief Retrieve the SWD product reference. Ex : ezSWD125IM.14/C
             *
             * @param pProductRef The product reference.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getProductRef(std::string &pProductRef) const override;

            /**
             * @brief Retrieve the position distance of the SWD product in mm.
             *      FORMULA : position_value / NbStepRevolutionElec / NbPolePair / Reduction x Diameter x M_PI
             *      NOTA : The previous parameters are defined into the configuration file.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : The format of the configuration file is JSON
             *             ie. Nidec motor :
             *              "nbStepRevolutionElec": 6,
             *              "nbPolePair": 5,
             *              "reduction": 14.0,
             *              "diameter": 125.0
             *
             * @param pOdometryValue The position distance of the SWD Core in mm.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getOdometryValue(int32_t &pOdometryValue) const override;

            /**
             * @brief Retrieve the position distance of the SWD product in mm.
             *      FORMULA : position_value / NbStepRevolutionElec / NbPolePair / Reduction x Diameter x M_PI
             *      NOTA : The previous parameters are defined into the configuration file.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : The format of the configuration file is JSON
             *             ie. Nidec motor :
             *              "nbStepRevolutionElec": 6,
             *              "nbPolePair": 5,
             *              "reduction": 14.0,
             *              "diameter": 125.0
             *
             * @param pOdometryValue The position distance of the SWD product in mm.
             * @param pTimestamp The timestamp in microseconds (Unix epoch time from 1 January 1970).
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getOdometryValueTS(int32_t &pOdometryValue, uint64_t &pTimestamp) const override;

            /**
             * @brief Retrieve a more precise position distance of the SWD product in mm at low level speed. (Warning : This position is non-safe. Safety relevant applications should rely with getOdometryValue()).
             *      FORMULA : accurate_position_value / Reduction x Diameter x M_PI
             *      NOTA : The previous parameters are defined into the configuration file.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : The format of the configuration file is JSON
             *             ie. Nidec motor :
             *              "reduction": 14.0,
             *              "diameter": 125.0
             *
             * @param pAccurateOdometryValue The accurate position distance of the SWD product in mm.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getAccurateOdometryValue(int32_t &pAccurateOdometryValue) const override;

            /**
             * @brief Retrieve a more precise position distance of the SWD product in mm at low level speed. (Warning : This position is non-safe. Safety relevant applications should rely with getOdometryValue()).
             *      FORMULA : accurate_position_value / Reduction x Diameter x M_PI
             *      NOTA : The previous parameters are defined into the configuration file.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : The format of the configuration file is JSON
             *             ie. Nidec motor :
             *              "reduction": 14.0,
             *              "diameter": 125.0
             *
             * @param pAccurateOdometryValue The accurate position distance of the SWD product in mm.
             * @param pTimestamp The timestamp in microseconds (Unix epoch time from 1 January 1970).
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getAccurateOdometryValueTS(int32_t &pAccurateOdometryValue, uint64_t &pTimestamp) const override;

            /**
             * @brief Retrieve the precise multiturn position value, in units of motor mechanical degrees.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : This position is non-safe and is for information only. Safety relevant applications should rely on safe object "0x6064: position_value".
             *
             * @param pAccuratePositionValue The precise multiturn position value, in units of motor mechanical degrees.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getAccuratePositionValue(int32_t &pAccuratePositionValue) const override;

            /**
             * @brief Retrieve the precise multiturn position value, in units of motor mechanical degrees.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *      NOTA : This position is non-safe and is for information only. Safety relevant applications should rely on safe object "0x6064: position_value".
             *
             * @param pAccuratePositionValue The precise multiturn position value, in units of motor mechanical degrees.
             * @param pTimestamp The timestamp in ms from 1970.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getAccuratePositionValueTS(int32_t &pAccuratePositionValue, uint64_t &pTimestamp) const override;

            /**
             * @brief Retrieve the control value for an OutputSource
             *      NOTA : Value of 1 means OutputSource is active
             *      NOTA : Value of 0 means OutputSource is inactive
             *      NOTA : Value of control can be saved in EEPROM ( MANUFACTURER data )
             *      NOTA : Value of control is applied immediately
             *
             * @param pOutputSource which OutputSource control you want to get.
             * @param pControl control for the OutputSource : 1 OutputSource is active, 0 OutputSource is inactive
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getOutputControl(const IManufacturerService::OutputSource &pOutputSource, bool &pControl) const override;

            /**
             * @brief Set the control value for an OutputSource
             *      NOTA : Value of 1 means OutputSource is active
             *      NOTA : Value of 0 means OutputSource is inactive
             *      NOTA : Value of control can be saved in EEPROM ( MANUFACTURER data )
             *      NOTA : Value of control is applied immediately
             *
             * @param pOutputSource which OutputSource control you want to set.
             * @param pControl control for the OutputSource : 1 OutputSource is active, 0 OutputSource is inactive
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setOutputControl(const IManufacturerService::OutputSource &pOutputSource, const bool &pControl) override;

            /**
             * @brief Retrieve the status of an OutputSource
             *      NOTA : Value of 1 means OutputSource is active
             *      NOTA : Value of 0 means OutputSource is inactive
             *
             * @param pOutputSource which OutputSource status you want to get.
             * @param pStatus The status of OutputSource.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getOutputStatus(const IManufacturerService::OutputSource &pOutputSource, bool &pStatus) const override;

            /**
             * @brief Modify the external brake presence flag.
             *      NOTA : Value of 1 means external brake is configured to be present.
             *      NOTA : Value of 0 means external brake is configured to be not present.
             *
             * @param pExternalbrakepresence The external brake presence flag.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setExternalBrakePresence(const bool &pExternalbrakepresence) override;

            /**
             * @brief Retrieve the external brake presence flag.
             *      NOTA : Value of 1 means external brake is configured to be present.
             *      NOTA : Value of 0 means external brake is configured to be not present.
             *
             * @param pExternalbrakepresence The external brake presence flag.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getExternalBrakePresence(bool &pExternalbrakepresence) const override;

            /*************************
             * IVelocityModeService
             *************************/

            /**
             * @brief Indicate the required velocity of the system. It will be multiplied by the vl dimension factor and the vl set-point factor.
             *  The value shall be given in user-defined velocity units or in revolutions per minute (r/min), if the vl dimension factor and the vl set-point factor are not implemented or have the value 1.
             *  Positive values shall indicate forward direction and negative values shall indicate reverse direction.
             *
             * @param pTargetVelocity The required velocity (range : -2000 to 2000 r/min).
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setTargetVelocity(const int16_t &pTargetVelocity) override;

            /**
             * @brief Retrieve the actual required velocity of the system.
             *
             * @param pTargetVelocity The actual required velocity of the system.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getTargetVelocity(int16_t &pTargetVelocity) const override;

            /**
             * @brief Retrieve the actual velocity of the system. The value shall be given in the very same unit as the vl target velocity.
             *      Positive values shall indicate forward direction and negative values shall indicate reverse direction.
             *
             * @param pVelocityActualValue The actual velocity of the system.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityActualValue(int32_t &pVelocityActualValue) const override;

            /**
             * @brief Retrieve the actual velocity of the system. The value shall be given in the very same unit as the vl target velocity.
             *      Positive values shall indicate forward direction and negative values shall indicate reverse direction.
             *
             * @param pVelocityActualValue The actual velocity of the system.
             * @param pTimestamp The timestamp in ms from 1970.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityActualValueTS(int32_t &pVelocityActualValue, uint64_t &pTimestamp) const override;

            /**
             * @brief Retrieve the instantaneous velocity generated by the ramp function. The value shall be given in the very same unit as the vl target velocity.
             *      Positive values shall indicate forward direction and negative values shall indicate reverse direction.
             *      NOTA : The velocity demand depends of the velocity polarity parameter.
             *
             * @param pVelocityDemand The instantaneous velocity generated by the ramp function.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityDemand(int16_t &pVelocityDemand) const override;

            /**
             * @brief Retrieve the position of the SWD product in motor revolution increments. The SWD product resolution is 30 increments par revolution.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *
             * @param pPositionValue The position of the SWD product in motor revolution increments.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getPositionValue(int32_t &pPositionValue) const override;

            /**
             * @brief Retrieve the position of the SWD product in motor revolution increments. The SWD product resolution is 30 increments par revolution.
             *      NOTA : The counter direction depends of the position polarity parameter.
             *
             * @param pPositionValue The position of the SWD product in motor revolution increments.
             * @param pTimestamp The timestamp in ms from 1970.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getPositionValueTS(int32_t &pPositionValue, uint64_t &pTimestamp) const override;

            /**
             * @brief Retrieve the velocity mode parameters.
             *
             * @param pParams The velocity mode parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityModeParameters(IVelocityModeService::VelocityModeParameters &pParams) const override;

            /**
             * @brief Modify the velocity mode parameters.
             *
             * @param pParams The new velocity mode parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setVelocityModeParameters(const IVelocityModeService::VelocityModeParameters &pParams) override;

            /**
             * @brief Retrieve the velocity mode statusword.
             *
             * @param pParams The velocity mode statusword.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityModeStatusword(IVelocityModeService::VelocityModeStatusword &pParams) const override;

            /**
             * @brief Retrieve the velocity mode controlword.
             *
             * @param pParams The velocity mode controlword.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getVelocityModeControlword(IVelocityModeService::VelocityModeControlword &pParams) const override;

            /**
             * @brief Modify the enable ramp flag into the velocity mode controlword.
             *
             * @param pEnableRamp If False, the velocity demand value shall be controlled in any other (manufacturer-specific) way, for example by a test function generator or manufacturer-specific halt function; else, the velocity demand value shall accord with ramp output value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setEnableRamp(const bool &pEnableRamp) override;

            /**
             * @brief Modify the unlock ramp flag into the velocity mode controlword.
             *
             * @param pUnlockRamp If False, the ramp output value shall be locked to current output value; else the ramp output value shall follow ramp input value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setUnlockRamp(const bool &pUnlockRamp) override;

            /**
             * @brief Modify the reference ramp flag into the velocity mode controlword.
             *
             * @param pReferenceRamp If False, the ramp input value shall be set to zero; else the ramp input value shall accord with ramp reference.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setReferenceRamp(const bool &pReferenceRamp) override;

            /**
             * @brief Modify the halt flag into the velocity mode controlword.
             *
             * @param pHalt If True, the motor shall be stopped.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setHalt(const bool &pHalt) override;

            /*************************
             * ISRDOService
             *************************/

            /**
             * @brief Retrieve the communication parameters of the specified SRDO id.
             *
             * @param pId The SRDO id.
             * @param pDirection The direction of the SRDO.
             * @param pParameters The communication parameters of the SRDO.
             * @param pSignature The signature of the SRDO.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSRDOParameters(const ISRDOService::SRDOId &pId, ISRDOService::SRDODirection &pDirection, ISRDOService::SRDOParameters &pParameters, uint16_t &pSignature) const override;

            /**
             * @brief Modify the communication parameters of the specified SRDO id.
             *
             * @param pId The SRDO id.
             * @param pParameters The new communication parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSRDOParameters(const ISRDOService::SRDOId &pId, const ISRDOService::SRDOParameters &pParameters) override;

            /**
             * @brief Retrieve the mapping parameters of the specified SRDO id.
             *
             * @param pId The SRDO id.
             * @param pMapping The configured mapping parameters.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSRDOMapping(const ISRDOService::SRDOId &pId, ISRDOService::SRDOMapping &pMapping) const override;

            /**
             * @brief Retrieve the SRDO configuration valid flag (0x13fe => 0xA5 the configuration is valid; other values the configuration is invalid).
             *
             * @param pIsvalid The SRDO configuration valid flag.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getSRDOConfigurationValidity(bool &pIsvalid) const override;

            /**
             * @brief Modify the SRDO configuration valid flag (0x13fe => 0xA5 the configuration is valid; other values the configuration is invalid).
             *
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setSRDOConfigurationValidity() override;

            /*************************
             * ICANOpenService
             *************************/

            /**
             * @brief Retrieve the value of the specified object address for a type string.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueString(const uint32_t &pAddress, std::string &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type string.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueString(const uint32_t &pAddress, const std::string &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type int64.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueInt64(const uint32_t &pAddress, int64_t &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type int64.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueInt64(const uint32_t &pAddress, const int64_t &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type int32.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueInt32(const uint32_t &pAddress, int32_t &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type int32.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueInt32(const uint32_t &pAddress, const int32_t &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type int16.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueInt16(const uint32_t &pAddress, int16_t &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type int16.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueInt16(const uint32_t &pAddress, const int16_t &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type int8.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueInt8(const uint32_t &pAddress, int8_t &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type int8.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueInt8(const uint32_t &pAddress, const int8_t &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type uint64.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueUInt64(const uint32_t &pAddress, uint64_t &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type uint64.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueUInt64(const uint32_t &pAddress, const uint64_t &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type uint32.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueUInt32(const uint32_t &pAddress, uint32_t &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type uint32.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueUInt32(const uint32_t &pAddress, const uint32_t &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type uint16.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueUInt16(const uint32_t &pAddress, uint16_t &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type uint16.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueUInt16(const uint32_t &pAddress, const uint16_t &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type uint8.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueUInt8(const uint32_t &pAddress, uint8_t &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type uint8.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueUInt8(const uint32_t &pAddress, const uint8_t &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type float.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueFloat(const uint32_t &pAddress, float &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type float.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueFloat(const uint32_t &pAddress, const float &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type double.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueDouble(const uint32_t &pAddress, double &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type double.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueDouble(const uint32_t &pAddress, const double &pData) override;

            /**
             * @brief Retrieve the value of the specified object address for a type boolean.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t getValueBool(const uint32_t &pAddress, bool &pData) const override;

            /**
             * @brief Modify the value of the specified object address for a type boolean.
             *
             * @param pAddress The object address.
             * @param pData The object value.
             * @return ERROR_NONE if no error occurred
             */
            virtual ezw_error_t setValueBool(const uint32_t &pAddress, const bool &pData) override;

          private:
            bool mInitialized;
            int  mContextId;

            std::shared_ptr<v1::commonapi::SmcService::CoreProxy<>>          mCoreProxy;
            std::shared_ptr<v1::commonapi::SmcService::InternalProxy<>>      mInternalProxy;
            std::shared_ptr<v1::commonapi::SmcService::NMTProxy<>>           mNMTProxy;
            std::shared_ptr<v1::commonapi::SmcService::EMCYProxy<>>          mEMCYProxy;
            std::shared_ptr<v1::commonapi::SmcService::PDSProxy<>>           mPDSProxy;
            std::shared_ptr<v1::commonapi::SmcService::SafeMotionProxy<>>    mSafeMotionProxy;
            std::shared_ptr<v1::commonapi::SmcService::CommunicationProxy<>> mCommunicationProxy;
            std::shared_ptr<v1::commonapi::SmcService::ManufacturerProxy<>>  mManufacturerProxy;
            std::shared_ptr<v1::commonapi::SmcService::VelocityModeProxy<>>  mVelocityModeProxy;
            std::shared_ptr<v1::commonapi::SmcService::SRDOProxy<>>          mSRDOProxy;
            std::shared_ptr<v1::commonapi::SmcService::CANOpenProxy<>>       mCANOpenProxy;

            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::CoreProxy>          mCoreClientDelegate;
            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::InternalProxy>      mInternalClientDelegate;
            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::NMTProxy>           mNMTClientDelegate;
            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::EMCYProxy>          mEMCYClientDelegate;
            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::PDSProxy>           mPDSClientDelegate;
            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::SafeMotionProxy>    mSafeMotionClientDelegate;
            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::CommunicationProxy> mCommunicationClientDelegate;
            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::ManufacturerProxy>  mManufacturerClientDelegate;
            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::VelocityModeProxy>  mVelocityModeClientDelegate;
            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::SRDOProxy>          mSRDOClientDelegate;
            ezw::tools::DBusClientDelegate<v1::commonapi::SmcService::CANOpenProxy>       mCANOpenClientDelegate;
        };
    } // namespace smcservice
} // namespace ezw

#endif /* EZW_SMCSERVICE_DBUSCLIENT_HPP */
