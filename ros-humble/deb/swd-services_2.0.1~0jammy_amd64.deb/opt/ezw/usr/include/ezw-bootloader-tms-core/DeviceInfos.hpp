/**
 * Copyright (C) 2022 EZ-Wheel S.A.S.
 *
 * @file DeviceInfos.hpp
 * @brief handle device infos data
 */

#ifndef EZW_BOOTLOADERTMS_DEVICEINFOS_HPP
#define EZW_BOOTLOADERTMS_DEVICEINFOS_HPP

#include <string>

namespace ezw {
    namespace bootloadertms {

        class DeviceInfos {
           public:
            DeviceInfos();

            DeviceInfos(const std::string& pSerialNumber, const std::string& pHardwareId, const std::string& pProductId, const std::string& pReference, const std::string& pVersion, const std::string& pBootStatus);

            virtual ~DeviceInfos();

            // @brief get the serial number of the device
            const std::string& getSerialNumber() const;
            // @brief get the hardware id of the device
            const std::string& getHardwareId() const;
            // @brief get the product id of the device
            const std::string& getProductId() const;
            // @brief get the firmware reference of the device
            const std::string& getReference() const;
            // @brief get the firmware version of the device
            const std::string& getVersion() const;
            // @brief get the boot status of the device
            const std::string& getBootStatus() const;

           private:
            std::string mSerialNumber;
            std::string mHardwareId;
            std::string mProductId;
            std::string mReference;
            std::string mVersion;
            std::string mBootStatus;
        };
    }  // namespace bootloadertms
}  // namespace ezw

#endif /* EZW_BOOTLOADERTMS_DEVICEINFOS_HPP */
