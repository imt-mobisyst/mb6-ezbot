/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file IBootLoader.hpp
 * @brief EZW serial port header file
 */

#ifndef EZW_BOOTLOADERTMS_IBOOTLOADER_HPP
#define EZW_BOOTLOADERTMS_IBOOTLOADER_HPP

#include <string>

#include "AppInfos.hpp"
#include "DeviceInfos.hpp"
#include "FeedbackListener.hpp"
#include "ISerialPort.hpp"

namespace ezw {
    namespace bootloadertms {

        enum BL_CMD {
            BL_CMD_UPLOAD_APPLI = 0x2A, /* '*' */
            BL_CMD_PING = 0x30,
            BL_CMD_WRITE_APPLI = 0x31,
            BL_CMD_READ_BYTE = 0x32,
            BL_CMD_WRITE_BYTE = 0x33,
            BL_CMD_ERASE = 0x34,
            BL_CMD_IS_VALIDATE = 0x35,
            BL_CMD_EXEC_APP = 0x36,
            BL_CMD_HW_INFO = 0x37,
            BL_CMD_BL_INFO = 0x38,
            BL_CMD_APP_INFO = 0x39,
            BL_CMD_DEVICE_INFO = 0x100,
            BL_CMD_RESTORE_DEFAULT_PARAMTERS = 0x110,
        };

        enum BL_STS {
            BL_STS_ACTIVE = 0x41,           /* A */
            BL_STS_ACTION_SUCCEEDED = 0x4F, /* O */
            BL_STS_ACTION_FAILED = 0x46,    /* F */
            BL_STS_UNKNOWN_CMD = 0x55,      /* U */
            BL_STS_NONE_APP = 0x4E          /* N */
        };

        enum APP_CMD {
            // launch calib motor application
            APP_CALIB = 0x4B,
            // activation code of bootloader from TMS's application
            APP_ACTIVE_BOOTLOADER = 0x51,
            // ping TMS's application
            APP_PING = 0x52,
            APP_CMD_SAFE_BOOT_STATUS = 0x62, /* b */
            APP_CMD_DEVICE_INFO = 0x200,
        };

        // @brief IBootLoader interface is used to interact with firmware bootloader.
        class IBootLoader {
           public:
            /**
             * @brief ping bootloader.
             * @param serial serial port to communicate
             * @return retry number. If 0 ping has failed
             */
            virtual uint8_t pingBootloader() = 0;

            /**
             * @brief ping application.
             * @param serial serial port to communicate
             * @return retry number. If 0 ping has failed
             */
            virtual uint8_t pingApplication() = 0;

            virtual uint8_t calibrationApplication() = 0;

            /**
             * @brief Active Bootloader
             * @param serial serial port to communicate
             * @throws std::runtime_error Thrown if bootloader doesn't respond.
             */
            virtual void activeBootloader() = 0;

            /**
             * @brief Active Application
             * @param serial serial port to communicate
             * @throws std::runtime_error Thrown if bootloader still respond.
             */
            virtual void activeApplication() = 0;

            /**
             * @brief Get Information
             * @param serial serial port to communicate
             * @param cmd information command id
             * @return Information
             * @throws std::runtime_error Thrown if an invalid response is received.
             */
            virtual const std::string getInformation(const BL_CMD cmd) = 0;

            virtual const std::string getInformation(const APP_CMD cmd) = 0;

            /**
             * @brief Upload a .bin file
             * @param filename file path to upload
             * @throws std::runtime_error Thrown if an error occured.
             */
            virtual void uploadFile(const std::string& filename) = 0;

            virtual void uploadFile(const std::string& filename, const AppInfos& appInfos) = 0;

            virtual void verbose(bool active) = 0;

            virtual void setFeedbackListener(feedback_listener p_cb) = 0;

            virtual const DeviceInfos getBlDeviceInformation() = 0;
            virtual const DeviceInfos getAppDeviceInformation() = 0;

            virtual void restoreDefaultParameters() = 0;

            /**
             * @brief Send command
             */
            virtual const std::string sendCommand(const char cmd) = 0;
        };
    }  // namespace bootloadertms
}  // namespace ezw
#endif /* EZW_BOOTLOADERTMS_IBOOTLOADER_HPP */
