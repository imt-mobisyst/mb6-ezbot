/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file ISerialPort.hpp
 * @brief EZW serial port header file
 */

#ifndef EZW_BOOTLOADERTMS_ISERIALPORT_HPP
#define EZW_BOOTLOADERTMS_ISERIALPORT_HPP

#include <fstream>
#include <sstream>
#include <string>
#include <vector>

namespace ezw {
    namespace bootloadertms {
        enum class State {
            CLOSED,
            OPEN
        };

        // @brief ISerialPort interface is used to perform rx/tx serial communication.
        class ISerialPort {
           public:
            // @brief	   Sets the device to use for serial port communications.
            // @details    Method can be called when serial port is in any state.
            virtual void setDevice(const std::string &device) = 0;

            virtual std::string getDevice() const = 0;

            virtual void setBaudRate(const uint32_t baudRate) = 0;

            virtual uint32_t getBaudRate() const = 0;

            // @brief      Sets the read timeout (in milliseconds)or blocking mode.
            // @details    Only call when state != OPEN. This method manipulates VMIN and VTIME.
            // @param      timeout_ms  Set to -1 to infinite timeout, 0 to return immediately with any data (non
            //             blocking, or >0 to wait for data for a specified number of milliseconds). Timeout will
            //             be rounded to the nearest 100ms (a Linux API restriction). Maximum value limited to
            //             25500ms (another Linux API restriction).
            virtual void setTimeout(int32_t timeoutMs) = 0;

            // @brief		Enables/disables echo.
            // @param		echoOn true to enable echo, false to disable echo.
            virtual void setEcho(bool echoOn) = 0;

            // @brief		Opens the COM port for use.
            // @throws		std::runtime_error if device cannot be opened.
            // @note		Must call this before you can configure the COM port.
            virtual void openSerial() = 0;

            // @brief		Closes the COM port.
            virtual void closeSerial() = 0;

            // @brief		Sends a message over the com port.
            // @param		data The data that will be written to the COM port.
            // @throws		std::runtime_error if state != OPEN.
            virtual void writeSerial(const std::string &data) = 0;

            // @brief		Sends a message over the com port.
            // @param		data The data that will be written to the COM port.
            // @param       delay_ms The delay between each characters to be written to the COM port.
            // @throws		std::runtime_error if state != OPEN.
            virtual void writeSerial(const std::string &data, uint32_t delay_ms) = 0;

            // @brief		Use to read from the COM port.
            // @param		data		The object the read characters from the COM port will be saved to.
            // @throws		std::runtime_error if state != OPEN.
            virtual void readSerial(std::string &data) = 0;

            // @brief		Sends a char over the com port.
            // @param		dataChar
            // @throws		std::runtime_error if state != OPEN.
            virtual void writeCharSerial(const char dataChar) = 0;

            // @brief		Use to read char from the COM port.
            // @return		data_char
            //
            // @throws		std::runtime_error if state != OPEN.
            virtual char readCharSerial() = 0;

            // @brief               flush all data unread from receive buffer
            virtual void flushRx() = 0;
        };
    }  // namespace bootloadertms
}  // namespace ezw
#endif /* EZW_BOOTLOADERTMS_ISERIALPORT_HPP */
