/**
 * Copyright (C) 2022 EZ-Wheel S.A.S.
 *
 * @file AppInfos.hpp
 * @brief handle app infos data
 * Send with ymodem packet zero
 */

#ifndef EZW_BOOTLOADERTMS_APPINFOS_HPP
#define EZW_BOOTLOADERTMS_APPINFOS_HPP

#include <string>

namespace ezw {
    namespace bootloadertms {

        class AppInfos {
           public:
            AppInfos(const std::string& pVersion, const std::string& pUserName, const std::string& pTimestamp);

            virtual ~AppInfos();

            // @brief get firmware update version
            const std::string& getVersion() const;
            // @brief get firmware update userName
            const std::string& getUserName() const;
            // @brief get firmware update timestamp
            const std::string& getTimestamp() const;

           private:
            std::string mVersion;
            std::string mUserName;
            std::string mTimestamp;
        };
    }  // namespace bootloadertms
}  // namespace ezw

#endif /* EZW_BOOTLOADERTMS_APPINFOS_HPP */
