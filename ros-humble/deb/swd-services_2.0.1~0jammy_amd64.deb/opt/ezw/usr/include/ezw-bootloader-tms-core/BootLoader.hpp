/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file BootLoader.hpp
 * @brief bootloader implementation
 */

#ifndef EZW_BOOTLOADERTMS_BOOTLOADER_HPP
#define EZW_BOOTLOADERTMS_BOOTLOADER_HPP

#include <memory>
#include <mutex>
#include <string>

#include "IBootLoader.hpp"

namespace ezw {
    namespace bootloadertms {
        class BootLoader : public IBootLoader {
           public:
            BootLoader(const std::string &device, const uint32_t baudRate);
            ~BootLoader();

            // IBootLoader
            uint8_t pingBootloader() override;
            uint8_t pingApplication() override;
            uint8_t calibrationApplication() override;
            void activeBootloader() override;
            void activeApplication() override;
            const std::string getInformation(const BL_CMD cmd) override;
            const std::string getInformation(const APP_CMD cmd) override;
            void uploadFile(const std::string &filename) override;
            void uploadFile(const std::string &filename, const AppInfos &appInfos) override;
            void verbose(bool active) override;
            void setFeedbackListener(feedback_listener p_cb) override;
            const DeviceInfos getBlDeviceInformation() override;
            const DeviceInfos getAppDeviceInformation() override;
            void restoreDefaultParameters() override;
            const std::string sendCommand(const char cmd) override;

           private:
            static std::string exec(const char *cmd);
            uint8_t _pingBootloader();
            uint8_t _pingApplication();

#ifndef _WIN32
            bool isDevPortUsed(const std::string &devPort);
#endif

            std::unique_ptr<ISerialPort> m_serial;
            std::mutex m_mutex;
            feedback_listener m_feedbackListener = nullptr;
        };
    }  // namespace bootloadertms
}  // namespace ezw

#endif /* EZW_BOOTLOADERTMS_BOOTLOADER_HPP */
