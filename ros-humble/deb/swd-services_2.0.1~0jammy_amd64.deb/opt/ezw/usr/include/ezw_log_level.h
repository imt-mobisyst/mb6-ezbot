/*
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @brief ezw-log levels definition header
 */

#ifndef EZW_LOG_LEVEL_H
#define EZW_LOG_LEVEL_H

#ifdef ENABLE_DLT
typedef DltLogLevelType ezw_log_level_t;
typedef DltContext ezw_log_context_t;
#else

/**
 * Definitions of log levels
 */
typedef enum
{
    EZW_LOG_DEFAULT =             -1,   /**< Default log level */
    EZW_LOG_OFF     =           0x00,   /**< Log level off */
    EZW_LOG_FATAL   =           0x01,   /**< fatal system error */
    EZW_LOG_ERROR   =           0x02,   /**< error with impact to correct functionality */
    EZW_LOG_WARN    =           0x03,   /**< warning, correct behaviour could not be ensured */
    EZW_LOG_INFO    =           0x04,   /**< informational */
    EZW_LOG_DEBUG   =           0x05,   /**< debug  */
    EZW_LOG_VERBOSE =           0x06,   /**< highest grade of information */
    EZW_LOG_MAX     =           0x07    /**< maximum value, used for range check */
} ezw_log_level_t;

#endif /*else of #ifdef ENABLE_DLT*/

#endif /* EZW_LOG_LEVEL_H */
