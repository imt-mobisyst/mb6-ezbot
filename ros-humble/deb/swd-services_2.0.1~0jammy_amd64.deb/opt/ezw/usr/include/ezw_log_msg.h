/*
 * Copyright (C) 2018 EZ-Wheel S.A.S.
 *
 * @brief ezw-log message types definitions public header
 */

#ifndef EZW_LOG_MSG_H
#define EZW_LOG_MSG_H

#include "ezw_types.h"

#include <stdlib.h>

#define EZW_LOG_MSG_END_BYTE (0xffU)     /**< Ending byte of an ezw-log message */

#define EZW_LOG_SIZE_SHIFT (3U)          /**< Size shares a byte with type */
#define EZW_LOG_STRING_SIZE_SHIFT (1U)   /**< String syze an type are a special case */

#define EZW_LOG_TYPE_MASK (0x07U)        /**< Size shares a byte with type */
#define EZW_LOG_STRING_TYPE_MASK (0x01U) /**< String syze an type are a special case */

#define EZW_LOG_MSG_BUFFER_SIZE 255U

/**
 * @brief ezw-log message structure
 *
 * Messages have an absolute maximum size of EZW_LOG_MSG_BUFFER_SIZE.
 */
typedef struct {
    uint8_t buffer[EZW_LOG_MSG_BUFFER_SIZE];
} ezw_log_msg_t;

typedef enum {
    EZW_LOG_TYPE_STRING = 0x00, /**< must be the only even value */

    EZW_LOG_TYPE_INT    = 0x01, /**< signed integer */
    EZW_LOG_TYPE_UINT   = 0x03, /**< unsigned integer */
    EZW_LOG_TYPE_FLOAT  = 0x05, /**< floating point representation of a number */

    EZW_LOG_TYPE_OTHER  = 0x07, /**< currently unsupported */
} ezw_log_type_t;

/** @brief float32 definition
 */
typedef float float32_t;

/** @brief float32 minimum value
 */
#define FLOAT32_MIN 1.175494e-38

/** @brief float32 maximum value
 */
#define FLOAT32_MAX 3.402823e+38

/** @brief float64 definition
 */
typedef double float64_t;

#endif/*EZW_LOG_MSG_H*/
