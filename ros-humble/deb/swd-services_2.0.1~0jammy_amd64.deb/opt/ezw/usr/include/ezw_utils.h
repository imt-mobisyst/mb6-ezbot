/*
 * Copyright (C) 2021 EZ-Wheel S.A.S
 *
 * @brief utils definitions header
 */

#ifndef EZW_UTILS_H
#define EZW_UTILS_H

#include "ezw_types.h"

/** @defgroup ezw-types ezw-types
 * EZW_TYPES module.
 */

/** @defgroup ezw-types-public public
 * Public API functions.
 * @ingroup ezw-types
 * @{
 */

/** @defgroup ezw-types-public-functions functions
 * @ingroup ezw-types-public
 * @{
 */

static inline uint8_t ezw_utils_get_bit_u8(uint8_t value, uint8_t bit)
{
    return ((value) & (1U << (bit))) >> (bit);
}

static inline uint8_t ezw_utils_set_bit_u8(uint8_t value, uint8_t bit_value, uint8_t bit)
{
    return ((value) & (~(1U << (bit)))) | ((bit_value) << (bit));
}

static inline uint32_t ezw_utils_set_bit_u32(uint32_t value, uint32_t bit_value, uint32_t bit)
{
    return ((value) & (~(1U << (bit)))) | ((bit_value) << (bit));
}

static inline ezw_bool_t ezw_utils_is_bit_set_u8(uint8_t value, uint8_t bit)
{
    return (((value) & (1U << (bit))) == (1U << (bit))) ? EZW_TRUE : EZW_FALSE;
}

static inline ezw_bool_t ezw_utils_is_bit_set_u32(uint32_t value, uint32_t bit)
{
    return (((value) & ((uint32_t)1U << (bit))) == (uint32_t)((uint32_t)1U << (bit))) ? EZW_TRUE : EZW_FALSE;
}

/* Deviation from std memcmp: returns   */
/* -1 if p1[i] < p2[i]                  */
/*  0 if p1[0..n-1] == p2[0..n-1]       */
/* +1 if p1[i] > p2[i]                  */
static inline int32_t ezw_utils_memcmp_U8(const uint8_t s1[], const uint8_t s2[], const uint32_t n)
{
    int32_t ret = 0;

    if ((s1 && s2) && (n > 0U))
    {
        uint32_t i = 0U;

        do {
            if (s1[i] < s2[i])
            {
                ret = -1;
            }
            else if (s1[i] > s2[i])
            {
                ret = 1;
            }
            else {
                /* Nothing to do */
            }

            i++;
        } while ((0 == ret) && (i < n));
    }
    return ret;
}

static inline uint8_t *ezw_utils_memcpy_U8(uint8_t * const dest, const uint8_t * const src, const uint32_t n)
{
    if (dest && src)
    {
        for (uint32_t i = 0; i < n; i++)
        {
            dest[i] = src[i];
        }
    }
    return dest;
}

static inline int32_t ezw_rpm_to_mdeg_sec_int32(int32_t rot_per_min)
{
    return rot_per_min * (360000 / 60);
}

static inline uint32_t ezw_rpm_to_mdeg_sec_uint32(uint32_t rot_per_min)
{
    return rot_per_min * (360000U / 60U);
}

static inline int16_t ezw_mdeg_sec_to_rpm(angular_speed_mdeg_per_s_t mdeg_per_sec)
{
    return (int16_t)(mdeg_per_sec * 60 / 360000);
}

/** @} */

/** @} */

#endif /* EZW_UTILS_H */
