/**
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file SharedMemory.hpp
 */

#ifndef EZW_TOOLS_SHAREDMEMORY_HPP
#define EZW_TOOLS_SHAREDMEMORY_HPP

#include "Flock.hpp"

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <fcntl.h>
#include <unistd.h>

#include <string>

namespace ezw
{
    namespace tools
    {
        template <typename DataContainer> class SharedMemory {
          public:
            SharedMemory() : mSharedMemory(nullptr)
            {
            }

            ~SharedMemory()
            {
                if (mSharedMemory != nullptr) {
                    munmap(mSharedMemory, sizeof(DataContainer));
                    shm_unlink((mName + "SHM").c_str());
                }
            }

            bool init(const std::string &pName)
            {
                if (!mFlock.init(pName)) {
                    return false;
                }

                // Create/Open shared memory region
                int fd = shm_open((pName + "SHM").c_str(), O_RDWR | O_CREAT, S_IRWXU);

                if (fd < 0) {
                    // EZW_LOG(pStreamInfos.contextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Cannot open shared memory").c_str()));
                    return false;
                }

                ftruncate(fd, sizeof(DataContainer));

                void *memptr = mmap(NULL, sizeof(DataContainer), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
                if (memptr == (void *)-1) {
                    // EZW_LOG(pStreamInfos.contextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR(std::string("Cannot access shared memory").c_str()));
                    return false;
                }

                close(fd);

                // It's ok
                mSharedMemory = (DataContainer *)memptr;

                return true;
            }

            bool valid()
            {
                return mSharedMemory != nullptr;
            }

            void lock()
            {
                mFlock.lock();
            }

            bool tryLock()
            {
                return mFlock.tryLock();
            }

            void unlock()
            {
                mFlock.unlock();
            }

            DataContainer *get()
            {
                return mSharedMemory;
            }

          private:
            std::string    mName;
            DataContainer *mSharedMemory;
            Flock          mFlock;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_SHAREDMEMORY_HPP */
