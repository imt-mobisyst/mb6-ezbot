/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file StringUtility.hpp
 */

#ifndef EZW_TOOLS_STRINGUTILITY_HPP
#define EZW_TOOLS_STRINGUTILITY_HPP

#include <string>
#include <vector>

namespace ezw
{
    namespace tools
    {
        class StringUtility {
          public:
            static void trim(std::string &pStr);

            static std::string format(const int number, const int nbDigit = 2);

            /**
             * @brief Split string by specificed delimiter (newline by default)
             *
             * @param str
             * @return std::vector<std::string>
             */
            static std::vector<std::string> splitString(const std::string &str, char delim = '\n');

            /**
             * @brief Get the tail of a string
             *
             * @param source
             * @param length
             * @return std::string
             */
            static std::string tail(const std::string &source, const size_t length);

            /**
             * @brief Compare two Version numbers
             * A version number looks like a.b.c.d (ie. "1.0.31")
             *
             * @param v1 First version
             * @param v2 Second version
             * @return 1 if v1 is greater, -1 if v1 is smaller, 0 if equal
             */
            static int versionCompare(const std::string &v1, const std::string &v2);
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_STRINGUTILITY_HPP */
