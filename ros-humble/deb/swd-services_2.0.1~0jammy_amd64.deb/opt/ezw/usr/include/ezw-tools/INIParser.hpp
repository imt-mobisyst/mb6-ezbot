/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file INIParser.hpp
 */

#ifndef EZW_TOOLS_INIPARSER_HPP
#define EZW_TOOLS_INIPARSER_HPP

#include <fstream>
#include <map>
#include <string>
#include <vector>

namespace ezw
{
    namespace tools
    {
        // Sometimes, we need a singleton, we can use IniParser
        // Sometimes, we don't want a singleton, we can use IniParserClass

        class INIParserClass {
          public:
            INIParserClass();

            bool parse(std::istream &pCfgFile, bool pPrintResult = true);

            bool getInteger(const std::string &pKeyname, int &pValue, const std::string &pKeySection = "default") const;
            bool getUInteger(const std::string &pKeyname, unsigned int &pValue, const std::string &pKeySection = "default") const;
            bool getString(const std::string &pKeyname, std::string &pValue, const std::string &pKeySection = "default") const;
            bool getBoolean(const std::string &pKeyname, bool &pValue, const std::string &pKeySection = "default") const;
            bool getDouble(const std::string &pKeyname, double &pValue, const std::string &pKeySection = "default") const;

            std::map<std::string, std::map<std::string, std::string>> &getKeySections();
            std::vector<std::string> &                                 getKeySectionsInsertOrder();
            std::map<std::string, std::vector<std::string>> &          getKeysInsertOrder();

          private:
            std::map<std::string, std::map<std::string, std::string>> mKeySections;
            std::vector<std::string>                                  mKeySectionsInsertOrder;
            std::map<std::string, std::vector<std::string>>           mKeysInsertOrder;
        };

        class INIParser : public INIParserClass {
          public:
            static INIParser *instance();

          private:
            INIParser();

            static INIParser *mInstance;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_INIPARSER_HPP */
