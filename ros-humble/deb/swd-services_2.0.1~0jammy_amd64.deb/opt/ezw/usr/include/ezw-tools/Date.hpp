/**
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file Date.hpp
 */

#ifndef EZW_TOOLS_DATE_HPP
#define EZW_TOOLS_DATE_HPP

#include <string>

namespace ezw
{
    namespace tools
    {
        class Date {
          public:
            static std::string returnCurrentTime();
            static std::string returnCurrentDate();

            /**
             * @brief Format current time as an ISO 8601 string with fractional seconds to 3 decimal places.
             * Warning will not work for any date/times before the start of the UNIX epoch.
             *
             * @return ISO 8601 string (e.g. 2016-08-30T08:18:51.861)
             */
            static std::string getCurrentISO8601TimeUTC();
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_DATE_HPP */