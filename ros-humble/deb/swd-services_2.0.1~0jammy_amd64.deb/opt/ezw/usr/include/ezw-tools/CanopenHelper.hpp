/**
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file CanopenHelper.hpp
 */

#ifndef EZW_TOOLS_CANOPENHELPER_HPP
#define EZW_TOOLS_CANOPENHELPER_HPP

#include "ezw_log.h"
#include "ezw_types.h"

#include <string>

namespace ezw
{
    namespace tools
    {
        class CanopenHelper {
            static constexpr const char *mClassName = "CanopenHelper";

          public:
            static ezw_app_state_t computeState(const uint8_t pNodeState, const ezw_app_state_t pAppState, const uint32_t pContextId = CON_APP);
            static bool            isNodeStateValid(const ezw_app_state_t pInternalNodeState, const uint8_t pCanNodeState, const uint32_t pContextId = CON_APP);
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_CANOPENHELPER_HPP */
