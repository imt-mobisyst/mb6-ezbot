/**
 *
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file Exec.hpp
 */

#ifndef EZW_TOOLS_EXEC_HPP
#define EZW_TOOLS_EXEC_HPP

#include <array>
#include <cstdio>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>

namespace ezw
{
    namespace tools
    {
        inline std::string exec(const char *pCmd)
        {
            std::array<char, 128>                    lBuffer;
            std::string                              lResult;
            std::unique_ptr<FILE, decltype(&pclose)> lPipe(popen(pCmd, "r"), pclose);

            if (!lPipe) {
                throw std::runtime_error("popen() failed!");
            }
            while (fgets(lBuffer.data(), lBuffer.size(), lPipe.get()) != nullptr) {
                lResult += lBuffer.data();
            }

            lResult.erase(lResult.find_last_not_of(" \n\r\t") + 1); // Trim result

            return lResult;
        }
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_EXEC_HPP */
