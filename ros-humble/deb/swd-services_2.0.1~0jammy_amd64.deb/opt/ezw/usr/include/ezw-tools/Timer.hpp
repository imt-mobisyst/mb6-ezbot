/**
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file Timer.hpp
 */

#ifndef EZW_TOOLS_TIMER_HPP
#define EZW_TOOLS_TIMER_HPP

#include <chrono>
#include <functional>
#include <iostream>
#include <thread>

namespace ezw
{
    namespace tools
    {
        /**
         *  Create asynchronous timers which execute specified
         *  functions in set time interval.
         */
        class Timer {
          public:
            Timer()
            {
            }

            /**
             * @brief Construct a new Timer object
             *
             * @param pFunc	 Function with one argument which sould be executed; arg1 => ended flag
             * @param pInterval Interval of time in which function will be executed (in milliseconds)
             */
            Timer(std::function<void(bool)> pFunc, const long &pInterval) : mFunc(pFunc), mInterval(pInterval)
            {
            }

            /**
             * Starting the timer.
             */
            void start()
            {
                if (mRunning) {
                    return;
                }

                mRunning = true;
                mThread  = std::thread([this]() {
                    while (mRunning) {
                        // Record start time
                        auto lStart = std::chrono::steady_clock::now();

                        if (mFunc) {
                            // Call function to execute with ended arg to false
                            mFunc(!mRunning);
                        }

                        if (mInterval == 0) {
                            mRunning = false;
                        } else {
                            // Record end time
                            auto lElapsed = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - lStart).count();

                            if (lElapsed > mInterval) {
                                //                            std::cout << "Process Call function overload : " << lElapsed << " ms instead of " << mInterval << " ms" << std::endl;
                                lElapsed = 0; // mInterval; // Pass a cycle in case of overload
                            }

                            //                        std::cout << "Process call function : " << lElapsed << " ms / " << mInterval << " ms" << std::endl;

                            // Waits
                            std::this_thread::sleep_for(std::chrono::milliseconds(mInterval - static_cast<int>(lElapsed)));
                        }
                    }

                    // Call function once with ended arg to true
                    mFunc(!mRunning);
                });
            }

            /*
             *  Stopping the timer and destroys the thread.
             */
            void stop()
            {
                mRunning = false;
                if (mThread.joinable()) {
                    mThread.join();
                }
            }

            /*
             *  Restarts the timer. Needed if you set a new
             *  timer interval for example.
             */
            void restart()
            {
                stop();
                start();
            }

            /*
             *  Check if timer is running.
             *
             *  @returns boolean is running
             */
            bool isRunning()
            {
                return mRunning;
            }

            /*
             *  Set a new function which sould be executed
             *
             *  @param pFunc Function with one argument which sould be executed; arg1 => ended flag
             *  @return  Timer reference of this
             */
            Timer *setFunc(std::function<void(bool)> pFunc)
            {
                mFunc = pFunc;
                return this;
            }

            /*
             *  Returns the current set interval in milliseconds.
             *
             *  @returns long interval
             */
            long getInterval()
            {
                return mInterval;
            }

            /*
             *  Set a new interval for the timer in milliseconds.
             *  This change will be valid only after restarting
             *  the timer.
             *
             *  @param pInterval new interval
             *  @return  Timer reference of this
             */
            Timer *setInterval(const long &pInterval)
            {
                mInterval = pInterval;
                return this;
            }

            ~Timer()
            {
                stop();
            }

          private:
            // Function to be executed after interval
            std::function<void(bool)> mFunc;

            // Timer interval in milliseconds
            long mInterval;

            // Thread timer is running into
            std::thread mThread;

            // Status if timer is running
            bool mRunning = false;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_TIMER_HPP */
