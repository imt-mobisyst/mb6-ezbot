/**
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file EDSParser.hpp
 */

#ifndef EZW_TOOLS_EDSPARSER_HPP
#define EZW_TOOLS_EDSPARSER_HPP

#include <fstream>
#include <iostream>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

template <typename T> std::string toHex(T pValue)
{
    std::stringstream stream;

    stream << "0x" << std::uppercase << std::hex << +pValue;
    return stream.str();
}

namespace ezw
{
    namespace tools
    {
        typedef enum
        {
            DT_UNKNOWN         = 0,
            DT_BOOL            = 1,
            DT_INT8            = 2,
            DT_INT16           = 3,
            DT_INT32           = 4,
            DT_UINT8           = 5,
            DT_UINT16          = 6,
            DT_UINT32          = 7,
            DT_REAL32          = 8,
            DT_STRING          = 9,
            DT_OCTET_STRING    = 0xA,
            DT_DATE            = 0xB,
            DT_TIME_OF_DAY     = 0xC,
            DT_TIME_DIFFERENCE = 0xD,
            DT_BIT_STRING      = 0xE,
            DT_DOMAIN          = 0xF,
            DT_REAL64          = 0x11, // PDO CommPar
            DT_INT64           = 0x15, // PDO Mapping
            DT_UINT64          = 0x18  // SDO Parameter
        } DataType;

        inline DataType convert_EDS_Types(int const &pDataType)
        {
            switch (pDataType) {
                case 0x01:
                {
                    return DT_BOOL;
                }
                case 0x02:
                {
                    return DT_INT8;
                }
                case 0x03:
                {
                    return DT_INT16;
                }
                case 0x04:
                {
                    return DT_INT32;
                }
                case 0x05:
                {
                    return DT_UINT8;
                }
                case 0x06:
                {
                    return DT_UINT16;
                }
                case 0x07:
                {
                    return DT_UINT32;
                }
                case 0x08:
                {
                    return DT_REAL32;
                }
                case 0x09:
                {
                    return DT_STRING;
                }
                case 0xA:
                {
                    return DT_OCTET_STRING;
                }
                case 0xB:
                {
                    return DT_DATE;
                }
                case 0xC:
                {
                    return DT_TIME_OF_DAY;
                }
                case 0xD:
                {
                    return DT_TIME_DIFFERENCE;
                }
                case 0xE:
                {
                    return DT_BIT_STRING;
                }
                case 0x0F:
                {
                    return DT_DOMAIN;
                }
                case 0x11:
                {
                    return DT_REAL64;
                }
                case 0x15:
                {
                    return DT_INT64;
                }
                case 0x1B:
                {
                    return DT_UINT64;
                }
                default:
                {
                    return DT_UNKNOWN;
                }
            }
            return DT_UNKNOWN;
        }

        inline uint8_t convert_EDS_Size(DataType const &pDataType)
        {
            switch (pDataType) {
                case DT_BOOL:
                case DT_INT8:
                case DT_UINT8:
                {
                    return 0x8;
                }
                case DT_INT16:
                case DT_UINT16:
                {
                    return 0x10;
                }
                case DT_INT32:
                case DT_UINT32:
                case DT_REAL32:
                {
                    return 0x20;
                }
                case DT_REAL64:
                case DT_INT64:
                case DT_UINT64:
                {
                    return 0x40;
                }
                case DT_STRING:
                case DT_OCTET_STRING:
                case DT_BIT_STRING:
                case DT_DOMAIN:
                case DT_DATE:
                case DT_TIME_OF_DAY:
                case DT_TIME_DIFFERENCE:
                {
                    // TODO
                    return 0;
                }
                case DT_UNKNOWN:
                {
                    return 0;
                }
                default:
                {
                    return 0;
                }
            }
            return 0;
        }

        typedef enum
        {
            AT_UNKNOWN = 0,
            AT_RO      = 1,
            AT_WO      = 2,
            AT_RW      = 3,
            AT_CNST    = 4
        } AccessType;

        inline AccessType convert_EDS_Types(const std::string &pAccessType)
        {
            if (pAccessType == "const") {
                return AT_CNST;
            } else if (pAccessType == "ro") {
                return AT_RO;
            } else if (pAccessType == "rw") {
                return AT_RW;
            } else if (pAccessType == "wo") {
                return AT_WO;
            }

            return AT_UNKNOWN;
        }

        inline std::string convert_EDS_Types(const AccessType &pAccessType)
        {
            if (pAccessType == AT_CNST) {
                return "const";
            } else if (pAccessType == AT_RO) {
                return "ro";
            } else if (pAccessType == AT_RW) {
                return "rw";
            } else if (pAccessType == AT_WO) {
                return "wo";
            }

            return "";
        }

        typedef enum
        {
            OT_UNKNOWN = 0,
            OT_DOMAIN  = 2,
            OT_VAR     = 7,
            OT_ARR     = 8,
            OT_RECORD  = 9
        } ObjectType;

        class ObjectID {
          public:
            explicit ObjectID()
            {
                mKey = 0;
            }

            explicit ObjectID(const uint16_t &pIndex, const uint8_t &pSubindex)
            {
                mKey = ((pIndex << 8) & 0xFFFF00) + pSubindex;
            }

            uint32_t operator()() const
            {
                return mKey;
            }

            uint32_t get() const
            {
                return mKey;
            }

            uint16_t index() const
            {
                return (mKey >> 8) & 0xFFFF;
            }

            uint8_t subindex() const
            {
                return mKey & 0xFF;
            }

            bool operator==(ObjectID const &k) const
            {
                return mKey == k.get();
            }

            ObjectID &operator=(ObjectID const &k)
            {
                (mKey = k.get());
                return *this;
            }

            bool operator<(ObjectID const &k) const
            {
                return mKey < k.get();
            }

            bool operator>(ObjectID const &k) const
            {
                return mKey > k.get();
            }

          private:
            uint32_t mKey;
        };

        class ObjectEntry {
          public:
            explicit ObjectEntry()
            {
            }

            ObjectID    id;
            std::string section        = "";
            std::string name           = "";
            std::string parameterName  = "";
            std::string denotation     = ""; // DCF needed
            ObjectType  objectType     = OT_UNKNOWN;
            DataType    dataType       = DT_UNKNOWN;
            AccessType  accessType     = AT_UNKNOWN;
            bool        isPDOMappable  = false;
            std::string defaultValue   = "";
            std::string parameterValue = ""; // DCF needed
            uint8_t     subNumber      = 0;
            std::string lowLimit       = "";
            std::string highLimit      = "";

            uint32_t getObjectAddress()
            {
                return (id.get() << 8 & 0xFFFFFF00) + convert_EDS_Size(dataType);
            }

            uint32_t getObjectAddressNoSize()
            {
                return (id.get() << 8 & 0xFFFFFF00);
            }

            // ------------------------------------
            // Get/Set value with object address
            // ------------------------------------

            bool getValue(std::string &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                pData              = lValue;

                return true;
            }

            bool setValue(const std::string &pData)
            {
                parameterValue = pData;

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(int64_t &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                int         lBase  = (lValue.length() > 2 && lValue[0] == '0' && lValue[1] == 'x') ? 16 : 10;
                try {
                    pData = std::stol(lValue, nullptr, lBase);
                } catch (const std::exception &e) {
                    // Conversion failed
                    pData = 0;
                    if (lValue != "") {
                        std::cerr << e.what() << '\n';
                        return false;
                    }
                }

                return true;
            }

            bool setValue(const int64_t &pData)
            {
                parameterValue = (defaultValue.length() > 2 && defaultValue[0] == '0' && defaultValue[1] == 'x') ? toHex(pData) : std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(int32_t &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                int         lBase  = (lValue.length() > 2 && lValue[0] == '0' && lValue[1] == 'x') ? 16 : 10;
                try {
                    pData = std::stoi(lValue, nullptr, lBase);
                } catch (const std::exception &e) {
                    // Conversion failed
                    pData = 0;
                    if (lValue != "") {
                        std::cerr << e.what() << '\n';
                        return false;
                    }
                }

                return true;
            }

            bool setValue(const int32_t &pData)
            {
                parameterValue = (defaultValue.length() > 2 && defaultValue[0] == '0' && defaultValue[1] == 'x') ? toHex(pData) : std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(int16_t &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                int         lBase  = (lValue.length() > 2 && lValue[0] == '0' && lValue[1] == 'x') ? 16 : 10;
                try {
                    pData = std::stoi(lValue, nullptr, lBase);
                } catch (const std::exception &e) {
                    // Conversion failed
                    pData = 0;
                    if (lValue != "") {
                        std::cerr << e.what() << '\n';
                        return false;
                    }
                }

                return true;
            }

            bool setValue(const int16_t &pData)
            {
                parameterValue = (defaultValue.length() > 2 && defaultValue[0] == '0' && defaultValue[1] == 'x') ? toHex(pData) : std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(int8_t &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                int         lBase  = (lValue.length() > 2 && lValue[0] == '0' && lValue[1] == 'x') ? 16 : 10;
                try {
                    pData = std::stoi(lValue, nullptr, lBase);
                } catch (const std::exception &e) {
                    // Conversion failed
                    pData = 0;
                    if (lValue != "") {
                        std::cerr << e.what() << '\n';
                        return false;
                    }
                }

                return true;
            }

            bool setValue(const int8_t &pData)
            {
                parameterValue = (defaultValue.length() > 2 && defaultValue[0] == '0' && defaultValue[1] == 'x') ? toHex(pData) : std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(uint64_t &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                int         lBase  = (lValue.length() > 2 && lValue[0] == '0' && lValue[1] == 'x') ? 16 : 10;
                try {
                    pData = std::stoul(lValue, nullptr, lBase);
                } catch (const std::exception &e) {
                    // Conversion failed
                    pData = 0;
                    if (lValue != "") {
                        std::cerr << e.what() << '\n';
                        return false;
                    }
                }

                return true;
            }

            bool setValue(const uint64_t &pData)
            {
                parameterValue = (defaultValue.length() > 2 && defaultValue[0] == '0' && defaultValue[1] == 'x') ? toHex(pData) : std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(uint32_t &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                int         lBase  = (lValue.length() > 2 && lValue[0] == '0' && lValue[1] == 'x') ? 16 : 10;
                try {
                    pData = std::stoul(lValue, nullptr, lBase);
                } catch (const std::exception &e) {
                    // Conversion failed
                    pData = 0;
                    if (lValue != "") {
                        std::cerr << e.what() << '\n';
                        return false;
                    }
                }

                return true;
            }

            bool setValue(const uint32_t &pData)
            {
                parameterValue = (defaultValue.length() > 2 && defaultValue[0] == '0' && defaultValue[1] == 'x') ? toHex(pData) : std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(uint16_t &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                int         lBase  = (lValue.length() > 2 && lValue[0] == '0' && lValue[1] == 'x') ? 16 : 10;
                try {
                    pData = std::stoul(lValue, nullptr, lBase);
                } catch (const std::exception &e) {
                    // Conversion failed
                    pData = 0;
                    if (lValue != "") {
                        std::cerr << e.what() << '\n';
                        return false;
                    }
                }

                return true;
            }

            bool setValue(const uint16_t &pData)
            {
                parameterValue = (defaultValue.length() > 2 && defaultValue[0] == '0' && defaultValue[1] == 'x') ? toHex(pData) : std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(uint8_t &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                int         lBase  = (lValue.length() > 2 && lValue[0] == '0' && lValue[1] == 'x') ? 16 : 10;
                try {
                    pData = std::stoul(lValue, nullptr, lBase);
                } catch (const std::exception &e) {
                    // Conversion failed
                    pData = 0;
                    if (lValue != "") {
                        std::cerr << e.what() << '\n';
                        return false;
                    }
                }

                return true;
            }

            bool setValue(const uint8_t &pData)
            {
                parameterValue = (defaultValue.length() > 2 && defaultValue[0] == '0' && defaultValue[1] == 'x') ? toHex(pData) : std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(float &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                try {
                    pData = std::stof(lValue);
                } catch (const std::exception &e) {
                    // Conversion failed
                    pData = 0;
                    if (lValue != "") {
                        std::cerr << e.what() << '\n';
                        return false;
                    }
                }

                return true;
            }

            bool setValue(const float &pData)
            {
                parameterValue = std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(double &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                try {
                    pData = std::stod(lValue);
                } catch (const std::exception &e) {
                    // Conversion failed
                    pData = 0;
                    if (lValue != "") {
                        std::cerr << e.what() << '\n';
                        return false;
                    }
                }

                return true;
            }

            bool setValue(const double &pData)
            {
                parameterValue = std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            bool getValue(bool &pData)
            {
                std::string lValue = (parameterValue == "" ? defaultValue : parameterValue);
                pData              = (lValue == "1");

                return true;
            }

            bool setValue(const bool &pData)
            {
                parameterValue = std::to_string(pData);

                if (parameterValue == defaultValue) {
                    // No modification
                    parameterValue = "";
                }

                return true;
            }

            void print()
            {
                uint lIndex     = id.index();
                uint lSubIndex  = id.subindex();
                uint lSubNumber = subNumber;

                std::cout << "Object index=0x" << std::hex << lIndex << " sub=0x" << std::hex << lSubIndex << std::endl;
                std::cout << " section=" << section << std::endl;
                std::cout << " name=" << name << std::endl;
                std::cout << " parameterName=" << parameterName << std::endl;
                std::cout << " denotation=" << denotation << std::endl; // DCF needed
                std::cout << " objectType=" << (int)objectType << std::endl;
                std::cout << " dataType=" << (int)dataType << std::endl;
                std::cout << " accesType=" << (int)accessType << std::endl;
                std::cout << " isPDOMappable=" << isPDOMappable << std::endl;
                std::cout << " defaultValue=" << defaultValue << std::endl;
                std::cout << " parameterValue=" << defaultValue << std::endl; // DCF needed
                std::cout << " lowLimit=" << lowLimit << std::endl;
                std::cout << " highLimit=" << highLimit << std::endl;
                std::cout << " subNumber=" << lSubNumber << std::endl;
            }
        };

        class EDSParser {
          public:
            EDSParser();
            virtual ~EDSParser();

            bool parse(const std::string &pFileName, bool pPrintResult = false);
            bool saveToEds(const std::string &pFileName);
            bool saveToDcf(const std::string &pFileName);

            std::map<uint32_t, std::shared_ptr<ObjectEntry>> getObjects() const;

            std::shared_ptr<ObjectEntry> getObjectBySection(const std::string &pSection) const;
            std::shared_ptr<ObjectEntry> getObjectByID(const ObjectID &pID) const;
            std::shared_ptr<ObjectEntry> getObjectByName(const std::string &pName) const;
            std::shared_ptr<ObjectEntry> getObjectByAdress(const uint32_t &pAdress) const;

          private:
            bool save(const std::string &pFileName, bool pPrintResult = false);

            std::map<std::string, std::shared_ptr<ObjectEntry>> mObjectsBySection;
            std::map<ObjectID, std::shared_ptr<ObjectEntry>>    mObjectsByID;
            std::map<std::string, std::shared_ptr<ObjectEntry>> mObjectsByName;
            std::map<uint32_t, std::shared_ptr<ObjectEntry>>    mObjectsByAdress;

            std::unique_ptr<class INIParserClass> mINIParser;
            std::string                           mParseFileName;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_EDSPARSER_HPP */
