/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file DBusClientDelegate.hpp
 */

#ifndef EZW_TOOLS_DBUSCLIENTDELEGATE_HPP
#define EZW_TOOLS_DBUSCLIENTDELEGATE_HPP

#include "ezw_log.h"
#include "ezw_types.h"

#include <memory>
#include <string>
#include <unistd.h>

#include <CommonAPI/CommonAPI.hpp>

#if !defined(COMMONAPI_INTERNAL_COMPILATION)
#define COMMONAPI_INTERNAL_COMPILATION
#endif

#include <CommonAPI/DBus/DBusProxy.hpp>

#undef COMMONAPI_INTERNAL_COMPILATION

#define DBUS_MAX_ATTEMPTS                  3
#define DBUS_RETRY_INTERVAL                500U // in usecs
#define DBUS_MAX_AVAILABITILITY_CHECK_TIME 120  // in s

namespace ezw
{
    namespace tools
    {
        template <template <typename...> class ProxyClass> class DBusClientDelegate {
            static constexpr const char *mClassName = "DBusClientDelegate";

          public:
            DBusClientDelegate();
            virtual ~DBusClientDelegate();

            virtual ezw_error_t init(int pContextId, std::shared_ptr<ProxyClass<>> pProxy);
            virtual ezw_error_t call(std::function<void(CommonAPI::CallStatus &pCallStatus, int &pErrorCode)> pFunction) const;

          private:
            int  mContextId;
            bool mInitialized;

            std::shared_ptr<ProxyClass<>> mProxy;
        };

        template <template <typename...> class ProxyClass> DBusClientDelegate<ProxyClass>::DBusClientDelegate() : mContextId(CON_APP), mInitialized(false)
        {
            //
        }

        template <template <typename...> class ProxyClass> DBusClientDelegate<ProxyClass>::~DBusClientDelegate()
        {
            //
        }

        template <template <typename...> class ProxyClass> ezw_error_t DBusClientDelegate<ProxyClass>::init(int pContextId, std::shared_ptr<ProxyClass<>> pProxy)
        {
            mContextId = pContextId;

            if (mInitialized) {
                EZW_LOG(pContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR("Instance of client already initialized"));
                return ERROR_INTERNAL;
            }

            if (nullptr == pProxy) {
                EZW_LOG(pContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR("Proxy is null"));
                return ERROR_EXTERNAL;
            }

            EZW_LOG(pContextId, EZW_LOG_INFO, EZW_STR(mClassName), EZW_STR((std::string() + "Checking DBUS proxy availability : " + pProxy->getAddress().getInstance()).c_str()));
            fflush(stdout);

            auto lStartTime    = std::chrono::steady_clock::now();
            auto lMaxCheckTime = std::chrono::seconds(DBUS_MAX_AVAILABITILITY_CHECK_TIME);
            while (!pProxy->isAvailable()) {
                if ((std::chrono::steady_clock::now() - lStartTime) > lMaxCheckTime) {
                    EZW_LOG(pContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR((std::string() + "Checking DBus proxy availability timeout (" + std::to_string(lMaxCheckTime.count()) + "s) for proxy " + pProxy->getAddress().getInstance().c_str()).c_str()));
                    return ERROR_INTERNAL;
                }
                usleep(100000U); // 100ms
            }

            EZW_LOG(pContextId, EZW_LOG_INFO, EZW_STR(mClassName), EZW_STR((std::string() + "DBUS Proxy available : " + pProxy->getAddress().getInstance()).c_str()));
            fflush(stdout);

            mInitialized = true;

            return ERROR_NONE;
        }

        template <template <typename...> class ProxyClass> ezw_error_t DBusClientDelegate<ProxyClass>::call(std::function<void(CommonAPI::CallStatus &pCallStatus, int &pErrorCode)> pFunction) const
        {
            ezw_error_t lError = ERROR_NONE;

            if (!mInitialized) {
                EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR("Instance of client not initialized !"));
                return ERROR_NOT_INITIALIZED;
            }

            CommonAPI::CallStatus lCallStatus = CommonAPI::CallStatus::UNKNOWN;
            int32_t               lErrorCode;
            for (int i = 0; i < DBUS_MAX_ATTEMPTS; i++) {
                pFunction(lCallStatus, lErrorCode);

                if (CommonAPI::CallStatus::SUCCESS == lCallStatus) {
                    break;
                }

                EZW_LOG(mContextId, EZW_LOG_WARN, EZW_STR(mClassName), EZW_STR((std::string() + "Remote call failed -> retry attempt : " + std::to_string(i + 1)).c_str()));

                usleep(DBUS_RETRY_INTERVAL);
            }

            if (CommonAPI::CallStatus::SUCCESS != lCallStatus) {
                EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR((std::string() + "Remote call failed w/ (status: " + std::to_string((int)lCallStatus) + ")").c_str()));
                lError = ERROR_INTERNAL;
            } else if (ERROR_NONE != lErrorCode) {
                EZW_LOG(mContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR((std::string() + "Remote call failed w/ (lError: " + std::to_string(lErrorCode) + ")").c_str()));
                lError = static_cast<ezw_error_t>(lErrorCode);
            } else {
                EZW_LOG(mContextId, EZW_LOG_DEBUG, EZW_STR(mClassName), EZW_STR("Remote call success"));
            }

            return lError;
        }
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_DBUSCLIENTDELEGATE_HPP */
