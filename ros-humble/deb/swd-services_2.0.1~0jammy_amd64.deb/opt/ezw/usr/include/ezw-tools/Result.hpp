/**
 *
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file Result.hpp
 */

#ifndef EZW_TOOLS_RESULT_HPP
#define EZW_TOOLS_RESULT_HPP

namespace ezw
{
    namespace tools
    {
        template <typename T> class Result {
          public:
            Result() : error(0)
            {
            }

            T   value;
            int error;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_RESULT_HPP */
