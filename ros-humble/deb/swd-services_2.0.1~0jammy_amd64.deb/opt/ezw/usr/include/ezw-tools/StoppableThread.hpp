/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file StoppableThread.hpp
 */

#ifndef EZW_TOOLS_STOPPABLETHREAD_HPP
#define EZW_TOOLS_STOPPABLETHREAD_HPP

#include <chrono>
#include <future>
#include <thread>

namespace ezw
{
    namespace tools
    {
        class StoppableThread {
          public:
            StoppableThread();
            StoppableThread(StoppableThread &&obj);

            StoppableThread &operator=(StoppableThread &&obj);

            // Task need to provide defination  for this function
            // It will be called by thread function
            virtual void run() = 0;

            // Thread function to be executed by thread
            void operator()();

            // Checks if thread is requested to stop
            bool stopRequested();

            // Request the thread to stop by setting value in promise object
            void stop();

          private:
            std::promise<void> exitSignal;
            std::future<void>  futureObj;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_STOPPABLETHREAD_HPP */
