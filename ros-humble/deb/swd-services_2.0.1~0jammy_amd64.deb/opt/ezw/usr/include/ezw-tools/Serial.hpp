/**
 * Copyright (C) 2021 EZ-Wheel S.A.S.
 *
 * @file Serial.hpp
 */

#ifndef EZW_TOOLS_SERIAL_HPP
#define EZW_TOOLS_SERIAL_HPP

#include <string>

namespace ezw
{
    namespace tools
    {
        class Serial {
          public:
            Serial(std::string pDeviceName, int pBaud);
            Serial(Serial &&other);
            ~Serial();

            bool send(unsigned char *pData, unsigned long int pLen);
            bool send(unsigned char pValue);
            bool send(std::string pValue);
            int  receive(unsigned char *pData, unsigned long int pLen);
            bool isOpen(void);
            void close(void);
            bool open();
            bool bytesAvailable(int &pByteLen);

          private:
            int         mHandle;
            std::string mDeviceName;
            int         mBaud;
        };
    } // namespace tools
} // namespace ezw
#endif /* EZW_TOOLS_SERIAL_HPP */
