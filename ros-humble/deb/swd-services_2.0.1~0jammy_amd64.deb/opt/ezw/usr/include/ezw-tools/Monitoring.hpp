/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file Monitoring.hpp
 */

#ifndef EZW_TOOLS_MONITORING_HPP
#define EZW_TOOLS_MONITORING_HPP

#include "ezw_types.h"

#include <chrono>
#include <string>

namespace ezw
{
    namespace tools
    {
        class Monitoring {
          public:
            static const std::string logExecutionTime(const std::string &pDescription, std::chrono::time_point<std::chrono::steady_clock> &pStart);
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_MONITORING_HPP */
