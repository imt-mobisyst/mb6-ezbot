/**
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file Maths.hpp
 */

#ifndef EZW_TOOLS_MATHS_HPP
#define EZW_TOOLS_MATHS_HPP

#include <vector>

namespace ezw
{
    namespace tools
    {
        namespace maths
        {
            // Apply linear regression on points x and y and give a and b coefs of tendancy line y=ax+b
            template <typename T, typename U> static void linearRegression(const std::vector<T> &pX, const std::vector<U> &pY, float &pA, float &pB)
            {
                size_t n = (float)std::min(pX.size(), pY.size());

                float xSum  = 0.0;
                float ySum  = 0.0;
                float xySum = 0.0;
                float xxSum = 0.0;

                for (size_t i = 0; i < n; i++) {
                    float pXi = (float)pX[i];
                    float pYi = (float)pY[i];

                    xSum += pXi;
                    ySum += pYi;
                    xySum += pXi * pYi;
                    xxSum += pXi * pXi;
                }

                float ai = (n * xySum - xSum * ySum) / (n * xxSum - xSum * xSum);
                float bi = (ySum - ai * xSum) / n;
                pA       = ai;
                pB       = bi;
            }

            template <typename T, typename U> static void linearRegressionEstimate(const std::vector<T> &pX, const std::vector<U> &pY, T pXEstimate, U &pYEstimate)
            {
                float pA, pB;

                linearRegression(pX, pY, pA, pB);
                pYEstimate = (U)(pA * (float)pXEstimate + pB);
            }
        } // namespace maths
    }     // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_MATHS_HPP */
