/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file CSVParser.hpp
 */

#ifndef EZW_TOOLS_CSVPARSER_HPP
#define EZW_TOOLS_CSVPARSER_HPP

#include <fstream>
#include <vector>

namespace ezw
{
    namespace tools
    {
        class CSVParser {
          public:
            static std::vector<std::string> getNextLineAndSplitIntoTokens(std::ifstream &pSs, bool &pEof, const char &pToken = ',');
            static bool                     caseInsensitiveStringCompare(const std::string &str1, const std::string &str2);
            static void                     replaceInString(std::string &str, const std::string &from, const std::string &to);
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_CSVPARSER_HPP */
