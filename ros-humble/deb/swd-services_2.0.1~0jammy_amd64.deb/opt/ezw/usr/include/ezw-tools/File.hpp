/**
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file File.hpp
 */

#ifndef EZW_TOOLS_FILE_HPP
#define EZW_TOOLS_FILE_HPP

#include <string>

namespace ezw
{
    namespace tools
    {
        namespace File
        {
            bool isEmpty(const std::string &pPath);
            bool read(const std::string &pPath, std::string &pContent);
            bool write(const std::string &pPath, const std::string &pContent);
            bool copy(const std::string &pFromPath, const std::string &pToPath);
            bool remove(const std::string &pPath);
            bool rename(const std::string &pFromPath, const std::string &pToPath);

            // If path already exists, Create a path~ temporary file before writing new content
            bool safeWrite(const std::string &pPath, const std::string &pContent);
            // If path doesn't exists, seek for backup file of form path~
            bool safeRead(const std::string &pPath, std::string &pContent);
        } // namespace File
    }     // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_FILE_HPP */
