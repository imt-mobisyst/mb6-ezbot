/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file DBusServiceDelegate.hpp
 */

#ifndef EZW_TOOLS_DBUSSERVICEDELEGATE_HPP
#define EZW_TOOLS_DBUSSERVICEDELEGATE_HPP

#include "expected.hpp"
#include "ezw_log.h"
#include "ezw_types.h"

#include <memory>
#include <string>

#include <CommonAPI/CommonAPI.hpp>

namespace ezw
{
    namespace tools
    {
        namespace DBus
        {
            template <typename ServiceClass> ezw_error_t registerService(uint32_t pContextId, const std::string &pDomainName, const std::string &pInstanceName, std::shared_ptr<ServiceClass> pService, const CommonAPI::ConnectionId_t &pConnectionId)
            {
                if (nullptr == pService) {
                    EZW_LOG(pContextId, EZW_LOG_ERROR, EZW_STR("pService is null"));

                    return ERROR_INTERNAL;
                }

                if (!CommonAPI::Runtime::get()->registerService(pDomainName, pInstanceName, pService, pConnectionId)) {
                    EZW_LOG(pContextId, EZW_LOG_ERROR, EZW_STR((std::string{"Failed to register service : "} + pInstanceName).c_str()));

                    return ERROR_EXTERNAL;
                }

                EZW_LOG(pContextId, EZW_LOG_INFO, EZW_STR((std::string{"Successfully registered service : "} + pInstanceName).c_str()));

                return ERROR_NONE;
            }
        } // namespace DBus

        template <typename ServiceClass> class DBusServiceDelegate {
            static constexpr const char *mClassName = "DBusServiceDelegate";

          public:
            DBusServiceDelegate();
            virtual ~DBusServiceDelegate();

            ezw_error_t init(uint32_t pContextId, const std::string &pDomainName, const std::string &pInstanceName, std::shared_ptr<ServiceClass> pService, const CommonAPI::ConnectionId_t &pConnectionId);

          private:
            bool mInitialized;

            std::shared_ptr<ServiceClass> mService;
        };

        template <typename ServiceClass> DBusServiceDelegate<ServiceClass>::DBusServiceDelegate() : mInitialized(false)
        {
        }

        template <typename ServiceClass> DBusServiceDelegate<ServiceClass>::~DBusServiceDelegate()
        {
        }

        template <typename ServiceClass> ezw_error_t DBusServiceDelegate<ServiceClass>::init(uint32_t pContextId, const std::string &pDomainName, const std::string &pInstanceName, std::shared_ptr<ServiceClass> pService, const CommonAPI::ConnectionId_t &pConnectionId)
        {
            if (mInitialized) {
                EZW_LOG(pContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR("Instance of service already initialized"));

                return ERROR_INTERNAL;
            }

            mService = pService;
            if (nullptr == mService) {
                EZW_LOG(pContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR("pService is null"));

                return ERROR_INTERNAL;
            }

            if (CommonAPI::Runtime::get()->registerService(pDomainName, pInstanceName, pService, pConnectionId)) {
                EZW_LOG(pContextId, EZW_LOG_INFO, EZW_STR(mClassName), EZW_STR((std::string() + "Successfully registered service : " + pInstanceName).c_str()));
            } else {
                EZW_LOG(pContextId, EZW_LOG_ERROR, EZW_STR(mClassName), EZW_STR((std::string() + "Failed to register service : " + pInstanceName).c_str()));

                return ERROR_EXTERNAL;
            }

            mInitialized = true;

            return ERROR_NONE;
        }
    } // namespace tools
} // namespace ezw
#endif /* EZW_TOOLS_DBUSSERVICEDELEGATE_HPP */
