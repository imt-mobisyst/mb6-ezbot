/**
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file Subprocess.hpp
 */

#ifndef EZW_TOOLS_SUBPROCESS_HPP
#define EZW_TOOLS_SUBPROCESS_HPP

#include <initializer_list>
#include <string>
#include <vector>

namespace ezw
{
    namespace tools
    {
        class Subprocess {
          public:
            struct State {
                enum
                {
                    STOPPED,
                    RUNNING,
                    ERROR,
                    FINISHED
                } state;
                int exitStatus;
            };

            Subprocess();
            ~Subprocess();

            void setCommand(const std::string &pCommand, const std::initializer_list<std::string> &pArgs);

            void start();
            void restart();

            State checkState();

            void stop();
            void kill();

          private:
            std::string              mCommand;
            std::vector<std::string> mArgs;
            pid_t                    mPID;
            int                      mExitStatus;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_SUBPROCESS_HPP */
