/**
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file ThreadPool.hpp
 */

#ifndef EZW_TOOLS_THREADPOOL_HPP
#define EZW_TOOLS_THREADPOOL_HPP

#include <chrono>
#include <condition_variable>
#include <functional>
#include <iostream>
#include <mutex>
#include <queue>
#include <thread>

namespace ezw
{
    namespace tools
    {
        class ThreadPool {
          public:
            ThreadPool(int threads) : mShutdown(false)
            {
                // Create the specified number of threads
                mThreads.reserve(threads);
                for (int i = 0; i < threads; ++i) {
                    mThreads.emplace_back(std::bind(&ThreadPool::threadEntry, this, i));
                }
            }

            ~ThreadPool()
            {
                {
                    // Unblock any threads and tell them to stop
                    std::unique_lock<std::mutex> l(mLock);

                    mShutdown = true;
                    mCondVar.notify_all();
                }

                // Wait for all threads to stop
                std::cerr << "Joining threads" << std::endl;

                for (auto &thread : mThreads) {
                    thread.join();
                }
            }

            void doJob(std::function<void(void)> func)
            {
                // Place a job on the queue and unblock a thread
                std::unique_lock<std::mutex> l(mLock);

                mJobs.emplace(std::move(func));
                mCondVar.notify_one();
            }

          protected:
            void threadEntry(int i)
            {
                std::function<void(void)> job;

                while (1) {
                    {
                        std::unique_lock<std::mutex> l(mLock);

                        while (!mShutdown && mJobs.empty()) {
                            mCondVar.wait(l);
                        }

                        if (mJobs.empty()) {
                            // No jobs to do and we are shutting down
                            std::cerr << "Thread " << i << " terminates" << std::endl;
                            return;
                        }

                        // std::cerr << "Thread " << i << " does a job" << std::endl;
                        job = std::move(mJobs.front());
                        mJobs.pop();
                    }

                    // Do the job without holding any locks
                    job();
                }
            }

            std::mutex                            mLock;
            std::condition_variable               mCondVar;
            bool                                  mShutdown;
            std::queue<std::function<void(void)>> mJobs;
            std::vector<std::thread>              mThreads;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_THREADPOOL_HPP */
