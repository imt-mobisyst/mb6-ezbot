/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file NetworkUtility.hpp
 */

#ifndef EZW_TOOLS_NETWORKUTILITY_HPP
#define EZW_TOOLS_NETWORKUTILITY_HPP

#include <string>
#include <vector>

namespace ezw
{
    namespace tools
    {
        class NetworkUtility {
          public:
            /**
             * @brief Get All Network Interface Names
             *
             * @return std::vector<std::string>
             */
            static std::vector<std::string> getAllNetworkInterfaceNames();

            /**
             * @brief Get MAC address of Linux based network device
             *
             * @return std::string
             */
            static std::string getMacAddress();
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_NETWORKUTILITY_HPP */
