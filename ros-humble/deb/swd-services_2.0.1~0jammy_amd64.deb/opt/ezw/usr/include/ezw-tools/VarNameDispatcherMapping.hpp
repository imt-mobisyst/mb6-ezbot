/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file VarNameDispatcherMapping.hpp
 */

#ifndef EZW_TOOLS_VARNAMEDISPATCHERMAPPING_HPP
#define EZW_TOOLS_VARNAMEDISPATCHERMAPPING_HPP

/* Includes -------------------------------------------- */
#include "VarNameDispatcherConfigFactory.hpp"

#include <map>
#include <string>

/* Defines --------------------------------------------- */

/* Variable declaration -------------------------------- */

/* Class ----------------------------------------------- */
namespace ezw
{
    namespace tools
    {
        class VarNameDispatcherConfigEntry;

        class VarNameDispatcherMapping {
          public:
            VarNameDispatcherMapping();
            VarNameDispatcherMapping(const std::map<std::string, VarNameDispatcherConfigEntry *> &pMapping);
            virtual ~VarNameDispatcherMapping();

            /* Getters */
            VarNameDispatcherConfigEntry *entry(const std::string &pKey) const;
            bool                          validity() const;

            /* Setters */
            void setContents(const std::map<std::string, VarNameDispatcherConfigEntry *> &pMapping);
            void setValidity(const bool &pValidity);

            /* Info/Status */
            bool   empty() const;
            size_t size() const;
            void   print() const;

          private:
            std::map<std::string, VarNameDispatcherConfigEntry *> mMapping;

            bool mValidity; // Is this node entry valid ? Set by Factory.
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_VARNAMEDISPATCHERMAPPING_HPP */
