/**
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file HardwareHelper.hpp
 */

#ifndef EZW_TOOLS_HARDWAREHELPER_HPP
#define EZW_TOOLS_HARDWAREHELPER_HPP

/* Includes -------------------------------------------- */
#include "ezw_log.h"
#include "ezw_types.h"

#include <string>
#include <vector>

/* Defines --------------------------------------------- */

/* Variable declaration -------------------------------- */

/* Class ----------------------------------------------- */
namespace ezw
{
    namespace tools
    {
        class Config;
        class HardwareHelper {
          private:
            struct UpdateInfo {
                std::string           type;
                std::string           binPath;
                std::string           swVersion;
                std::string           hwVersion;
                std::vector<uint32_t> compatibilityList;
                std::string           device;
            };

          public:
            HardwareHelper(uint32_t pContextId);

            virtual ~HardwareHelper();

            ezw_error_t init(const std::string &pConfigFile);

            ezw_error_t checkHWCompatibility(const std::string &pSWCompatibilityFile, const uint32_t pCurrentHWVersion, bool &pIsCompatible);
            ezw_error_t checkIMMBCompatibility(const std::string &pSWCompatibilityFile, bool &pIsCompatible);
            ezw_error_t checkUpdate(const uint32_t pCurrentHWVersion, const uint32_t pCurrentSWVersion, bool &pUpdateNeeded);
            ezw_error_t update();

            ezw_error_t activeBL() const;
            ezw_error_t activeAPP() const;

            ezw_error_t convertVersionFromString(const std::string &pToConvert, uint32_t &pConverted) const;
            std::string convertVersionToString(const uint32_t &pVersion) const;

            ezw_error_t getHWConfigurationMember(const std::string &pMember, int &pValue) const;
            ezw_error_t getHWConfigurationMember(const std::string &pMember, double &pValue) const;
            ezw_error_t getHWConfigurationMember(const std::string &pMember, std::string &pValue) const;
            ezw_error_t getHWConfigurationMember(const std::string &pMember, std::vector<int> &pValue) const;

            ezw_error_t getHWConfigurationSetting(const std::string &pName, int &pValue) const;
            ezw_error_t getHWConfigurationSetting(const std::string &pName, bool &pValue) const;
            ezw_error_t getHWConfigurationSetting(const std::string &pName, double &pValue) const;
            ezw_error_t getHWConfigurationSetting(const std::string &pName, std::string &pValue) const;

            ezw_error_t checkUSB(const std::string &pDeviceName, bool &pIsPresent) const;
            ezw_error_t checkUSB(bool &pAllPresent) const;
            ezw_error_t reloadUSB() const;
            ezw_error_t waitUSB() const;

            bool isCarrierOnEth0() const;

          private:
            static constexpr const char *mClassName = "HardwareHelper";

            ezw_error_t loadUpdateInfo(const std::string &pSWCompatibilityFile);
            ezw_error_t extractNextPart(const std::string &pSource, const std::string &pDelim, uint32_t &pStart, uint32_t &pEnd, uint32_t &pValue) const;
            bool        compareVersions(const uint32_t &pCurrent, const uint32_t &pLatest) const;
            ezw_error_t checkHWCompatibility(const uint32_t pCurrentHWVersion, bool &pIsCompatible) const;

            uint32_t mContextId;

            UpdateInfo mUpdateInfo;
            Config *   mConfig;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_HARDWAREHELPER_HPP */
