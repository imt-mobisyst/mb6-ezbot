/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file VarNameDispatcherConfigEntry.hpp
 */

#ifndef EZW_TOOLS_VARNAMEDISPATCHERCONFIGENTRY_HPP
#define EZW_TOOLS_VARNAMEDISPATCHERCONFIGENTRY_HPP

/* Includes -------------------------------------------- */

#include <string>

/* Defines --------------------------------------------- */

/* Variable declaration -------------------------------- */

/* Class ----------------------------------------------- */
namespace ezw
{
    namespace tools
    {
        class VarNameDispatcherConfigEntry {
          public:
            VarNameDispatcherConfigEntry();
            virtual ~VarNameDispatcherConfigEntry();

            /* Getters */
            std::string srcVarName() const;
            std::string destVarName() const;
            std::string targetName() const;

            bool validity() const;

            /* Setters */
            void setSrcVarName(const std::string &pName);
            void setDestVarName(const std::string &pName);
            void setTargetName(const std::string &pName);

            void setValidity(const bool &pValidity);

            /* Print */
            void print() const;

          private:
            std::string mSrcVarName;
            std::string mDestVarName;
            std::string mTargetName;

            bool mValidity;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_VARNAMEDISPATCHERCONFIGENTRY_HPP */
