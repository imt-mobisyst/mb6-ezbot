/**
 * Copyright (C) 2020 EZ-Wheel S.A.S.
 *
 * @file Flock.hpp
 */

#ifndef EZW_TOOLS_FLOCK_HPP
#define EZW_TOOLS_FLOCK_HPP

#include <string>

namespace ezw
{
    namespace tools
    {
        class Flock {
          public:
            Flock();
            ~Flock();

            bool init(const std::string &pName);

            void lock();
            // Return true on success, false overwise
            bool tryLock();
            void unlock();

          private:
            int mFd;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_FLOCK_HPP */
