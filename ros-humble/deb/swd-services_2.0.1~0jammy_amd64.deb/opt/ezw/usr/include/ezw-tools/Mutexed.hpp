/**
 *
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file Mutexed.hpp
 */

#ifndef EZW_TOOLS_MUTEXED_HPP
#define EZW_TOOLS_MUTEXED_HPP

#include <mutex>

namespace ezw
{
    namespace tools
    {
        template <typename T> class Mutexed : public std::mutex {
          public:
            Mutexed() : std::mutex()
            {
            }

            virtual ~Mutexed()
            {
            }

            T value;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_MUTEXED_HPP */
