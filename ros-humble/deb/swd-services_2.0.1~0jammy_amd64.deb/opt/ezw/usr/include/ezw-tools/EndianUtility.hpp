/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file EndianUtility.hpp
 */

#ifndef EZW_TOOLS_ENDIANUTILITY_HPP
#define EZW_TOOLS_ENDIANUTILITY_HPP

#include <limits.h>

namespace ezw
{
    namespace tools
    {
        class EndianUtility {
          public:
            template <typename T> static T swap_endian(T u)
            {
                static_assert(CHAR_BIT == 8, "CHAR_BIT != 8");

                union {
                    T             u;
                    unsigned char u8[sizeof(T)];
                } source, dest;

                source.u = u;

                for (size_t k = 0; k < sizeof(T); k++) {
                    dest.u8[k] = source.u8[sizeof(T) - k - 1];
                }

                return dest.u;
            }
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_ENDIANUTILITY_HPP */
