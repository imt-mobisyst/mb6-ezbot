/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file VarNameDispatcherConfigFactory.hpp
 */

#ifndef EZW_TOOLS_VARNAMEDISPATCHERCONFIGFACTORY_HPP
#define EZW_TOOLS_VARNAMEDISPATCHERCONFIGFACTORY_HPP

/* Includes -------------------------------------------- */

#include <map>
#include <string>

/* Defines --------------------------------------------- */

/* Variable declaration -------------------------------- */

/* Class ----------------------------------------------- */
namespace ezw
{
    namespace tools
    {
        class VarNameDispatcherMapping;

        class VarNameDispatcherConfigFactory {
          public:
            /* Configuration parser */
            static VarNameDispatcherMapping *loadMapping(const std::string &pFilePath);
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_VARNAMEDISPATCHERCONFIGFACTORY_HPP */
