/**
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @file Https.hpp
 */

#ifndef EZW_TOOLS_HTTPS_HPP
#define EZW_TOOLS_HTTPS_HPP

#include "ezw_types.h"

#include "ezw_log.h"

#include "rapidjson/document.h"

// sudo apt-get install libcurl4-openssl-dev
#include <curl/curl.h>

#include <mutex>
#include <string>

namespace ezw
{
    namespace tools
    {
        class Https {
          public:
            static constexpr const char *mClassName = "Https";

            Https();
            virtual ~Https();
            // Due to presence of mutex, the class is movable only
            Https(const Https &) = delete;
            Https(Https &&);
            Https &operator=(const Https &) = delete;
            Https &operator                 =(Https &&);

            void init(int pContextId);

            void         setTimeout(unsigned int pTimeout);
            unsigned int getTimeout();

            ezw_error_t get(const std::string &pUrl, rapidjson::Document &pJsonResponse);
            ezw_error_t put(const std::string &pUrl, const std::string &pJsonArgs, rapidjson::Document &pJsonResponse);
            ezw_error_t put(const std::string &pUrl, const rapidjson::Document &pJsonArgs, rapidjson::Document &pJsonResponse);
            ezw_error_t post(const std::string &pUrl, const std::string &pJsonArgs, rapidjson::Document &pJsonResponse);
            ezw_error_t post(const std::string &pUrl, const rapidjson::Document &pJsonArgs, rapidjson::Document &pJsonResponse);
            ezw_error_t del(const std::string &pUrl, rapidjson::Document &pJsonResponse);
            ezw_error_t del(const std::string &pUrl, const rapidjson::Document &pJsonArgs, rapidjson::Document &pJsonResponse);
            ezw_error_t del(const std::string &pUrl, const std::string &pJsonArgs, rapidjson::Document &pJsonResponse);

            static const std::string toString(const rapidjson::Document &pJson);

          private:
            ezw_error_t curlInit();
            ezw_error_t perform(const std::string &pUrl, rapidjson::Document &pJsonResponse);
            ezw_error_t send(const std::string &pCustomRequest, const std::string &pUrl, const std::string &pJsonArgs, rapidjson::Document &pJsonResponse);

            CURL *      mCurl;
            int         mContextId;
            std::string mResponse;

            static uint32_t mNumSessions;

            // Request timeout (s)
            unsigned int mTimeout;

            uint32_t mUnreachableCount;

            mutable std::mutex mMutex;
        };
    } // namespace tools
} // namespace ezw

#endif /* EZW_TOOLS_HTTPS_HPP */
