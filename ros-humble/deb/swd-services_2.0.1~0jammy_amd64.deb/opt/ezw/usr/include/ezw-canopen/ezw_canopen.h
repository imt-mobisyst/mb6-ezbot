/**
 * Copyright (C) 2018 EZ-Wheel S.A.S.
 *
 * @file ezw_canopen.h
 * @brief EZW CANOpen main source code header
 */

#ifndef EZW_CANOPEN_H
#define EZW_CANOPEN_H

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "co_datatype.h"
#include "ezw_types.h"

#include "ezw-can/ezw_can.h"

#if defined(EZW_MCU)
#include "ezw_eeprom_tms.h"
#endif

/** @defgroup ezw-canopen ezw-canopen
 * EZ-Wheel CANOpen module.
 */

/** @defgroup ezw-canopen-public public
 * Public API functions.
 * @ingroup ezw-canopen
 * @{
 */

/** @defgroup ezw-canopen-public-defines defines
 * @ingroup ezw-canopen-public
 * @{
 */
#define EZW_CO_NODEID_MAX             127U                                  /*!< Maximum value for a can COB-ID      */
#define EZW_CO_NODEID_MIN             0U                                    /*!< Minimum value for a can COB-ID (NOTA : allow 0 for broadcasting) */
#define EZW_CO_SDO_DATA_SZ            4U                                    /*!< Size of a SDO data answer in bytes  */
#define EZW_CO_SDO_REQUEST_TIMEOUT_MS 20U                                   /*!< Delay to answer a SDO request in ms */
#define EZW_CO_SDO_REQUEST_TIMEOUT_US EZW_CO_SDO_REQUEST_TIMEOUT_MS * 1000U /*!< Delay to answer a SDO request in µs */
#define EZW_CO_SDO_SEG_MAX_LEN        256U                                  /*!< Maximum length of a SDO segment     */
#define EZW_CO_PDO_NUM_MAPPING        8U                                    /*!< Maximum mapping number available    */
    /** @} */

    /** @defgroup ezw-canopen-public-typedefs typedefs
     * @ingroup ezw-canopen-public
     * @{
     */

    /**
     * @brief This enum defines the SDO types
     */
    typedef enum
    {
        EZW_CO_SDO_UNKNOWN = 0,
        EZW_CO_SDO_READ,
        EZW_CO_SDO_WRITE,
        EZW_CO_SDO_READ_SEG,
        EZW_CO_SDO_WRITE_SEG,
        EZW_CO_SDO_ERROR,
        EZW_CO_SDO_ABORT
    } ezw_canopen_sdo_type_t;

    /**
     * @brief All of the 29 abort codes of the CANOpen stack,
     * as defined in CiA Draft Standard 301 (or DS301).
     * @warning It is not possible to use custom, non-defined abort codes.
     * @note The most common abort codes are
     *  - EZW_CO_ABORT_TOGGLE_BIT
     *  - EZW_CO_ABORT_TIMEOUT
     *  - EZW_CO_ABORT_READ_ONLY
     *  - EZW_CO_ABORT_OBJECT_NOT_FOUND
     *  - EZW_CO_ABORT_TYPE_ERROR_PARAM_LEN
     *  - EZW_CO_ABORT_TYPE_ERROR_PARAM_LEN_HIGH
     *  - EZW_CO_ABORT_TYPE_ERROR_PARAM_LEN_LOW
     *  - EZW_CO_ABORT_SUBINDEX_NOT_FOUND
     *  - EZW_CO_ABORT_GENERAL_ERROR
     */
    typedef enum
    {
        EZW_CO_ABORT_TOGGLE_BIT                              = 0x05030000U, /*!< Toggle bit not alternated.                                                                   */
        EZW_CO_ABORT_TIMEOUT                                 = 0x05040000U, /*!< SDO protocol timed out.                                                                      */
        EZW_CO_ABORT_CCS_UNKNOWN                             = 0x05040001U, /*!< Client/Server command specifier not valid or unknown.                                        */
        EZW_CO_ABORT_BLOCK_SZ_INVALID                        = 0x05040002U, /*!< Invalid block size (block mode only).                                                        */
        EZW_CO_ABORT_SEQ_NB_INVALID                          = 0x05040003U, /*!< Invalid sequence number (block mode only).                                                   */
        EZW_CO_ABORT_CRC_ERROR                               = 0x05040004U, /*!< CRC error (block mode only).                                                                 */
        EZW_CO_ABORT_OUT_OF_MEMORY                           = 0x05040005U, /*!< Out of memory.                                                                               */
        EZW_CO_ABORT_UNSUPPORTED_ACCESS                      = 0x06010000U, /*!< Unsupported access to an object.                                                             */
        EZW_CO_ABORT_WRITE_ONLY                              = 0x06010001U, /*!< Attempt to read a write only object.                                                         */
        EZW_CO_ABORT_READ_ONLY                               = 0x06010002U, /*!< Attempt to write a read only object.                                                         */
        EZW_CO_ABORT_OBJECT_NOT_FOUND                        = 0x06020000U, /*!< Object does not exist in the object dictionary.                                              */
        EZW_CO_ABORT_PDO_UNMAPPABLE                          = 0x06040041U, /*!< Object cannot be mapped to the PDO.                                                          */
        EZW_CO_ABORT_LEN_EXCEED_PDO_LEN                      = 0x06040042U, /*!< The number and length of the objects to be mapped would exceed PDO length.                   */
        EZW_CO_ABORT_GENERAL_PARAM_INCOMPATIBILITY           = 0x06040043U, /*!< General parameter incompatibility reason.                                                    */
        EZW_CO_ABORT_GENERAL_DEVICE_INTERNAL_INCOMPATIBILITY = 0x06040047U, /*!< General internal incompatibility in the device.                                              */
        EZW_CO_ABORT_HARDWARE_ERROR_ON_ACCESS                = 0x06060000U, /*!< Access failed due to a hardware error.                                                       */
        EZW_CO_ABORT_TYPE_ERROR_PARAM_LEN                    = 0x06070010U, /*!< Data type does not match; length of service parameter does not match.                        */
        EZW_CO_ABORT_TYPE_ERROR_PARAM_LEN_HIGH               = 0x06070012U, /*!< Data type does not match; length of service parameter too high.                              */
        EZW_CO_ABORT_TYPE_ERROR_PARAM_LEN_LOW                = 0x06070013U, /*!< Data type does not match; length of service parameter too low.                               */
        EZW_CO_ABORT_SUBINDEX_NOT_FOUND                      = 0x06090011U, /*!< Sub-index does not exist.                                                                    */
        EZW_CO_ABORT_VALUE_LIMIT                             = 0x06090030U, /*!< Value range of parameter exceeded (only for write access).                                   */
        EZW_CO_ABORT_VALUE_LIMIT_HIGH                        = 0x06090031U, /*!< Value of parameter written too high.                                                         */
        EZW_CO_ABORT_VALUE_LIMIT_LOW                         = 0x06090032U, /*!< Value of parameter written too low.                                                          */
        EZW_CO_ABORT_VALUE_LIMIT_INVALID                     = 0x06090036U, /*!< Maximum value is less than minimum value.                                                    */
        EZW_CO_ABORT_GENERAL_ERROR                           = 0x08000000U, /*!< General error.                                                                               */
        EZW_CO_ABORT_DATA_TRANSFER_STORAGE                   = 0x08000020U, /*!< Data cannot be transferred or stored to the application.                                     */
        EZW_CO_ABORT_DATA_TRANSFER_STORAGE_LOCAL             = 0x08000021U, /*!< Data cannot be transferred or stored to the application because of local control.            */
        EZW_CO_ABORT_DATA_TRANSFER_STORAGE_DEVICE_STATE      = 0x08000022U, /*!< Data cannot be transferred or stored to the application because of the present device state. */
        EZW_CO_ABORT_DYN_OD                                  = 0x08000023U, /*!< Object dictionary dynamic generation fails or no object dictionary is present                */
        EZW_CO_ABORT_ERR_NO_DATA                             = 0x08000024U, /*!< No data available.                                                                           */
    } ezw_canopen_abort_code_t;

    /**
     * @brief This enum defines the NMT states
     */
    typedef enum
    {
        EZW_CO_NMT_STATE_UNKNOWN = 0x0,  /*!< UNKNOWN         */
        EZW_CO_NMT_STATE_STOPPED = 0x4,  /*!< STOPPED         */
        EZW_CO_NMT_STATE_OPER    = 0x5,  /*!< OPERATIONAL     */
        EZW_CO_NMT_STATE_PREOP   = 0x7F, /*!< PRE-OPERATIONAL */
    } ezw_nmt_state_t;

    /**
     * @brief This enum defines the NMT commands
     */
    typedef enum
    {
        EZW_CO_NMT_COMMAND_OPER       = 0x01, /*!< Go to OPERATIONAL     */
        EZW_CO_NMT_COMMAND_STOP       = 0x02, /*!< Go to STOP            */
        EZW_CO_NMT_COMMAND_PREOP      = 0x80, /*!< Go to PRE-OPERATIONAL */
        EZW_CO_NMT_COMMAND_RESET_NODE = 0x81, /*!< Reset NODE            */
        EZW_CO_NMT_COMMAND_RESET_COMM = 0x82, /*!< Reset Communication   */
    } ezw_nmt_command_t;

    /**
     * @brief Indices of SDO Server in public configuration
     */
    typedef enum
    {
        EZW_CANOPEN_IDX_SDO_SERVER_2 = 0,
        EZW_CANOPEN_IDX_SDO_SERVER_3,
        EZW_CANOPEN_IDX_SDO_SERVER_4,
        EZW_CANOPEN_IDX_SDO_SERVER_NUM
    } ezw_canopen_sdo_server_idx_t;

    /**
     * @brief Indices of SRDO in public configuration
     */
    typedef enum
    {
        EZW_CANOPEN_IDX_SRDO_1 = 0,
        EZW_CANOPEN_IDX_SRDO_2,
        EZW_CANOPEN_IDX_SRDO_9,
        EZW_CANOPEN_IDX_SRDO_10,
        EZW_CANOPEN_IDX_SRDO_11,
        EZW_CANOPEN_IDX_SRDO_12,
        EZW_CANOPEN_IDX_SRDO_13,
        EZW_CANOPEN_IDX_SRDO_14,
        EZW_CANOPEN_IDX_SRDO_15,
        EZW_CANOPEN_IDX_SRDO_16,
        EZW_CANOPEN_IDX_SRDO_NUM
    } ezw_canopen_srdo_idx_t;

    /**
     * @brief Indices of RPDO in public configuration
     */
    typedef enum
    {
        EZW_CANOPEN_IDX_RPDO_1 = 0,
        EZW_CANOPEN_IDX_RPDO_2,
        EZW_CANOPEN_IDX_RPDO_3,
        EZW_CANOPEN_IDX_RPDO_4,
        EZW_CANOPEN_IDX_RPDO_5,
        EZW_CANOPEN_IDX_RPDO_6,
        EZW_CANOPEN_IDX_RPDO_7,
        EZW_CANOPEN_IDX_RPDO_8,
        EZW_CANOPEN_IDX_RPDO_NUM
    } ezw_canopen_rpdo_idx_t;

    /**
     * @brief Indices of TPDO in public configuration
     */
    typedef enum
    {
        EZW_CANOPEN_IDX_TPDO_1 = 0,
        EZW_CANOPEN_IDX_TPDO_2,
        EZW_CANOPEN_IDX_TPDO_3,
        EZW_CANOPEN_IDX_TPDO_4,
        EZW_CANOPEN_IDX_TPDO_5,
        EZW_CANOPEN_IDX_TPDO_6,
        EZW_CANOPEN_IDX_TPDO_7,
        EZW_CANOPEN_IDX_TPDO_8,
        EZW_CANOPEN_IDX_TPDO_NUM
    } ezw_canopen_tpdo_idx_t;

    /**
     * @brief This structure defines a sdo
     */
    typedef struct {
        uint8_t                node_id;     /*!< The destination node ID                       */
        uint8_t                sdo_number;
        uint16_t               index;       /*!< The Index in the OD                           */
        uint8_t                subindex;    /*!< The subindex in the OD                        */
        ezw_canopen_sdo_type_t type;
        uint32_t               result;
        uint32_t               data_len;   /*!< The length of the data in the OD               */
        uint8_t *              data_ptr;   /*!< The pointer to the data                        */
    } ezw_canopen_sdo_info_t;

    /**
     * @brief Store SRDO Configuration
     */
    typedef struct {
        uint8_t  direction;   /*!< information direction                        */
        uint16_t refreshTime; /*!< refresh time between 2 messages              */
        uint8_t  srvt;        /*!< SRVT time between the message and its invert */
        uint8_t  transType;   /*!< transmission type (None[0]/TX[1]/RX[2])      */
        uint32_t cobId1;      /*!< COB id 1                                     */
        uint32_t cobId2;      /*!< COB id 2                                     */
        uint16_t signature;   /*!< signature for the SRDO                       */
    } ezw_canopen_srdo_config_t;

    /**
     * @brief Store PDO Configuration
     */
    typedef struct {
        uint32_t cobId;                                 /*!< Communication Object Identifier                                           */
        uint8_t  transType;                             /*!< transmission type. Synchronous or Event driven (each time it's available) */
        uint16_t eventTimer;                            /*!< Event Timer, Timeout time in ms between two consecutive PDO received      */
        uint8_t  mapCnt;                                /*!< number of actual mappings     */
        uint32_t mapping_entry[EZW_CO_PDO_NUM_MAPPING]; /*!< Variable mapped to this entry */
    } ezw_canopen_pdo_config_t;

    /**
     * @brief Store SDO Server Configuration
     */
    typedef struct {
        uint32_t cob_id_client_to_server;
        uint32_t cob_id_server_to_client;
    } ezw_canopen_sdo_server_config_t;

    /**
     * @brief This structure defines the LSS Configuration
     */
    typedef struct {
        uint8_t configure_bit_timing;
        uint8_t node_id;
        uint8_t r_termination;
    } ezw_canopen_lss_config_t;

    /**
     * @brief Store Communication informations
     */
    typedef struct {
        uint32_t                        cob_id_sync_message;
        uint16_t                        producer_heartbeat_time; /*!< ms */
        ezw_canopen_sdo_server_config_t sdo_server[EZW_CANOPEN_IDX_SDO_SERVER_NUM];
        uint8_t                         global_fail_safe_command;
        ezw_canopen_srdo_config_t       srdo[EZW_CANOPEN_IDX_SRDO_NUM];
        uint8_t                         configuration_valid;
        ezw_canopen_pdo_config_t        rpdo[EZW_CANOPEN_IDX_RPDO_NUM];
        ezw_canopen_pdo_config_t        tpdo[EZW_CANOPEN_IDX_TPDO_NUM];
        ezw_canopen_lss_config_t        lss;
    } ezw_canopen_public_config_t;
    /** @} */

    /** @defgroup ezw-canopen-public-extern extern
     * @ingroup ezw-canopen-public
     * @{
     * Configuration table that must be defined by the application
     */
    extern uint32_t ezw_canopen_sdo_server_id[EZW_CANOPEN_IDX_SDO_SERVER_NUM];
    extern uint32_t ezw_canopen_srdo_id[EZW_CANOPEN_IDX_SRDO_NUM];
    extern uint32_t ezw_canopen_rpdo_id[EZW_CANOPEN_IDX_RPDO_NUM];
    extern uint32_t ezw_canopen_tpdo_id[EZW_CANOPEN_IDX_TPDO_NUM];
    /** @} */

    /** @defgroup ezw-canopen-public-functions functions
     * @ingroup ezw-canopen-public
     * @{
     */

    /**
     * @brief Check if ezw_canopen module is initiated
     * @return Bool : 0 if not inited, 1 elsewise
     */
    bool ezw_canopen_is_inited(void);

    /**
     * @brief Initialize ezw_canopen instance with specified can interface
     * @param[in]   is_master           1 if master; else slave
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_init(uint8_t is_master);

    /**
     * @brief Initialize can with specified can interface
     * @param[in]   can_socket_name         Name of the can interface
     * @param[in]   can_socket_filter_size  Size of array of can id to filter
     * @param[in]   can_socket_filter       Array of can id to filter
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_can_init(const char can_socket_name[EZW_CAN_SOCKET_PATH_SZ], const uint32_t can_socket_filter_size, const uint32_t can_socket_filter[EZW_CAN_SOCKET_FILTER_SZ]);

    /**
     * @brief Close specified can interface
     * @param[in]   can_socket_name     Name of the can interface
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_can_close(const char can_socket_name[EZW_CAN_SOCKET_PATH_SZ]);

    /**
     * @brief Registers the indicator functions to their respective events.
     * @warning This function is a placeholder implementation for testing.
     * Another way to register functions will be implemented in SMC-173.
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_register_inds(void);

    /* Getters --------------------------------------------- */
    /**
     * @brief Returns whether the CAN bus is on or off
     * @param[out]  out                 Output of the getter.
     */
    ezw_error_t ezw_canopen_can_is_bus_on(bool *const out);

    /**
     * @brief Fetches the node id of this node.
     * The value is contained in [1;127] for a valid node ID.
     * @param[out]  out                 Output of the getter.
     */
    ezw_error_t ezw_canopen_get_node_id(uint8_t *const out);

    /**
     * @brief Set the requested node id to used by the CAN open stack after reset
     * communication is called.
     * The value is contained in [1;127] for a valid node ID.
     * @param[in]  node_id     Requested node ID value
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_set_requested_node_id(uint8_t node_id);

    /**
     * @brief Fetches the timer interval between tick as defined
     * by the object dictionnary.
     * @warning This function is not implemented if the said interval is not define.
     * Please check your object dictonary if any errors/warnings occur.
     * @param[out]  out                 Output of the getter.
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_get_timer_interval(uint32_t *const out);

    /**
     * @brief Fetches the srdo timer interval between tick as defined
     * by the object dictionnary.
     * @warning This function is not implemented if the said interval is not define.
     * Please check your object dictonary if any errors/warnings occur.
     * @param[out]  out                 Output of the getter.
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_get_srdo_timer_interval(uint32_t *const out);

    /**
     * @brief Fetches the node state of a specific node.
     * The node ID value must be contained in [1;127] to be a valid node ID.
     * @param[in]   node_id             The id of the wanted ezw-canopen node
     * @param[out]  out                 Output of the getter.
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_get_node_state(const uint8_t node_id, ezw_app_state_t *const out);

    /**
     * @brief Fetches the nmt state of a specific node.
     * The node ID value must be contained in [1;127] to be a valid node ID.
     * @param[in]   node_id             The id of the wanted ezw-canopen node
     * @param[out]  out                 Output of the getter.
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_get_nmt_state(const uint8_t node_id, ezw_nmt_state_t *const out);

    /**
     * @brief Change the nmt state of a specific node.
     * The node ID value must be contained in [1;127] to be a valid node ID.
     * @param[in]   node_id             The id of the wanted ezw-canopen node
     * @param[in]   in                  Input of the setter.
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_set_nmt_state(const uint8_t node_id, const ezw_nmt_command_t in);

    /**
     * @brief Get the address of an object from the object dictionary
     * for read access
     * @param[in]   index               The Index in the OD
     * @param[in]   sub                 The subindex in the OD
     * @param[out]  out                 The pointer to the data
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_get_read_ptr(const uint16_t index, const uint8_t sub, const void **const out);

    /**
     * @brief Get the address of an object from the object dictionary
     * for read access
     * @param[in]   index               The Index in the OD
     * @param[in]   sub                 The subindex in the OD
     * @param[in]   pdo_nbr             The PDO number
     * @param[out]  out                 The pointer to the data
     * @param[out]  timetsamp           The timestamp of the data
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_get_read_ptr_ts(const uint16_t index, const uint8_t sub, const uint8_t pdo_nbr, const void **const out, uint64_t *timestamp);


    /**
     * @brief Get the address of an object from the object dictionary
     * for write access
     * @param[in]   index               The Index in the OD
     * @param[in]   sub                 The subindex in the OD
     * @param[out]  out                 The pointer to the data
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_get_write_ptr(const uint16_t index, const uint8_t sub, void **const out);

    /**
     * @brief Translates a CANOpen abort code into a readable description
     * @param[in] abort_code    CANOpen abort code
     * @param[out] out          Desciption (char array)
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_abort_code_to_string(const uint32_t abort_code, const char **const out);

    /**
     * @brief Gets the response to a SDO request if there is one.
     * @param[inout]        info                SDO info
     */
    ezw_error_t ezw_canopen_get_sdo_response(ezw_canopen_sdo_info_t *const info);

    /* Setters --------------------------------------------- */

    /* Senders --------------------------------------------- */
    /**
     * @brief Sends a read SDO client request to a SDO server on the CAN bus
     *
     * @param[inout] info SDO parameters
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_sdo_read_request(ezw_canopen_sdo_info_t *const info);

    /**
     * @brief Sends a write SDO client request to a SDO server on the CAN bus
     *
     * @param[inout] info SDO parameters
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_sdo_write_request(ezw_canopen_sdo_info_t *const info);

    /* Receivers ------------------------------------------- */

    /* Resetters ------------------------------------------- */

    /* Process --------------------------------------------- */
    /**
     * @brief ezw_canopen computations, will be called in main loop
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_process(void);

    /* Other functions ------------------------------------- */
    /**
     * @brief Increments the stack's internal timer.
     * Uses the OD's timer interval definition.
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_timer_tick(void);

    /**
     * @brief Increments the SRDO stack's internal timer.
     * Uses the OD's SRDO timer interval definition.
     * @return void
     */
    void ezw_canopen_srdo_timer_tick(void);

#ifdef EZW_LINUX
    /**
     * @brief Transmit timer.
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_transmit(void);
#endif

    /**
     * @brief Removes a SDO request from the array of requests currently
     * waiting for their response.
     * Use this when the request has timed out or when an error occurred.
     * ezw_canopen_get_sdo_response already attempts
     * to remove the corresponding request from the array.
     * @param[in] info      SDO information about the request to remove
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_sdo_remove_request(const ezw_canopen_sdo_info_t *const info);

    /** @brief Make a binary inversion of the value
     * @param[in] value : value to be inverted
     * @return ~value
     */
    uint8_t ezw_canopen_invert_value(uint8_t value);

    /**
     * @brief Restart SYNC service.
     *
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_sync_reset();

    /**
     * @brief Restart Heartbeat service.
     *
     * @return error code, ERROR_NONE if no error occurred
     */
    ezw_error_t ezw_canopen_hb_reset();

#if defined(EZW_MCU)

    /**
     * @brief Configure module, all paramaters are applied
     *
     * @param[in] public_conf public configuration
     * @return ezw_error_t error code
     */
    ezw_error_t ezw_canopen_configure(const ezw_canopen_public_config_t *public_conf);

    /**
     * @brief Store passed configuration in EEPROM
     *
     * @param[in] public_conf public configuration
     * @return ezw_error_t error_code
     */
    ezw_error_t ezw_canopen_store(const ezw_canopen_public_config_t *public_conf);

    /**
     * @brief Load configuration in EEPROM according to storage type
     *
     * @param[in] type storage type (FACTORY, USER)
     * @param[out] public_conf loaded configuration
     * @return ezw_error_t error_code
     */
    ezw_error_t ezw_canopen_load(const ezw_eeprom_tms_config_type_t type, ezw_canopen_public_config_t *public_conf);

    /**
     * @brief Instant update RPDO COB-ID
     *
     * @param idx RPDO id
     * @param cob_id new cob-id
     * @return ezw_error_t error code
     */
    ezw_error_t ezw_canopen_update_rpdo_cob_id(ezw_canopen_rpdo_idx_t idx, uint32_t cob_id);

    /**
     * @brief Instant update TPDO COB-ID
     *
     * @param idx TPDO id
     * @param cob_id new cob-id
     * @return ezw_error_t error code
     */
    ezw_error_t ezw_canopen_update_tpdo_cob_id(ezw_canopen_tpdo_idx_t idx, uint32_t cob_id);

#endif /* defined(EZW_MCU) */

    /**@}*/

    /**@}*/

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* EZW_CANOPEN_H */
