#ifndef EZW_CANOPEN_DEBUG_H
#define EZW_CANOPEN_DEBUG_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "ezw_canopen.h"

#include "ezw_types.h"

/* Defines --------------------------------------------- */

/* Typedefs -------------------------------------------- */

/* Variable declaration -------------------------------- */

/* Debug functions ------------------------------------- */
#ifdef DEBUG
void print_sdo_info(const ezw_canopen_sdo_info_t * const info);
void print_sdo_request_array(void);
void print_sdo_response_array(void);
#endif /* DEBUG */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* EZW_CANOPEN_DEBUG_H */
