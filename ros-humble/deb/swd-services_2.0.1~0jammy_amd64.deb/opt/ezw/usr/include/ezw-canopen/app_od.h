/**
 * Copyright (C) 2022, EZ-Wheel S.A.S.
 *
 * \file app_od.h
 */

#ifndef APP_OD_H
#define APP_OD_H

#include "co_datatype.h"
#include "ezw_types.h"

#define APP_OD_OCTET_STRING_MAX_SIZE 32
extern uint8_t  od_supported_fsa_actions;                                     /**< 0x2308:0x00 (supported_fsa_actions) */
extern uint8_t  od_safety_controlword_system;                                 /**< 0x2620:0x01 (Safety controlwords manufacturer safety_controlword_system) */
extern uint8_t  od_safety_controlword_safemotion;                             /**< 0x2620:0x03 (Safety controlwords manufacturer safety_controlword_safemotion) */
extern uint8_t  od_inverted_safety_controlword_system;                        /**< 0x2622:0x01 (Inverted Safety controlwords manufacturer inverted_safety_controlword_system) */
extern uint8_t  od_inverted_safety_controlword_safemotion;                    /**< 0x2622:0x03 (Inverted Safety controlwords manufacturer inverted_safety_controlword_safemotion) */
extern int32_t  od_speed_demand;                                              /**< 0x3002:0x00 (speed_demand) */
extern int32_t  od_motor_ratio;                                               /**< 0x3003:0x00 (motor_ratio) */
extern int32_t  od_angle_mdeg;                                                /**< 0x3004:0x00 (angle_mdeg) */
extern uint16_t od_error_code;                                                /**< 0x603f:0x00 (error_code) */
extern uint16_t od_controlword;                                               /**< 0x6040:0x00 (controlword) */
extern uint16_t od_statusword;                                                /**< 0x6041:0x00 (statusword) */
extern int16_t  od_vl_target_velocity;                                        /**< 0x6042:0x00 (vl_target_velocity) */
extern int16_t  od_vl_velocity_demand;                                        /**< 0x6043:0x00 (vl_velocity_demand) */
extern int16_t  od_vl_velocity_actual_value;                                  /**< 0x6044:0x00 (vl_velocity_actual_value) */
extern uint32_t od_vl_velocity_min_max_amount_vl_velocity_min_amount;         /**< 0x6046:0x01 (vl_velocity_min_max_amount vl_velocity_min_max_amount_vl_velocity_min_amount) */
extern uint32_t od_vl_velocity_min_max_amount_vl_velocity_max_amount;         /**< 0x6046:0x02 (vl_velocity_min_max_amount vl_velocity_min_max_amount_vl_velocity_max_amount) */
extern uint32_t od_vl_velocity_acceleration_delta_speed;                      /**< 0x6048:0x01 (vl_velocity_acceleration vl_velocity_acceleration_delta_speed) */
extern uint16_t od_vl_velocity_acceleration_delta_time;                       /**< 0x6048:0x02 (vl_velocity_acceleration vl_velocity_acceleration_delta_time) */
extern uint32_t od_vl_velocity_deceleration_delta_speed;                      /**< 0x6049:0x01 (vl_velocity_deceleration vl_velocity_deceleration_delta_speed) */
extern uint16_t od_vl_velocity_deceleration_delta_time;                       /**< 0x6049:0x02 (vl_velocity_deceleration vl_velocity_deceleration_delta_time) */
extern uint32_t od_vl_velocity_quick_stop_delta_speed;                        /**< 0x604a:0x01 (vl_velocity_quick_stop vl_velocity_quick_stop_delta_speed) */
extern uint16_t od_vl_velocity_quick_stop_delta_time;                         /**< 0x604a:0x02 (vl_velocity_quick_stop vl_velocity_quick_stop_delta_time) */
extern int16_t  od_vl_set_point_factor_numerator;                             /**< 0x604b:0x01 (vl_set_point_factor vl_set_point_factor_numerator) */
extern int16_t  od_vl_set_point_factor_denominator;                           /**< 0x604b:0x02 (vl_set_point_factor vl_set_point_factor_denominator) */
extern int32_t  od_vl_dimension_factor_numerator;                             /**< 0x604c:0x01 (vl_dimension_factor vl_dimension_factor_numerator) */
extern int32_t  od_vl_dimension_factor_denominator;                           /**< 0x604c:0x02 (vl_dimension_factor vl_dimension_factor_denominator) */
extern int8_t   od_modes_of_operation;                                        /**< 0x6060:0x00 (modes_of_operation) */
extern int8_t   od_modes_of_operation_display;                                /**< 0x6061:0x00 (modes_of_operation_display) */
extern int32_t  od_position_value;                                            /**< 0x6064:0x00 (position_value) */
extern int32_t  od_velocity_actual_value;                                     /**< 0x606c:0x00 (velocity_actual_value) */
extern uint8_t  od_polarity;                                                  /**< 0x607e:0x00 (polarity) */
extern uint32_t od_position_encoder_resolution_encoder_increments;            /**< 0x608f:0x01 (position_encoder_resolution position_encoder_resolution_encoder_increments) */
extern uint32_t od_position_encoder_resolution_motor_revolutions;             /**< 0x608f:0x02 (position_encoder_resolution position_encoder_resolution_motor_revolutions) */
extern uint32_t od_velocity_encoder_resolution_encoder_increments_per_second; /**< 0x6090:0x01 (velocity_encoder_resolution velocity_encoder_resolution_encoder_increments_per_second) */
extern uint32_t od_velocity_encoder_resolution_motor_revolutions_per_second;  /**< 0x6090:0x02 (velocity_encoder_resolution velocity_encoder_resolution_motor_revolutions_per_second) */
extern uint32_t od_gear_ratio_motor_revolutions;                              /**< 0x6091:0x01 (gear_ratio gear_ratio_motor_revolutions) */
extern uint32_t od_gear_ratio_shaft_revolutions;                              /**< 0x6091:0x02 (gear_ratio gear_ratio_shaft_revolutions) */
extern uint32_t od_feed_constant_feed;                                        /**< 0x6092:0x01 (feed_constant feed_constant_feed) */
extern uint32_t od_feed_constant_shaft_revolutions;                           /**< 0x6092:0x02 (feed_constant feed_constant_shaft_revolutions) */
extern uint32_t od_supported_drive_modes;                                     /**< 0x6502:0x00 (supported_drive_modes) */

extern uint8_t od_safety_controlword_safein_1;
extern uint8_t od_inverted_safety_controlword_safein_1;

extern uint8_t od_safety_controlword_can1;
extern uint8_t od_safety_controlword_can2;
extern uint8_t od_safety_controlword_can3;
extern uint8_t od_safety_controlword_can4;
extern uint8_t od_safety_controlword_can5;
extern uint8_t od_safety_controlword_can6;
extern uint8_t od_safety_controlword_can7;
extern uint8_t od_safety_controlword_can8;

extern uint8_t od_inverted_safety_controlword_can1;
extern uint8_t od_inverted_safety_controlword_can2;
extern uint8_t od_inverted_safety_controlword_can3;
extern uint8_t od_inverted_safety_controlword_can4;
extern uint8_t od_inverted_safety_controlword_can5;
extern uint8_t od_inverted_safety_controlword_can6;
extern uint8_t od_inverted_safety_controlword_can7;
extern uint8_t od_inverted_safety_controlword_can8;

extern uint8_t od_safety_statusword_can1;
extern uint8_t od_safety_statusword_can2;
extern uint8_t od_safety_statusword_can3;
extern uint8_t od_safety_statusword_can4;
extern uint8_t od_safety_statusword_can5;
extern uint8_t od_safety_statusword_can6;
extern uint8_t od_safety_statusword_can7;
extern uint8_t od_safety_statusword_can8;

extern uint8_t od_inverted_safety_statusword_can1;
extern uint8_t od_inverted_safety_statusword_can2;
extern uint8_t od_inverted_safety_statusword_can3;
extern uint8_t od_inverted_safety_statusword_can4;
extern uint8_t od_inverted_safety_statusword_can5;
extern uint8_t od_inverted_safety_statusword_can6;
extern uint8_t od_inverted_safety_statusword_can7;
extern uint8_t od_inverted_safety_statusword_can8;

extern int16_t od_ezw_hall_abc_out[1][4];

extern int32_t od_safe_position_actual_value_i32;
extern int32_t od_safe_velocity_actual_value_i32;
extern int32_t od_inverted_safe_position_actual_value_i32;
extern int32_t od_inverted_safe_velocity_actual_value_i32;

extern uint8_t od_sbu_status; /**< 0x3041:0x00 (SBU status) */
extern uint16_t od_safety_function_output_1; /**< 0x2630:0x01 (Safety Function Output safety_function_output_1) */
extern uint16_t od_safety_function_output_2; /**< 0x2630:0x02 (Safety Function Output safety_function_output_2) */
extern int32_t od_hall_encoder; /**< 0x2064:0x00 (accurate_position_value) */
extern uint32_t od_system_error_output_1; /**< 0x2631:0x01 (System Error Output system_error_output_1) */
extern uint32_t od_system_error_output_2; /**< 0x2631:0x02 (System Error Output system_error_output_2) */

/* Insert application variables that are used in the OD here */

#endif /* APP_OD_H */
