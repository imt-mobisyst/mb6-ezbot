/**
 * Copyright (C) 2018 EZ-Wheel S.A.S.
 *
 * @file ezw_canopen_config.h
 * @brief EZW CAN configuration declaration header
 */

#ifndef EZW_CANOPEN_CONFIG_H
#define EZW_CANOPEN_CONFIG_H

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "ezw_canopen.h"

/** @defgroup ezw-canopen ezw-canopen
 * EZ-Wheel CANOpen module.
 */

/** @defgroup ezw-canopen-public public
 * Public API functions.
 * @ingroup ezw-canopen
 * @{
 */

/** @defgroup ezw-canopen-public-defines defines
 * @ingroup ezw-canopen-public
 * @{
 */
#define EZW_CANOPEN_MASTER_NODE 1U /*!< Define a master node */
#define EZW_CANOPEN_SLAVE_NODE  0U /*!< Define a slave node  */
    /** @} */

    /** @defgroup ezw-canopen-public-typedefs typedefs
     * @ingroup ezw-canopen-public
     * @{
     */

    typedef ezw_error_t (*ptr_fct_app_config)(uint8_t subIndex); /*!< Function pointer to load/clear/save configuration functions */
    typedef void (*ptr_fct_app_led)(uint8_t on);                 /*!< Function pointer to control can led functions               */

    /** @brief canopen HAL configuration
     * is_master equals '1' if master, otherwise means slave
     */
    typedef struct {
        uint8_t            is_master;
        ptr_fct_app_config ptr_fct_app_config_load;
        ptr_fct_app_config ptr_fct_app_config_save;
        ptr_fct_app_config ptr_fct_app_config_clear;
    } ezw_canopen_config_hal_t;
    /**@}*/

    /** @defgroup ezw-canopen-public-extern extern
     * @ingroup ezw-canopen-public
     * @{
     * Configuration table that must be defined by the application
     */
    extern ezw_canopen_config_hal_t ezw_canopen_config_hal;
    /**@}*/

    /**@}*/

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* EZW_CANOPEN_CONFIG_H */
