/**
 * Copyright (C) 2018 EZ-Wheel S.A.S.
 *
 * @file ezw_canopen_event_register.h
 * @brief EZW CANOpen main source code header
 */

#ifndef EZW_CANOPEN_EVENT_REGISTER_H
#define EZW_CANOPEN_EVENT_REGISTER_H

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/* Includes -------------------------------------------- */
#include "gen_define.h" // TODO : Check if there is a better way to order these includes.

#include "ezw_canopen.h"

#include "co_datatype.h"
#include "co_nmt.h"
#include "co_pdo.h"

#include "ezw_types.h"

    /** @defgroup ezw-canopen ezw-canopen
     * EZ-Wheel CANOpen module.
     */

    /** @defgroup ezw-canopen-public public
     * Public API functions.
     * @ingroup ezw-canopen
     * @{
     */

    /** @defgroup ezw-canopen-public-typedefs typedefs
     * @ingroup ezw-canopen-public
     * @{
     */

    /** @brief function pointer to NMT state changed function
     * @param NMT state
     *
     * @return RET_T
     */
    typedef RET_T (*ezw_canopen_callback_nmt_changed_t)(CO_NMT_STATE_T);

    /** @brief function pointer to object changed function
     * @param index - object index
     * @param subindex - object subindex
     *
     * @return RET_T
     */
    typedef RET_T (*ezw_canopen_callback_object_changed_t)(uint16_t, uint8_t);

    /** @brief function pointer to SYNC indication
     * @param syncCounter - actual SYNC counter
     *
     */
    typedef void (*ezw_canopen_callback_sync_t)(uint8_t);

    /** @brief function pointer to PDO indication
     * @param pdoNr - PDO number
     *
     */
    typedef void (*ezw_canopen_callback_pdo_t)(uint16_t); /*lint !e960 customer specific parameter names */

    /** @brief function pointer to PDO update indication
     * @param index
     * @param subindex
     *
     */
    typedef void (*ezw_canopen_callback_pdo_update_t)(uint16_t, uint8_t);

    /** @brief function pointer to SDO server event
     * @param execute - execute or test only
     * @param sdoNr - sdo number
     * @param index - object index
     * @param subindex - object subindex
     *
     * @return RET_T
     */
    typedef RET_T (*ezw_canopen_callback_sdo_server_t)(BOOL_T, uint8_t, uint16_t, uint8_t); /*lint !e960 customer specific parameter names */

    /** @brief function pointer to SDO client read event
     * @param sdoNr - sdo number
     * @param index - object index
     * @param subindex - object subindex
     * @param size - size of received data
     * @param result - result of transfer
     *
     */
    typedef void (*ezw_canopen_callback_sdo_client_read_t)(uint8_t, uint16_t, uint8_t, uint32_t, uint32_t); /*lint !e960 customer specific parameter names */

    /** @brief function pointer to SDO client write event
     * @param sdoNr - sdo number
     * @param index - object index
     * @param subindex - object subindex
     * @param result - result of transfer
     *
     */
    typedef void (*ezw_canopen_callback_sdo_client_write_t)(uint8_t, uint16_t, uint8_t, uint32_t); /*lint !e960 customer specific parameter names */
    /**@}*/

    /** @defgroup ezw-canopen-public-functions functions
     * @ingroup ezw-canopen-public
     * @{
     */

    /** @brief set NMT changed callback
     *
     */
    void setNMTChangeCallback(ezw_canopen_callback_nmt_changed_t cb);

    /** @brief NMT changed callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_nmt_changed(ezw_canopen_callback_nmt_changed_t fn);

    /** @brief Object changed callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_object_changed(const ezw_canopen_callback_object_changed_t fn, const uint16_t index, const uint8_t subindex);

    /** @brief Synchronisation message received callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_sync_received(const ezw_canopen_callback_sync_t fn);

    /** @brief Synchronisation pdo received callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_sync_pdo_received(const ezw_canopen_callback_pdo_t fn);

    /** @brief Asynchronisation message received callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_async_pdo_received(const ezw_canopen_callback_pdo_t fn);

    /** @brief PDO message received callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_pdo_received(const ezw_canopen_callback_pdo_t fn);

    /** @brief PDO update received callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_pdo_update(const ezw_canopen_callback_pdo_update_t fn);

    /** @brief SDO server read message received callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_sdo_server_read(const ezw_canopen_callback_sdo_server_t fn);

    /** @brief SDO server write message received callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_sdo_server_write(const ezw_canopen_callback_sdo_server_t fn);

    /** @brief SDO client read message received callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_sdo_client_read(const ezw_canopen_callback_sdo_client_read_t fn);

    /** @brief SDO client write message received callback
     *
     */
    ezw_error_t ezw_canopen_register_callback_sdo_client_write(const ezw_canopen_callback_sdo_client_write_t fn);
    /**@}*/

    /**@}*/

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* EZW_CANOPEN_EVENT_REGISTER_H */
