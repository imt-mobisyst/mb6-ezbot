/*
 * Copyright (C) 2019 EZ-Wheel S.A.S.
 *
 * @brief ezw-log contexts definition header
 */

#ifndef EZW_LOG_CONTEXT_H
#define EZW_LOG_CONTEXT_H

/**
 * @brief Common Context IDs for ez-Wheel
 *
 * Create contextes so that we are likely to reuse them
 * For instance, Wheel, CAN, WMS (database) will always have
 * the same filters/XML parserss working in viewer
 *
 */
#define CON_APP 0	   /**<General application */
#define CON_SAFETY 1   /**<Safety and Emmergency related */
#define CON_CAN 2	   /**<CAN message handling */
#define CON_WHEEL 3	   /**<Motor and Wheel-level APIs and objects */
#define CON_BATT 4	   /**<Battery and Power managemen */
#define CON_WMS 5	   /**<DataBase and high level fleet and infra protocols */
#define CON_IDBG 6	   /**<Interroll API debug */
#define CON_IAPI 7	   /**<Interroll API Functionalities tracing */
#define CON_SENSOR 8   /**<Compound sensor handling */
#define CON_ROS 9	   /**<ROS context marker */
#define CON_COS 10     /**<CAN Open Service */
#define CON_IOS 11     /**<IO Service */
#define CON_SMCDS 12   /**<SMC Drive Service */
#define CON_SMCBS 13   /**<SMC Belt Service */
#define CON_FPS 14     /**<Front Perception Service */
#define CON_BPS 15     /**<Back Perception Service */
#define CON_BMSS 16    /**<BMS Service */
#define CON_BUS 17     /**<Bridge Up Service */
#define CON_BDS 18     /**<Bridge Down Service */
#define CON_LOS 19     /**<Log Service */
#define CON_LOH 20     /**<Log Hub Service */
#define CON_ROM 21     /**<Robot Manager */
#define CON_FLM 22     /**<Fleet Manager */
#define CON_ROMREST 23 /**<Robot Manager restapi */
#define CON_FLMREST 24 /**<Fleet Manager restapi */
#define CON_BLTMS 25   /**<Bootloader TMS */
#define CON_FCAMS 26   /**<Front Camera Service */
#define CON_BCAMS 27   /**<Back Camera Service */
#define CON_BES 28     /**<Belt Service */
#define CON_ERM 29     /**<Error Manager */
#define CON_ERMREST 30 /**<Error Manager restapi */
#define CON_BIT 31     /**<Error Manager for Built In Tests */
#define CON_MON 32     /**<Monitoring Service */
#define CON_LAST 33    /**<Last/Invalid context marker */

#endif /* EZW_LOG_CONTEXT_H */
