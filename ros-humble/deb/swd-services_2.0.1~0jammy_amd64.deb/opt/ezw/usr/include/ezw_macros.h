/*
 * Copyright (C) 2020 EZ-Wheel S.A.S
 *
 * @brief types definitions header
 */

#ifndef EZW_MACROS_H
#define EZW_MACROS_H

/** @defgroup ezw-types-public-macros macros
 * @ingroup ezw-types-public
 * @{
 */

#ifndef FROM_S_TO_US
    #define FROM_S_TO_US(value_in_s)   (value_in_s * 1000000U )
#endif /* FROM_S_TO_US */

#ifndef EZW_ARRAY_SIZE
    #define EZW_ARRAY_SIZE(array) (sizeof(array) / sizeof(array[0]))
#endif /* EZW_ARRAY_SIZE */

#ifndef EZW_UNUSED_PARAMETER
    #define EZW_UNUSED_PARAMETER(param) ((void)(param))
#endif /* EZW_UNUSED_PARAMETER */

#ifndef EZW_GET_BIT
    #define EZW_GET_BIT(value, bit) (((value) & (1 << (bit))) >> (bit))
#endif /* EZW_GET_BIT */

#ifndef EZW_SET_BIT
    #define EZW_SET_BIT(value, bit_value, bit) (((value) & (~(1 << (bit)))) | ((bit_value) << (bit)))
#endif /* EZW_SET_BIT */

#ifndef EZW_BIT_IS_SET
    #define EZW_BIT_IS_SET(value, bit) (((value) & (1 << (bit))) == (1 << (bit)))
#endif /* EZW_BIT_IS_SET */

#ifndef EZW_LO_UINT32
    #define EZW_LO_UINT32(ui64) ((uint32_t)(ui64) & 0xFFFFFFFF)
#endif /* EZW_LO_UINT32 */

#ifndef EZW_HI_UINT32
    #define EZW_HI_UINT32(ui64) ((uint32_t)(ui64) >> 32)
#endif /* EZW_HI_UINT32 */

#ifndef EZW_LO_UINT16
    #define EZW_LO_UINT16(ui32) ((uint16_t)(ui32) & 0xFFFF)
#endif /* EZW_LO_UINT16 */

#ifndef EZW_HI_UINT16
    #define EZW_HI_UINT16(ui32) ((uint16_t)(ui32) >> 16)
#endif /* EZW_HI_UINT16 */

#ifndef EZW_LO_UINT8
    #define EZW_LO_UINT8(ui16) ((uint8_t)(ui16) & 0xFF)
#endif /* EZW_LO_UINT8 */

#ifndef EZW_HI_UINT8
    #define EZW_HI_UINT8(ui16) ((uint8_t)(ui16) >> 8)
#endif /* EZW_HI_UINT8 */

#ifndef EZW_MAKE_UINT64
    #define EZW_MAKE_UINT64(Low32, High32)      ((uint64_t)(((uint32_t)((Low32) & 0xFFFFFFFF)) | \
                                                ((uint64_t)((uint32_t)((High32) & 0xFFFFFFFF))) <<32))
#endif /* EZW_MAKE_UINT64 */

#ifndef EZW_MAKE_UINT32
    #define EZW_MAKE_UINT32(Low16, High16)      ((uint32_t)(((uint16_t)((Low16) & 0xFFFF)) | \
                                                ((uint32_t)((uint16_t)((High16) & 0xFFFF))) << 16))
#endif /* EZW_MAKE_UINT32 */

#ifndef EZW_MAKE_UINT16
    #define EZW_MAKE_UINT16(Low8, High8)        ((uint16_t)(((uint8_t)( (Low8)  & 0xFF)) | \
                                                ((uint16_t)((uint8_t)( (High8)  & 0xFF))) << 8))
#endif /* EZW_MAKE_UINT16 */

#ifndef EZW_MDEG_SEC_TO_RPM
    #define EZW_MDEG_SEC_TO_RPM(mdeg_per_sec)   (mdeg_per_sec * 60 / 360000)
#endif /* EZW_MDEG_SEC_TO_RPM */

#ifndef EZW_RPM_TO_MDEG_SEC
    #define EZW_RPM_TO_MDEG_SEC(rot_per_min)   ((rot_per_min) * 360000 / 60)
#endif /* EZW_RPM_TO_MDEG_SEC */

#ifndef EZW_ALIGN_VALUE
    #define EZW_ALIGN_VALUE(val_to_align, val_to_align_on)    (((val_to_align) + (val_to_align_on) - 1U) & ~((val_to_align_on) - 1U))
#endif /* EZW_ALIGN_VALUE */

/** @} */

#endif /* EZW_MACROS_H */
