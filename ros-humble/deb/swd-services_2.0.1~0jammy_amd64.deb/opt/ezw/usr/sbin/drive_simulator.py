#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# =======================================================================

# Import the modules needed to run the script.
import sys, os, time
import threading

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "/opt/ezw/usr/lib"))

import enum

from smcdbusclient.nmt import NMTDBusClient, NMTCommand
from smcdbusclient.pds import (
    PDSDBusClient,
)
from smcdbusclient.safe_motion import (
    SafeMotionDBusClient,
)
from smcdbusclient.manufacturer import ManufacturerDBusClient

from smcdbusclient.velocity_mode import VelocityModeDBusClient

from smcdbusclient.srdo import SRDODBusClient
from smcdbusclient.communication import CommunicationDBusClient, NetworkParameters
from smcdbusclient.emcy import EMCYDBusClient
from smcdbusclient.internal import InternalDBusClient
from smcdbusclient.core import CoreDBusClient, ModeEnum

from smcdbusclient.can_open import CANOpenDBusClient

import argparse

velocity = 500
direction = 1

import termios
import fcntl

from pathlib import Path


class bcolors:
    HEADER = "\033[95m"
    OKBLUE = "\033[94m"
    OKCYAN = "\033[96m"
    OKGREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"


def print_result(name, result):
    lst = list(result)
    value = ""
    res = lst.pop()

    for v in lst:
        if isinstance(type(v), enum.EnumMeta):
            value += v.name + " "
        elif isinstance(v, list):
            value += ", ".join(list(str(a) for a in v)) + " "

    if value == "":
        value = lst[0]

    # print(f"{name}".ljust(20, " "), end=" ")
    print("{}".format(name).ljust(20, " "), end=" ")
    # print(f": {value} ".ljust(80, "."), end=" ")
    print(": {} ".format(value).ljust(80, "."), end=" ")

    if res == 1:
        # print(f"{bcolors.OKGREEN}[OK]{bcolors.ENDC}")
        print("{}[OK]{}".format(bcolors.OKGREEN, bcolors.ENDC))
    else:
        # print(f"{bcolors.FAIL}[KO]{bcolors.ENDC}")
        print("{}[KO]{}".format(bcolors.FAIL, bcolors.ENDC))


class MotorSim:
    def __init__(self, instance_id: str):
        self.nmt_client = NMTDBusClient(instance_id)
        self.pds_client = PDSDBusClient(instance_id)
        self.safe_motion_client = SafeMotionDBusClient(instance_id)
        self.manufacturer_client = ManufacturerDBusClient(instance_id)
        self.velocity_mode_client = VelocityModeDBusClient(instance_id)
        self.srdo_client = SRDODBusClient(instance_id)
        self.communication_client = CommunicationDBusClient(instance_id)
        self.emcy_client = EMCYDBusClient(instance_id)
        self.internal_client = InternalDBusClient(instance_id)
        self.core_client = CoreDBusClient(instance_id)
        self.can_open_client = CANOpenDBusClient(instance_id)

    def init(self):
        self.core_client.switchMode(ModeEnum.LOCAL)

        self.can_open_client.setValueUInt16(0x6041_00_00, 0x27)  # statusword (0x27 = OPERATION_ENABLED)

        self.nmt_client.setNMTState(NMTCommand.OPER)
        self.pds_client.switchOn()

        self.__hb_running = threading.Event()
        self.__hb_running.set()
        self.__hb_thread = threading.Thread(target=self.__cb_hb)
        self.__hb_thread.start()

        self.__speed_acceleration = 1000  # rpm
        self.__speed_running = threading.Event()
        self.__speed_running.set()
        self.__speed_thread = threading.Thread(target=self.__cb_speed)
        self.__speed_thread.start()

        self.__odometry_running = threading.Event()
        self.__odometry_running.set()
        self.__odometry_thread = threading.Thread(target=self.__cb_odometry)
        self.__odometry_thread.start()

    def __cb_hb(self):
        nodeId, _ = self.core_client.getConnectedNodeId()
        cobId = 0x700 + nodeId
        device, _ = self.core_client.getCanDevice()

        while self.__hb_running.is_set():
            os.system(f"cansend {device} {format(cobId,'x')}#05")

            time.sleep(0.5)

    def __cb_speed(self):
        while self.__speed_running.is_set():
            actual, _ = self.velocity_mode_client.getVelocityActualValue()
            target, _ = self.velocity_mode_client.getTargetVelocity()

            if actual == target:
                time.sleep(0.1)
                continue

            self.can_open_client.setValueInt16(0x6043_00_00, target)  # vl_velocity_demand

            if abs(actual == target) < 50:
                speed = target
            else:
                if actual > target:
                    speed = speed - self.__speed_acceleration * 0.1
                else:
                    speed = speed + self.__speed_acceleration * 0.1

            self.can_open_client.setValueInt16(0x606C_00_00, speed)  # velocity_actual_value
            print(f"set velocity_actual_value : {speed}")

            time.sleep(0.1)

    def __cb_odometry(self):
        while self.__odometry_running.is_set():
            # The SWD Core resolution is 30 increments par revolution.
            # The counter direction depends of the position polarity parameter.

            speed, _ = self.velocity_mode_client.getVelocityActualValue()
            if speed == 0:
                time.sleep(0.1)
                continue

            params, _ = self.pds_client.getPolarityParameters()
            polarity = -1 if params.velocity_polarity else 1  # velocity demand value/motor revolution increments shall be multiplied by –1 if True

            position, _ = self.velocity_mode_client.getPositionValue()
            position = position + speed / 60 * 0.1 * 30 * polarity

            self.can_open_client.setValueInt32(0x6064_00_00, position)  # position_value

            odom, _ = self.manufacturer_client.getOdometryValue()
            print(f"OdometryValue : {odom}")

            time.sleep(0.1)


# =======================
#      MAIN PROGRAM
# =======================


def main(argv):
    parser = argparse.ArgumentParser("DriveSimulator")
    parser.add_argument("instance", help="Name of the smc dbus instance (ie: smc_drive).", type=str)
    args = parser.parse_args()

    instance_id = args.instance

    # Load specific dbus user session if exists
    session = ""
    if os.path.isfile("/tmp/SYSTEMCTL_dbus.id"):
        session = "/tmp/SYSTEMCTL_dbus.id"
    elif os.path.isfile("/opt/ezw/data/tmp/SYSTEMCTL_dbus.id"):
        session = "/opt/ezw/data/tmp/SYSTEMCTL_dbus.id"

    if session != "":
        print("SYSTEMCTL_dbus.id detected")

        with open(session) as f:
            lines = f.readlines()
        env = dict(line.strip().split("=", 1) for line in lines)
        os.environ.update(env)

    motor = MotorSim(instance_id)

    motor.init()

    # Commissioning
    if instance_id == "swd_left":
        params, _ = motor.pds_client.getPolarityParameters()
        params.velocity_polarity = True  # velocity demand value/motor revolution increments shall be multiplied by –1 if True
        motor.pds_client.setPolarityParameters(params)

    params, _ = motor.communication_client.getNetworkParameters()
    params.node_id, _ = motor.core_client.getConnectedNodeId()
    motor.communication_client.setNetworkParameters(params)

    # Init safety functions
    motor.can_open_client.setValueBool(0x6640_00_00, 1)  # STO command => 1 (no STO)
    motor.can_open_client.setValueBool(0x6660_01_00, 1)  # SBC command 1 => 1 (no SBC)
    motor.can_open_client.setValueBool(0x6690_01_00, 1)  # SLS command 1 => 1 (no SLS)
    motor.can_open_client.setValueBool(0x66D0_01_00, 1)  # SDIp command 1 => 1 (no SDIp)
    motor.can_open_client.setValueBool(0x66D1_01_00, 1)  # SDIn command 1 => 1 (no SDIn)

    motor.nmt_client.setNMTState(NMTCommand.OPER)

    # Initial state
    print("")
    print_result("Node ID", motor.core_client.getConnectedNodeId())
    print_result("CAN device", motor.core_client.getCanDevice())

    print_result("NMT State", motor.nmt_client.getNMTState())
    print_result("PDS State", motor.pds_client.getPDSState())

    print_result("TargetVelocity", motor.velocity_mode_client.getTargetVelocity())
    print_result("VelocityDemand", motor.velocity_mode_client.getVelocityDemand())
    print_result("VelocityActualValue", motor.velocity_mode_client.getVelocityActualValue())
    print_result("PositionValue", motor.velocity_mode_client.getPositionValue())
    print_result("OdometryValue", motor.manufacturer_client.getOdometryValue())


if __name__ == "__main__":
    main(sys.argv[1:])
