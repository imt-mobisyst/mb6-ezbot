#!/bin/bash

#
# Copyright (C) 2020 EZ-Wheel S.A.S.
#

SCRIPT_PATH=$(readlink -f $0)
SCRIPT_DIR=$(dirname $SCRIPT_PATH)

IMAGE_DIR=$(readlink -f "/opt/ezw/usr")

BIN_DIR="$IMAGE_DIR/bin"
LIB_DIR="$IMAGE_DIR/lib"
TMP_DIR="/tmp"
LOG_DIR="$TMP_DIR/logs"
DBUS_ID_TMP="$TMP_DIR/SYSTEMCTL_dbus.id"

dbg() {
    echo $@
}
DEBUG=
WAIT=1
SUDO_PASSWORD=""

########################################################

APPS_PID="$TMP_DIR/app_pid"
PYTHON_APPS=(
    "../lib/ezwtools/SRDO_emulator.py"
)

BIN_APPS=(
    ".smc_drive:ezw-smc-service $IMAGE_DIR/etc/ezw-smc-core/drive_config.ini"
)

usage() {
    echo "Usage: $0 <start|stop> [sudo_password]"
}

sudo_cmd() {
    if [ -n "$SUDO_PASSWORD" ]; then
        $DEBUG echo "$SUDO_PASSWORD" | sudo -S -k "$@"
    else
        $DEBUG "$@"
    fi
}

check_dbus() {
    if [ -f "$DBUS_ID_TMP" ]; then
        echo "D-Bus session found"
        $DEBUG export $(cat $DBUS_ID_TMP)
    # else
    #     $DEBUG dbus-launch >$DBUS_ID_TMP
    #     $DEBUG export $(cat $DBUS_ID_TMP)
    fi
}

kill_all() {
    PIDS=$(ps -ef | grep "/opt/ezw/usr/bin" | awk '{print $2}')
    if [ ! -z "$PIDS" ]; then
        kill -9 $PIDS 2>/dev/null
    fi

    PIDS=$(ps -ef | grep "/opt/ezw/usr/sbin" | awk '{print $2}')
    if [ ! -z "$PIDS" ]; then
        kill -9 $PIDS 2>/dev/null
    fi
}

stop_all() {
    kill_all

    sleep 2

    if [ -f $DBUS_ID_TMP ]; then
        $DEBUG export $(cat $DBUS_ID_TMP)
        $DEBUG rm $DBUS_ID_TMP
    fi

    if [ ! -e "$APPS_PID" ]; then
        echo "ERROR: $APPS_PID does not exist. Can not clean up everything."
        exit 1
    fi

    for i in $(cat $APPS_PID); do
        N=$(echo $i | sed -e "s/;.*$//")
        P=$(echo $i | sed -e "s/^.*;//")
        if [ "$(ps | grep "$P" | grep -v "grep")" != "" ]; then
            echo "Killing app $N..."
            $DEBUG kill "$P"
        fi
    done

    DBPID="$(ps | grep "$DBUS_SESSION_BUS_PID" | grep -v "grep" | awk '{print $1}')"
    if [ "$DBPID" = "$DBUS_SESSION_BUS_PID" ]; then
        $DEBUG kill "$DBUS_SESSION_BUS_PID"
    fi
}

check_error() {
    err=0
    for i in $(cat $APPS_PID); do
        N=$(echo $i | sed -e "s/;.*$//")
        P=$(echo $i | sed -e "s/^.*;//")
        if [ "$(ps | grep $P | grep -v "grep")" = "" ]; then
            err=1
            echo " --------- Application $N ended unexpectedly --------"
        fi
    done
    if [ $err -eq 1 ]; then
        echo " --------- Killing everything --------"
        stop_all
        exit 1
    fi
}

check_can() {
    ret=$(cat /sys/class/net/can0/operstate 2>/dev/null)
    if [ $? -eq 0 ]; then
        echo "Can itface can0 may not set up correctly. Setting up..."
        sudo_cmd ip link set down can0
        sudo_cmd ip link set can0 up type can bitrate 1000000 restart-ms 100
        sudo_cmd ip link set can0 txqueuelen 1000

        return 0
    else
        echo "Can itface can0 not found !!!"
    fi

    echo "Can itface virtual vcan may not set up correctly. Setting up..."
    sudo_cmd ip link add dev vcan type vcan bitrate 1000000
    sudo_cmd ip link set up vcan

    ret=$(cat /sys/class/net/vcan/operstate 2>/dev/null)
    if [ $? -eq 0 ]; then
        return 0
    else
        echo "Can itface vcan not found !!!"
    fi

    echo "ERROR: No Can itface found !!!"
    exit 1
}

create_usr() {
    echo "Create usr..."
    if [ ! -d $(pwd)/image_x86_64/opt/ezw ]; then
        echo "Workspace $(pwd)/image_x86_64/opt/ezw not found !!!"
        echo "=> SKIP: /opt/ezw/usr redirection"
        return 1
    fi

    sudo_cmd mkdir -p /opt/ezw
    if [ ! -L /opt/ezw ]; then
        echo "=> mv /opt/ezw into /opt/ezw.sav"
        sudo_cmd rm -rf /opt/ezw.sav
        sudo_cmd mv /opt/ezw /opt/ezw.sav
    else
        echo "=> rm symlink /opt/ezw"
        sudo_cmd rm -rf /opt/ezw
    fi
    sudo_cmd ln -s $(pwd)/image_x86_64/opt/ezw /opt
}

check_apps() {
    err=0
    for ((i = 0; i < ${#PYTHON_APPS[@]}; i++)); do
        N=$(echo "$BIN_DIR/${PYTHON_APPS[$i]}" | sed -e "s/ .*//")
        if [ ! -e "$N" ]; then
            echo "ERROR: $N does not exist."
            err=1
        fi

    done

    for ((i = 0; i < ${#BIN_APPS[@]}; i++)); do
        if [[ ${BIN_APPS[$i]} == *":"* ]]; then
            A=$(echo "${BIN_APPS[$i]}" | cut -d ":" -f2)
        else
            A=${BIN_APPS[$i]}
        fi
        N=$(echo "$BIN_DIR/$A" | sed -e "s/ .*//")
        if [ ! -e "$N" ]; then
            echo "ERROR: $N does not exist."
            err=1
        fi
    done

    if [ $err -eq 1 ]; then
        exit 1
    fi
}

start() {
    create_usr $1
    check_apps
    check_dbus
    check_can $1

    #if problem . Should not happen ..
    [ ! -d $LOG_DIR ] && $(which mkdir) -p $LOG_DIR
    [ ! -d $TMP_DIR ] && $(which mkdir) -p $TMP_DIR/data/tmp

    echo "" >$APPS_PID
    for ((i = 0; i < ${#PYTHON_APPS[@]}; i++)); do
        N=$(echo "${PYTHON_APPS[$i]}" | sed -e "s/ .*//")
        N=$(basename $N .py)
        echo "-------------------------------------------"
        echo "Starting python app $N.py... (cf. $LOG_DIR/$N.log)"
        echo "-------------------------------------------"
        echo $DEBUG /usr/bin/python3 $BIN_DIR/${PYTHON_APPS[$i]}
        $DEBUG /usr/bin/python3 $BIN_DIR/${PYTHON_APPS[$i]} >$LOG_DIR/$N.log &
        echo "$N;$!" >>$APPS_PID
        sleep $WAIT
    done

    for ((i = 0; i < ${#BIN_APPS[@]}; i++)); do
        if [[ ${BIN_APPS[$i]} == *":"* ]]; then
            I=$(echo "${BIN_APPS[$i]}" | cut -d ":" -f1)
            A=$(echo "${BIN_APPS[$i]}" | cut -d ":" -f2)
        else
            A=${BIN_APPS[$i]}
        fi
        N=$(echo "$A" | sed -e "s/ .*//")
        echo "-------------------------------------------"
        echo "Starting $N... (cf. $LOG_DIR/$N$I.log)"
        echo "-------------------------------------------"
        echo $DEBUG $BIN_DIR/$A
        $DEBUG $BIN_DIR/$A >$LOG_DIR/$N$I.log &
        echo "$N;$!" >>$APPS_PID
        sleep $WAIT
    done
}

# Check args

# Check if started as sudo
IS_SUDO=1
if [[ $(/usr/bin/id -u) -ne 0 ]]; then
    IS_SUDO=0
else
    IS_SUDO=1
fi

# IS_SUDO=1 : 1 or 2 args
# IS_SUDO=0 : 2 Args
if [ "$IS_SUDO" -eq 1 ]; then
    if [ $# -ne 1 -a $# -ne 2 ]; then
        usage
        exit 1
    fi
else
    if [ "$#" -eq 1 ]; then
        usage
        echo "sudo_password is mandatory when launched without root privileges !"
        exit 1
    elif [ "$#" -ne 2 ]; then
        usage
        exit 1
    fi
fi

if [ "$IS_SUDO" -eq 1 ]; then
    echo "Launched as root"
else
    SUDO_PASSWORD=$2
    echo "Launched as user"
fi

export LD_LIBRARY_PATH=$LIB_DIR

# Go
case "$1" in
"start")
    kill_all
    start
    check_error
    ;;
"stop")
    kill_all
    ;;
*)
    usage
    ;;
esac
