#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# description     :This program displays an interactive menu on CLI
# =======================================================================

# Import the modules needed to run the script.
import sys, os, time
import os.path
import subprocess

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "/opt/ezw/usr/lib"))

import enum
import attr
import click

from smcdbusclient.nmt import NMTDBusClient, NMTCommand
from smcdbusclient.pds import (
    PDSDBusClient,
    PDSState,
    PeripheralStatus,
)
from smcdbusclient.safe_motion import (
    SafeMotionDBusClient,
    SafetyStatusWordId,
    SafetyControlWordId,
    SafetyWordType,
    STOId,
    STOParameters,
)
from smcdbusclient.manufacturer import ManufacturerDBusClient

from smcdbusclient.velocity_mode import VelocityModeDBusClient

from smcdbusclient.srdo import SRDODBusClient
from smcdbusclient.communication import CommunicationDBusClient, BlocId
from smcdbusclient.emcy import EMCYDBusClient, EMCY_ERROR_CODE
from smcdbusclient.internal import InternalDBusClient
from smcdbusclient.core import CoreDBusClient, ModeEnum
from smcdbusclient.can_open import CANOpenDBusClient

import argparse

velocity = 500
direction = 1

import termios
import fcntl

from pathlib import Path


def getch():
    fd = sys.stdin.fileno()

    oldterm = termios.tcgetattr(fd)
    newattr = termios.tcgetattr(fd)
    newattr[3] = newattr[3] & ~termios.ICANON & ~termios.ECHO
    termios.tcsetattr(fd, termios.TCSANOW, newattr)

    oldflags = fcntl.fcntl(fd, fcntl.F_GETFL)
    fcntl.fcntl(fd, fcntl.F_SETFL, oldflags)

    try:
        while 1:
            try:
                c = sys.stdin.read(1)
                break
            except IOError:
                pass
    finally:
        termios.tcsetattr(fd, termios.TCSAFLUSH, oldterm)
        fcntl.fcntl(fd, fcntl.F_SETFL, oldflags)
    return c


class bcolors:
    HEADER = "\033[95m"
    OKBLUE = "\033[94m"
    OKCYAN = "\033[96m"
    OKGREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"


def print_result(name, result):
    lst = list(result)
    value = ""
    res = lst.pop()

    for v in lst:
        if "SCW PERMANENT" in name:
            if res == 1:
                value += ", ".join(list(str(a) for a in attr.astuple(v))).replace("SafetyFunctionId.", "") + " "
            else:
                value = " "
        elif isinstance(type(v), enum.EnumMeta):
            value += v.name + " "
        elif isinstance(v, SafetyWordType) or isinstance(v, PeripheralStatus):
            value += ", ".join(list(str(a) for a in attr.astuple(v))) + " "
        elif isinstance(v, list):
            value += ", ".join(list(str(a) for a in v)) + " "

    if "SafetyFunctionOutput" in name or "SystemErrorOutput" in name:
        outputs = lst[0]
        value = "["
        if res == 1:
            if "SafetyFunctionOutput" in name:
                value += "".join([f"{out.safety_function_id.name}, " if out is not None and out.status else "" for out in outputs])
            elif "SystemErrorOutput" in name:
                value += "".join([f"{out.system_error_id.name}, " if out is not None and out.status else "" for out in outputs])
            if value[-1] == " ":
                value = value[:-2]
        value += "]"

        print("{}".format(name).ljust(20, " "), end=" ")
        print(": {} ".format(value).ljust(80, "."), end=" ")
    else:
        if value == "":
            value = lst[0]

        print("{}".format(name).ljust(20, " "), end=" ")
        print(": {} ".format(value).ljust(80, "."), end=" ")

    if res == 0:
        print("{}[NA]{}".format(bcolors.WARNING, bcolors.ENDC))
    elif res == 1:
        print("{}[OK]{}".format(bcolors.OKGREEN, bcolors.ENDC))
    else:
        print("{}[KO]{}".format(bcolors.FAIL, bcolors.ENDC))


def translateSerialNumber(serialNumber: int):
    if serialNumber == 0:
        return "XXXXXXXXXXXX"

    year = serialNumber >> 25
    dayOfYear = (serialNumber - (year << 25)) >> 16
    benchNumber = (serialNumber - ((year << 25) + (dayOfYear << 16))) >> 10
    SWDCoreNumber = (serialNumber - ((year << 25) + (dayOfYear << 16) + (benchNumber << 10))) >> 0
    return str(year) + f"{dayOfYear:0>3d}" + "SC" + f"{SWDCoreNumber:0>3d}" + "A" + str(benchNumber + 1)


# Main definition - constants
menu_actions = {}

# =======================
#     MENUS FUNCTIONS
# =======================


# Root menu
def root_menu():
    global velocity
    global direction

    print("<COM> Connect NodeId = i Disconnect = d Restore param = j Change current NodeId = g")
    print("<NMT> RESET_NODE = r Start all = m")
    print("<PDS> Go to OPERATION_ENABLED = o")
    print("<VL mode> target velocity ({}) = +/- positive order = 8 negative order = 2 stop = *".format(velocity))
    value, error = manufacturer_client.getExternalBrakePresence()
    print(f"<Param> STO_ACK off/on = f/n Change brake_presence to {str(not value) if error == 1 else 'UNKNOWN'} = b")
    print("<Mode> local = w remote = z")
    print("<Diagnostic> a")
    print("<STO> change STO activate_SBC = t")
    print("<EMCY> get full EMCY list = e, clear EMCY list = c")
    print("<SW> s")
    print("<quit> 0")

    #    choice = input(" >>  ")
    choice = getch()
    exec_menu(choice)

    root_menu()


# Execute menu
def exec_menu(choice):
    # os.system('clear')
    ch = choice.lower()
    if ch == "":
        menu_actions["root_menu"]()
    else:
        try:
            menu_actions[ch]()
        except KeyError:
            print("Invalid selection, please try again.\n")
            menu_actions["root_menu"]()
    return


def sto_ack(status: bool):
    params = STOParameters()

    error = nmt_client.setNMTState(NMTCommand.PREOP)
    if error == 1:
        time.sleep(0.5)
        params, signature, error = safe_motion_client.getSTOParameters(STOId.STO_1)
        print(params)
    else:
        print("setNMTState(PREOP) failed\n")

    if error == 1:
        params.restart_acknowledge_behavior = status
        error = safe_motion_client.setSTOParameters(STOId.STO_1, params)
        print(params)
    else:
        print("getSTOParameters() failed\n")

    # Save data in EEPROM
    if error == 1:
        error = communication_client.storeParameters(BlocId.ALL)  # BlocId.COMMUNICATION
    else:
        print("setSTOParameters failed\n")

    # Reset NODE
    if error == 1:
        error = nmt_client.setNMTState(NMTCommand.RESET_NODE)
    else:
        print("storeParameters failed\n")

    if error == 1:
        error = nmt_client.setNMTState(NMTCommand.OPER)
    else:
        print("setNMTState(RESET_NODE) failed\n")

    if error == 1:
        print(f"STO ACK set to {status}\n")
    else:
        print("setNMTState(OPER) failed\n")

    menu_actions["root_menu"]()


def sto_ack_off():
    sto_ack(False)


def sto_ack_on():
    sto_ack(True)


def clear_EMCY():
    emcy_client.clearErrorList()


def list_EMCY():
    errorCount, ret = emcy_client.getErrorCount()
    print("EMCY list : ")
    for msg in range(0, errorCount):
        emcy, err = emcy_client.getError(msg + 1)
        try:
            errorName = EMCY_ERROR_CODE(emcy).name
        except:
            errorName = "Unknown Error"

        print(f" {msg+1:>3} : \t[{emcy:X}] {errorName}")


# Start drive in OPERATION_ENABLED
def drive_oper():
    error = pds_client.enterInOperationEnabledState()
    print_result("PDS", (PDSState.OPERATION_ENABLED, error))
    if error != 1:
        print_result("PDS State", pds_client.getPDSState())
    menu_actions["root_menu"]()


def nmt_start_all():
    error = nmt_client.broadcastNMTState(NMTCommand.OPER)
    if error != 1:
        print("broadcastNMTState(NMTCommand.OPER) failed\n")


def nmt_stop_all():
    error = nmt_client.broadcastNMTState(NMTCommand.STOP)
    if error != 1:
        print("broadcastNMTState(NMTCommand.STOP) failed\n")


# Send velocity
def set_velocity():
    global velocity
    global direction

    error = velocity_mode_client.setTargetVelocity(direction * velocity)
    print_result("VelocityActualValue", velocity_mode_client.getVelocityActualValue())


# Positive velocity
def drive_positive():
    global direction

    direction = 1

    set_velocity()


# Negative velocity
def drive_negative():
    global direction

    direction = -1

    set_velocity()


# Stop velocity
def drive_stop():
    error = velocity_mode_client.setTargetVelocity(0)


# Inc velocity
def drive_inc_velocity():
    global velocity

    velocity = velocity + 100
    if velocity > 2000:
        velocity = 2000

    set_velocity()


# Dec velocity
def drive_dec_velocity():
    global velocity

    velocity = velocity - 100
    if velocity < 0:
        velocity = 0

    set_velocity()


def change_brake_present():
    value, error = manufacturer_client.getExternalBrakePresence()
    if error == 1:
        error = manufacturer_client.setExternalBrakePresence(not value)
    else:
        print("getExternalBrakePresence failed\n")

    if error != 1:
        print("storeParameters failed\n")
    else:
        if error == 1 and click.confirm("Do you want to save this parameters ? (This parameter has to be correlated with the STO active_sbc parameter)"):
            communication_client.storeParameters(BlocId.ALL)
            time.sleep(0.5)
            error = nmt_client.setNMTState(NMTCommand.RESET_NODE)
        else:
            print("Parameters not saved\n")


def change_sto_activate_sbc():
    value, _, error = safe_motion_client.getSTOParameters(STOId.STO_1)
    if error == 1:
        print("current config for STO active SBC is " + str(value.activate_sbc))
        promt = click.prompt(
            "Enter the number of the SBC you want set to STO activate SBC (0, 1, 2 or 3)",
            type=click.IntRange(0, 3),
            default=1,
        )
        SBCAddress = 0x66600000
        value.activate_sbc = SBCAddress + promt * 0x0100 if promt != 0 else 0x0
        error = safe_motion_client.setSTOParameters(STOId.STO_1, value)
    else:
        print("getSTOParameters(STO_1) failed\n")

    if error != 1:
        print("setSTOParameters(STO_1) failed\n")
    else:
        if error == 1 and click.confirm("Do you want to save this parameters ? (This parameter has to be correlated with the brake present)"):
            communication_client.storeParameters(BlocId.ALL)
            time.sleep(0.5)
            error = nmt_client.setNMTState(NMTCommand.RESET_NODE)
        else:
            print("Parameters not saved\n")


# Connect NodeId
def connect_node_id():
    print("Enter NodeId to connect on ?")
    nodeId = click.prompt("NodeId", type=click.IntRange(min=1, max=127), default=16)
    core_client.connect(nodeId)


# Set NodeId
def set_node_id():
    print("Enter new NodeId")
    nodeId = click.prompt("NodeId", type=click.IntRange(min=1, max=127), default=16)
    error = nmt_client.setNMTState(NMTCommand.PREOP)
    if error == 1:
        time.sleep(0.05)
        network_parameters, error = communication_client.getNetworkParameters()
    else:
        print("setNMTState(PREOP) failed\n")

    if error == 1:
        network_parameters.node_id = nodeId
        error = communication_client.setNetworkParameters(network_parameters)
        time.sleep(0.05)
    else:
        print("getNetworkParameters() failed\n")

    if error == 1:
        communication_client.storeParameters(BlocId.ALL)
        time.sleep(0.5)
        error = nmt_client.setNMTState(NMTCommand.RESET_NODE)
    else:
        print("setNetworkParameters failed\n")

    if error != 1:
        print("setNMTState(RESET_NODE) failed\n")


# Disconnect
def disconnect():
    core_client.disconnect()


# Switch to local mode
def local_mode():
    core_client.switchMode(ModeEnum.LOCAL)


# Switch to remote mode
def remote_mode():
    core_client.switchMode(ModeEnum.REMOTE)


# Restore parameters
def restore_parameters():
    communication_client.restoreDefaultParameters(BlocId.ALL)  # BlocId.APPLICATION
    nmt_client.setNMTState(NMTCommand.RESET_NODE)


# Reset drive
def drive_reset():
    nmt_client.setNMTState(NMTCommand.RESET_NODE)


# Menu Diagnostic
def menu_diagnostic():
    print_result("DBUS Instance", (instance_id, 1))
    print_result("Core Version", core_client.getCoreVersion())
    core_connection_status = core_client.getConnectionStatus()
    print_result("Core connected", [core_connection_status[0], core_connection_status[2]])
    print_result("Core PDO initialized", [core_connection_status[1], core_connection_status[2]])
    print_result("Core CAN device", core_client.getCanDevice())
    val = communication_client.getNetworkParameters()
    node_id = attr.asdict(val[0])["node_id"] if val[1] == 1 else 0x0
    rt_activated = attr.asdict(val[0])["rt_activated"] if val[1] == 1 else False
    print_result("Node ID", [hex(node_id), val[1]])
    print_result("RT activated", [rt_activated, val[1]])
    val = communication_client.getIdentityParameters()
    print_result("Vendor-Id", [hex(attr.asdict(val[0])["vendor_id"]), val[1]])
    print_result("Product code", [hex(attr.asdict(val[0])["product_code"]), val[1]])
    rev_major = (attr.asdict(val[0])["revision_number"] >> 16) & 0xFFFF
    rev_minor = (attr.asdict(val[0])["revision_number"] & 0xFFFF)
    print_result("Revision number", (f"{rev_major}.{rev_minor}", val[1]))
    print_result(
        "Serial number",
        [translateSerialNumber(attr.asdict(val[0])["serial_number"]), val[1]],
    )
    print_result("Product Ref", manufacturer_client.getProductRef())
    print_result("SW Ref", manufacturer_client.getSWRef())
    print_result("SW Version", manufacturer_client.getSWVersion())
    hw_id = manufacturer_client.getHWId()
    hw_version = manufacturer_client.getHWVersion()  # 1 = A
    if hw_version[0] > 255:  # Old firmware detected (<= 1.2.0)
        hw_version = [32 - 64, 1]  # In order to obtain a space character
    print_result(
        "HW Id",
        [
            f"{hw_id[0]}{chr(64 + hw_version[0])}",
            1 if hw_id[1] == 1 and hw_version[1] == 1 else 0,
        ],
    )
    print_result("Calibrated", manufacturer_client.getCalibrationValidity())
    print_result("SRDO validity", srdo_client.getSRDOConfigurationValidity())
    print_result("NMT state on error", can_open_client.getValueUInt8(0x1029_02_00))  # error_behavior_syserr_for_error => 1 (no change of the NMT state)
    state, error = nmt_client.getNMTState()
    print_result("NMT State", nmt_client.getNMTState())
    print_result("PDS State", pds_client.getPDSState())
    count, error_error_count = emcy_client.getErrorCount()
    print_result("NbError", [count, error_error_count])
    lastError, error = emcy_client.getError(1)
    try:
        lastErrorName = EMCY_ERROR_CODE(lastError).name
    except:
        lastErrorName = "Unknown Error"
    print_result("LastError", [f"{lastError:X} : {lastErrorName}", error if count != 0 and error_error_count == 1 else error_error_count])
    print_result("SystemError", manufacturer_client.getSystemErrorProtectState())
    print_result("SSW CAN1", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_1))
    print_result("SSW CAN2", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_2))
    print_result("SSW CAN3", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_3))
    print_result("SSW CAN4", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_4))
    print_result("SSW CAN5", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_5))
    print_result("SSW CAN6", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_6))
    print_result("SSW CAN7", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_7))
    print_result("SSW CAN8", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_8))
    print_result("SSW SAFEOUT", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.SAFEOUT))
    print_result("SCW SAFEIN_1", safe_motion_client.getSafetyControlWord(SafetyControlWordId.SAFEIN_1))
    print_result("SCW PERMANENT CAN1", safe_motion_client.getSafetyControlWordMapping(SafetyControlWordId.PERMANENT_CAN_1))
    print_result("SCW PERMANENT CAN2", safe_motion_client.getSafetyControlWordMapping(SafetyControlWordId.PERMANENT_CAN_2))
    print_result("SafetyFunctionOutput", safe_motion_client.getSafetyFunctionOutputs())
    print_result("SystemErrorOutput", internal_client.getSystemErrorOutputs())
    val = velocity_mode_client.getVelocityModeStatusword()
    val_str = str(attr.asdict(val[0])).replace("{", "").replace("}", "").replace("'", "")
    print_result("VelocityModeSW", [val_str, val[1]])

    val = velocity_mode_client.getVelocityModeControlword()
    val_str = str(attr.asdict(val[0])).replace("{", "").replace("}", "").replace("'", "")
    print_result("VelocityModeCW", [val_str, val[1]])

    val = pds_client.getPolarityParameters()
    val_str = str(attr.asdict(val[0])).replace("{", "").replace("}", "").replace("'", "")
    print_result("Polarity", [val_str, val[1]])
    print_result("ExternalBrakePresent", manufacturer_client.getExternalBrakePresence())
    value, _, error = safe_motion_client.getSTOParameters(STOId.STO_1)
    value.activate_sbc = hex(value.activate_sbc)
    val_str = str(attr.asdict(value)).replace("{", "").replace("}", "").replace("'", "")
    print_result("STO", [val_str, error])
    print_result("TargetVelocity", velocity_mode_client.getTargetVelocity())
    print_result("VelocityDemand", velocity_mode_client.getVelocityDemand())
    print_result("VelocityActualValue", velocity_mode_client.getVelocityActualValue())
    print_result("PositionValue", velocity_mode_client.getPositionValue())
    print_result("OdometryValue", manufacturer_client.getOdometryValue())

    menu_actions["root_menu"]()

    return


# Menu SW
def menu_SW():
    # print_result("SCW CAN1 mapping", safe_motion_client.getSafetyControlWordMapping(SafetyControlWordId.CAN_1))
    # print_result("SCW CAN2 mapping", safe_motion_client.getSafetyControlWordMapping(SafetyControlWordId.CAN_2))

    print_result("SCW CAN1", safe_motion_client.getSafetyControlWord(SafetyControlWordId.CAN_1))
    print_result("SCW CAN2", safe_motion_client.getSafetyControlWord(SafetyControlWordId.CAN_2))
    print_result("SCW CAN3", safe_motion_client.getSafetyControlWord(SafetyControlWordId.CAN_3))
    print_result("SCW CAN4", safe_motion_client.getSafetyControlWord(SafetyControlWordId.CAN_4))
    print_result("SCW CAN5", safe_motion_client.getSafetyControlWord(SafetyControlWordId.CAN_5))
    print_result("SCW CAN6", safe_motion_client.getSafetyControlWord(SafetyControlWordId.CAN_6))
    print_result("SCW CAN7", safe_motion_client.getSafetyControlWord(SafetyControlWordId.CAN_7))
    print_result("SCW CAN8", safe_motion_client.getSafetyControlWord(SafetyControlWordId.CAN_8))
    print_result(
        "SCW SAFEIN_1",
        safe_motion_client.getSafetyControlWord(SafetyControlWordId.SAFEIN_1),
    )

    print_result("SSW CAN1", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_1))
    print_result("SSW CAN2", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_2))
    print_result("SSW CAN3", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_3))
    print_result("SSW CAN4", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_4))
    print_result("SSW CAN5", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_5))
    print_result("SSW CAN6", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_6))
    print_result("SSW CAN7", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_7))
    print_result("SSW CAN8", safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.CAN_8))
    print_result(
        "SSW SAFEOUT",
        safe_motion_client.getSafetyStatusWord(SafetyStatusWordId.SAFEOUT),
    )

    menu_actions["root_menu"]()

    return


# Back to root menu
def back():
    menu_actions["root_menu"]()


# Exit program
def exit():
    sys.exit()


# =======================
#    MENUS DEFINITIONS
# =======================

# Menu definition
menu_actions = {
    "root_menu": root_menu,
    "f": sto_ack_off,
    "n": sto_ack_on,
    "o": drive_oper,
    "m": nmt_start_all,
    "e": list_EMCY,
    "c": clear_EMCY,
    "8": drive_positive,
    "2": drive_negative,
    "*": drive_stop,
    "+": drive_inc_velocity,
    "-": drive_dec_velocity,
    "r": drive_reset,
    "a": menu_diagnostic,
    "b": change_brake_present,
    "t": change_sto_activate_sbc,
    "i": connect_node_id,
    "g": set_node_id,
    "d": disconnect,
    "j": restore_parameters,
    "s": menu_SW,
    "w": local_mode,
    "z": remote_mode,
    "9": back,
    "0": exit,
}

# =======================
#      MAIN PROGRAM
# =======================


def main(argv):
    global instance_id
    global nmt_client
    global pds_client
    global safe_motion_client
    global manufacturer_client
    global velocity_mode_client
    global srdo_client
    global communication_client
    global emcy_client
    global internal_client
    global core_client
    global can_open_client

    parser = argparse.ArgumentParser("Remote")
    parser.add_argument("instance", help="Name of the smc dbus instance (ie: smc_drive).", type=str)
    args = parser.parse_args()

    instance_id = args.instance

    # Load specific dbus user session if exists
    session = ""
    if os.path.isfile("/tmp/SYSTEMCTL_dbus.id"):
        session = "/tmp/SYSTEMCTL_dbus.id"
    elif os.path.isfile("/opt/ezw/data/tmp/SYSTEMCTL_dbus.id"):
        session = "/opt/ezw/data/tmp/SYSTEMCTL_dbus.id"

    if session != "":
        print("SYSTEMCTL_dbus.id detected")

        with open(session) as f:
            lines = f.readlines()
        env = dict(line.strip().split("=", 1) for line in lines)
        os.environ.update(env)

    nmt_client = NMTDBusClient(instance_id)
    pds_client = PDSDBusClient(instance_id)
    safe_motion_client = SafeMotionDBusClient(instance_id)
    manufacturer_client = ManufacturerDBusClient(instance_id)
    velocity_mode_client = VelocityModeDBusClient(instance_id)
    srdo_client = SRDODBusClient(instance_id)
    communication_client = CommunicationDBusClient(instance_id)
    emcy_client = EMCYDBusClient(instance_id)
    internal_client = InternalDBusClient(instance_id)
    core_client = CoreDBusClient(instance_id)
    can_open_client = CANOpenDBusClient(instance_id)

    # Launch menu_diagnostic
    menu_diagnostic()


if __name__ == "__main__":
    main(sys.argv[1:])
