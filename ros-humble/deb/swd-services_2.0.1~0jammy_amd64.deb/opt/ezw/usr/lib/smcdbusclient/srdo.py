# Code Generated with fidl-code-gen
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "."))

from ezw_smc_service_types import *

import dbus
from enum import IntEnum
import attr, time

# Types
class SRDOId(IntEnum):
    SRDO_1 = 1
    SRDO_2 = 2
    SRDO_9 = 9
    SRDO_10 = 10
    SRDO_11 = 11
    SRDO_12 = 12
    SRDO_13 = 13
    SRDO_14 = 14
    SRDO_15 = 15
    SRDO_16 = 16

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SRDOId(int(dbus_obj))


class SRDODirection(IntEnum):
    SRDO_TX = 1
    SRDO_RX = 2

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SRDODirection(int(dbus_obj))


class SRDOTransmissionType(IntEnum):
    PDO_ASYNC_FE = 254

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SRDOTransmissionType(int(dbus_obj))


@attr.s
class SRDOParameters:
    valid = attr.ib(default=False)
    sct = attr.ib(default=0)
    srvt = attr.ib(default=0)
    transmission_type = attr.ib(default=SRDOTransmissionType.PDO_ASYNC_FE)
    can_id1 = attr.ib(default=0)
    can_id2 = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.Boolean(py_obj.valid),
                dbus.UInt16(py_obj.sct),
                dbus.Byte(py_obj.srvt),
                SRDOTransmissionType.toDBus(py_obj.transmission_type),
                dbus.UInt16(py_obj.can_id1),
                dbus.UInt16(py_obj.can_id2),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SRDOParameters()
        ret.valid = bool(dbus_obj[0])
        ret.sct = int(dbus_obj[1])
        ret.srvt = int(dbus_obj[2])
        ret.transmission_type = SRDOTransmissionType.fromDBus(dbus_obj[3])
        ret.can_id1 = int(dbus_obj[4])
        ret.can_id2 = int(dbus_obj[5])
        return ret


@attr.s
class SRDOMapping:
    mapping_count = attr.ib(default=0)
    data = attr.ib(default=[])

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.Byte(py_obj.mapping_count),
                dbus.Array([dbus.UInt32(x) for x in py_obj.data]),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SRDOMapping()
        ret.mapping_count = int(dbus_obj[0])
        ret.data = [int(x) for x in dbus_obj[1]]
        return ret


# Interface
class SRDODBusClient:
    def __init__(self, instance_id=""):
        self.bus = dbus.SessionBus()

        self.dbus_object = self.bus.get_object(
            "commonapi.SmcService.SRDO.v1_0_commonapi.ezw.smcservice" + ("" if instance_id == "" else ".") + instance_id,
            "/commonapi/ezw/smcservice" + ("" if instance_id == "" else "/") + instance_id,
        )
        self.dbus_iface = dbus.Interface(self.dbus_object, "commonapi.SmcService.SRDO.v1_0")

    def getSRDOParameters(self, id):
        try:
            r = self.dbus_iface.getSRDOParameters(SRDOId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SRDODirection.fromDBus(r[0]), SRDOParameters.fromDBus(r[1]), int(r[2]), int(r[3]))
        return a

    def setSRDOParameters(self, id, parameters):
        try:
            r = self.dbus_iface.setSRDOParameters(SRDOId.toDBus(id), SRDOParameters.toDBus(parameters))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getSRDOMapping(self, id):
        try:
            r = self.dbus_iface.getSRDOMapping(SRDOId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SRDOMapping.fromDBus(r[0]), int(r[1]))
        return a

    def getSRDOConfigurationValidity(self):
        try:
            r = self.dbus_iface.getSRDOConfigurationValidity()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (bool(r[0]), int(r[1]))
        return a

    def setSRDOConfigurationValidity(self):
        try:
            r = self.dbus_iface.setSRDOConfigurationValidity()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a
