# Code Generated with fidl-code-gen
import dbus
from enum import IntEnum
import attr

# Types
class ErrorEnum(IntEnum):
    ERROR_NOT_INITIALIZED = 0
    ERROR_NONE = 1
    ERROR_HARDWARE = 2
    ERROR_CONFIG = 3
    ERROR_ARGUMENT = 4
    ERROR_INTERNAL = 5
    ERROR_EXTERNAL = 6

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return ErrorEnum(int(dbus_obj))
