# Code Generated with fidl-code-gen
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "."))

from ezw_smc_service_types import *

import dbus
from enum import IntEnum
import attr, time

# Types
class _BlocId(IntEnum):
    FACTORY = 5
    TEST_RESULTS = 6

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return _BlocId(int(dbus_obj))


@attr.s
class _DeviceParameters:
    manufacturer_device_name = attr.ib(default="")
    hardware_version_description = attr.ib(default="")
    manufacturer_software_version = attr.ib(default="")

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.String(py_obj.manufacturer_device_name),
                dbus.String(py_obj.hardware_version_description),
                dbus.String(py_obj.manufacturer_software_version),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = _DeviceParameters()
        ret.manufacturer_device_name = str(dbus_obj[0])
        ret.hardware_version_description = str(dbus_obj[1])
        ret.manufacturer_software_version = str(dbus_obj[2])
        return ret


@attr.s
class _SelfTestStatus:
    auto_init_status = attr.ib(default=0)
    motor_driver_status = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.Byte(py_obj.auto_init_status),
                dbus.Byte(py_obj.motor_driver_status),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = _SelfTestStatus()
        ret.auto_init_status = int(dbus_obj[0])
        ret.motor_driver_status = int(dbus_obj[1])
        return ret


@attr.s
class _CalibrationParameters:
    is_valid = attr.ib(default=False)
    cos_adc_offset_mv = attr.ib(default=0)
    cos_gain = attr.ib(default=0.0)
    cos_angle_offset_mdeg = attr.ib(default=0)
    sin_adc_offset_mv = attr.ib(default=0)
    sin_gain = attr.ib(default=0.0)
    sin_angle_offset_mdeg = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.Boolean(py_obj.is_valid),
                dbus.Int32(py_obj.cos_adc_offset_mv),
                dbus.Double(py_obj.cos_gain),
                dbus.Int32(py_obj.cos_angle_offset_mdeg),
                dbus.Int32(py_obj.sin_adc_offset_mv),
                dbus.Double(py_obj.sin_gain),
                dbus.Int32(py_obj.sin_angle_offset_mdeg),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = _CalibrationParameters()
        ret.is_valid = bool(dbus_obj[0])
        ret.cos_adc_offset_mv = int(dbus_obj[1])
        ret.cos_gain = float(dbus_obj[2])
        ret.cos_angle_offset_mdeg = int(dbus_obj[3])
        ret.sin_adc_offset_mv = int(dbus_obj[4])
        ret.sin_gain = float(dbus_obj[5])
        ret.sin_angle_offset_mdeg = int(dbus_obj[6])
        return ret


@attr.s
class _SystemErrorConfig:
    time_ms_zero_torque_protect = attr.ib(default=0)
    time_ms_brake_cc_protect = attr.ib(default=0)
    battery_uv_warning = attr.ib(default=0)
    battery_uv_error = attr.ib(default=0)
    battery_ov_warning = attr.ib(default=0)
    battery_ov_error = attr.ib(default=0)
    phase_oc_warning = attr.ib(default=0)
    phase_oc_error = attr.ib(default=0)
    battery_uv_warning_timeout_ms = attr.ib(default=0)
    battery_ov_warning_timeout_ms = attr.ib(default=0)
    phase_oc_warning_timeout_ms = attr.ib(default=0)
    phase_over_board_factor = attr.ib(default=0.0)
    mos1_temp_threshold_rise = attr.ib(default=0)
    mos1_temp_threshold_fall = attr.ib(default=0)
    mos2_temp_threshold_rise = attr.ib(default=0)
    mos2_temp_threshold_fall = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.UInt32(py_obj.time_ms_zero_torque_protect),
                dbus.UInt32(py_obj.time_ms_brake_cc_protect),
                dbus.Int32(py_obj.battery_uv_warning),
                dbus.Int32(py_obj.battery_uv_error),
                dbus.Int32(py_obj.battery_ov_warning),
                dbus.Int32(py_obj.battery_ov_error),
                dbus.Int32(py_obj.phase_oc_warning),
                dbus.Int32(py_obj.phase_oc_error),
                dbus.UInt32(py_obj.battery_uv_warning_timeout_ms),
                dbus.UInt32(py_obj.battery_ov_warning_timeout_ms),
                dbus.UInt32(py_obj.phase_oc_warning_timeout_ms),
                dbus.Double(py_obj.phase_over_board_factor),
                dbus.Int32(py_obj.mos1_temp_threshold_rise),
                dbus.Int32(py_obj.mos1_temp_threshold_fall),
                dbus.Int32(py_obj.mos2_temp_threshold_rise),
                dbus.Int32(py_obj.mos2_temp_threshold_fall),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = _SystemErrorConfig()
        ret.time_ms_zero_torque_protect = int(dbus_obj[0])
        ret.time_ms_brake_cc_protect = int(dbus_obj[1])
        ret.battery_uv_warning = int(dbus_obj[2])
        ret.battery_uv_error = int(dbus_obj[3])
        ret.battery_ov_warning = int(dbus_obj[4])
        ret.battery_ov_error = int(dbus_obj[5])
        ret.phase_oc_warning = int(dbus_obj[6])
        ret.phase_oc_error = int(dbus_obj[7])
        ret.battery_uv_warning_timeout_ms = int(dbus_obj[8])
        ret.battery_ov_warning_timeout_ms = int(dbus_obj[9])
        ret.phase_oc_warning_timeout_ms = int(dbus_obj[10])
        ret.phase_over_board_factor = float(dbus_obj[11])
        ret.mos1_temp_threshold_rise = int(dbus_obj[12])
        ret.mos1_temp_threshold_fall = int(dbus_obj[13])
        ret.mos2_temp_threshold_rise = int(dbus_obj[14])
        ret.mos2_temp_threshold_fall = int(dbus_obj[15])
        return ret


class SystemErrorId(IntEnum):
    ERROR_COM_GEN = 0
    ERROR_TEMP_GEN = 1
    ERROR_DC_OVER_CURRENT_1 = 2
    ERROR_DC_OVER_CURRENT_2 = 3
    ERROR_BMS_OVER_CURRENT = 4
    ERROR_OVER_VOLTAGE_1 = 5
    ERROR_OVER_VOLTAGE_2 = 6
    ERROR_UNDER_VOLTAGE_1 = 7
    ERROR_UNDER_VOLTAGE_2 = 8
    ERROR_BMS_UNDER_VOLTAGE = 9
    ERROR_BMS_OVER_VOLTAGE = 10
    ERROR_BMS_UNDER_VOLTAGE_CHA = 11
    ERROR_EXCESS_TEMPERATURE_DEVICE = 12
    ERROR_OVER_TEMPERATURE_BMS = 13
    ERROR_UNDER_TEMPERATURE_BMS = 14
    ERROR_EXCESS_TEMPERATURE_DRIVE = 15
    ERROR_BMS_PACK_TEMP_SENSOR = 16
    ERROR_CANOPEN_PARAMETER_ERROR = 17
    ERROR_BMS_INTERNAL_ERROR = 18
    ERROR_MOTOR_BLOCKED = 19
    ERROR_POWER_ADDITIONAL_MODULE = 20
    ERROR_OSSD_STO_1 = 21
    ERROR_OSSD_STO_2 = 22
    ERROR_SAFE_IN_1 = 23
    ERROR_SAFE_IN_2 = 24
    ERROR_SAFE_OUT_1 = 25
    ERROR_SAFE_OUT_2 = 26
    ERROR_HALL_INCONSISTENCY = 27
    ERROR_SAFE_DRVOFF_COHERENCY = 28
    ERROR_SAFE_STO_COHERENCY = 29
    ERROR_SAFE_NBRAKE = 30
    ERROR_SAFE_NBRAKE_INT = 31
    ERROR_SAFE_NBRAKE_CTRL = 32
    ERROR_SAFE_NCCSTATE = 33
    ERROR_SAFE_MCU_NBRAKE = 34
    ERROR_SAFE_BLC = 35
    ERROR_FAULT_EXT_BRAKE_CMD = 36
    ERROR_ENDRV = 37
    ERROR_FAULT_ALIM_EXT = 38
    ERROR_FAULT_EMERGENCY = 39
    ERROR_FAULT_EXT_BRAKE_PRESENCE = 40
    ERROR_FAULT_BRAKE_OC = 41
    ERROR_FAULT_SBU_ACTIVATED = 42
    ERROR_FAULT_SBU_ACTIVATION_ERROR = 43
    ERROR_DRIVER_GENERIC = 44
    ERROR_CAN_ERROR_PASSIVE = 45
    ERROR_CAN_RECOVERED_FROM_BUS_OFF = 46
    ERROR_PROTOCOL_ERROR_SRDO_SCT_TIMEOUT = 47
    ERROR_PROTOCOL_ERROR_SRDO_SRVT_TIMEOUT = 48
    ERROR_PROTOCOL_ERROR_SRDO_DATA_MISMATCH = 49
    ERROR_PROTOCOL_ERROR_SRDO_WRONG_MSG = 50
    ERROR_PROTOCOL_ERROR_SRDO_WRONG_LEN = 51
    ERROR_PROTOCOL_ERROR_EVENT_TIMER = 52
    ERROR_NUMOF = 53

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SystemErrorId(int(dbus_obj))


@attr.s
class SystemErrorOutput:
    system_error_id = attr.ib(default=SystemErrorId.ERROR_COM_GEN)
    status = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                SystemErrorId.toDBus(py_obj.system_error_id),
                dbus.Boolean(py_obj.status),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SystemErrorOutput()
        ret.system_error_id = SystemErrorId.fromDBus(dbus_obj[0])
        ret.status = bool(dbus_obj[1])
        return ret


# Interface
class InternalDBusClient:
    def __init__(self, instance_id=""):
        self.bus = dbus.SessionBus()

        self.dbus_object = self.bus.get_object(
            "commonapi.SmcService.Internal.v1_0_commonapi.ezw.smcservice" + ("" if instance_id == "" else ".") + instance_id,
            "/commonapi/ezw/smcservice" + ("" if instance_id == "" else "/") + instance_id,
        )
        self.dbus_iface = dbus.Interface(self.dbus_object, "commonapi.SmcService.Internal.v1_0")

    def _storeParameters(self, bloc_id):
        try:
            r = self.dbus_iface._storeParameters(_BlocId.toDBus(bloc_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def _restoreDefaultParameters(self, bloc_id):
        try:
            r = self.dbus_iface._restoreDefaultParameters(_BlocId.toDBus(bloc_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def _setDeviceParameters(self, params):
        try:
            r = self.dbus_iface._setDeviceParameters(_DeviceParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def _getSelfTestStatus(self):
        try:
            r = self.dbus_iface._getSelfTestStatus()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (_SelfTestStatus.fromDBus(r[0]), int(r[1]))
        return a

    def _simulateSelfTestError(self, self_test_status):
        try:
            r = self.dbus_iface._simulateSelfTestError(_SelfTestStatus.toDBus(self_test_status))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def _getCalibrationParameters(self):
        try:
            r = self.dbus_iface._getCalibrationParameters()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (_CalibrationParameters.fromDBus(r[0]), int(r[1]))
        return a

    def _getSystemErrorConfig(self):
        try:
            r = self.dbus_iface._getSystemErrorConfig()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (_SystemErrorConfig.fromDBus(r[0]), int(r[1]))
        return a

    def _setSystemErrorConfig(self, config):
        try:
            r = self.dbus_iface._setSystemErrorConfig(_SystemErrorConfig.toDBus(config))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def _getLevel1Error(self):
        try:
            r = self.dbus_iface._getLevel1Error()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getSystemErrorOutputs(self):
        try:
            r = self.dbus_iface.getSystemErrorOutputs()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (dbus.Array([SystemErrorOutput.fromDBus(x) for x in r[0]]), int(r[1]))
        return a
