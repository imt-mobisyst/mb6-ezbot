# Code Generated with fidl-code-gen
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "."))

from ezw_smc_service_types import *

import dbus
from enum import IntEnum
import attr, time

# Types
@attr.s
class VelocityModeParameters:
    vl_velocity_min_amount = attr.ib(default=0)
    vl_velocity_max_amount = attr.ib(default=0)
    vl_velocity_acceleration_delta_speed = attr.ib(default=0)
    vl_velocity_acceleration_delta_time = attr.ib(default=0)
    vl_velocity_deceleration_delta_speed = attr.ib(default=0)
    vl_velocity_deceleration_delta_time = attr.ib(default=0)
    vl_velocity_quick_stop_delta_speed = attr.ib(default=0)
    vl_velocity_quick_stop_delta_time = attr.ib(default=0)
    vl_set_point_factor_numerator = attr.ib(default=0)
    vl_set_point_factor_denominator = attr.ib(default=0)
    vl_dimension_factor_numerator = attr.ib(default=0)
    vl_dimension_factor_denominator = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.UInt32(py_obj.vl_velocity_min_amount),
                dbus.UInt32(py_obj.vl_velocity_max_amount),
                dbus.UInt32(py_obj.vl_velocity_acceleration_delta_speed),
                dbus.UInt16(py_obj.vl_velocity_acceleration_delta_time),
                dbus.UInt32(py_obj.vl_velocity_deceleration_delta_speed),
                dbus.UInt16(py_obj.vl_velocity_deceleration_delta_time),
                dbus.UInt32(py_obj.vl_velocity_quick_stop_delta_speed),
                dbus.UInt16(py_obj.vl_velocity_quick_stop_delta_time),
                dbus.Int16(py_obj.vl_set_point_factor_numerator),
                dbus.Int16(py_obj.vl_set_point_factor_denominator),
                dbus.Int32(py_obj.vl_dimension_factor_numerator),
                dbus.Int32(py_obj.vl_dimension_factor_denominator),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = VelocityModeParameters()
        ret.vl_velocity_min_amount = int(dbus_obj[0])
        ret.vl_velocity_max_amount = int(dbus_obj[1])
        ret.vl_velocity_acceleration_delta_speed = int(dbus_obj[2])
        ret.vl_velocity_acceleration_delta_time = int(dbus_obj[3])
        ret.vl_velocity_deceleration_delta_speed = int(dbus_obj[4])
        ret.vl_velocity_deceleration_delta_time = int(dbus_obj[5])
        ret.vl_velocity_quick_stop_delta_speed = int(dbus_obj[6])
        ret.vl_velocity_quick_stop_delta_time = int(dbus_obj[7])
        ret.vl_set_point_factor_numerator = int(dbus_obj[8])
        ret.vl_set_point_factor_denominator = int(dbus_obj[9])
        ret.vl_dimension_factor_numerator = int(dbus_obj[10])
        ret.vl_dimension_factor_denominator = int(dbus_obj[11])
        return ret


@attr.s
class VelocityModeStatusword:
    internal_limit_active = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct((dbus.Boolean(py_obj.internal_limit_active),))

    @staticmethod
    def fromDBus(dbus_obj):
        ret = VelocityModeStatusword()
        ret.internal_limit_active = bool(dbus_obj[0])
        return ret


@attr.s
class VelocityModeControlword:
    enable_ramp = attr.ib(default=False)
    unlock_ramp = attr.ib(default=False)
    reference_ramp = attr.ib(default=False)
    halt = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.Boolean(py_obj.enable_ramp),
                dbus.Boolean(py_obj.unlock_ramp),
                dbus.Boolean(py_obj.reference_ramp),
                dbus.Boolean(py_obj.halt),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = VelocityModeControlword()
        ret.enable_ramp = bool(dbus_obj[0])
        ret.unlock_ramp = bool(dbus_obj[1])
        ret.reference_ramp = bool(dbus_obj[2])
        ret.halt = bool(dbus_obj[3])
        return ret


# Interface
class VelocityModeDBusClient:
    def __init__(self, instance_id=""):
        self.bus = dbus.SessionBus()

        self.dbus_object = self.bus.get_object(
            "commonapi.SmcService.VelocityMode.v1_0_commonapi.ezw.smcservice" + ("" if instance_id == "" else ".") + instance_id,
            "/commonapi/ezw/smcservice" + ("" if instance_id == "" else "/") + instance_id,
        )
        self.dbus_iface = dbus.Interface(self.dbus_object, "commonapi.SmcService.VelocityMode.v1_0")

    def setTargetVelocity(self, target_velocity):
        try:
            r = self.dbus_iface.setTargetVelocity(dbus.Int16(target_velocity))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getTargetVelocity(self):
        try:
            r = self.dbus_iface.getTargetVelocity()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getVelocityActualValue(self):
        try:
            r = self.dbus_iface.getVelocityActualValue()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getVelocityActualValueTS(self):
        try:
            r = self.dbus_iface.getVelocityActualValueTS()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]), int(r[2]))
        return a

    def getVelocityDemand(self):
        try:
            r = self.dbus_iface.getVelocityDemand()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getPositionValue(self):
        try:
            r = self.dbus_iface.getPositionValue()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getPositionValueTS(self):
        try:
            r = self.dbus_iface.getPositionValueTS()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]), int(r[2]))
        return a

    def getVelocityModeParameters(self):
        try:
            r = self.dbus_iface.getVelocityModeParameters()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (VelocityModeParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setVelocityModeParameters(self, params):
        try:
            r = self.dbus_iface.setVelocityModeParameters(VelocityModeParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getVelocityModeStatusword(self):
        try:
            r = self.dbus_iface.getVelocityModeStatusword()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (VelocityModeStatusword.fromDBus(r[0]), int(r[1]))
        return a

    def getVelocityModeControlword(self):
        try:
            r = self.dbus_iface.getVelocityModeControlword()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (VelocityModeControlword.fromDBus(r[0]), int(r[1]))
        return a

    def setEnableRamp(self, enable_ramp):
        try:
            r = self.dbus_iface.setEnableRamp(dbus.Boolean(enable_ramp))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def setUnlockRamp(self, unlock_ramp):
        try:
            r = self.dbus_iface.setUnlockRamp(dbus.Boolean(unlock_ramp))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def setReferenceRamp(self, reference_ramp):
        try:
            r = self.dbus_iface.setReferenceRamp(dbus.Boolean(reference_ramp))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def setHalt(self, halt):
        try:
            r = self.dbus_iface.setHalt(dbus.Boolean(halt))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a
