# Code Generated with fidl-code-gen
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "."))

from ezw_smc_service_types import *

import dbus
from enum import IntEnum
import attr, time

# Types
class PDSState(IntEnum):
    NOT_READY_TO_SWITCH_ON = 0
    SWITCH_ON_DISABLED = 1
    READY_TO_SWITCH_ON = 2
    SWITCHED_ON = 3
    OPERATION_ENABLED = 4
    QUICK_STOP_ACTIVE = 5
    FAULT_REACTION_ACTIVE = 6
    FAULT = 7

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return PDSState(int(dbus_obj))


@attr.s
class PeripheralStatus:
    brake_applied = attr.ib(default=False)
    low_level_power_applied = attr.ib(default=False)
    high_level_power_applied = attr.ib(default=False)
    driver_enabled = attr.ib(default=False)
    configuration_allowed = attr.ib(default=False)
    communication_enabled = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.Boolean(py_obj.brake_applied),
                dbus.Boolean(py_obj.low_level_power_applied),
                dbus.Boolean(py_obj.high_level_power_applied),
                dbus.Boolean(py_obj.driver_enabled),
                dbus.Boolean(py_obj.configuration_allowed),
                dbus.Boolean(py_obj.communication_enabled),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = PeripheralStatus()
        ret.brake_applied = bool(dbus_obj[0])
        ret.low_level_power_applied = bool(dbus_obj[1])
        ret.high_level_power_applied = bool(dbus_obj[2])
        ret.driver_enabled = bool(dbus_obj[3])
        ret.configuration_allowed = bool(dbus_obj[4])
        ret.communication_enabled = bool(dbus_obj[5])
        return ret


class AbortConnectionOptionCode(IntEnum):
    AC_OPTION_0 = 0
    AC_OPTION_1 = 1
    AC_OPTION_2 = 2
    AC_OPTION_3 = 3

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return AbortConnectionOptionCode(int(dbus_obj))


class QuickStopOptionCode(IntEnum):
    QS_OPTION_1 = 1
    QS_OPTION_2 = 2
    QS_OPTION_5 = 5
    QS_OPTION_6 = 6

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return QuickStopOptionCode(int(dbus_obj))


class ShutdownOptionCode(IntEnum):
    SD_OPTION_0 = 0
    SD_OPTION_1 = 1

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return ShutdownOptionCode(int(dbus_obj))


class DisableOperationOptionCode(IntEnum):
    DO_OPTION_0 = 0
    DO_OPTION_1 = 1

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return DisableOperationOptionCode(int(dbus_obj))


class HaltOptionCode(IntEnum):
    HA_OPTION_1 = 1
    HA_OPTION_2 = 2

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return HaltOptionCode(int(dbus_obj))


class FaultReactionOptionCode(IntEnum):
    FR_OPTION_0 = 0
    FR_OPTION_1 = 1
    FR_OPTION_2 = 2

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return FaultReactionOptionCode(int(dbus_obj))


class OperationMode(IntEnum):
    NO_MODE = 0
    PP_MODE = 1
    VL_MODE = 2
    PV_MODE = 3
    TQ_MODE = 4
    R_MODE = 5
    HM_MODE = 6
    IP_MODE = 7
    CSP_MODE = 8
    CSV_MODE = 9
    CST_MODE = 10
    CSTCA_MODE = 11

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return OperationMode(int(dbus_obj))


@attr.s
class UnitParameters:
    time_unit = attr.ib(default=0)
    position_unit = attr.ib(default=0)
    velocity_unit = attr.ib(default=0)
    acceleration_unit = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.UInt32(py_obj.time_unit),
                dbus.UInt32(py_obj.position_unit),
                dbus.UInt32(py_obj.velocity_unit),
                dbus.UInt32(py_obj.acceleration_unit),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = UnitParameters()
        ret.time_unit = int(dbus_obj[0])
        ret.position_unit = int(dbus_obj[1])
        ret.velocity_unit = int(dbus_obj[2])
        ret.acceleration_unit = int(dbus_obj[3])
        return ret


@attr.s
class PolarityParameters:
    velocity_polarity = attr.ib(default=False)
    position_polarity = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.Boolean(py_obj.velocity_polarity),
                dbus.Boolean(py_obj.position_polarity),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = PolarityParameters()
        ret.velocity_polarity = bool(dbus_obj[0])
        ret.position_polarity = bool(dbus_obj[1])
        return ret


# Interface
class PDSDBusClient:
    def __init__(self, instance_id=""):
        self.bus = dbus.SessionBus()

        self.dbus_object = self.bus.get_object(
            "commonapi.SmcService.PDS.v1_0_commonapi.ezw.smcservice" + ("" if instance_id == "" else ".") + instance_id,
            "/commonapi/ezw/smcservice" + ("" if instance_id == "" else "/") + instance_id,
        )
        self.dbus_iface = dbus.Interface(self.dbus_object, "commonapi.SmcService.PDS.v1_0")

    def getPeripheralStatus(self):
        try:
            r = self.dbus_iface.getPeripheralStatus()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (PeripheralStatus.fromDBus(r[0]), int(r[1]))
        return a

    def getPDSState(self):
        try:
            r = self.dbus_iface.getPDSState()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (PDSState.fromDBus(r[0]), int(r[1]))
        return a

    def disableVoltage(self):
        try:
            r = self.dbus_iface.disableVoltage()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def shutdown(self):
        try:
            r = self.dbus_iface.shutdown()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def quickStop(self):
        try:
            r = self.dbus_iface.quickStop()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def switchOn(self):
        try:
            r = self.dbus_iface.switchOn()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def enableOperation(self):
        try:
            r = self.dbus_iface.enableOperation()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def disableOperation(self):
        try:
            r = self.dbus_iface.disableOperation()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def faultReset(self, status):
        try:
            r = self.dbus_iface.faultReset(dbus.Boolean(status))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def enterInOperationEnabledState(self):
        try:
            r = self.dbus_iface.enterInOperationEnabledState()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getAbortConnectionOptionCode(self):
        try:
            r = self.dbus_iface.getAbortConnectionOptionCode()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (AbortConnectionOptionCode.fromDBus(r[0]), int(r[1]))
        return a

    def setAbortConnectionOptionCode(self, code):
        try:
            r = self.dbus_iface.setAbortConnectionOptionCode(AbortConnectionOptionCode.toDBus(code))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getQuickStopOptionCode(self):
        try:
            r = self.dbus_iface.getQuickStopOptionCode()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (QuickStopOptionCode.fromDBus(r[0]), int(r[1]))
        return a

    def setQuickStopOptionCode(self, code):
        try:
            r = self.dbus_iface.setQuickStopOptionCode(QuickStopOptionCode.toDBus(code))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getShutdownOptionCode(self):
        try:
            r = self.dbus_iface.getShutdownOptionCode()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (ShutdownOptionCode.fromDBus(r[0]), int(r[1]))
        return a

    def setShutdownOptionCode(self, code):
        try:
            r = self.dbus_iface.setShutdownOptionCode(ShutdownOptionCode.toDBus(code))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getDisableOperationOptionCode(self):
        try:
            r = self.dbus_iface.getDisableOperationOptionCode()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (DisableOperationOptionCode.fromDBus(r[0]), int(r[1]))
        return a

    def setDisableOperationOptionCode(self, code):
        try:
            r = self.dbus_iface.setDisableOperationOptionCode(DisableOperationOptionCode.toDBus(code))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getHaltOptionCode(self):
        try:
            r = self.dbus_iface.getHaltOptionCode()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (HaltOptionCode.fromDBus(r[0]), int(r[1]))
        return a

    def setHaltOptionCode(self, code):
        try:
            r = self.dbus_iface.setHaltOptionCode(HaltOptionCode.toDBus(code))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getFaultReactionOptionCode(self):
        try:
            r = self.dbus_iface.getFaultReactionOptionCode()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (FaultReactionOptionCode.fromDBus(r[0]), int(r[1]))
        return a

    def setFaultReactionOptionCode(self, code):
        try:
            r = self.dbus_iface.setFaultReactionOptionCode(FaultReactionOptionCode.toDBus(code))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getOperationModes(self):
        try:
            r = self.dbus_iface.getOperationModes()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (OperationMode.fromDBus(r[0]), OperationMode.fromDBus(r[1]), int(r[2]))
        return a

    def isDriveModeSupported(self, mode):
        try:
            r = self.dbus_iface.isDriveModeSupported(OperationMode.toDBus(mode))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (bool(r[0]), int(r[1]))
        return a

    def getUnitParameters(self):
        try:
            r = self.dbus_iface.getUnitParameters()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (UnitParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setUnitParameters(self, params):
        try:
            r = self.dbus_iface.setUnitParameters(UnitParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getPolarityParameters(self):
        try:
            r = self.dbus_iface.getPolarityParameters()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (PolarityParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setPolarityParameters(self, params):
        try:
            r = self.dbus_iface.setPolarityParameters(PolarityParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a
