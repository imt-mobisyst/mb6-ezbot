# Code Generated with fidl-code-gen
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "."))

from ezw_smc_service_types import *

import dbus
from enum import IntEnum
import attr, time

# Types
class SafetyControlWordId(IntEnum):
    CAN_1 = 0
    CAN_2 = 1
    CAN_3 = 2
    CAN_4 = 3
    CAN_5 = 4
    CAN_6 = 5
    CAN_7 = 6
    CAN_8 = 7
    SAFEIN_1 = 8
    PERMANENT_CAN_1 = 9
    PERMANENT_CAN_2 = 10

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SafetyControlWordId(int(dbus_obj))


class SafetyStatusWordId(IntEnum):
    CAN_1 = 0
    CAN_2 = 1
    CAN_3 = 2
    CAN_4 = 3
    CAN_5 = 4
    CAN_6 = 5
    CAN_7 = 6
    CAN_8 = 7
    SAFEOUT = 8
    PERMANENT_CAN_1 = 9
    PERMANENT_CAN_2 = 10

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SafetyStatusWordId(int(dbus_obj))


class SafetyFunctionId(IntEnum):
    STO = 0
    SBC_1 = 1
    SBC_2 = 2
    SBC_3 = 3
    SLS_1 = 4
    SLS_2 = 5
    SLS_3 = 6
    SLS_4 = 7
    SLS_5 = 8
    SLS_6 = 9
    SLS_7 = 10
    SLS_8 = 11
    SDIP_1 = 12
    SDIP_2 = 13
    SDIN_1 = 14
    SDIN_2 = 15
    ERROR_ACK = 16
    RST_ACK = 17
    SBU = 18
    SMS_1 = 19
    SLSa_1 = 20
    SLSa_2 = 21
    SLSa_3 = 22
    SLSa_4 = 23
    SLSa_5 = 24
    SLSa_6 = 25
    SLSa_7 = 26
    SLSa_8 = 27
    NONE = -1

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SafetyFunctionId(int(dbus_obj))


@attr.s
class SafetyWordMapping:
    safety_function_0 = attr.ib(default=SafetyFunctionId.NONE)
    safety_function_1 = attr.ib(default=SafetyFunctionId.NONE)
    safety_function_2 = attr.ib(default=SafetyFunctionId.NONE)
    safety_function_3 = attr.ib(default=SafetyFunctionId.NONE)
    safety_function_4 = attr.ib(default=SafetyFunctionId.NONE)
    safety_function_5 = attr.ib(default=SafetyFunctionId.NONE)
    safety_function_6 = attr.ib(default=SafetyFunctionId.NONE)
    safety_function_7 = attr.ib(default=SafetyFunctionId.NONE)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                SafetyFunctionId.toDBus(py_obj.safety_function_0),
                SafetyFunctionId.toDBus(py_obj.safety_function_1),
                SafetyFunctionId.toDBus(py_obj.safety_function_2),
                SafetyFunctionId.toDBus(py_obj.safety_function_3),
                SafetyFunctionId.toDBus(py_obj.safety_function_4),
                SafetyFunctionId.toDBus(py_obj.safety_function_5),
                SafetyFunctionId.toDBus(py_obj.safety_function_6),
                SafetyFunctionId.toDBus(py_obj.safety_function_7),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SafetyWordMapping()
        ret.safety_function_0 = SafetyFunctionId.fromDBus(dbus_obj[0])
        ret.safety_function_1 = SafetyFunctionId.fromDBus(dbus_obj[1])
        ret.safety_function_2 = SafetyFunctionId.fromDBus(dbus_obj[2])
        ret.safety_function_3 = SafetyFunctionId.fromDBus(dbus_obj[3])
        ret.safety_function_4 = SafetyFunctionId.fromDBus(dbus_obj[4])
        ret.safety_function_5 = SafetyFunctionId.fromDBus(dbus_obj[5])
        ret.safety_function_6 = SafetyFunctionId.fromDBus(dbus_obj[6])
        ret.safety_function_7 = SafetyFunctionId.fromDBus(dbus_obj[7])
        return ret


@attr.s
class SafetyWordType:
    safety_function_0 = attr.ib(default=False)
    safety_function_1 = attr.ib(default=False)
    safety_function_2 = attr.ib(default=False)
    safety_function_3 = attr.ib(default=False)
    safety_function_4 = attr.ib(default=False)
    safety_function_5 = attr.ib(default=False)
    safety_function_6 = attr.ib(default=False)
    safety_function_7 = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.Boolean(py_obj.safety_function_0),
                dbus.Boolean(py_obj.safety_function_1),
                dbus.Boolean(py_obj.safety_function_2),
                dbus.Boolean(py_obj.safety_function_3),
                dbus.Boolean(py_obj.safety_function_4),
                dbus.Boolean(py_obj.safety_function_5),
                dbus.Boolean(py_obj.safety_function_6),
                dbus.Boolean(py_obj.safety_function_7),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SafetyWordType()
        ret.safety_function_0 = bool(dbus_obj[0])
        ret.safety_function_1 = bool(dbus_obj[1])
        ret.safety_function_2 = bool(dbus_obj[2])
        ret.safety_function_3 = bool(dbus_obj[3])
        ret.safety_function_4 = bool(dbus_obj[4])
        ret.safety_function_5 = bool(dbus_obj[5])
        ret.safety_function_6 = bool(dbus_obj[6])
        ret.safety_function_7 = bool(dbus_obj[7])
        return ret


@attr.s
class STOParameters:
    restart_acknowledge_behavior = attr.ib(default=False)
    activate_sbc = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.Boolean(py_obj.restart_acknowledge_behavior),
                dbus.UInt32(py_obj.activate_sbc),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = STOParameters()
        ret.restart_acknowledge_behavior = bool(dbus_obj[0])
        ret.activate_sbc = int(dbus_obj[1])
        return ret


class STOId(IntEnum):
    STO_1 = 1

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return STOId(int(dbus_obj))


@attr.s
class SLSParameters:
    time_to_velocity_monitoring = attr.ib(default=0)
    velocity_limit_u32 = attr.ib(default=0)
    time_for_velocity_in_limits = attr.ib(default=0)
    sto_error_reaction = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.UInt16(py_obj.time_to_velocity_monitoring),
                dbus.UInt32(py_obj.velocity_limit_u32),
                dbus.UInt16(py_obj.time_for_velocity_in_limits),
                dbus.Boolean(py_obj.sto_error_reaction),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SLSParameters()
        ret.time_to_velocity_monitoring = int(dbus_obj[0])
        ret.velocity_limit_u32 = int(dbus_obj[1])
        ret.time_for_velocity_in_limits = int(dbus_obj[2])
        ret.sto_error_reaction = bool(dbus_obj[3])
        return ret


class SLSId(IntEnum):
    SLS_1 = 1
    SLS_2 = 2
    SLS_3 = 3
    SLS_4 = 4
    SLS_5 = 5
    SLS_6 = 6
    SLS_7 = 7
    SLS_8 = 8

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SLSId(int(dbus_obj))


@attr.s
class SDIParameters:
    velocity_zero_window_u32 = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct((dbus.UInt32(py_obj.velocity_zero_window_u32),))

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SDIParameters()
        ret.velocity_zero_window_u32 = int(dbus_obj[0])
        return ret


class SDIId(IntEnum):
    SDI_1 = 1
    SDI_2 = 2

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SDIId(int(dbus_obj))


@attr.s
class SBCParameters:
    brake_time_delay = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct((dbus.UInt16(py_obj.brake_time_delay),))

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SBCParameters()
        ret.brake_time_delay = int(dbus_obj[0])
        return ret


class SBCId(IntEnum):
    SBC_1 = 1
    SBC_2 = 2
    SBC_3 = 3

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SBCId(int(dbus_obj))


@attr.s
class SMSParameters:
    velocity_maximum_positive_u32 = attr.ib(default=0)
    velocity_maximum_negative_u32 = attr.ib(default=0)
    sto_error_reaction = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.UInt32(py_obj.velocity_maximum_positive_u32),
                dbus.UInt32(py_obj.velocity_maximum_negative_u32),
                dbus.Boolean(py_obj.sto_error_reaction),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SMSParameters()
        ret.velocity_maximum_positive_u32 = int(dbus_obj[0])
        ret.velocity_maximum_negative_u32 = int(dbus_obj[1])
        ret.sto_error_reaction = bool(dbus_obj[2])
        return ret


class SMSId(IntEnum):
    SMS_1 = 1

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SMSId(int(dbus_obj))


@attr.s
class SLSaParameters:
    time_to_positive_velocity_monitoring = attr.ib(default=0)
    positive_velocity_limit_u32 = attr.ib(default=0)
    time_for_positive_velocity_in_limits = attr.ib(default=0)
    time_to_negative_velocity_monitoring = attr.ib(default=0)
    negative_velocity_limit_u32 = attr.ib(default=0)
    time_for_negative_velocity_in_limits = attr.ib(default=0)
    sto_error_reaction = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.UInt16(py_obj.time_to_positive_velocity_monitoring),
                dbus.UInt32(py_obj.positive_velocity_limit_u32),
                dbus.UInt16(py_obj.time_for_positive_velocity_in_limits),
                dbus.UInt16(py_obj.time_to_negative_velocity_monitoring),
                dbus.UInt32(py_obj.negative_velocity_limit_u32),
                dbus.UInt16(py_obj.time_for_negative_velocity_in_limits),
                dbus.Boolean(py_obj.sto_error_reaction),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SLSaParameters()
        ret.time_to_positive_velocity_monitoring = int(dbus_obj[0])
        ret.positive_velocity_limit_u32 = int(dbus_obj[1])
        ret.time_for_positive_velocity_in_limits = int(dbus_obj[2])
        ret.time_to_negative_velocity_monitoring = int(dbus_obj[3])
        ret.negative_velocity_limit_u32 = int(dbus_obj[4])
        ret.time_for_negative_velocity_in_limits = int(dbus_obj[5])
        ret.sto_error_reaction = bool(dbus_obj[6])
        return ret


class SLSaId(IntEnum):
    SLSa_1 = 1
    SLSa_2 = 2
    SLSa_3 = 3
    SLSa_4 = 4
    SLSa_5 = 5
    SLSa_6 = 6
    SLSa_7 = 7
    SLSa_8 = 8

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SLSaId(int(dbus_obj))


@attr.s
class SafetyFunctionOuputStatus:
    safety_function_id = attr.ib(default=SafetyFunctionId.NONE)
    status = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                SafetyFunctionId.toDBus(py_obj.safety_function_id),
                dbus.Boolean(py_obj.status),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SafetyFunctionOuputStatus()
        ret.safety_function_id = SafetyFunctionId.fromDBus(dbus_obj[0])
        ret.status = bool(dbus_obj[1])
        return ret


# Interface
class SafeMotionDBusClient:
    def __init__(self, instance_id=""):
        self.bus = dbus.SessionBus()

        self.dbus_object = self.bus.get_object(
            "commonapi.SmcService.SafeMotion.v1_0_commonapi.ezw.smcservice" + ("" if instance_id == "" else ".") + instance_id,
            "/commonapi/ezw/smcservice" + ("" if instance_id == "" else "/") + instance_id,
        )
        self.dbus_iface = dbus.Interface(self.dbus_object, "commonapi.SmcService.SafeMotion.v1_0")

    def getSafetyControlWordMapping(self, safety_control_word_id):
        try:
            r = self.dbus_iface.getSafetyControlWordMapping(SafetyControlWordId.toDBus(safety_control_word_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SafetyWordMapping.fromDBus(r[0]), int(r[1]))
        return a

    def setSafetyControlWordMapping(self, safety_control_word_id, safety_control_word_mapping):
        try:
            r = self.dbus_iface.setSafetyControlWordMapping(SafetyControlWordId.toDBus(safety_control_word_id), SafetyWordMapping.toDBus(safety_control_word_mapping))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getSafetyStatusWordMapping(self, safety_status_word_id):
        try:
            r = self.dbus_iface.getSafetyStatusWordMapping(SafetyStatusWordId.toDBus(safety_status_word_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SafetyWordMapping.fromDBus(r[0]), int(r[1]))
        return a

    def setSafetyStatusWordMapping(self, safety_status_word_id, safety_status_word_mapping):
        try:
            r = self.dbus_iface.setSafetyStatusWordMapping(SafetyStatusWordId.toDBus(safety_status_word_id), SafetyWordMapping.toDBus(safety_status_word_mapping))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getSafetyFunctionCommand(self, safety_function_id):
        try:
            r = self.dbus_iface.getSafetyFunctionCommand(SafetyFunctionId.toDBus(safety_function_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (bool(r[0]), int(r[1]))
        return a

    def getSafetyFunctionStatus(self, safety_function_id):
        try:
            r = self.dbus_iface.getSafetyFunctionStatus(SafetyFunctionId.toDBus(safety_function_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (bool(r[0]), int(r[1]))
        return a

    def getSafetyControlWord(self, safety_control_word_id):
        try:
            r = self.dbus_iface.getSafetyControlWord(SafetyControlWordId.toDBus(safety_control_word_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SafetyWordType.fromDBus(r[0]), int(r[1]))
        return a

    def setSafetyControlWord(self, safety_control_word_id, safety_control_word):
        try:
            r = self.dbus_iface.setSafetyControlWord(SafetyControlWordId.toDBus(safety_control_word_id), SafetyWordType.toDBus(safety_control_word))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getSafetyStatusWord(self, safety_status_word_id):
        try:
            r = self.dbus_iface.getSafetyStatusWord(SafetyStatusWordId.toDBus(safety_status_word_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SafetyWordType.fromDBus(r[0]), int(r[1]))
        return a

    def getSTOParameters(self, id):
        try:
            r = self.dbus_iface.getSTOParameters(STOId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (STOParameters.fromDBus(r[0]), int(r[1]), int(r[2]))
        return a

    def setSTOParameters(self, id, parameters):
        try:
            r = self.dbus_iface.setSTOParameters(STOId.toDBus(id), STOParameters.toDBus(parameters))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getSLSParameters(self, id):
        try:
            r = self.dbus_iface.getSLSParameters(SLSId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SLSParameters.fromDBus(r[0]), int(r[1]), int(r[2]))
        return a

    def setSLSParameters(self, id, parameters):
        try:
            r = self.dbus_iface.setSLSParameters(SLSId.toDBus(id), SLSParameters.toDBus(parameters))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getSDIParameters(self, id):
        try:
            r = self.dbus_iface.getSDIParameters(SDIId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SDIParameters.fromDBus(r[0]), int(r[1]), int(r[2]))
        return a

    def setSDIParameters(self, id, parameters):
        try:
            r = self.dbus_iface.setSDIParameters(SDIId.toDBus(id), SDIParameters.toDBus(parameters))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getSBCParameters(self, id):
        try:
            r = self.dbus_iface.getSBCParameters(SBCId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SBCParameters.fromDBus(r[0]), int(r[1]), int(r[2]))
        return a

    def getSMSParameters(self, id):
        try:
            r = self.dbus_iface.getSMSParameters(SMSId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SMSParameters.fromDBus(r[0]), int(r[1]), int(r[2]))
        return a

    def setSMSParameters(self, id, parameters):
        try:
            r = self.dbus_iface.setSMSParameters(SMSId.toDBus(id), SMSParameters.toDBus(parameters))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getSLSaParameters(self, id):
        try:
            r = self.dbus_iface.getSLSaParameters(SLSaId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SLSaParameters.fromDBus(r[0]), int(r[1]), int(r[2]))
        return a

    def setSLSaParameters(self, id, parameters):
        try:
            r = self.dbus_iface.setSLSaParameters(SLSaId.toDBus(id), SLSaParameters.toDBus(parameters))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getSafetyFunctionOutput(self, safety_function_id):
        try:
            r = self.dbus_iface.getSafetyFunctionOutput(SafetyFunctionId.toDBus(safety_function_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (bool(r[0]), int(r[1]))
        return a

    def getSafetyFunctionOutputs(self):
        try:
            r = self.dbus_iface.getSafetyFunctionOutputs()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (dbus.Array([SafetyFunctionOuputStatus.fromDBus(x) for x in r[0]]), int(r[1]))
        return a
