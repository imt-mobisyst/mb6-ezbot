# Code Generated with fidl-code-gen
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "."))

from ezw_smc_service_types import *

import dbus
from enum import IntEnum
import attr, time

# Types
class NMTState(IntEnum):
    UNKNOWN = 0
    STOPPED = 4
    OPER = 5
    PREOP = 127

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return NMTState(int(dbus_obj))


class NMTCommand(IntEnum):
    OPER = 1
    STOP = 2
    PREOP = 128
    RESET_NODE = 129
    RESET_COMM = 130

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return NMTCommand(int(dbus_obj))


# Interface
class NMTDBusClient:
    def __init__(self, instance_id=""):
        self.bus = dbus.SessionBus()

        self.dbus_object = self.bus.get_object(
            "commonapi.SmcService.NMT.v1_0_commonapi.ezw.smcservice" + ("" if instance_id == "" else ".") + instance_id,
            "/commonapi/ezw/smcservice" + ("" if instance_id == "" else "/") + instance_id,
        )
        self.dbus_iface = dbus.Interface(self.dbus_object, "commonapi.SmcService.NMT.v1_0")

    def getNMTState(self):
        try:
            r = self.dbus_iface.getNMTState()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (NMTState.fromDBus(r[0]), int(r[1]))
        return a

    def setNMTState(self, nmt_command):
        try:
            r = self.dbus_iface.setNMTState(NMTCommand.toDBus(nmt_command))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def broadcastNMTState(self, nmt_command):
        try:
            r = self.dbus_iface.broadcastNMTState(NMTCommand.toDBus(nmt_command))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a
