# Code Generated with fidl-code-gen
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "."))

from ezw_smc_service_types import *

import dbus
from enum import IntEnum
import attr, time

# Types
@attr.s
class DeviceParameters:
    manufacturer_device_name = attr.ib(default="")
    hardware_version_description = attr.ib(default="")
    manufacturer_software_version = attr.ib(default="")

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.String(py_obj.manufacturer_device_name),
                dbus.String(py_obj.hardware_version_description),
                dbus.String(py_obj.manufacturer_software_version),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = DeviceParameters()
        ret.manufacturer_device_name = str(dbus_obj[0])
        ret.hardware_version_description = str(dbus_obj[1])
        ret.manufacturer_software_version = str(dbus_obj[2])
        return ret


@attr.s
class SWDParameters:
    motctrl_speed_pid_p = attr.ib(default=0)
    motctrl_speed_pid_i = attr.ib(default=0)
    motctrl_speed_pid_d = attr.ib(default=0)
    motctrl_speed_pid_tw = attr.ib(default=0)
    motctrl_speed_pid_tn = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.UInt32(py_obj.motctrl_speed_pid_p),
                dbus.UInt32(py_obj.motctrl_speed_pid_i),
                dbus.UInt32(py_obj.motctrl_speed_pid_d),
                dbus.UInt32(py_obj.motctrl_speed_pid_tw),
                dbus.UInt32(py_obj.motctrl_speed_pid_tn),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SWDParameters()
        ret.motctrl_speed_pid_p = int(dbus_obj[0])
        ret.motctrl_speed_pid_i = int(dbus_obj[1])
        ret.motctrl_speed_pid_d = int(dbus_obj[2])
        ret.motctrl_speed_pid_tw = int(dbus_obj[3])
        ret.motctrl_speed_pid_tn = int(dbus_obj[4])
        return ret


class SystemErrorStatus(IntEnum):
    EZW_SAFETY_CHECK_NORMAL = 0
    EZW_SAFETY_CHECK_WARNING = 1
    EZW_SAFETY_CHECK_ERROR = 2

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SystemErrorStatus(int(dbus_obj))


class SystemErrorProtectState(IntEnum):
    EZW_PROTECT_NONE = 0
    EZW_PROTECT_ZERO_TORQUE_PROTECT = 1
    EZW_PROTECT_BRAKE_CC_PROTECT = 2
    EZW_PROTECT_APPLY_SBC_CONFIG = 3

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SystemErrorProtectState(int(dbus_obj))


class OutputSource(IntEnum):
    CAN_ALIM = 0
    CAN_IO_ALIM = 1

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return OutputSource(int(dbus_obj))


# Interface
class ManufacturerDBusClient:
    def __init__(self, instance_id=""):
        self.bus = dbus.SessionBus()

        self.dbus_object = self.bus.get_object(
            "commonapi.SmcService.Manufacturer.v1_0_commonapi.ezw.smcservice" + ("" if instance_id == "" else ".") + instance_id,
            "/commonapi/ezw/smcservice" + ("" if instance_id == "" else "/") + instance_id,
        )
        self.dbus_iface = dbus.Interface(self.dbus_object, "commonapi.SmcService.Manufacturer.v1_0")

    def getDeviceParameters(self):
        try:
            r = self.dbus_iface.getDeviceParameters()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (DeviceParameters.fromDBus(r[0]), int(r[1]))
        return a

    def getSWDParameters(self):
        try:
            r = self.dbus_iface.getSWDParameters()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SWDParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setSWDParameters(self, params):
        try:
            r = self.dbus_iface.setSWDParameters(SWDParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getCalibrationValidity(self):
        try:
            r = self.dbus_iface.getCalibrationValidity()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (bool(r[0]), int(r[1]))
        return a

    def getSystemErrorState(self):
        try:
            r = self.dbus_iface.getSystemErrorState()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (
            SystemErrorStatus.fromDBus(r[0]),
            SystemErrorStatus.fromDBus(r[1]),
            SystemErrorStatus.fromDBus(r[2]),
            SystemErrorStatus.fromDBus(r[3]),
            SystemErrorStatus.fromDBus(r[4]),
            int(r[5]),
        )
        return a

    def getSystemErrorProtectState(self):
        try:
            r = self.dbus_iface.getSystemErrorProtectState()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SystemErrorProtectState.fromDBus(r[0]), SystemErrorProtectState.fromDBus(r[1]), int(r[2]))
        return a

    def getSWVersion(self):
        try:
            r = self.dbus_iface.getSWVersion()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (str(r[0]), int(r[1]))
        return a

    def getSWId(self):
        try:
            r = self.dbus_iface.getSWId()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getSWRef(self):
        try:
            r = self.dbus_iface.getSWRef()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (str(r[0]), int(r[1]))
        return a

    def getHWVersion(self):
        try:
            r = self.dbus_iface.getHWVersion()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getHWId(self):
        try:
            r = self.dbus_iface.getHWId()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getProductId(self):
        try:
            r = self.dbus_iface.getProductId()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getProductRef(self):
        try:
            r = self.dbus_iface.getProductRef()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (str(r[0]), int(r[1]))
        return a

    def getOdometryValue(self):
        try:
            r = self.dbus_iface.getOdometryValue()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getOdometryValueTS(self):
        try:
            r = self.dbus_iface.getOdometryValueTS()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]), int(r[2]))
        return a

    def getAccurateOdometryValue(self):
        try:
            r = self.dbus_iface.getAccurateOdometryValue()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getAccurateOdometryValueTS(self):
        try:
            r = self.dbus_iface.getAccurateOdometryValueTS()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]), int(r[2]))
        return a

    def getAccuratePositionValue(self):
        try:
            r = self.dbus_iface.getAccuratePositionValue()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getAccuratePositionValueTS(self):
        try:
            r = self.dbus_iface.getAccuratePositionValueTS()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]), int(r[2]))
        return a

    def getOutputControl(self, output_source):
        try:
            r = self.dbus_iface.getOutputControl(OutputSource.toDBus(output_source))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (bool(r[0]), int(r[1]))
        return a

    def setOutputControl(self, output_source, control):
        try:
            r = self.dbus_iface.setOutputControl(OutputSource.toDBus(output_source), dbus.Boolean(control))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getOutputStatus(self, output_source):
        try:
            r = self.dbus_iface.getOutputStatus(OutputSource.toDBus(output_source))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (bool(r[0]), int(r[1]))
        return a

    def setExternalBrakePresence(self, externalBrakePresence):
        try:
            r = self.dbus_iface.setExternalBrakePresence(dbus.Boolean(externalBrakePresence))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getExternalBrakePresence(self):
        try:
            r = self.dbus_iface.getExternalBrakePresence()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (bool(r[0]), int(r[1]))
        return a
