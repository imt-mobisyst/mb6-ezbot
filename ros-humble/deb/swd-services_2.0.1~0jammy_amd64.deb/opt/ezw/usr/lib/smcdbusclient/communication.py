# Code Generated with fidl-code-gen
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "."))

from ezw_smc_service_types import *

import dbus
from enum import IntEnum
import attr, time

# Types
class BlocId(IntEnum):
    ALL = 1
    COMMUNICATION = 2
    APPLICATION = 3
    MANUFACTURER = 4

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return BlocId(int(dbus_obj))


@attr.s
class IdentityParameters:
    vendor_id = attr.ib(default=0)
    product_code = attr.ib(default=0)
    revision_number = attr.ib(default=0)
    serial_number = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.UInt32(py_obj.vendor_id),
                dbus.UInt32(py_obj.product_code),
                dbus.UInt32(py_obj.revision_number),
                dbus.UInt32(py_obj.serial_number),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = IdentityParameters()
        ret.vendor_id = int(dbus_obj[0])
        ret.product_code = int(dbus_obj[1])
        ret.revision_number = int(dbus_obj[2])
        ret.serial_number = int(dbus_obj[3])
        return ret


class BitTiming(IntEnum):
    BT_1000 = 0
    BT_800 = 1
    BT_500 = 2
    BT_250 = 3
    BT_125 = 4
    BT_100 = 5
    BT_50 = 6
    BT_20 = 7
    BT_10 = 8

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return BitTiming(int(dbus_obj))


@attr.s
class NetworkParameters:
    bit_timing = attr.ib(default=BitTiming.BT_1000)
    node_id = attr.ib(default=0)
    rt_activated = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                BitTiming.toDBus(py_obj.bit_timing),
                dbus.Byte(py_obj.node_id),
                dbus.Boolean(py_obj.rt_activated),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = NetworkParameters()
        ret.bit_timing = BitTiming.fromDBus(dbus_obj[0])
        ret.node_id = int(dbus_obj[1])
        ret.rt_activated = bool(dbus_obj[2])
        return ret


@attr.s
class COBID:
    can_id = attr.ib(default=0)
    valid = attr.ib(default=False)
    flag = attr.ib(default=False)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.UInt16(py_obj.can_id),
                dbus.Boolean(py_obj.valid),
                dbus.Boolean(py_obj.flag),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = COBID()
        ret.can_id = int(dbus_obj[0])
        ret.valid = bool(dbus_obj[1])
        ret.flag = bool(dbus_obj[2])
        return ret


@attr.s
class CommunicationParameters:
    can_id_sync = attr.ib(default=0)
    prod_hb_time = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.UInt16(py_obj.can_id_sync),
                dbus.UInt16(py_obj.prod_hb_time),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = CommunicationParameters()
        ret.can_id_sync = int(dbus_obj[0])
        ret.prod_hb_time = int(dbus_obj[1])
        return ret


class SDOId(IntEnum):
    SDO_1 = 1
    SDO_2 = 2
    SDO_3 = 3
    SDO_4 = 4

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return SDOId(int(dbus_obj))


@attr.s
class SDOCommunicationParameters:
    cob_id_client_to_server = attr.ib(default=COBID())
    cob_id_server_to_client = attr.ib(default=COBID())

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                COBID.toDBus(py_obj.cob_id_client_to_server),
                COBID.toDBus(py_obj.cob_id_server_to_client),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = SDOCommunicationParameters()
        ret.cob_id_client_to_server = COBID.fromDBus(dbus_obj[0])
        ret.cob_id_server_to_client = COBID.fromDBus(dbus_obj[1])
        return ret


class PDOId(IntEnum):
    PDO_1 = 1
    PDO_2 = 2
    PDO_3 = 3
    PDO_4 = 4
    PDO_5 = 5
    PDO_6 = 6
    PDO_7 = 7
    PDO_8 = 8

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return PDOId(int(dbus_obj))


class PDOTransmissionType(IntEnum):
    PDO_SYNC_1 = 1
    PDO_SYNC_2 = 2
    PDO_SYNC_3 = 3
    PDO_SYNC_4 = 4
    PDO_SYNC_5 = 5
    PDO_SYNC_6 = 6
    PDO_SYNC_7 = 7
    PDO_SYNC_8 = 8
    PDO_SYNC_9 = 9
    PDO_SYNC_10 = 10
    PDO_SYNC_11 = 11
    PDO_SYNC_12 = 12
    PDO_SYNC_13 = 13
    PDO_SYNC_14 = 14
    PDO_SYNC_15 = 15
    PDO_SYNC_16 = 16
    PDO_SYNC_17 = 17
    PDO_SYNC_18 = 18
    PDO_SYNC_19 = 19
    PDO_SYNC_20 = 20
    PDO_SYNC_21 = 21
    PDO_SYNC_22 = 22
    PDO_SYNC_23 = 23
    PDO_SYNC_24 = 24
    PDO_SYNC_25 = 25
    PDO_SYNC_26 = 26
    PDO_SYNC_27 = 27
    PDO_SYNC_28 = 28
    PDO_SYNC_29 = 29
    PDO_SYNC_30 = 30
    PDO_SYNC_31 = 31
    PDO_SYNC_32 = 32
    PDO_SYNC_33 = 33
    PDO_SYNC_34 = 34
    PDO_SYNC_35 = 35
    PDO_SYNC_36 = 36
    PDO_SYNC_37 = 37
    PDO_SYNC_38 = 38
    PDO_SYNC_39 = 39
    PDO_SYNC_40 = 40
    PDO_SYNC_41 = 41
    PDO_SYNC_42 = 42
    PDO_SYNC_43 = 43
    PDO_SYNC_44 = 44
    PDO_SYNC_45 = 45
    PDO_SYNC_46 = 46
    PDO_SYNC_47 = 47
    PDO_SYNC_48 = 48
    PDO_SYNC_49 = 49
    PDO_SYNC_50 = 50
    PDO_SYNC_51 = 51
    PDO_SYNC_52 = 52
    PDO_SYNC_53 = 53
    PDO_SYNC_54 = 54
    PDO_SYNC_55 = 55
    PDO_SYNC_56 = 56
    PDO_SYNC_57 = 57
    PDO_SYNC_58 = 58
    PDO_SYNC_59 = 59
    PDO_SYNC_60 = 60
    PDO_SYNC_61 = 61
    PDO_SYNC_62 = 62
    PDO_SYNC_63 = 63
    PDO_SYNC_64 = 64
    PDO_SYNC_65 = 65
    PDO_SYNC_66 = 66
    PDO_SYNC_67 = 67
    PDO_SYNC_68 = 68
    PDO_SYNC_69 = 69
    PDO_SYNC_70 = 70
    PDO_SYNC_71 = 71
    PDO_SYNC_72 = 72
    PDO_SYNC_73 = 73
    PDO_SYNC_74 = 74
    PDO_SYNC_75 = 75
    PDO_SYNC_76 = 76
    PDO_SYNC_77 = 77
    PDO_SYNC_78 = 78
    PDO_SYNC_79 = 79
    PDO_SYNC_80 = 80
    PDO_SYNC_81 = 81
    PDO_SYNC_82 = 82
    PDO_SYNC_83 = 83
    PDO_SYNC_84 = 84
    PDO_SYNC_85 = 85
    PDO_SYNC_86 = 86
    PDO_SYNC_87 = 87
    PDO_SYNC_88 = 88
    PDO_SYNC_89 = 89
    PDO_SYNC_90 = 90
    PDO_SYNC_91 = 91
    PDO_SYNC_92 = 92
    PDO_SYNC_93 = 93
    PDO_SYNC_94 = 94
    PDO_SYNC_95 = 95
    PDO_SYNC_96 = 96
    PDO_SYNC_97 = 97
    PDO_SYNC_98 = 98
    PDO_SYNC_99 = 99
    PDO_SYNC_100 = 100
    PDO_SYNC_101 = 101
    PDO_SYNC_102 = 102
    PDO_SYNC_103 = 103
    PDO_SYNC_104 = 104
    PDO_SYNC_105 = 105
    PDO_SYNC_106 = 106
    PDO_SYNC_107 = 107
    PDO_SYNC_108 = 108
    PDO_SYNC_109 = 109
    PDO_SYNC_110 = 110
    PDO_SYNC_111 = 111
    PDO_SYNC_112 = 112
    PDO_SYNC_113 = 113
    PDO_SYNC_114 = 114
    PDO_SYNC_115 = 115
    PDO_SYNC_116 = 116
    PDO_SYNC_117 = 117
    PDO_SYNC_118 = 118
    PDO_SYNC_119 = 119
    PDO_SYNC_120 = 120
    PDO_SYNC_121 = 121
    PDO_SYNC_122 = 122
    PDO_SYNC_123 = 123
    PDO_SYNC_124 = 124
    PDO_SYNC_125 = 125
    PDO_SYNC_126 = 126
    PDO_SYNC_127 = 127
    PDO_SYNC_128 = 128
    PDO_SYNC_129 = 129
    PDO_SYNC_130 = 130
    PDO_SYNC_131 = 131
    PDO_SYNC_132 = 132
    PDO_SYNC_133 = 133
    PDO_SYNC_134 = 134
    PDO_SYNC_135 = 135
    PDO_SYNC_136 = 136
    PDO_SYNC_137 = 137
    PDO_SYNC_138 = 138
    PDO_SYNC_139 = 139
    PDO_SYNC_140 = 140
    PDO_SYNC_141 = 141
    PDO_SYNC_142 = 142
    PDO_SYNC_143 = 143
    PDO_SYNC_144 = 144
    PDO_SYNC_145 = 145
    PDO_SYNC_146 = 146
    PDO_SYNC_147 = 147
    PDO_SYNC_148 = 148
    PDO_SYNC_149 = 149
    PDO_SYNC_150 = 150
    PDO_SYNC_151 = 151
    PDO_SYNC_152 = 152
    PDO_SYNC_153 = 153
    PDO_SYNC_154 = 154
    PDO_SYNC_155 = 155
    PDO_SYNC_156 = 156
    PDO_SYNC_157 = 157
    PDO_SYNC_158 = 158
    PDO_SYNC_159 = 159
    PDO_SYNC_160 = 160
    PDO_SYNC_161 = 161
    PDO_SYNC_162 = 162
    PDO_SYNC_163 = 163
    PDO_SYNC_164 = 164
    PDO_SYNC_165 = 165
    PDO_SYNC_166 = 166
    PDO_SYNC_167 = 167
    PDO_SYNC_168 = 168
    PDO_SYNC_169 = 169
    PDO_SYNC_170 = 170
    PDO_SYNC_171 = 171
    PDO_SYNC_172 = 172
    PDO_SYNC_173 = 173
    PDO_SYNC_174 = 174
    PDO_SYNC_175 = 175
    PDO_SYNC_176 = 176
    PDO_SYNC_177 = 177
    PDO_SYNC_178 = 178
    PDO_SYNC_179 = 179
    PDO_SYNC_180 = 180
    PDO_SYNC_181 = 181
    PDO_SYNC_182 = 182
    PDO_SYNC_183 = 183
    PDO_SYNC_184 = 184
    PDO_SYNC_185 = 185
    PDO_SYNC_186 = 186
    PDO_SYNC_187 = 187
    PDO_SYNC_188 = 188
    PDO_SYNC_189 = 189
    PDO_SYNC_190 = 190
    PDO_SYNC_191 = 191
    PDO_SYNC_192 = 192
    PDO_SYNC_193 = 193
    PDO_SYNC_194 = 194
    PDO_SYNC_195 = 195
    PDO_SYNC_196 = 196
    PDO_SYNC_197 = 197
    PDO_SYNC_198 = 198
    PDO_SYNC_199 = 199
    PDO_SYNC_200 = 200
    PDO_SYNC_201 = 201
    PDO_SYNC_202 = 202
    PDO_SYNC_203 = 203
    PDO_SYNC_204 = 204
    PDO_SYNC_205 = 205
    PDO_SYNC_206 = 206
    PDO_SYNC_207 = 207
    PDO_SYNC_208 = 208
    PDO_SYNC_209 = 209
    PDO_SYNC_210 = 210
    PDO_SYNC_211 = 211
    PDO_SYNC_212 = 212
    PDO_SYNC_213 = 213
    PDO_SYNC_214 = 214
    PDO_SYNC_215 = 215
    PDO_SYNC_216 = 216
    PDO_SYNC_217 = 217
    PDO_SYNC_218 = 218
    PDO_SYNC_219 = 219
    PDO_SYNC_220 = 220
    PDO_SYNC_221 = 221
    PDO_SYNC_222 = 222
    PDO_SYNC_223 = 223
    PDO_SYNC_224 = 224
    PDO_SYNC_225 = 225
    PDO_SYNC_226 = 226
    PDO_SYNC_227 = 227
    PDO_SYNC_228 = 228
    PDO_SYNC_229 = 229
    PDO_SYNC_230 = 230
    PDO_SYNC_231 = 231
    PDO_SYNC_232 = 232
    PDO_SYNC_233 = 233
    PDO_SYNC_234 = 234
    PDO_SYNC_235 = 235
    PDO_SYNC_236 = 236
    PDO_SYNC_237 = 237
    PDO_SYNC_238 = 238
    PDO_SYNC_239 = 239
    PDO_SYNC_240 = 240
    PDO_ASYNC_FF = 255

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return PDOTransmissionType(int(dbus_obj))


@attr.s
class PDOCommunicationParameters:
    cob_id = attr.ib(default=COBID())
    transmission_type = attr.ib(default=PDOTransmissionType.PDO_SYNC_1)
    event_timer = attr.ib(default=0)

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                COBID.toDBus(py_obj.cob_id),
                PDOTransmissionType.toDBus(py_obj.transmission_type),
                dbus.UInt16(py_obj.event_timer),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = PDOCommunicationParameters()
        ret.cob_id = COBID.fromDBus(dbus_obj[0])
        ret.transmission_type = PDOTransmissionType.fromDBus(dbus_obj[1])
        ret.event_timer = int(dbus_obj[2])
        return ret


@attr.s
class PDOMappingParameters:
    nb = attr.ib(default=0)
    items = attr.ib(default=[])

    @staticmethod
    def toDBus(py_obj):
        return dbus.Struct(
            (
                dbus.Byte(py_obj.nb),
                dbus.Array([dbus.UInt32(x) for x in py_obj.items]),
            )
        )

    @staticmethod
    def fromDBus(dbus_obj):
        ret = PDOMappingParameters()
        ret.nb = int(dbus_obj[0])
        ret.items = [int(x) for x in dbus_obj[1]]
        return ret


# Interface
class CommunicationDBusClient:
    def __init__(self, instance_id=""):
        self.bus = dbus.SessionBus()

        self.dbus_object = self.bus.get_object(
            "commonapi.SmcService.Communication.v1_0_commonapi.ezw.smcservice" + ("" if instance_id == "" else ".") + instance_id,
            "/commonapi/ezw/smcservice" + ("" if instance_id == "" else "/") + instance_id,
        )
        self.dbus_iface = dbus.Interface(self.dbus_object, "commonapi.SmcService.Communication.v1_0")

    def storeParameters(self, bloc_id):
        try:
            r = self.dbus_iface.storeParameters(BlocId.toDBus(bloc_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def restoreDefaultParameters(self, bloc_id):
        try:
            r = self.dbus_iface.restoreDefaultParameters(BlocId.toDBus(bloc_id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getIdentityParameters(self):
        try:
            r = self.dbus_iface.getIdentityParameters()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (IdentityParameters.fromDBus(r[0]), int(r[1]))
        return a

    def getNetworkParameters(self):
        try:
            r = self.dbus_iface.getNetworkParameters()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (NetworkParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setNetworkParameters(self, params):
        try:
            r = self.dbus_iface.setNetworkParameters(NetworkParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getCommunicationParameters(self):
        try:
            r = self.dbus_iface.getCommunicationParameters()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (CommunicationParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setCommunicationParameters(self, params):
        try:
            r = self.dbus_iface.setCommunicationParameters(CommunicationParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getSDOCommunicationParameters(self, id):
        try:
            r = self.dbus_iface.getSDOCommunicationParameters(SDOId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (SDOCommunicationParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setSDOCommunicationParameters(self, id, params):
        try:
            r = self.dbus_iface.setSDOCommunicationParameters(SDOId.toDBus(id), SDOCommunicationParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getRPDOCommunicationParameters(self, id):
        try:
            r = self.dbus_iface.getRPDOCommunicationParameters(PDOId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (PDOCommunicationParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setRPDOCommunicationParameters(self, id, params):
        try:
            r = self.dbus_iface.setRPDOCommunicationParameters(PDOId.toDBus(id), PDOCommunicationParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getTPDOCommunicationParameters(self, id):
        try:
            r = self.dbus_iface.getTPDOCommunicationParameters(PDOId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (PDOCommunicationParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setTPDOCommunicationParameters(self, id, params):
        try:
            r = self.dbus_iface.setTPDOCommunicationParameters(PDOId.toDBus(id), PDOCommunicationParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getRPDOMappingParameters(self, id):
        try:
            r = self.dbus_iface.getRPDOMappingParameters(PDOId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (PDOMappingParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setRPDOMappingParameters(self, id, params):
        try:
            r = self.dbus_iface.setRPDOMappingParameters(PDOId.toDBus(id), PDOMappingParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getTPDOMappingParameters(self, id):
        try:
            r = self.dbus_iface.getTPDOMappingParameters(PDOId.toDBus(id))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (PDOMappingParameters.fromDBus(r[0]), int(r[1]))
        return a

    def setTPDOMappingParameters(self, id, params):
        try:
            r = self.dbus_iface.setTPDOMappingParameters(PDOId.toDBus(id), PDOMappingParameters.toDBus(params))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a
