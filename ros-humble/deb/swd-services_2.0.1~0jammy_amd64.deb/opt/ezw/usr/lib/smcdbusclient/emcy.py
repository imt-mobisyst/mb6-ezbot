# Code Generated with fidl-code-gen
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "."))

from ezw_smc_service_types import *

import dbus
from enum import IntEnum
import attr, time

# Types
class ErrorBehavior(IntEnum):
    NMT_PREOP = 0
    NMT_NO_CHANGE = 1
    NMT_STOP = 2

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return ErrorBehavior(int(dbus_obj))


class ErrorType(IntEnum):
    COMMUNICATION = 1
    EMCY_ERROR = 2
    EMCY_WARNING = 3

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return ErrorType(int(dbus_obj))


class EMCY_ERROR_CODE(IntEnum):
    GENERIC_ERROR = 4096
    ERROR_RESET = 0
    DC_OVER_CURRENT_1 = 8737
    DC_OVER_CURRENT_2 = 8738
    BMS_OC = 8753
    OVER_VOLTAGE_1 = 12817
    OVER_VOLTAGE_2 = 12818
    UNDER_VOLTAGE_1 = 12833
    UNDER_VOLTAGE_2 = 12834
    BMS_UV = 12849
    BMS_OV = 12850
    BMS_UV_CHA = 12851
    TEMPERATURE = 16384
    EXCESS_TEMPERATURE_DEVICE = 16912
    OVER_TEMPERATURE_BMS = 16928
    UNDER_TEMPERATURE_BMS = 16929
    EXCESS_TEMPERATURE_DRIVE = 17168
    BMS_PACK_TEMP_SENSOR = 20496
    CANOPEN_DEVICE_SOFT = 24576
    CANOPEN_PARAMETER_ERROR = 24608
    BMS_INTERNAL_ERROR = 24848
    POWER_ADDITIONAL_MODULES = 28928
    MOTOR_BLOCKED = 28961
    OSSD_STO_1 = 32769
    OSSD_STO_2 = 32770
    SAFE_IN_1 = 32771
    SAFE_IN_2 = 32772
    SAFE_OUT_1 = 32773
    SAFE_OUT_2 = 32774
    HALL_INCONSISTENCY = 32775
    DRVOFF_COHERENCY = 32776
    STO_COHERENCY = 32777
    NBRAKE = 32778
    NBRAKE_CTRL = 32779
    ENDRV = 32780
    FAULT_ALIM_EXT = 32781
    EMERGENCY = 32782
    BRAKE_PRESENCE = 32784
    BRAKE_OC = 32785
    SBU_SET = 32786
    SBU_ACTIVATION_ERROR = 32787
    NCCSTATE = 32788
    MCU_NBRAKE = 32789
    BLC = 32790
    EXT_BRAKE_CMD = 32791
    NBRAKE_INT = 32792
    DRIVER_GENERIC = 32848
    CAN_ERROR_PASSIVE = 33056
    CAN_RECOVER_BUS_OFF = 33088
    PROTOCOL_ERROR_SRDO_SCT_TIMEOUT = 33281
    PROTOCOL_ERROR_SRDO_SRVT_TIMEOUT = 33282
    PROTOCOL_ERROR_SRDO_DATA_MISMATCH = 33283
    PROTOCOL_ERROR_SRDO_WRONG_MSG = 33284
    PROTOCOL_ERROR_SRDO_WRONG_LEN = 33285
    PROTOCOL_ERROR_EVENT_TIMER = 33286

    @staticmethod
    def toDBus(py_obj):
        return dbus.Int32(int(py_obj))

    @staticmethod
    def fromDBus(dbus_obj):
        return EMCY_ERROR_CODE(int(dbus_obj))


# Interface
class EMCYDBusClient:
    def __init__(self, instance_id=""):
        self.bus = dbus.SessionBus()

        self.dbus_object = self.bus.get_object(
            "commonapi.SmcService.EMCY.v1_0_commonapi.ezw.smcservice" + ("" if instance_id == "" else ".") + instance_id,
            "/commonapi/ezw/smcservice" + ("" if instance_id == "" else "/") + instance_id,
        )
        self.dbus_iface = dbus.Interface(self.dbus_object, "commonapi.SmcService.EMCY.v1_0")

    def getErrorBehavior(self, error_type):
        try:
            r = self.dbus_iface.getErrorBehavior(ErrorType.toDBus(error_type))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (ErrorBehavior.fromDBus(r[0]), int(r[1]))
        return a

    def setErrorBehavior(self, error_type, error_behavior):
        try:
            r = self.dbus_iface.setErrorBehavior(ErrorType.toDBus(error_type), ErrorBehavior.toDBus(error_behavior))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def clearErrorList(self):
        try:
            r = self.dbus_iface.clearErrorList()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = int(r)
        return a

    def getErrorCount(self):
        try:
            r = self.dbus_iface.getErrorCount()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getErrorRegister(self):
        try:
            r = self.dbus_iface.getErrorRegister()
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a

    def getError(self, index):
        try:
            r = self.dbus_iface.getError(dbus.Int32(index))
        except dbus.exceptions.DBusException as e:
            if "the reply timeout expired" in str(e):
                # Timeout dbus call => ignore it
                time.sleep(5)  # Wait 5s more (some command are very long > 20s but less than 30s)
                return 1  # OK
            raise e

        if isinstance(r, dbus.String) and "the reply timeout expired" in str(r):
            # Timeout dbus call => ignore it
            return 1  # OK

        a = (int(r[0]), int(r[1]))
        return a
