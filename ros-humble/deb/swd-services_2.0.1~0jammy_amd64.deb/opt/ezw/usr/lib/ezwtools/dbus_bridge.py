#
# Copyright (C) 2019 EZ-Wheel S.A.S. All Rights Reserved.
#

import sys, os
import dbus, dbus.exceptions
import xml
import xml.etree.ElementTree as ET
import json

from ezwlog.ezwlog import EzwLog
from ezwlog.ezwlogtypes import *


class JsonDBusTypesConverter:
    def __init__(self):
        self.datajson = None
        self.argtypes = None
        self.argtype = None
        self.idx = 0

    def setJsonString(self, datajson):
        if datajson != None:
            self.datajson = datajson
            # If datajson is a basic type, it needs an array as a wrapper
            # to apply the recursive process
            basic_types = ["y", "b", "n", "q", "i", "u", "x", "t", "d", "s"]
            if self.argtypes in basic_types:
                self.datajson = []
                self.datajson.append(datajson)

    def setDBusArgTypes(self, argtypes):
        self.argtypes = argtypes

    def j2D(self):
        dbus_args = []
        for i in range(0, len(self.argtypes)):
            self.idx = 0
            self.argtype = self.argtypes[i]

            dbus_args.append(self._convert(self.datajson[i]))

        # Case dbus_args size 0, not to return a struct of length 1
        if len(dbus_args) == 1:
            return dbus_args[0]
        else:
            return dbus_args

    def _convert(self, datain):
        # basic types
        if self.argtype[self.idx] == "y":
            out = dbus.types.Byte(datain)
            self.idx += 1

        elif self.argtype[self.idx] == "b":
            out = dbus.types.Boolean(datain)
            self.idx += 1

        elif self.argtype[self.idx] == "n":
            out = dbus.types.Int16(datain)
            self.idx += 1

        elif self.argtype[self.idx] == "q":
            out = dbus.types.UInt16(datain)
            self.idx += 1

        elif self.argtype[self.idx] == "i":
            out = dbus.types.Int32(datain)
            self.idx += 1

        elif self.argtype[self.idx] == "u":
            out = dbus.types.UInt32(datain)
            self.idx += 1

        elif self.argtype[self.idx] == "x":
            out = dbus.types.Int64(datain)
            self.idx += 1

        elif self.argtype[self.idx] == "t":
            out = dbus.types.UInt64(datain)
            self.idx += 1

        elif self.argtype[self.idx] == "d":
            out = dbus.types.Double(datain)
            self.idx += 1

        elif self.argtype[self.idx] == "s":
            out = dbus.types.String(datain)
            self.idx += 1

            ### Containers
            # Array
        elif self.argtype[self.idx] == "a":
            myarray = []
            baseidx = self.idx
            # We parse all the elements from data tree based on the type
            # specified just after 'a'. That's why we need to keep the baseidx
            # for arg type after a 'parse_type_gram' call
            for elem in datain:
                self.idx = baseidx + 1
                myarray.append(self._convert(elem))
            out = dbus.types.Array(myarray)

            # Variant, don't know what to do with it yet
        elif self.argtype == "v":
            out = "variant"

            # Struct
        elif self.argtype[self.idx] == "(":
            mylist = []
            i = 0
            self.idx += 1
            while self.argtype[self.idx] != ")":
                mylist.append(self._convert(datain[i]))
                i += 1
            out = dbus.types.Struct(mylist)

            # Dictionary
        elif self.argtype[self.idx] == "{":
            myDict = {}
            i = 0
            self.idx += 1
            # Get the idx of the second argument which is not string in the dict
            while self.argtype[self.idx] != "}":
                if self.argtype[self.idx] != "s":
                    break
                self.idx += 1

                # If both args were strings...
            if self.argtype[self.idx] == "}":
                baseidx = self.idx - 1

            for elem in datain.keys():
                self.idx = baseidx
                myDict[elem] = self._convert(datain.get(elem))
            out = dbus.types.Dictionary(myDict)

            # Set the idx after the dict
            while self.argtype[self.idx] != "}":
                self.idx += 1
            self.idx += 1

        else:
            out = "0xUNK"
        return out

    def D2j(self, val):
        if isinstance(val, (tuple, list)):
            dataout = []
            for data in val:
                dataout.append(self.unwrap(data))
            return tuple(dataout)
        else:
            return self.unwrap(val)

    def unwrap(self, val):
        if isinstance(val, dbus.ByteArray):
            return "".join([str(x) for x in val])
        if isinstance(val, (dbus.Array, list, tuple)):
            return [self.unwrap(x) for x in val]
        if isinstance(val, (dbus.Dictionary, dict)):
            return dict([(self.unwrap(x), self.unwrap(y)) for x, y in val.items()])
        if isinstance(val, (dbus.Signature, dbus.String)):
            return str(val)
        if isinstance(val, dbus.Boolean):
            return bool(val)
        if isinstance(val, (dbus.Int16, dbus.UInt16, dbus.Int32, dbus.UInt32, dbus.Int64, dbus.UInt64)):
            return int(val)
        if isinstance(val, dbus.Byte):
            return bytes([int(val)])
        return val


class DbusCallable:
    def __init__(self, ezwLog, contextId):
        self.__ezwLog = ezwLog
        self.__contextId = contextId
        self.objname = None
        self.busname = None
        self.itfname = None

        self.bus = dbus.SessionBus()

        self.obj = None
        self.iface = None
        self.root = None

        self.converter = JsonDBusTypesConverter()

    def init(self, objname, busname, itfname):
        self.objname = objname
        self.busname = busname
        self.itfname = itfname

    def __set(self):
        # Get remote proxy object
        self.obj = self.bus.get_object(self.busname, self.objname)
        self.iface = dbus.Interface(self.obj, self.itfname)

        # Get items of remote proxy object
        iface_introsp = dbus.Interface(self.obj, "org.freedesktop.DBus.Introspectable")
        self.root = ET.fromstring(iface_introsp.Introspect())

    def call(self, methodname, args):

        jsonout_header = (
            """{
		\"busname\":\""""
            + self.busname
            + """\",
		\"objname\":\""""
            + self.objname
            + """\",
		\"itfname\":\""""
            + self.itfname
            + """\",
		\"methodname\":\""""
            + methodname
            + """\""""
        )

        jsonout = jsonout_header

        try:
            # Is remote proxy object exists ?
            if not self.obj:
                self.__set()

        except Exception as e:
            self.__ezwLog.ezw_log_string(self.__contextId, ezw_log_level_t.EZW_LOG_ERROR, str(e))

            # DBusError, reset remote proxy object
            self.obj = None

            jsonout += (
                """,\n\t\"exception-type\":\"DBusError\",
\t\"error-msg\":\""""
                + str(e)
                + """\"}"""
            )
            return jsonout

        try:
            ## Format input args from Json to DBus data type
            if args != None:
                datajson = json.loads(args)
        except Exception as e:
            self.__ezwLog.ezw_log_string(self.__contextId, ezw_log_level_t.EZW_LOG_ERROR, str(e))

            jsonout += (
                """,\n\t\"exception-type\":\"JSONDecodeError\",
\t\"error-msg\":\""""
                + str(e)
                + """\"}"""
            )
            return jsonout

        # Get data in types
        dbus_args = []

        for itf in self.root.findall("interface"):
            if itf.get("name") == self.itfname:
                for mtd in itf.findall("method"):
                    if mtd.get("name") == methodname:
                        for arg in mtd.findall("arg"):
                            if arg.get("direction") == "in":
                                try:
                                    self.converter.setDBusArgTypes(arg.get("type"))
                                    self.converter.setJsonString(datajson[arg.get("name")])
                                    dbus_args.append(self.converter.j2D())
                                except Exception as e:
                                    self.__ezwLog.ezw_log_string(self.__contextId, ezw_log_level_t.EZW_LOG_ERROR, str(e))
                                    jsonout += (
                                        """,\n\t\"exception-type\":\"JSONDecodeError\",
                        \t\"error-msg\":\""""
                                        + str(e)
                                        + """\"}"""
                                    )
                                    return jsonout
                            if arg.get("direction") == "out":
                                if arg.get("name") != None:
                                    jsonout += ',\n\t"' + arg.get("name") + '": "%s"'
                                else:
                                    jsonout += ',\n\t"unnamed-output": "%s"'
        jsonout += "\n}"

        # Convert to readable json output
        try:
            # Call the method
            ans = getattr(self.iface, methodname)(*dbus_args)
            try:
                iter(ans)
            except:
                return jsonout % ans

            # \" String if needed
            lst = list(ans)
            for elt in range(len(lst)):
                if isinstance(lst[elt], dbus.String):
                    lst[elt] = lst[elt].replace('"', '\\"')
                if isinstance(lst[elt], dbus.Byte):
                    lst[elt] = int(lst[elt])

            return jsonout % tuple(lst)
        except Exception as e:
            self.__ezwLog.ezw_log_string(self.__contextId, ezw_log_level_t.EZW_LOG_ERROR, str(e))

            # DBusError, reset remote proxy object
            self.obj = None

            jsonout = jsonout_header
            jsonout += (
                """,\n\t\"exception-type\":\"DBusError\",
\t\"error-msg\":\""""
                + str(e)
                + """\"}"""
            )

            return jsonout
