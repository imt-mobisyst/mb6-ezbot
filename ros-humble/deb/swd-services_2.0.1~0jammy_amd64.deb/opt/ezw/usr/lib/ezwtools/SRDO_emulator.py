#
# Copyright (C) 2021 ez-Wheel. All Rights Reserved.
#

import threading
import copy
import can
import time
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "/opt/ezw/usr/lib"))

from ezwtools.PeriodicThread import PeriodicThread

CAN_IFACE = "can0"
BUS_TYPE = "socketcan"
NODE_ID = 0x10
BUS = can.interface.Bus(CAN_IFACE, bustype=BUS_TYPE)

NMT_GO_TO_OPER = 1
NMT_GO_TO_STOP = 2
NMT_GO_TO_PREOP = 128
NMT_GO_TO_RESET_NODE = 129
NMT_GO_TO_RESET_COMM = 130

def send_nmt_cmd(cmd):
    BUS.send(can.Message(arbitration_id=0x0, data=[cmd, NODE_ID], is_extended_id=False))

class CANOpenSync(object):
    def __init__(self, bus, sync_time=0.01):
        self.bus = bus
        self.thread = PeriodicThread(self.send, sync_time)

    def send(self):
        self.bus.send(can.Message(arbitration_id=0x80, data=None, is_extended_id=False))

    def start(self):
        self.thread.start()
        self.isStarted = True

    def stop(self):
        self.thread.cancel()
        self.isStarted = False


class CANopenSRDO(object):
    isStarted = False
    cobid = 0
    cobid_inv = 0
    mutex = threading.Lock()

    def __init__(self, bus, cob_id, inverted_cob_id, value=[0x0], SCT=0.025, SRVT=0.010):
        self.bus = bus
        self.SCT = SCT
        self.SRVT = SRVT
        self.cobid = cob_id
        self.cobid_inv = inverted_cob_id
        self.set_value(value)
        self.error_SCT_timing = False
        self.error_SRVT_timing = False
        self.error_inverting = False

        self.thread = None

    def run(self):
        while self.isStarted:
            last_time = time.time()
            self.send()
            while (time.time() - last_time) < self.SCT:
                time.sleep(self.SCT / 10)

    def send(self):
        try:
            self.mutex.acquire()
            msg = copy.deepcopy(self.msg)
            msg_inverted = copy.deepcopy(self.msg_inverted)
            not_msg_inverted = copy.deepcopy(self.not_msg_inverted)
            sct = self.SCT
            srvt = self.SRVT
            error_SCT_timing = self.error_SCT_timing
            error_SRVT_timing = self.error_SRVT_timing
            error_inverting = self.error_inverting
            self.mutex.release()

            if error_SCT_timing:
                time.sleep(sct)

            self.bus.send(msg)

            if error_SRVT_timing:
                time.sleep(2 * srvt)

            if error_inverting:
                self.bus.send(not_msg_inverted)
            else:
                self.bus.send(msg_inverted)
        except can.CanError:
            print("Message NOT sent")

    def recv(self):
        return self.bus.recv(timeout=1)

    def invertData(self, data):
        invertedData = []
        for x in data:
            invertedData.append(x ^ 0xFF)
        return invertedData

    def set_value(self, value):
        self.mutex.acquire()
        dataToSend = value
        dataToSendInv = self.invertData(value)
        self.msg = can.Message(arbitration_id=self.cobid, data=dataToSend, is_extended_id=False)
        self.msg_inverted = can.Message(arbitration_id=self.cobid_inv, data=dataToSendInv, is_extended_id=False)
        self.not_msg_inverted = can.Message(arbitration_id=self.cobid_inv, data=dataToSend, is_extended_id=False)
        self.mutex.release()

    def start(self):
        self.isStarted = True
        if not self.thread:
            self.thread = threading.Thread(target=self.run)
            self.thread.start()

    def stop(self):
        self.isStarted = False
        if self.thread:
            self.thread.join()
        self.thread = None

    def do_error_SCT_timing(self):
        self.mutex.acquire()
        self.error_SCT_timing = True
        self.error_SRVT_timing = False
        self.error_inverting = False
        self.mutex.release()

    def do_error_SRVT_timing(self):
        self.mutex.acquire()
        self.error_SCT_timing = False
        self.error_SRVT_timing = True
        self.error_inverting = False
        self.mutex.release()

    def do_error_inverting(self):
        self.mutex.acquire()
        self.error_SCT_timing = False
        self.error_SRVT_timing = False
        self.error_inverting = True
        self.mutex.release()

    def stop_error(self):
        self.mutex.acquire()
        self.error_SCT_timing = False
        self.error_SRVT_timing = False
        self.error_inverting = False
        self.mutex.release()


if __name__ == "__main__":

    # Default Value :
    # cobId1 = 0x107 # node 4
    # cobId2 = 0x108 # node 4
    cobId1 = 0x11F
    cobId2 = 0x120

    # sync  = CANOpenSync(BUS)
    srdo1 = CANopenSRDO(BUS, cobId1, cobId2, value=[0x7F])
    # srdo1  = CANopenSRDO(BUS, 0x11F, 0x120, value=[0x7F])
    # srdo9 = CANopenSRDO(BUS, 0x105, 0x106, value=[0x7F])
    # srdo11 = CANopenSRDO(BUS, 0x109, 0x10A, value=[0x7F])
    # srdo12 = CANopenSRDO(BUS, 0x10B, 0x10C, value=[0x7F])
    # srdo13 = CANopenSRDO(BUS, 0x10D, 0x10E, value=[0x7F])
    # srdo14 = CANopenSRDO(BUS, 0x10F, 0x110, value=[0x7F])
    # srdo15 = CANopenSRDO(BUS, 0x111, 0x112, value=[0x7F])
    # srdo16 = CANopenSRDO(BUS, 0x113, 0x114, value=[0x7F])

    print("Start SRDO")
    srdo1.start()
    # R-SRDO 9 and 11 to 16 are desactivated by default
    # SRDO [3; 8], are reserved for CIA further development
    # SRDO 2 & 10 are TX by default
    # srdo9.start()
    # srdo11.start()
    # srdo12.start()
    # srdo13.start()
    # srdo14.start()
    # srdo15.start()
    # srdo16.start()
