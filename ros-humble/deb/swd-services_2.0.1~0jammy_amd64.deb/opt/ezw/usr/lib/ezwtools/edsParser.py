#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2021 EZ-Wheel S.A.S. All Rights Reserved.
#

import configparser
from enum import IntEnum
from enum import Enum
from typing import List
import sys


class ObjectTypeEnum(IntEnum):
    OT_UNKNOWN = 0
    OT_DOMAIN = 2
    OT_VAR = 7
    OT_ARR = 8
    OT_RECORD = 9


class AccesTypeEnum(Enum):
    AT_UNKNOWN = ""
    AT_RO = "ro"
    AT_WO = "wo"
    AT_RW = "rw"
    AT_CNST = "const"


class DataTypeEnum(IntEnum):
    DT_UNKNOWN = 0x00
    DT_BOOL = 0x01
    DT_INT8 = 0x02
    DT_INT16 = 0x03
    DT_INT32 = 0x04
    DT_UINT8 = 0x05
    DT_UINT16 = 0x06
    DT_UINT32 = 0x07
    DT_REAL32 = 0x08
    DT_STRING = 0x09
    DT_OCTET_STRING = 0x0A
    DT_DATE = 0x0B
    DT_TIME_OF_DAY = 0x0C
    DT_TIME_DIFFERENCE = 0x0D
    DT_BIT_STRING = 0x0E
    DT_DOMAIN = 0x0F
    DT_REAL64 = 0x11
    DT_INT64 = 0x15
    DT_UINT64 = 0x18


class CanObject:
    def __init__(self):
        self.index = 0
        self.subIndex = 0
        self.name = ""
        self.parameterName = ""
        self.objectType = ObjectTypeEnum.OT_UNKNOWN
        self.dataType = DataTypeEnum.DT_UNKNOWN
        self.accessType = AccesTypeEnum.AT_UNKNOWN
        self.isPDOMappable = False
        self.defaultValue = ""
        self.subNumber = 0
        self.min = None
        self.max = None

    def getAddress(self):
        # Format address : AAAA BB CC
        # A : Index |  B : SubIndex | C : size = 0 here
        address = "0x{0:0>4}{1:0>2}{2:0>2}".format(self.index, self.subIndex, 0x0)
        return address


class EDSParser:
    def __init__(self):

        self.__canObjectList = []
        self.__canMapFromAddr = {}
        self.__canMapFromName = {}

    def load(self, file: str, node_id: int):

        config = configparser.ConfigParser()

        # Open file
        config.read(file)

        # parse
        for section in config:

            canObject = CanObject()

            # Skip non CanObject
            if not ("ParameterName" in config[section]):
                continue

            # Skip IndexObject ## maybe use "subnumber" to gess type ?
            if config[section]["ObjectType"] == "8" or config[section]["ObjectType"] == "9":
                continue

            # Extract Index
            canObject.index = section.split("sub")[0]

            # Determine if subIndex
            isSubIndex = len(section.split("sub")) > 1

            # Extract SubIndex if any
            if isSubIndex:
                canObject.subIndex = section.split("sub")[1]

            # Copy all fields
            for key in config[section]:

                if key == "parametername":
                    canObject.name = config[section][key]
                    canObject.parameterName = config[section][key]

                    if isSubIndex:
                        canObject.name = config[canObject.index]["parametername"] + " " + canObject.name
                        canObject.parameterName = config[canObject.index]["parametername"] + " " + canObject.parameterName

                if key == "objecttype":
                    l_intObjectType = int(config[section][key])
                    if any(x.value == l_intObjectType for x in ObjectTypeEnum):
                        canObject.objectType = ObjectTypeEnum(l_intObjectType)
                    else:
                        print(f"ObjectType value : {l_intObjectType} from canObject[{section}] is not a supported enum ")

                if key == "datatype":
                    l_intDataType = int(config[section][key])
                    if any(x.value == l_intDataType for x in DataTypeEnum):
                        canObject.dataType = DataTypeEnum(l_intDataType)
                    else:
                        print(f"DataType value : {l_intDataType} from canObject[{section}] is not a supported enum ")

                if key == "accesstype":
                    canObject.accessType = AccesTypeEnum(str(config[section][key]))

                if key == "ispdomappable":
                    canObject.isPDOMappable = config[section][key]

                if key == "defaultvalue":
                    canObject.defaultValue = config[section][key]
                    if canObject.dataType in range(DataTypeEnum.DT_INT16, DataTypeEnum.DT_REAL32):
                        # Replace and evaluate $NODEID with node_id value
                        if "$NODEID" in canObject.defaultValue:
                            canObject.defaultValue = canObject.defaultValue.replace("$NODEID", str(node_id))
                            canObject.defaultValue = eval(canObject.defaultValue)
                        # Evaluate hexadecimal string as Int
                        elif "0x" in canObject.defaultValue:
                            canObject.defaultValue = str(int(canObject.defaultValue, 16))

                if key == "subnumber":
                    canObject.subNumber = config[section][key]

                if key == "min":
                    canObject.min = config[section][key]

                if key == "max":
                    canObject.max = config[section][key]

            self.__canMapFromAddr[canObject.getAddress()] = canObject
            self.__canMapFromName[canObject.name] = canObject
            self.__canObjectList.append(canObject)

    def getObjectByName(self, name) -> CanObject:
        return self.__canMapFromName[name]

    def getObjectByAddress(self, address) -> CanObject:
        return self.__canMapFromAddr[address]

    def getObjects(self) -> List[CanObject]:
        return self.__canObjectList


if __name__ == "__main__":

    parser = EDSParser()

    if len(sys.argv) > 2:
        parser.load(sys.argv[1], sys.argv[2])
    else:
        print("\nUSAGE : \n\tedsParser.py /path/to/file.eds nodeID \n\tPrint all CanObject from edsFile")
        print("\n\t-d\t : print only CanObject with default value")
        # parser.load("/home/charles/workspace-ezw/ezw-canopen-dico/smc/drive/smc_velocitymode.eds")

    canObjectList = parser.getObjects()  # type: List[CanObject]
    # Print all datas
    for canObject in canObjectList:
        # filter only with default value
        if "-d" in sys.argv:
            if canObject.defaultValue != "":
                print(canObject.getAddress() + f" : {canObject.name:<100} | default : {canObject.defaultValue}")
        else:
            print(canObject.getAddress() + f" : {canObject.name:<100} | default : {canObject.defaultValue}")
