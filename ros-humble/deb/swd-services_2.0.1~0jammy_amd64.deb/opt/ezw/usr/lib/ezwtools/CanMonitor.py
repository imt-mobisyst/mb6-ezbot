#
# Copyright (C) 2021 ez-Wheel. All Rights Reserved.
#

import canopen
import time
import sys, os
import argparse

CAN_IFACE = "can0"
BUS_TYPE = "socketcan"
DEFAULT_BUFFER_SIZE = 20


class ChannelMonitor(object):
    def __init__(self, canId: int, network: canopen.Network, bufferSize=DEFAULT_BUFFER_SIZE):
        self.network = network
        self.canId = canId
        self.bufferSize = bufferSize
        self.isStarted = False
        self.start()

    def clear(self):
        self.bufferIndex = 0
        self.rawBuffer = [[0, 0]] * self.bufferSize
        self.bytesBuffer = [["--"]] * self.bufferSize

    def __del__(self):
        self.stop()

    def getCanId(self):
        return self.canId

    def start(self):
        self.stop()
        self.network.subscribe(can_id=self.canId, callback=self.subscriber)
        self.isStarted = True

    def stop(self):
        if self.isStarted:
            self.network.unsubscribe(can_id=self.canId)
        self.clear()

    def getRawBuffer(self):
        return self.rawBuffer

    def getBytesBuffer(self):
        return self.bytesBuffer

    def subscriber(self, canId: int, bytearrayMsg: bytearray, receivedTime):
        rawBuffer = bytearrayMsg.hex()
        self.rawBuffer[self.bufferIndex] = [rawBuffer, receivedTime]
        self.bytesBuffer[self.bufferIndex] = self.msgRawToBytes(rawBuffer)
        self.bufferIndex = (self.bufferIndex + 1) % self.bufferSize

    @staticmethod
    def msgRawToBytes(raw: str):
        bytes = []

        while len(raw) >= 2:
            byte = int(raw[0:2], 16)
            bytes.append(byte)
            raw = raw[2:]
        return bytes


class CanMonitor(object):
    def __init__(self, canInterface=CAN_IFACE):
        self.channelDictionary = {}
        self.network = canopen.Network()
        self.network.connect(channel=canInterface, bustype=BUS_TYPE)

    def __del__(self):
        pass

    def addChannel(self, canId, bufferSize=DEFAULT_BUFFER_SIZE):
        if canId in self.channelDictionary:
            print(f"CanId {canId} already monitored")
            return False
        self.channelDictionary[canId] = ChannelMonitor(canId, self.network, bufferSize)
        return True

    def clearChannel(self, canId):
        if canId in self.channelDictionary:
            self.channelDictionary[canId].clear()
            return True
        print(f"Cannot clear channel for non monitored canId {canId}")
        return False

    def removeChannel(self, canId):
        if canId in self.channelDictionary:
            del self.channelDictionary[canId]
            return True
        print(f"CanId {canId} is not monitored")
        return False

    def listMonitor(self):
        return self.channelDictionary

    def getRawBuffer(self, canId):
        if canId in self.channelDictionary:
            return self.channelDictionary[canId].getRawBuffer()
        print(f"{canId} is not monitored")
        return [[]]

    def getBytesBuffer(self, canId):
        if canId in self.channelDictionary:
            return self.channelDictionary[canId].getBytesBuffer()
        print(f"{canId} is not monitored")
        return [[]]

    def removeAllChannels(self):
        for channel in list(self.channelDictionary):
            self.removeChannel(channel)
        return True


if __name__ == "__main__":

    parser = argparse.ArgumentParser("CanMonitor")
    parser.add_argument("--can", help="which can bus shall be used (default can0)", type=str, default=CAN_IFACE, required=False)
    parser.add_argument("--channel", help="Which add channel to listen to a canId", type=str, nargs="+")
    parser.add_argument("--bufferSize", help=f"Size of the channel's buffer (default {DEFAULT_BUFFER_SIZE})", type=int, default=DEFAULT_BUFFER_SIZE, required=False)
    parser.add_argument("--refresh", help="Delay between two refresh of the display in ms (default 1000ms)", type=int, default="1000", required=False)
    args = parser.parse_args()

    can = args.can
    bufferSize = args.bufferSize
    refresh = args.refresh
    channelList = args.channel

    # Start CanMonitor
    myMonitor = CanMonitor(can)

    # Open each channel :
    for index in range(0, len(channelList)):
        # If channel contain hex
        if channelList[index].find("0x") != -1:
            channelList[index] = int(channelList[index], 16)
        else:
            channelList[index] = int(channelList[index])
        myMonitor.addChannel(channelList[index])

    print(f"Monitoring {can} for canId {channelList} with bufferSize {bufferSize}")

    while True:
        time.sleep(refresh / 1000)

        dataArray = []

        # Print Header
        for channel in channelList:
            dataArray.append(myMonitor.getBytesBuffer(channel))
            channel = f"{channel:X}"
            print(f"{channel:^24} ", end="\t")
        print("")

        for lineNbr in range(0, bufferSize):
            lineStr = ""
            for collumn in range(0, len(channelList)):
                dataStr = ""
                bytesMsg = dataArray[collumn][lineNbr]
                for byte in bytesMsg:
                    if byte == "--":
                        dataStr += f"{byte:0>2} "
                    else:
                        dataStr += f"{byte:02X} "
                lineStr += f"{dataStr:24}\t"
            print(f"{lineStr}")
