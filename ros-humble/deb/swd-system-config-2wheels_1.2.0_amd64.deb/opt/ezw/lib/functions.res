#!/bin/bash

##### -*-Shell-script-*-
#
# functions This file contains functions and variables to be used by most or all
#       shell scripts
#

# Make sure umask is sane
umask 022

#########################################################################################
CURRENT_RELEASE=0.1.3_swd_sk
#########################################################################################

##PATHs
#OS
EZ=/opt/ezw
EZBIN=$EZ/bin
EZETC=$EZ/etc
EZLIB=$EZ/lib
EZSBI=$EZ/sbin
EZDAT=$EZ/data
EZSSH=$EZDAT/ssh
EZVAR=$EZ/var
EZLOG=$EZVAR/logs
EZRUN=$EZVAR/run
EZTMP=/tmp
#APP EZW
EZUSR=$EZ/usr
EZUSRBIN=$EZUSR/bin
EZUSRETC=$EZUSR/etc
EZUSRLIB=$EZUSR/lib
EZUSRLOG=/tmp

###########################################
EZENV=$EZDAT/env.sh
###########################################
EZINI=$EZETC/ezwheel.ini
###########################################
DIRECT_NAME=$(dirname $0)
##READ/WRITE INI FILES#####################
PARSEINI=$EZBIN/utils/ezreadini
WRITEINI=$EZBIN/utils/ezwriteini
###########################################
#CONVERT STR STRING TO HEXADECIMAL
STR2HEXA=$EZSBI/tools/str2hexa.pl
###########################################
CONNMAN_CONF=/var/lib/connman
CONNMAN_ETCDIR=/etc/connman
CONNMAN_MAIN=/etc/connman/main.conf
IFCONF_CONFIG=/etc/network/interfaces
HOSTAPD_CONF=/etc/hostapd.conf
IPTABLES_RULES=$EZETC/iptables.rules
#
DB_FACTORY_PATH=$EZ/data.FACTORY/ezw.db
DB_MMC_PATH=$EZDAT/ezw.db
#
OPENVPNDIR=$EZETC/openvpn
#
WAITINTERVAL=60
#
DNSMASQ_CONF=/etc/dnsmasq.conf
RESOLV_CONF=/etc/resolv.conf
RESOLVED_CONF=/etc/systemd/resolved.conf
NTP_CONF=/etc/ntp.conf
NMGLOBAL_CONF=/etc/NetworkManager/NetworkManager.conf
#
#dns
NSSWITCH_CONF=/etc/nsswitch.conf
#NGINX CONFIG FILES
NGINX_WLAN0_INC=$EZETC/nginx/wlan0.include
NGINX_WLAN1_INC=$EZETC/nginx/wlan1.include
NGINX_ETH0_INC=$EZETC/nginx/eth0.include
#
SQL_EZ_ISMAST=""
SQL_EZ_ADDNS1=""
SQL_EZ_ADDNS2=""
SQL_EZ_GATEWA=""
SQL_EZ_TOPOLY=""
SQL_EZ_DOMAIN=""
#

#HOSTS
ETC_HOSTS="/etc/hosts"

#DBUS
DBUSWAIT=3
#

DEBUG=

#CRON
CRON_SRC=$EZETC/cron_root
CRON_DST=/var/spool/cron/root

#COREDUMPER
COREDUMP_PATH=/etc/minicoredumper
COREDUMP_GEN_SRC=$EZETC/generic.recept.json
COREDUMP_GEN_DST=$COREDUMP_PATH/generic.recept.json
COREDUMP_CFG_SRC=$EZETC/minicoredumper.cfg.json
COREDUMP_CFG_DST=$COREDUMP_PATH/minicoredumper.cfg.json
#

# Set up a default search path.
PATH="$EZBIN:$EZSBI:$EZUSRBIN:/sbin:/usr/sbin:/bin:/usr/bin"
export PATH
#

#system binaries
WHIC=/usr/bin/which
IWCM=/usr/sbin/iw
FIND=/usr/bin/find
HEAD=/usr/bin/head
AWKC=/usr/bin/awk
IFCF=/sbin/ifconfig
GREP=/bin/grep
EGREP=/bin/egrep
MVCM=/bin/mv
CATC=/bin/cat
WPAP=/usr/bin/wpa_passphrase
RMCM=/bin/rm
DATE=/bin/date
HOST=/bin/hostname
CPCM=/bin/cp
SEDC=/bin/sed
SYSC=/sbin/sysctl
TRCM=/usr/bin/tr
MACC=/usr/bin/macchanger
ECHO=/bin/echo
PRIN=/usr/bin/printf
MKDI=/bin/mkdir
VCON=/sbin/vconfig
SQLI=/usr/bin/sqlite3
IPTA=/usr/sbin/iptables
IPTAS=/usr/sbin/iptables-save
IPTAR=/usr/sbin/iptables-restore
CHOW=/bin/chown
CHMO=/bin/chmod
IFUP=/sbin/ifup
IFDOWN=/sbin/ifdown
LNCM=/bin/ln
NMCL=/usr/bin/nmcli
SLEE=/bin/sleep
IPCA=/usr/bin/ipcalc
LOCA=/usr/bin/localedef
IDUS=/usr/bin/id
USAD=/usr/sbin/useradd
TOUCH=/bin/touch
DIFF=/usr/bin/diff
MOUN=/bin/mount
SYSTEMCTL=/bin/systemctl
BASN=/usr/bin/basename
BLKI=/sbin/blkid
MKFS=/sbin/mkfs.ext4
WGET=/usr/bin/wget
PSCM=/bin/ps
IPCMD=/sbin/ip
PROBE=/sbin/modprobe
RMMOD=/sbin/rmmod
WCCM=/usr/bin/wc
DFCM=/bin/df
MKFI=/usr/bin/mkfifo
FTEE=/usr/bin/ftee
CUT=/usr/bin/cut
PDCTN=/usr/sbin/pdctname

#
DBSN=$($WHIC dbus-send)
#system variables
HOST_NAME=$(hostname)

#sofware variables
OK=0
FAILED=1
ABORT=999

#ENABLE DEBUG/HEALTH METROLOGY
METROLOGY=0
#### IF = 1, MODIFY /opt/ezw/etc/logsce.ini with correct variables//
#### We need a Graylog server (or equivalent) with
#### LOGSERVER=<IP ADRESS>
#### LOGPORT=<PORT TO CONNECT TO    - Warning: HAS TO BE AN UDP PORT (not tcp)
#### METRICSTEP= SEND EACH x s
##############################

TRUE=1
FALSE=0

RES_COL=60
BOOTUP="color"
MOVE_TO_COL="$ECHO -en \\033[${RES_COL}G"
SETCOLOR_SUCCESS="$ECHO -en \\033[1;32m"
SETCOLOR_FAILURE="$ECHO -en \\033[1;31m"
SETCOLOR_WARNING="$ECHO -en \\033[1;33m"
SETCOLOR_NORMAL="$ECHO -en \\033[0;39m"
SETCOLOR_BLUE="$ECHO -en \\033[1;34m"
SETCOLOR_CYAN="$ECHO -en \\033[1;36m"

###################CAN OPTIONS #######################################
#1Mbps
BITRATE=1000000
#autokeepalive , restart on 100ms on error (if possible)
AUTOKEEPAL=100
#transmit queue
TXQUEUELEN=1000
#OPTIONS FOR up canX interface
OPTIONS="type can bitrate ${BITRATE} restart-ms ${AUTOKEEPAL}"
######################################################################

###################CUSTOM ENV #######################################

if [ -f "$EZENV" ]; then
  source "$EZENV"
fi

##########################################
echo_simple() {
  printf "%-50.50s" "$1"
}
##########################################

echo_skipped() {
  $ECHO -n "["
  [ "$BOOTUP" = "color" ] && $SETCOLOR_CYAN
  $ECHO -n $" SKIP "
  [ "$BOOTUP" = "color" ] && $SETCOLOR_NORMAL
  $ECHO -n "]"
  $ECHO ""
  return $OK
}

##########################################
echo_success() {
  $ECHO -n "["
  [ "$BOOTUP" = "color" ] && $SETCOLOR_SUCCESS
  $ECHO -n $"  OK  "
  [ "$BOOTUP" = "color" ] && $SETCOLOR_NORMAL
  $ECHO -n "]"
  $ECHO ""

  return $OK
}
##########################################

##########################################
echo_todo() {
  $ECHO -n "["
  [ "$BOOTUP" = "color" ] && $SETCOLOR_BLUE
  $ECHO -n $" TODO "
  [ "$BOOTUP" = "color" ] && $SETCOLOR_NORMAL
  $ECHO -n "]"
  $ECHO ""

  return $OK
}
##########################################

##########################################
echo_failure() {
  $ECHO -n "["
  [ "$BOOTUP" = "color" ] && $SETCOLOR_FAILURE
  $ECHO -n $"FAILED"
  [ "$BOOTUP" = "color" ] && $SETCOLOR_NORMAL
  $ECHO -n "]"
  $ECHO ""

  return $FAILURE
}
##########################################

##########################################
echo_passed() {
  $ECHO -n "["
  [ "$BOOTUP" = "color" ] && $SETCOLOR_WARNING
  $ECHO -n $" SKIP "
  [ "$BOOTUP" = "color" ] && $SETCOLOR_NORMAL
  $ECHO -n "]"
  $ECHO ""

  return $OK
}
##########################################

##########################################
echo_dbuserr() {
  $ECHO -n "["
  [ "$BOOTUP" = "color" ] && $SETCOLOR_WARNING
  $ECHO -n $"DBUSERR"
  [ "$BOOTUP" = "color" ] && $SETCOLOR_NORMAL
  $ECHO -n "]"
  $ECHO ""
  return $OK
}
##########################################

##########################################
echo_warning() {
  $ECHO -n "["
  [ "$BOOTUP" = "color" ] && $SETCOLOR_WARNING
  $ECHO -n $"WARNING"
  [ "$BOOTUP" = "color" ] && $SETCOLOR_NORMAL
  $ECHO -n "]"
  $ECHO ""

  return $FAILURE
}
##########################################

##########################################
echo_notready() {
  $ECHO -n "["
  [ "$BOOTUP" = "color" ] && $SETCOLOR_WARNING
  $ECHO -n $"WARNING"
  [ "$BOOTUP" = "color" ] && $SETCOLOR_NORMAL
  $ECHO -n "]"
  $ECHO ""

  return $FAILURE
}
##########################################

#################################################################################
# GLOBAL VARIABLES IN USE                                                ########
#################################################################################
global_ismaster=""
master_addres=""
global_topology=""
global_gw=""
global_dns1=""
global_dns2=""
global_ntp1=""
global_ntp2=""
global_equipment_type=""
fw_app_low=""
fw_app_hig=""

#
wlan0_isactive=""
wlan0_ipaddres=""
wlan0_netmask=""
wlan0_ssid=""
wlan0_hiddenssid=""
wlan0_ssid_enc=""
wlan0_psk=""
wlan0_mac=""
wlan0_mac_enc=""
wlan0_vlanid=""

wlan1_isactive=""
wlan1_ipaddres=""
wlan1_netmask=""
wlan1_mac=""
wlan1_channel=""
wlan1_ssid=""
wlan1_psk=""
wlan1_dhcp=""
wlan1_dhcpmin=""
wlan1_dhcpmax=""

eth0_isactive=""
eth0_ipaddres=""
eth0_netmask=""
eth0_dhcp=""
eth0_dhcpmin=""
eth0_dhcpmax=""
eth0_mac=""

EZ_DOMAIN=ezwheelx

###################################################################################################
# Valid IP?####################################################################
###################################################################################################
valid_ip() {
  local ip=$1
  local stat=1

  if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
    OIFS=$IFS
    IFS='.'
    ip=($ip)
    IFS=$OIFS
    [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 &&
      ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
    stat=$?
  fi
  return $stat
}
###################################################################################################
# PURGE CONFIG/CACHE of connman####################################################################
###################################################################################################
clear_connman_conf() {
  #i prefere here the use of no variable ... but absolute path..
  #rm -rf at boot with variables .. it's the better way to make a rm -rf / !!!
  [ -s /etc/connman/main.cf ] && $RMCM -f /etc/connman/main.cf
  [ -s /var/lib/connman/settings ] && $RMCM -f /var/lib/connman/settings >/dev/null 2>&1
  $RMCM -rf /var/lib/connman/ethernet* >/dev/null 2>&1
  $RMCM -rf /var/lib/connman/wifi* >/dev/null 2>&1

  return $OK
}

###################################################################################################
# LOAD VARS FROM .INI FILE ########################################################################
###################################################################################################
load_ini_vars() {

  global_ismaster=$($PARSEINI $EZINI global ismaster | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  master_addres=$($PARSEINI $EZINI global master_addres | $SEDC 's/ //g')
  global_topology=$($PARSEINI $EZINI global topology | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  global_gw=$($PARSEINI $EZINI global global_gw)
  global_dns1=$($PARSEINI $EZINI global global_dns1)
  global_dns2=$($PARSEINI $EZINI global global_dns2)
  global_ntp1=$($PARSEINI $EZINI global global_ntp1 | $SEDC 's/ //g')
  global_ntp2=$($PARSEINI $EZINI global global_ntp2 | $SEDC 's/ //g')
  global_equipment_type=$($PARSEINI $EZINI global equipment_type | $SEDC 's/ //g')
  fw_app_low=$($PARSEINI $EZINI global fw_app_low)
  [ "$fw_app_low" = "" ] && fw_app_low=6000
  fw_app_hig=$($PARSEINI $EZINI global fw_app_hig)
  [ "$fw_app_hig" = "" ] && fw_app_hig=6010

  wlan0_isactive=$($PARSEINI $EZINI wlan0 isactive | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  wlan0_ipaddres=$($PARSEINI $EZINI wlan0 ipaddres | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  wlan0_netmask=$($PARSEINI $EZINI wlan0 netmask | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  # the network admin is allowed to use min/maj and space  !!!! ;)  do not upper nor trim !!
  wlan0_ssid=$($PARSEINI $EZINI wlan0 ssid)
  wlan0_ssid_enc=$($STR2HEXA $wlan0_ssid)
  wlan0_psk=$($PARSEINI $EZINI wlan0 psk)
  wlan0_hiddenssid=$($PARSEINI $EZINI wlan0 hiddenssid | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  wlan0_mac=$($MACC -s wlan0 | $AWKC '{print $3}')
  wlan0_mac_enc=$($ECHO $wlan0_mac | $SEDC 's/://g')
  wlan0_vlanid=$($PARSEINI $EZINI wlan0 vlanid)

  wlan1_isactive=$($PARSEINI $EZINI wlan1 isactive | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  wlan1_ipaddres=$($PARSEINI $EZINI wlan1 ipaddres | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  wlan1_netmask=$($PARSEINI $EZINI wlan1 netmask | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  wlan1_mac=$($MACC -s wlan1 | $AWKC '{print $3}')
  wlan1_channel=$($PARSEINI $EZINI wlan1 channel | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  wlan1_ssid=$($PARSEINI $EZINI wlan1 ssid)
  wlan1_psk=$($PARSEINI $EZINI wlan1 psk)

  wlan1_dhcp=$($PARSEINI $EZINI wlan1 dhcp | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  wlan1_dhcpmin=$($PARSEINI $EZINI wlan1 dhcpmin | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  wlan1_dhcpmax=$($PARSEINI $EZINI wlan1 dhcpmax | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])

  eth0_isactive=$($PARSEINI $EZINI eth0 isactive | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  eth0_ipaddres=$($PARSEINI $EZINI eth0 ipaddres | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  eth0_netmask=$($PARSEINI $EZINI eth0 netmask | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  eth0_mac=$($MACC -s eth0 | $AWKC '{print $3}')
  eth0_dhcp=$($PARSEINI $EZINI eth0 dhcp | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  eth0_dhcpmin=$($PARSEINI $EZINI eth0 dhcpmin | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])
  eth0_dhcpmax=$($PARSEINI $EZINI eth0 dhcpmax | $SEDC 's/ //g' | $TRCM [:lower:] [:upper:])

  return $OK
}

###################################################################################################
# CLEAN          .INI FILE ########################################################################
###################################################################################################

init_etc_file_atboot() {

  $CATC <<EOF_EZW >$EZINI
[global]
ismaster = TRUE
master_addres = 
topology = isolated
global_gw = 
global_dns1 = 
global_dns2 = 
global_ntp1 = 
global_ntp2 =
equipment_type =
fw_app_low = 6000
fw_app_hig = 6010

[wlan0]
isactive = FALSE
ipaddres = dhcp
netmask = 
ssid = 
psk = 
algo = wpa-psk
hiddenssid = FALSE
vlanid = 

[wlan1]
isactive = FALSE
ipaddres = 172.16.177.254
netmask = 255.255.255.0
channel = 11
ssid = wlan1
psk = ezwheel
dhcp = TRUE
dhcpmin = 172.16.177.1
dhcpmax = 172.16.177.200

[eth0]
isactive = TRUE
ipaddres = 172.16.178.254
netmask = 24
dhcp = TRUE
dhcpmin = 172.16.178.1
dhcpmax = 172.16.178.200

[bdd]
path = /opt/ezw/data/ezw.db

EOF_EZW

  return ${OK}

}

###################################################################################################
# UPGRADE VERSION IN DATABASE  ####################################################################
###################################################################################################
update_sql_OSVERSION() {
  if [ -s $DB_MMC_PATH ]; then
    DB_PATH=$DB_MMC_PATH
  else
    return $KO #### not upgrade factory (??)
  fi

  #################
  [ "${CURRENT_RELEASE}" = "" ] && return $OK
  #################

  #################
  echo_simple "Create Table version if not existing .............."
  echo_simple "Create Table version if not existing .............." >>$EZLOG/startup.log
  requeteSQL="CREATE TABLE IF NOT EXISTS versions(active short, version text);"
  ZRequestLine=$($SQLI ${DB_PATH} "${requeteSQL}")
  if [ $? -eq 0 ]; then
    echo_success
    $ECHO "OK" >>$EZLOG/startup.log
  else
    echo_failure
    $ECHO "KO ($SQLI ${DB_PATH} \"${requeteSQL}\")" >>$EZLOG/startup.log
  fi

  #################
  echo_simple "Verify Current Release in database ..............."
  echo_simple "Verify Current Release in database ..............." >>$EZLOG/startup.log
  requeteSQL="SELECT COUNT(*) FROM versions WHERE version='${CURRENT_RELEASE}'"
  ZRequestLine=$($SQLI ${DB_PATH} "${requeteSQL}" 2>/dev/null)
  VerifyRET=$?
  if [ $VerifyRET -eq 0 ]; then
    echo_success
    $ECHO "OK (${ZRequestLine})" >>$EZLOG/startup.log

    if [ $ZRequestLine -eq 0 ]; then
      #################
      echo_simple "Add Current Release (${CURRENT_RELEASE}) in database ..............."
      echo_simple "Add Current Release (${CURRENT_RELEASE}) in database ..............." >>$EZLOG/startup.log
      requeteSQL="INSERT INTO versions VALUES(1,'${CURRENT_RELEASE}');"
      ZRequestLine=$($SQLI ${DB_PATH} "${requeteSQL}" 2>/dev/null)
      if [ $? -eq 0 ]; then
        echo_success
        $ECHO "OK" >>$EZLOG/startup.log
      else
        echo_failure
        $ECHO "KO ($SQLI ${DB_PATH} \"${requeteSQL}\")" >>$EZLOG/startup.log
        return $KO
      fi
      #################
      echo_simple "Invalid older release(s) in database ..............."
      echo_simple "Invalid older release(s) in database ..............." >>$EZLOG/startup.log
      requeteSQL="UPDATE versions SET active=0 WHERE version != '${CURRENT_RELEASE}';"
      ZRequestLine=$($SQLI ${DB_PATH} "${requeteSQL}" 2>/dev/null)
      if [ $? -eq 0 ]; then
        echo_success
        $ECHO "OK" >>$EZLOG/startup.log
      else
        echo_failure
        $ECHO "KO ($SQLI ${DB_PATH} \"${requeteSQL}\")" >>$EZLOG/startup.log
        return $KO
      fi
    fi
  else
    echo_failure
    $ECHO "KO (Return: $VerifyRET) | ($SQLI ${DB_PATH} \"${requeteSQL}\")" >>$EZLOG/startup.log
    return $KO
  fi
}

##############################################################################
#  UPGRADE SQLITE SCHEMA   ###################################################
##############################################################################
upgrade_sql_vars() {
  # Check if db exists
  if [ ! -s $DB_MMC_PATH ]; then
    # Clone factory db
    $CPCM -f $DB_FACTORY_PATH $DB_MMC_PATH

    # No upgrade needed
    return ${OK}
  fi

  ######################################################################
  # NOTA : The commented lines below are let as migration script example
  ######################################################################

  # for DB_PATH in "$DB_MMC_PATH $DB_FACTORY_PATH"
  # do
  #   DB_PATH=$DB_MMC_PATH

  #   for TABLE in "globalconfig" "globalconfig_factory"
  #   do
  #      ###################################################################################################################################################
  #      ####VERSION 0.1.2 : add perception robot/trolley => need a flag in database (globalconfig|globalconfig_factory.equipment_type : TEXT, DEFAULT:ROBOT
  #      ###################################################################################################################################################
  #      $ECHO "Upgrade 0.1.2 : Check equipment_type in mmc database (table ${TABLE}) "
  #      $ECHO "Upgrade 0.1.2 : Check equipment_type in mmc database (table ${TABLE}) " >> $EZLOG/startup.log
  #      #Add Column equipment_type
  #      ZFound=`$SQLI ${DB_PATH} ".schema ${TABLE}" 2>&1 | $GREP -q "equipment_type"`
  #      if [ $? -ne 0 ]; then
  #        # to be added
  #        echo_todo

  #        $ECHO -n "Upgrade 0.1.2 : Add equipment_type  TABLE:${TABLE} DB:${DB_PATH}"
  #        $ECHO -n "Upgrade 0.1.2 : Add equipment_type  TABLE:${TABLE} DB:${DB_PATH}" >> $EZLOG/startup.log

  #        ZFound=`$SQLI ${DB_PATH} "ALTER TABLE ${TABLE} ADD COLUMN equipment_type text DEFAULT \"\";" 2>&1`
  #        if [ $? -ne 0 ]; then
  #            echo_failure
  #            echo ">>> FAILED" >> $EZLOG/startup.log
  #        else
  #            echo_success
  #            echo ">>> OK" >> $EZLOG/startup.log
  #        fi
  #      else
  #       echo_skipped
  #       echo ">>> NOT NECESSARY" >> $EZLOG/startup.log
  #       # found - still in db
  #      fi
  #   done
  # done

  return ${OK}
}

##############################################################################
# EXTRACT VARIABLES FROM SQLITE ##############################################
##############################################################################
load_sql_vars() {
  if [ -s $DB_MMC_PATH ]; then
    DB_PATH=$DB_MMC_PATH
  else
    DB_PATH=$DB_FACTORY_PATH
  fi
  ##Extract global config from sqlite database => inject into ini.file
  ZRequestLine=$($SQLI ${DB_PATH} \
    "SELECT ismaster,master_addres,topology,global_gw,global_dns1,global_dns2,global_ntp1,global_ntp2,equipment_type FROM globalconfig WHERE active=1 ORDER BY datetime_modif ASC LIMIT 1;")
  if [ "${ZRequestLine}" != "" ]; then
    Z_Ini_ismaster=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $1}' | $SEDC 's/ //g')
    [ "${Z_Ini_ismaster}" = "1" ] && Z_Ini_ismaster="TRUE" || Z_Ini_ismaster="FALSE"
    Z_Ini_master_addres=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $2}' | $SEDC 's/ //g')
    Z_Ini_topology=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $3}' | $SEDC 's/ //g')
    Z_Ini_global_gw=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $4}' | $SEDC 's/ //g')
    Z_Ini_global_dns1=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $5}' | $SEDC 's/ //g')
    Z_Ini_global_dns2=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $6}' | $SEDC 's/ //g')
    Z_Ini_global_ntp1=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $7}' | $SEDC 's/ //g')
    Z_Ini_global_ntp2=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $8}' | $SEDC 's/ //g')
    Z_Ini_equipment_type=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $9}' | $SEDC 's/ //g')

    $WRITEINI $EZINI global ismaster "${Z_Ini_ismaster}"
    $WRITEINI $EZINI global master_addres "${Z_Ini_master_addres}"
    $WRITEINI $EZINI global topology "${Z_Ini_topology}"
    $WRITEINI $EZINI global global_gw "${Z_Ini_global_gw}"
    $WRITEINI $EZINI global global_dns1 "${Z_Ini_global_dns1}"
    $WRITEINI $EZINI global global_dns2 "${Z_Ini_global_dns2}"
    $WRITEINI $EZINI global global_ntp1 "${Z_Ini_global_ntp1}"
    $WRITEINI $EZINI global global_ntp2 "${Z_Ini_global_ntp2}"
    $WRITEINI $EZINI global equipment_type "${Z_Ini_equipment_type}"
  fi

  ##Extract wlan0 config from sqlite database => inject into ini.file
  ZRequestLine=$($SQLI ${DB_PATH} \
    "SELECT isactive,ipaddres,netmask,ssid,psk,algo,hiddenssid,vlanid FROM wlan0 WHERE active=1 ORDER BY datetime_modif ASC LIMIT 1;")
  if [ "${ZRequestLine}" != "" ]; then

    Z_Ini_isactive=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $1}' | $SEDC 's/ //g')
    [ "${Z_Ini_isactive}" = "1" ] && Z_Ini_isactive="TRUE" || Z_Ini_isactive="FALSE"
    Z_Ini_ipaddres=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $2}' | $SEDC 's/ //g')
    Z_Ini_netmask=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $3}' | $SEDC 's/ //g')
    # DO NOT SED ' ' to '' on ssid/psk !!!!
    Z_Ini_ssid=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $4}')
    Z_Ini_psk=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $5}')
    Z_Ini_algo=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $6}' | $SEDC 's/ //g')
    Z_Ini_hiddenssid=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $7}' | $SEDC 's/ //g')
    [ "${Z_Ini_hiddenssid}" = "1" ] && Z_Ini_hiddenssid="TRUE" || Z_Ini_hiddenssid="FALSE"
    Z_Ini_vlanid=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $8}')

    $WRITEINI $EZINI wlan0 isactive "${Z_Ini_isactive}"
    $WRITEINI $EZINI wlan0 ipaddres "${Z_Ini_ipaddres}"
    $WRITEINI $EZINI wlan0 netmask "${Z_Ini_netmask}"
    $WRITEINI $EZINI wlan0 ssid "${Z_Ini_ssid}"
    $WRITEINI $EZINI wlan0 psk "${Z_Ini_psk}"
    $WRITEINI $EZINI wlan0 algo "${Z_Ini_algo}"
    $WRITEINI $EZINI wlan0 hiddenssid "${Z_Ini_hiddenssid}"
    $WRITEINI $EZINI wlan0 vlanid "${Z_Ini_vlanid}"
  fi

  ZRequestLine=$($SQLI ${DB_PATH} \
    "SELECT isactive,ipaddres,netmask,ssid,psk,channel,dhcp,dhcpmin,dhcpmax FROM wlan1 WHERE active=1 ORDER BY datetime_modif ASC LIMIT 1;")
  if [ "${ZRequestLine}" != "" ]; then
    Z_Ini_isactive=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $1}' | $SEDC 's/ //g')
    [ "${Z_Ini_isactive}" = "1" ] && Z_Ini_isactive="TRUE" || Z_Ini_isactive="FALSE"
    Z_Ini_ipaddres=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $2}' | $SEDC 's/ //g')
    Z_Ini_netmask=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $3}' | $SEDC 's/ //g')
    # DO NOT SED ' ' to '' on ssid/psk !!!!
    Z_Ini_ssid=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $4}')
    Z_Ini_psk=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $5}')
    Z_Ini_channel=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $6}' | $SEDC 's/ //g')
    Z_Ini_dhcp=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $7}' | $SEDC 's/ //g')
    [ "${Z_Ini_dhcp}" = "1" ] && Z_Ini_dhcp="TRUE" || Z_Ini_dhcp="FALSE"
    Z_Ini_dhcpmin=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $8}' | $SEDC 's/ //g')
    Z_Ini_dhcpmax=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $9}' | $SEDC 's/ //g')

    $WRITEINI $EZINI wlan1 isactive "${Z_Ini_isactive}"
    $WRITEINI $EZINI wlan1 ipaddres "${Z_Ini_ipaddres}"
    $WRITEINI $EZINI wlan1 netmask "${Z_Ini_netmask}"
    $WRITEINI $EZINI wlan1 ssid "${Z_Ini_ssid}"
    $WRITEINI $EZINI wlan1 psk "${Z_Ini_psk}"
    $WRITEINI $EZINI wlan1 channel "${Z_Ini_channel}"
    $WRITEINI $EZINI wlan1 dhcp "${Z_Ini_dhcp}"
    $WRITEINI $EZINI wlan1 dhcpmin "${Z_Ini_dhcpmin}"
    $WRITEINI $EZINI wlan1 dhcpmax "${Z_Ini_dhcpmax}"
  fi

  ZRequestLine=$($SQLI ${DB_PATH} \
    "SELECT isactive,ipaddres,netmask, \
   dhcp,dhcpmin,dhcpmax FROM eth0 WHERE active=1 ORDER BY datetime_modif ASC LIMIT 1;")

  if [ "${ZRequestLine}" != "" ]; then

    Z_Ini_isactive=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $1}' | $SEDC 's/ //g')
    [ "${Z_Ini_isactive}" = "1" ] && Z_Ini_isactive="TRUE" || Z_Ini_isactive="FALSE"
    Z_Ini_ipaddres=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $2}' | $SEDC 's/ //g')
    Z_Ini_netmask=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $3}' | $SEDC 's/ //g')
    Z_Ini_dhcp=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $4}' | $SEDC 's/ //g')
    [ "${Z_Ini_dhcp}" = "1" ] && Z_Ini_dhcp="TRUE" || Z_Ini_dhcp="FALSE"
    Z_Ini_dhcpmin=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $5}' | $SEDC 's/ //g')
    Z_Ini_dhcpmax=$($ECHO $ZRequestLine | $AWKC -F '|' '{print $6}' | $SEDC 's/ //g')

    $WRITEINI $EZINI eth0 isactive "${Z_Ini_isactive}"
    $WRITEINI $EZINI eth0 ipaddres "${Z_Ini_ipaddres}"
    $WRITEINI $EZINI eth0 netmask "${Z_Ini_netmask}"
    $WRITEINI $EZINI eth0 dhcp "${Z_Ini_dhcp}"
    $WRITEINI $EZINI eth0 dhcpmin "${Z_Ini_dhcpmin}"
    $WRITEINI $EZINI eth0 dhcpmax "${Z_Ini_dhcpmax}"
  fi
  return $OK
}

#############################################################################
# Connman default config                      ###############################
# connman exclude eth0 and wlan1 (not managed) ##############################
#############################################################################
connman_global_config() { # not working on all wifi ssid .. poor stability with hidden ssid
  ######################
  ## NOT USED ANYMORE !!
  ######################
  [ ! -d ${CONNMAN_CONF} ] && $MKDI ${CONNMAN_CONF}

  $ECHO "[global]" >${CONNMAN_CONF}/settings
  $ECHO "OfflineMode=false" >>${CONNMAN_CONF}/settings
  $ECHO "[Wired]" >>${CONNMAN_CONF}/settings
  $ECHO "Enable=false" >>${CONNMAN_CONF}/settings
  $ECHO "Tethering=false" >>${CONNMAN_CONF}/settings
  $ECHO "[WiFi]" >>${CONNMAN_CONF}/settings
  $ECHO "Enable=true" >>${CONNMAN_CONF}/settings
  $ECHO "Tethering=false" >>${CONNMAN_CONF}/settings
  $ECHO "[P2P]" >>${CONNMAN_CONF}/settings
  $ECHO "Enable=false" >>${CONNMAN_CONF}/settings
  $ECHO "Tethering=false" >>${CONNMAN_CONF}/settings
  [ ! -d ${CONNMAN_ETCDIR} ] && $MKDI ${CONNMAN_ETCDIR}

  $ECHO "[General]" >${CONNMAN_MAIN}
  $ECHO "InputRequestTimeout=120" >>${CONNMAN_MAIN}
  $ECHO "BrowserLaunchTimeout=300" >>${CONNMAN_MAIN}
  $ECHO "BackgroundScanning=true" >>${CONNMAN_MAIN}
  $ECHO "DefaultAutoConnectTechnologies=wifi" >>${CONNMAN_MAIN}
  $ECHO "PreferredTechnologies=wifi" >>${CONNMAN_MAIN}
  $ECHO "NetworkInterfaceBlacklist=eth0,wlan1" >>${CONNMAN_MAIN}
  $ECHO "AllowHostnameUpdates=false" >>${CONNMAN_MAIN}
  $ECHO "SingleConnectedTechnology=false" >>${CONNMAN_MAIN}
  $ECHO "TetheringTechnologies=wifi" >>${CONNMAN_MAIN}
  $ECHO "PersistentTetheringMode=false" >>${CONNMAN_MAIN}

  return $OK
}

#############################################################################
# Build /etc/network/interfaces part for wlan1 ###############################
# static IP
#############################################################################
ifconf_wlan1_config() {
  #variables usables
  #wlan1_isactive
  #wlan1_ipaddres [ correct IP or DHCP ]
  #wlan1_netmask
  #IFCONF_CONFIG

  [ "$wlan1_isactive" != "TRUE" ] && return $ABORT

  #in this case echo more lisible than cat eof ...

  $ECHO "auto wlan1" >>${IFCONF_CONFIG}
  if [ "$wlan1_ipaddres" = "DHCP" ]; then
    $ECHO "iface wlan1 inet dhcp" >>${IFCONF_CONFIG}
  else
    $ECHO "iface wlan1 inet static" >>${IFCONF_CONFIG}
    $ECHO "  address ${wlan1_ipaddres}" >>${IFCONF_CONFIG}
    $ECHO "  netmask ${wlan1_netmask}" >>${IFCONF_CONFIG}
  fi
  $ECHO "" >>${IFCONF_CONFIG}

  return $OK
}

#############################################################################
# Build /etc/hostapd.conf (hotspot wifi on wlan1) ###########################
# 80211n
# country: FR
# WPA2/PSK
# OPTIONNAL: configuration of channel
#############################################################################
hostapd_wlan1_config() {
  #variables usables
  #wlan1_isactive
  #wlan1_ipaddres [ correct IP or DHCP ]
  #wlan1_netmask
  #wlan1_mac
  #wlan1_channel
  #wlan1_ssid
  #wlan1_psk

  if [ "$wlan1_isactive" != "TRUE" ]; then
    #if wlan1 is disabled, hostapd may not run... remove file.
    $RMCM -f ${HOSTAPD_CONF} >/dev/null 2>&1
    return $ABORT
  fi

  #in this case echo more lisible than cat eof ...
  $ECHO "ctrl_interface=/var/run/hostapd" >${HOSTAPD_CONF}
  $ECHO "ctrl_interface_group=0" >>${HOSTAPD_CONF}
  $ECHO "interface=wlan1" >>${HOSTAPD_CONF}
  $ECHO "driver=nl80211" >>${HOSTAPD_CONF}
  $ECHO "ssid=${wlan1_ssid}" >>${HOSTAPD_CONF}
  $ECHO "auth_algs=1" >>${HOSTAPD_CONF}
  $ECHO "wpa=2" >>${HOSTAPD_CONF}
  $ECHO "country_code=FR" >>${HOSTAPD_CONF}
  #WPA2-AES encryption #####################################
  $ECHO "wpa_key_mgmt=WPA-PSK" >>${HOSTAPD_CONF}
  $ECHO "wpa_pairwise=CCMP" >>${HOSTAPD_CONF}
  $ECHO "wpa_psk_radius=0" >>${HOSTAPD_CONF}
  $ECHO "rsn_pairwise=CCMP" >>${HOSTAPD_CONF}
  $ECHO "wpa_group_rekey=86400" >>${HOSTAPD_CONF}
  $ECHO "wpa_strict_rekey=1" >>${HOSTAPD_CONF}
  $ECHO "wpa_gmk_rekey=8640" >>${HOSTAPD_CONF}
  ##########################################################
  $ECHO "wpa_passphrase=${wlan1_psk}" >>${HOSTAPD_CONF}
  $ECHO "#IEEE-80211n" >>${HOSTAPD_CONF}
  #802.11n
  $ECHO "hw_mode=g" >>${HOSTAPD_CONF}
  $ECHO "ieee80211n=1" >>${HOSTAPD_CONF}

  [ "$wlan1_channel" != "" ] && $ECHO "channel=${wlan1_channel}" >>${HOSTAPD_CONF}

  return $OK
}

#############################################################################
# Initialize /etc/network/interfaces  and configure Loopback#################
#############################################################################
ifconf_lo_config() {
  #in this case echo more lisible than cat eof ...
  $ECHO "#configuration file for ifup(8),ifdown(8)" >$IFCONF_CONFIG
  $ECHO "# The loopback interface" >>$IFCONF_CONFIG
  $ECHO "auto lo" >>$IFCONF_CONFIG
  $ECHO "iface lo inet loopback" >>$IFCONF_CONFIG
  $ECHO "" >>$IFCONF_CONFIG

  return $OK
}

#############################################################################
# Build /etc/network/interfaces part for eth0 ###############################
# static IP
#############################################################################

#ifconf_eth0_config()
#{
#  #variables usables
#  #eth0_isactive
#  #eth0_ipaddres [ correct IP or DHCP ]
#  #eth0_netmask
#  #IFCONF_CONFIG
#
#  [ "$eth0_isactive" != "TRUE" ] && return $ABORT
#
#  #in this case echo more lisible than cat eof ...
#
#  $ECHO "auto eth0"                                >> $IFCONF_CONFIG
#  if [ "$eth0_ipaddres" = "DHCP" ]; then
#     $ECHO "iface eth0 inet dhcp"                     >> $IFCONF_CONFIG
#  else
#     $ECHO "iface eth0 inet static"                   >> $IFCONF_CONFIG
#     $ECHO "  address ${eth0_ipaddres}"               >> $IFCONF_CONFIG
#     $ECHO "  netmask ${eth0_netmask}"                >> $IFCONF_CONFIG
#  fi
#
#  return $OK
#}

#############################################################################
# Build global configuration for nm                       ###################
#############################################################################

set_nm_globalconf() {
  $CATC <<EOF_EZW >$NMGLOBAL_CONF
[main]
plugins=ifupdown,keyfile
#no-auto-default=type:ethernet
rc-manager=file
[ifupdown]
managed=true
[keyfile]
unmanaged-devices=interface-name:p2p*;interface-name:wlan1;
#unmanaged-devices=interface-name:p2p*;
[device]
wifi.scan-rand-mac-address=no
EOF_EZW

  #remove previous configs..
  $RMCM -f /etc/NetworkManager/system-connections/*

  return $OK
}

#############################################################################
#  Configure and start eth0 interface                     ###################
#############################################################################
setstart_eth0_config() {
  #####usable vars ####
  #eth0_isactive=""
  #eth0_ipaddres=""
  #eth0_netmask=""

  if [ "$eth0_isactive" != "TRUE" ]; then
    #if wlan1 is disabled, hostapd may not run... remove file.
    return $OK
  fi

  NBVERIF=$($NMCL c s | $GREP eth0 | wc -l)
  if [ $NBVERIF -ge 1 ]; then
    $ECHO ""
    $ECHO "Remove all old references FROM NM"
    $NMCL c delete eth0 2>&1 1>/dev/null || CONF_ERROR=1
  fi

  CONF_ERROR=0
  [ "$eth0_isactive" != "TRUE" ] && return $ABORT

  $ECHO "Adding Interface eth0 (${eth0_ipaddres}/${eth0_netmask})"
  $NMCL con add con-name eth0 ifname eth0 type ethernet ip4 "${eth0_ipaddres}/${eth0_netmask}" 2>&1 1>/dev/null || CONF_ERROR=2
  $ECHO "Up interface eth0"
  $NMCL con up eth0 2>&1 1>/dev/null || CONF_ERROR=3
  return $CONF_ERROR
}

#############################################################################
# Configure and start wlan1 interface                     ###################
#############################################################################
#setstart_wlan1_config()
#{
#####usable vars ####
#
#wlan1_isactive=""
#wlan1_ipaddres=""
#wlan1_netmask=""
### hostapd is using other wlan1 variables..
###########################################

#   [ "$wlan1_isactive" != "TRUE" ] && return $OK
#   CONF_ERROR=0
#   #remove all references to wlan1
#   NBVERIF=`$NMCL c s | $GREP wlan1 |wc -l`
#   if [ $NBVERIF -ge 1 ]; then
#      $ECHO ""
#      $ECHO "Remove all old references FROM NM"
#      $NMCL c delete wlan1 2>&1 1>/dev/null|| CONF_ERROR=1
#   fi
#
#   $NMCL c add type wifi con-name wlan1 ifname wlan1 ssid "${wlan1_ssid}" 2>&1 1>/dev/null|| CONF_ERROR=2
#
#   if [ "${wlan1_ipaddres}" = "DHCP" ]; then
#      $ECHO "set ipv4 dhcp"
#      $NMCL c modify wlan1 ipv4.method auto 2>&1 1>/dev/null || CONF_ERROR=3
#   else
#      $ECHO "set wlan1 ipv4 static (${wlan1_ipaddres}/${wlan1_netmask})"
#      $NMCL c modify wlan1 ipv4.method manual ipv4.addr "${wlan1_ipaddres}/${wlan1_netmask}"  2>&1 1>/dev/null|| CONF_ERROR=4
#   fi
#   $ECHO "set wlan1  ipv6 ignore"
#   $NMCL c modify wlan1 ipv6.method ignore 2>&1 1>/dev/null || CONF_ERROR=5
#   $NMCL con up wlan1 || CONF_ERROR=1
#   return $CONF_ERROR
#}

#############################################################################
# Configure and start wlan0 interface                     ###################
#############################################################################
setstart_wlan0_config() {
  #####usable vars ####
  #
  #wlan0_isactive=""
  #wlan0_ipaddres=""
  #wlan0_netmask=""
  #wlan0_ssid=""
  #wlan0_hiddenssid=""
  #wlan0_ssid_enc=""
  #wlan0_psk=""
  #wlan0_mac=""
  #wlan0_mac_enc=""
  #global_topology=""
  #global_gw=""
  ###########################################

  if [ "$global_topology" != "ISOLATED" -a "${wlan0_isactive}" = "TRUE" ] || [ "$global_topology" = "ISOLATED" -a "$global_ismaster" = "FALSE" ]; then
    CONF_ERROR=0
    #remove all references to wlan0
    $ECHO "Remove all old references FROM NM"
    $NMCL c delete wlan0 2>&1 1>/dev/null || CONF_ERROR=1
    #
    $ECHO ""
    $ECHO "" >>$EZLOG/startup.log

    wlan0_psk_cypher=$($WPAP "${wlan0_ssid}" "${wlan0_psk}" | $GREP -v '#psk' | $GREP 'psk' | $AWKC -F '=' '{print $2'})
    #SSID2CONNECT=`$ECHO ${wlan0_ssid} | $SEDC 's/^"//g' | $SEDC 's/"$//g'`

    if [ "${wlan0_hiddenssid}" = "TRUE" ]; then
      echo_simple "Adding wlan0 to NM"
      echo_simple "Adding wlan0 to NM" >>$EZLOG/startup.log
      #IFS='<>'
      $NMCL c add type wifi ifname wlan0 con-name wlan0 autoconnect yes ssid "${wlan0_ssid}" 2>&1 1>/dev/null
      if [ $? -eq 0 ]; then
        $ECHO "OK" >>$EZLOG/startup.log
        echo_success
      else
        $ECHO "KO" >>$EZLOG/startup.log
        echo_failure
        CONF_ERROR=2
      fi
      #IFS=' '
      echo_simple "set wlan0 hidden"
      echo_simple "set wlan0 hidden" >>$EZLOG/startup.log
      $NMCL c modify wlan0 802-11-wireless.hidden true 2>&1 1>/dev/null
      if [ $? -eq 0 ]; then
        $ECHO "OK" >>$EZLOG/startup.log
        echo_success
      else
        $ECHO "KO" >>$EZLOG/startup.log
        echo_failure
        CONF_ERROR=3
      fi

      echo_simple "set security wpa-psk"
      echo_simple "set security wpa-psk" >>$EZLOG/startup.log
      $NMCL c modify wlan0 wifi-sec.key-mgmt wpa-psk wifi-sec.psk "${wlan0_psk_cypher}" 2>&1 1>/dev/null
      if [ $? -eq 0 ]; then
        $ECHO "OK" >>$EZLOG/startup.log
        echo_success
      else
        $ECHO "KO" >>$EZLOG/startup.log
        echo_failure
        CONF_ERROR=4
      fi

    else

      echo_simple "Adding wlan0 to NM"
      echo_simple "Adding wlan0 to NM" >>$EZLOG/startup.log
      $NMCL c add type wifi ifname wlan0 con-name wlan0 autoconnect yes ssid "${wlan0_ssid}" 2>&1 1>/dev/null
      if [ $? -eq 0 ]; then
        $ECHO "OK" >>$EZLOG/startup.log
        echo_success
      else
        $ECHO "KO" >>$EZLOG/startup.log
        echo_failure
        CONF_ERROR=2
      fi

      echo_simple "set security wpa-psk"
      echo_simple "set security wpa-psk" >>$EZLOG/startup.log

      $NMCL c modify wlan0 wifi-sec.key-mgmt wpa-psk wifi-sec.psk "${wlan0_psk_cypher}" 2>&1 1>/dev/null || CONF_ERROR=4
      if [ $? -eq 0 ]; then
        $ECHO "OK" >>$EZLOG/startup.log
        echo_success
      else
        $ECHO "KO" >>$EZLOG/startup.log
        echo_failure
        CONF_ERROR=4
      fi

    fi

    if [ "${wlan0_ipaddres}" = "DHCP" ]; then
      echo_simple "set ipv4 dhcp"
      echo_simple "set ipv4 dhcp" >>$EZLOG/startup.log

      $NMCL c modify wlan0 ipv4.method auto 2>&1 1>/dev/null
      if [ $? -eq 0 ]; then
        $ECHO "OK" >>$EZLOG/startup.log
        echo_success
      else
        $ECHO "KO" >>$EZLOG/startup.log
        echo_failure
        CONF_ERROR=5
      fi
    else
      if valid_ip ${wlan0_ipaddres}; then

        echo_simple "set wlan0 ipv4 static (${wlan0_ipaddres}/${wlan0_netmask})"
        echo_simple "set wlan0 ipv4 static (${wlan0_ipaddres}/${wlan0_netmask})" >>$EZLOG/startup.log
        $NMCL c modify wlan0 ipv4.method manual ipv4.addr "${wlan0_ipaddres}/${wlan0_netmask}" 2>&1 1>/dev/null
        if [ $? -eq 0 ]; then
          $ECHO "OK" >>$EZLOG/startup.log
          echo_success
        else
          $ECHO "KO" >>$EZLOG/startup.log
          echo_failure
          CONF_ERROR=6
        fi

        echo_simple "set wlan0 ipv4 gateway (${global_gw})"
        echo_simple "set wlan0 ipv4 gateway (${global_gw})" >>$EZLOG/startup.log
        $NMCL c modify wlan0 ipv4.gateway ${global_gw} 2>&1 1>/dev/null
        if [ $? -eq 0 ]; then
          $ECHO "OK" >>$EZLOG/startup.log
          echo_success
        else
          $ECHO "KO" >>$EZLOG/startup.log
          echo_failure
          CONF_ERROR=7
        fi

      else
        $ECHO "Not a valid IP address for wlan0"
        $ECHO "Not a valid IP address for wlan0" >>$EZLOG/startup.log
        CONF_ERROR=8
      fi
    fi

    echo_simple "set wlan0 ipv6 ignore"
    echo_simple "set wlan0 ipv6 ignore" >>$EZLOG/startup.log
    $NMCL c modify wlan0 ipv6.method ignore 2>&1 1>/dev/null
    if [ $? -eq 0 ]; then
      $ECHO "OK" >>$EZLOG/startup.log
      echo_success
    else
      $ECHO "KO" >>$EZLOG/startup.log
      echo_failure
      CONF_ERROR=9
    fi

    #############################
    echo_simple "Bring UP WLAN0"
    echo_simple "Bring UP WLAN0" >>$EZLOG/startup.log
    $NMCL con up wlan0
    if [ $? -ne 0 ]; then
      #################################
      #.. wait 5 seconds and retry ..#
      #################################
      $SLEE 5
      $NMCL con up wlan0
      if [ $? -ne 0 ]; then
        #.. wait x0 seconds more and retry #
        $ECHO "KO" >>$EZLOG/startup.log
        echo_failure

        echo_simple "Bring UP WLAN0 (2nd Attempt)"
        echo_simple "Bring UP WLAN0 (2nd Attempt)" >>$EZLOG/startup.log
        $SLEE 30

        $NMCL con up wlan0
        if [ $? -ne 0 ]; then
          $ECHO "KO" >>$EZLOG/startup.log
          echo_failure
          CONF_ERROR=10 #### HERE IT'S A BIG PROBLEM ....!
        else
          $ECHO "OK" >>$EZLOG/startup.log
          echo_success
          CONF_ERROR=0
        fi
      else
        $ECHO "OK" >>$EZLOG/startup.log
        echo_success
        CONF_ERROR=0
      fi
    fi
    if [ ! "${wlan0_vlanid}" = "" ]; then
      echo_simple "Create VLAN interface for WLAN0"
      echo_simple "Create VLAN interface for WLAN0" >>$EZLOG/startup.log
      $NMCL con add type vlan con-name VLAN${wlan0_vlanid} dev wlan0 id ${wlan0_vlanid}
      if [ $? -ne 0 ]; then
        $ECHO "KO" >>$EZLOG/startup.log
        echo_failure
        CONF_ERROR=11
      else
        $ECHO "OK" >>$EZLOG/startup.log
        echo_success
        CONF_ERROR=0
      fi
    fi
    return $CONF_ERROR
  fi
}

#############################################################################
# Configure resolver if necessary                         ###################
#############################################################################
config_resolver_service() {
  #####usable vars ####
  #wlan0_isactive=""
  #global_topology=""
  ###########################################
  if [ "$global_topology" != "ISOLATED" -a "${wlan0_isactive}" = "TRUE" ] || [ "$global_topology" = "ISOLATED" -a "$global_ismaster" = "FALSE" ]; then
    if [ "${wlan0_ipaddres}" = "DHCP" ]; then
      $ECHO "##1###Generated by EZWHEEL initialisation process (static address)" >${RESOLVED_CONF}
      $ECHO "#  This file is part of systemd. " >>${RESOLVED_CONF}
      $ECHO "#  systemd is free software; you can redistribute it and/or modify it " >>${RESOLVED_CONF}
      $ECHO "#  under the terms of the GNU Lesser General Public License as published by " >>${RESOLVED_CONF}
      $ECHO "#  the Free Software Foundation; either version 2.1 of the License, or " >>${RESOLVED_CONF}
      $ECHO "#  (at your option) any later version. " >>${RESOLVED_CONF}
      $ECHO "# Entries in this file show the compile time defaults. " >>${RESOLVED_CONF}
      $ECHO "# You can change settings by editing this file. " >>${RESOLVED_CONF}
      $ECHO "# Defaults can be restored by simply deleting this file. " >>${RESOLVED_CONF}
      $ECHO "# See resolved.conf(5) for details " >>${RESOLVED_CONF}
      $ECHO "[Resolve]" >>${RESOLVED_CONF}
      $ECHO "#DNS=127.0.0.1" >>${RESOLVED_CONF}
      #disapointing patch ... systemd-resolved.service do not register dns in this case ... why ????
      if [ "${global_ismaster}" = "FALSE" ]; then
        $ECHO "DNS=${master_addres}" >>${RESOLVED_CONF}
      fi
    else
      dnslist="$global_dns1 $global_dns2"
      $ECHO "##2###Generated by EZWHEEL initialisation process (static address)" >${RESOLVED_CONF}
      $ECHO "#  This file is part of systemd. " >>${RESOLVED_CONF}
      $ECHO "#  systemd is free software; you can redistribute it and/or modify it " >>${RESOLVED_CONF}
      $ECHO "#  under the terms of the GNU Lesser General Public License as published by " >>${RESOLVED_CONF}
      $ECHO "#  the Free Software Foundation; either version 2.1 of the License, or " >>${RESOLVED_CONF}
      $ECHO "#  (at your option) any later version. " >>${RESOLVED_CONF}
      $ECHO "# Entries in this file show the compile time defaults. " >>${RESOLVED_CONF}
      $ECHO "# You can change settings by editing this file. " >>${RESOLVED_CONF}
      $ECHO "# Defaults can be restored by simply deleting this file. " >>${RESOLVED_CONF}
      $ECHO "# See resolved.conf(5) for details " >>${RESOLVED_CONF}
      $ECHO "[Resolve]" >>${RESOLVED_CONF}
      $ECHO "DNS=${dnslist}" >>${RESOLVED_CONF}
    fi
  else
    $ECHO "##3##Generated by EZWHEEL initialisation process (static address)" >${RESOLVED_CONF}
    $ECHO "#  This file is part of systemd. " >>${RESOLVED_CONF}
    $ECHO "#  systemd is free software; you can redistribute it and/or modify it " >>${RESOLVED_CONF}
    $ECHO "#  under the terms of the GNU Lesser General Public License as published by " >>${RESOLVED_CONF}
    $ECHO "#  the Free Software Foundation; either version 2.1 of the License, or " >>${RESOLVED_CONF}
    $ECHO "#  (at your option) any later version. " >>${RESOLVED_CONF}
    $ECHO "# Entries in this file show the compile time defaults. " >>${RESOLVED_CONF}
    $ECHO "# You can change settings by editing this file. " >>${RESOLVED_CONF}
    $ECHO "# Defaults can be restored by simply deleting this file. " >>${RESOLVED_CONF}
    $ECHO "# See resolved.conf(5) for details " >>${RESOLVED_CONF}
    $ECHO "[Resolve]" >>${RESOLVED_CONF}
    #DNS for slave IS the momomaster ...
    $ECHO "DNS=${master_addres}" >>${RESOLVED_CONF}
  fi
  return $OK
}

#############################################################################
#BUILD /etc/iptables.rules  #################################################
#############################################################################
load_iptables_rules() {
  [ ! -s ${IPTABLES_RULES} ] && return $ABORT
  [ ! -x $IPTAR ] && return $ABORT

  $IPTAR <${IPTABLES_RULES} && return $OK || return $FAILURE
}

#############################################################################
#BUILD /etc/iptables.rules  #################################################
#############################################################################
build_iptables_rules() {
  #we must deals with ok variables before ... rathing than inside function!
  #usable variables
  #global_ismaster
  #global_topology
  #IPTABLES_RULES

  #memo:
  #allowed topology: isolated connected hosted
  #isolated  : work on an independant network segment without uplink to the customer's network
  #connected : work on an independant connected to the customer's network (uplink)
  #hosted    : fully integrated to the customer's network, master is hosted by customer

  $ECHO "*nat" >${IPTABLES_RULES}
  $ECHO ":PREROUTING ACCEPT [0:0]" >>${IPTABLES_RULES}
  $ECHO ":INPUT ACCEPT [0:0]" >>${IPTABLES_RULES}
  $ECHO ":OUTPUT ACCEPT [0:0]" >>${IPTABLES_RULES}
  $ECHO ":POSTROUTING ACCEPT [0:0]" >>${IPTABLES_RULES}
  $ECHO "-A POSTROUTING -o wlan0 -j MASQUERADE" >>${IPTABLES_RULES}
  $ECHO "COMMIT" >>${IPTABLES_RULES}
  $ECHO "*filter" >>${IPTABLES_RULES}
  $ECHO ":INPUT   ACCEPT [0:0]" >>${IPTABLES_RULES}
  $ECHO ":FORWARD ACCEPT [0:0]" >>${IPTABLES_RULES}
  $ECHO ":OUTPUT  ACCEPT [0:0]" >>${IPTABLES_RULES}
  ###############################
  ############LO  ###############
  ###############################
  #loopback : ok for any protocol
  $ECHO "-A INPUT  -i lo                                                                 -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A OUTPUT -o lo                                                                 -j ACCEPT" >>${IPTABLES_RULES}
  ###############################
  ############WLAN1##############
  ###############################
  #TCP: Allow output if established session..
  $ECHO "-A OUTPUT  -o wlan1 -m tcp -p tcp                                               -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A OUTPUT  -o wlan1 -m udp -p udp                                               -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A OUTPUT  -o wlan1 -p icmp --icmp-type echo-reply                              -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A OUTPUT  -o wlan1 -p icmp --icmp-type echo-request                            -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A INPUT   -i wlan1 -p icmp --icmp-type echo-request                            -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A INPUT   -i wlan1 -p icmp --icmp-type echo-reply                              -j ACCEPT" >>${IPTABLES_RULES}
  #RELATED CONNECTIONS ...
  $ECHO "-A INPUT   -i wlan1 -m state --state RELATED,ESTABLISHED                        -j ACCEPT" >>${IPTABLES_RULES}
  #SSH
  $ECHO "-A INPUT   -i wlan1 -m tcp -p tcp  --dport  22                                  -j ACCEPT" >>${IPTABLES_RULES}
  #HTTPS
  $ECHO "-A INPUT   -i wlan1 -m tcp -p tcp  --dport 443                                  -j ACCEPT" >>${IPTABLES_RULES}
  #APP PORTS - free use - register in /etc/services
  $ECHO "-A INPUT   -i wlan1 -m tcp -p tcp  --dport ${fw_app_low}:${fw_app_hig}          -j ACCEPT" >>${IPTABLES_RULES}
  #DNS
  $ECHO "-A INPUT   -i wlan1 -m udp -p udp  --dport 53                                   -j ACCEPT" >>${IPTABLES_RULES}
  #DHCP
  $ECHO "-A INPUT   -i wlan1 -m udp -p udp  --dport 67:68 --sport 67:68                  -j ACCEPT" >>${IPTABLES_RULES}
  #NTP
  $ECHO "-A INPUT   -i wlan1 -m udp -p udp  --dport 123                                  -j ACCEPT" >>${IPTABLES_RULES}
  ###############################
  ############ETH0###############
  ###############################
  $ECHO "-A OUTPUT  -o eth0 -m tcp -p tcp                                                -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A OUTPUT  -o eth0 -m udp -p udp                                                -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A OUTPUT  -o eth0 -p icmp --icmp-type echo-reply                               -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A OUTPUT  -o eth0 -p icmp --icmp-type echo-request                             -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A INPUT   -i eth0 -p icmp --icmp-type echo-request                             -j ACCEPT" >>${IPTABLES_RULES}
  $ECHO "-A INPUT   -i eth0 -p icmp --icmp-type echo-reply                               -j ACCEPT" >>${IPTABLES_RULES}
  #RELATED CONNECTIONS ...
  $ECHO "-A INPUT   -i eth0 -m state --state RELATED,ESTABLISHED                         -j ACCEPT" >>${IPTABLES_RULES}
  #SSH
  $ECHO "-A INPUT   -i eth0 -m tcp -p tcp  --dport  22                                   -j ACCEPT" >>${IPTABLES_RULES}
  #HTTPS
  $ECHO "-A INPUT   -i eth0 -m tcp -p tcp  --dport 443                                   -j ACCEPT" >>${IPTABLES_RULES}
  #DNS
  $ECHO "-A INPUT   -i eth0 -m udp -p udp  --dport 53                                    -j ACCEPT" >>${IPTABLES_RULES}
  #DHCP
  $ECHO "-A INPUT   -i eth0 -m udp -p udp  --dport 67:68 --sport 67:68                   -j ACCEPT" >>${IPTABLES_RULES}
  #Free Open Ports
  $ECHO "-A INPUT   -i eth0 -m tcp -p tcp  --dport ${fw_app_low}:${fw_app_hig}          -j ACCEPT" >>${IPTABLES_RULES}

  ###############################
  ############WLAN0###############
  ###############################
  if [ "$global_ismaster" = "TRUE" ]; then
    case "$global_topology" in
    "ISOLATED")
      #everthing locked on uplink port# normmaly down, wlan0 have to be isolated by firewall.
      $ECHO "-A INPUT   -i wlan0                                                             -j DROP" >>${IPTABLES_RULES}
      $ECHO "-A OUTPUT  -o wlan0                                                             -j DROP" >>${IPTABLES_RULES}
      ;;
    "CONNECTED" | "HOSTED")
      #statefull firewall: any communication allow from device.
      $ECHO "-A OUTPUT  -o wlan0 -m state --state NEW,RELATED,ESTABLISHED                    -j ACCEPT" >>${IPTABLES_RULES}
      $ECHO "-A OUTPUT  -o wlan0 -p icmp --icmp-type echo-reply                              -j ACCEPT" >>${IPTABLES_RULES}
      $ECHO "-A OUTPUT  -o wlan0 -p icmp --icmp-type echo-request                            -j ACCEPT" >>${IPTABLES_RULES}
      $ECHO "-A INPUT   -i wlan0 -p icmp --icmp-type echo-request                            -j ACCEPT" >>${IPTABLES_RULES}
      $ECHO "-A INPUT   -i wlan0 -p icmp --icmp-type echo-reply                              -j ACCEPT" >>${IPTABLES_RULES}
      #return packets are ok.
      $ECHO "-A INPUT   -i wlan0 -m state --state RELATED,ESTABLISHED                        -j ACCEPT" >>${IPTABLES_RULES}
      #SSH
      $ECHO "-A INPUT   -i wlan0 -m tcp -p tcp  --dport  22                                  -j ACCEPT" >>${IPTABLES_RULES}
      #HTTPS
      $ECHO "-A INPUT   -i wlan0 -m tcp -p tcp  --dport 443                                  -j ACCEPT" >>${IPTABLES_RULES}
      #DNS : NO . forbidden on uplink
      $ECHO "-A INPUT   -i wlan0 -m udp -p udp  --dport 53                                   -j DROP" >>${IPTABLES_RULES}
      #DHCP: NO . forbidden on uplink
      $ECHO "-A INPUT   -i wlan0 -m udp -p udp  --dport 67:68 --sport 67:68                  -j DROP" >>${IPTABLES_RULES}
      #Free Open Ports
      $ECHO "-A INPUT   -i wlan0 -m tcp -p tcp  --dport ${fw_app_low}:${fw_app_hig}          -j ACCEPT" >>${IPTABLES_RULES}

      #statefull firewall: any communication allow from device. # if vpn mounted after, iptables rules still ok
      $ECHO "-A OUTPUT  -o tun16 -m state --state NEW,RELATED,ESTABLISHED                    -j ACCEPT" >>${IPTABLES_RULES}
      $ECHO "-A OUTPUT  -o tun16 -p icmp --icmp-type echo-reply                              -j ACCEPT" >>${IPTABLES_RULES}
      $ECHO "-A OUTPUT  -o tun16 -p icmp --icmp-type echo-request                            -j ACCEPT" >>${IPTABLES_RULES}
      $ECHO "-A INPUT   -i tun16 -p icmp --icmp-type echo-request                            -j ACCEPT" >>${IPTABLES_RULES}
      $ECHO "-A INPUT   -i tun16 -p icmp --icmp-type echo-reply                              -j ACCEPT" >>${IPTABLES_RULES}
      #return packets are ok.
      $ECHO "-A INPUT   -i tun16 -m state --state RELATED,ESTABLISHED                        -j ACCEPT" >>${IPTABLES_RULES}
      #SSH
      $ECHO "-A INPUT   -i tun16 -m tcp -p tcp  --dport  22                                  -j ACCEPT" >>${IPTABLES_RULES}
      #HTTPS
      $ECHO "-A INPUT   -i tun16 -m tcp -p tcp  --dport 443                                  -j ACCEPT" >>${IPTABLES_RULES}
      #DNS : NO . forbidden on uplink
      $ECHO "-A INPUT   -i tun16 -m udp -p udp  --dport 53                                   -j DROP" >>${IPTABLES_RULES}
      #DHCP: NO . forbidden on uplink
      $ECHO "-A INPUT   -i tun16 -m udp -p udp  --dport 67:68 --sport 67:68                  -j DROP" >>${IPTABLES_RULES}
      #Free Open Ports
      $ECHO "-A INPUT   -i tun16 -m tcp -p tcp  --dport ${fw_app_low}:${fw_app_hig}          -j ACCEPT" >>${IPTABLES_RULES}

      ##############VPN #######################
      ;;
    *) ;;

      #drop all?
    esac
  else ## global_ismaster=false ##
    case "$global_topology" in
    "ISOLATED" | "CONNECTED" | "HOSTED")
      #everthing locked on uplink port# normmaly down,it's a slave: connected on a "trusted" network ...
      #we could evaluate the possibility of opening 22/80/443/6000:6010 TCP and OUTPUT#
      #WAF will do the job.
      $ECHO "-A INPUT   -i wlan0                                                     -j ACCEPT" >>${IPTABLES_RULES}
      $ECHO "-A OUTPUT  -o wlan0                                                     -j ACCEPT" >>${IPTABLES_RULES}
      ;;
    *)
      #should not happen !!
      ;;
    esac
  fi
  $ECHO "-A INPUT                                                                        -j DROP" >>${IPTABLES_RULES}
  $ECHO "-A OUTPUT                                                                       -j DROP" >>${IPTABLES_RULES}
  $ECHO "COMMIT" >>${IPTABLES_RULES}
  #
  return $OK
}

#############################################################################
#CONFIGURE HOSTS
#############################################################################

configure_etc_host() {
  ###########################################################################
  #if [ "$global_ismaster" = "TRUE" ];then
  #else
  #fi
  #by design, the db is filled with all robots if master, and only himself if slave..
  #so i think we can fill host with the whole db.robots content..
  ###########################################################################
  #
  #first write: init with localhost
  #wlan1_ipaddres=""
  #eth0_ipaddres=""
  #wlan1_isactive=""
  #eth0_isactive=""
  #HOST_NAME
  #global_ismaster=""
  $ECHO "127.0.0.1  localhost localhost" >/etc/hosts

  #dnsmasq run with --localise-queries: Answer DNS queries based on the interface a query was sent to.
  #we can have 2 entries with same hostname.
  #if [ "${wlan1_isactive}" = "TRUE" ] ; then
  #  $ECHO "${wlan1_ipaddres} ${HOST_NAME}" >> /etc/hosts
  #fi
  #if [ "${eth0_isactive}" = "TRUE" ]; then
  #  $ECHO "${eth0_ipaddres} ${HOST_NAME}" >>/etc/hosts
  #fi
  #if [ "${wlan1_isactive}" = "TRUE" ]; then
  #  $ECHO "${wlan1_ipaddres} ${HOST_NAME}" >>/etc/hosts
  #fi

  if [ -s $DB_MMC_PATH ]; then
    DB_PATH=$DB_MMC_PATH
  else
    DB_PATH=$DB_FACTORY_PATH
  fi

  ######################################################
  #only flagged robots as ezwheel are published in dns.#
  #only on master.                                     #
  ######################################################
  if [ "${global_ismaster}" = "TRUE" ]; then
    #hard coded : layoutmaster
    #ip management for the layout is on wlan1 hotspot ...

    $ECHO "${wlan1_ipaddres} layoutmaster" >>/etc/hosts
    #
    for ZRobot_Line in $($SQLI ${DB_PATH} "SELECT macaddress,name,ipaddress FROM hosts WHERE is_ez_robot=1;"); do
      #MAC , then NAME, then IP, trim each variable.
      ZRobot_MAC=$($ECHO $ZRobot_Line | $AWKC -F '|' '{print $1}' | $SEDC 's/ //g')
      ZRobot_NAM=$($ECHO $ZRobot_Line | $AWKC -F '|' '{print $2}' | $SEDC 's/ //g' | $TRCM [:upper:] [:lower:])
      ZRobot_AIP=$($ECHO $ZRobot_Line | $AWKC -F '|' '{print $3}' | $SEDC 's/ //g')
      $ECHO "${ZRobot_AIP} ${ZRobot_NAM}" >>/etc/hosts
    done
    #add alias
    for ZRobot_Line in $($SQLI ${DB_PATH} "select robots.idmomo,hosts.ipaddress FROM robots,hosts WHERE robots.name=hosts.name AND hosts.is_ez_robot=1;"); do
      ZRobot_IDMO=$($ECHO $ZRobot_Line | $AWKC -F '|' '{print $1}' | $SEDC 's/ //g' | $TRCM [:upper:] [:lower:])
      ZRobot_ADIP=$($ECHO $ZRobot_Line | $AWKC -F '|' '{print $2}' | $SEDC 's/ //g')
      $ECHO "${ZRobot_ADIP} ${ZRobot_IDMO}" >>/etc/hosts
    done
  fi
  return $OK
}

#############################################################################
#CONFIGURE NSSWITCH
#############################################################################

configure_nsswitch_conf() {

  $CATC <<EOF_EZW >$NSSWITCH_CONF
passwd:         compat
group:          compat
shadow:         compat
hosts:          files dns
networks:       files
protocols:      files
services:       files
ethers:         files
rpc:            files
EOF_EZW

  return $OK
}

#############################################################################
#CONFIGURE  DNSMASQ          ################################################
#############################################################################
configure_dnsmasq_conf() {
  #  if [ "$global_ismaster" = "FALSE" ];then
  #     #sure that dnsmasq could not start ...  empty file.
  #     $ECHO "" > ${DNSMASQ_CONF}
  #     return ${OK}
  #  fi
  #DNSMASQ_CONF=/etc/dnsmasq.conf
  $ECHO "### EZWHEEL AUTO GENERATED CONFIGURATION DNSMASQ (dns/dhcp)" >${DNSMASQ_CONF}
  $ECHO "" >>${DNSMASQ_CONF}
  #bind on port 53
  $ECHO "port=53" >${DNSMASQ_CONF}
  $ECHO "strict-order" >>${DNSMASQ_CONF}
  #$ECHO "domain-needed" >> ${DNSMASQ_CONF}
  $ECHO "domain=ezw" >>${DNSMASQ_CONF}
  $ECHO "expand-hosts" >>${DNSMASQ_CONF}
  $ECHO "bogus-priv" >>${DNSMASQ_CONF}
  $ECHO "resolv-file=/etc/resolv.conf" >>${DNSMASQ_CONF}
  #no gateway push by dhcp ... no routing.
  $ECHO "dhcp-option=3" >>${DNSMASQ_CONF}

  if [ "$wlan1_dhcp" = "TRUE" ]; then
    #listen on wlan1 (interface downlink)
    $ECHO "interface=wlan1" >>${DNSMASQ_CONF}
    $ECHO "dhcp-range=wlan1,${wlan1_dhcpmin},${wlan1_dhcpmax},30m" >>${DNSMASQ_CONF}
    #ntp for each subnet
    $ECHO "dhcp-option=wlan1,option:ntp-server,${wlan1_ipaddres}" >>${DNSMASQ_CONF}
    $ECHO "dhcp-option=wlan1,6,${wlan1_ipaddres}" >>${DNSMASQ_CONF}
  fi
  if [ "$eth0_dhcp" = "TRUE" ]; then
    #listen on eth0 (copper interface)
    $ECHO "interface=eth0" >>${DNSMASQ_CONF}
    $ECHO "dhcp-range=eth0,${eth0_dhcpmin},${eth0_dhcpmax},5m" >>${DNSMASQ_CONF}
    $ECHO "dhcp-option=eth0,option:ntp-server,${eth0_ipaddres}" >>${DNSMASQ_CONF}
    $ECHO "dhcp-option=eth0,6,${eth0_ipaddres}" >>${DNSMASQ_CONF}
  fi
  #disable logging (logs on stdout)
  $ECHO "log-facility=-" >>${DNSMASQ_CONF}
  #
  $ECHO "" >>${DNSMASQ_CONF}

  if [ -s $DB_MMC_PATH ]; then
    DB_PATH=$DB_MMC_PATH
  else
    DB_PATH=$DB_FACTORY_PATH
  fi

  for ZRobot_Line in $($SQLI ${DB_PATH} "SELECT macaddress,name,ipaddress FROM hosts WHERE is_ez_robot=1"); do
    #MAC , then NAME, then IP, trim each variable.
    ZRobot_MAC=$($ECHO $ZRobot_Line | $AWKC -F '|' '{print $1}' | $SEDC 's/ //g')
    ZRobot_NAM=$($ECHO $ZRobot_Line | $AWKC -F '|' '{print $2}' | $SEDC 's/ //g')
    ZRobot_AIP=$($ECHO $ZRobot_Line | $AWKC -F '|' '{print $3}' | $SEDC 's/ //g')
    $ECHO "dhcp-host=${ZRobot_MAC},${ZRobot_AIP},${ZRobot_NAM},168h" >>${DNSMASQ_CONF}
  done
  #################################################
  return $OK
}

#############################################################################
#CONFIGURE  NTP          ################################################
#############################################################################
configure_ntp_conf() {
  #usable vars
  #eth0_ipaddres=""
  #eth0_netmask=""
  #eth0_isactive=""
  #wlan1_ipaddres=""
  #wlan1_netmask=""
  #wlan1_isactive=""
  #global_ismaster=""
  #global_ntp1=""
  #global_ntp2=""

  $ECHO "#EZWHEEL Configuration process" >${NTP_CONF}
  $ECHO "driftfile /var/lib/ntp/drift" >>${NTP_CONF}

  RANGE_ETH0=$($IPCA ${eth0_ipaddres}/${eth0_netmask} | $GREP 'HostMin' | $SEDC 's/HostMin://g' | $AWKC -F '=' '{print $1}' | $SEDC 's/ //g' | $SEDC 's/\t//g')
  RANGE_ETH0=$($IPCA ${eth0_ipaddres}/${eth0_netmask} | $GREP 'HostMin' | $SEDC 's/HostMin://g' | $AWKC -F '=' '{print $1}' | $SEDC 's/ //g' | $SEDC 's/\t//g')
  RANGE_WLA1=$($IPCA ${wlan1_ipaddres}/${wlan1_netmask} | $GREP 'HostMin' | $SEDC 's/HostMin://g' | $AWKC -F '=' '{print $1}' | $SEDC 's/ //g' | $SEDC 's/\t//g')
  NETM_ETH0=$($IPCA ${eth0_ipaddres}/${eth0_netmask} | $GREP 'Netmask' | $SEDC 's/Netmask://g' | $AWKC -F '=' '{print $1}' | $SEDC 's/ //g' | $SEDC 's/\t//g')
  NETM_WLA1=$($IPCA ${wlan1_ipaddres}/${wlan1_netmask} | $GREP 'Netmask' | $SEDC 's/Netmask://g' | $AWKC -F '=' '{print $1}' | $SEDC 's/ //g' | $SEDC 's/\t//g')
  BROA_ETH0=$($IPCA ${eth0_ipaddres}/${eth0_netmask} | $GREP 'Broadcast' | $SEDC 's/Broadcast://g' | $AWKC -F '=' '{print $1}' | $SEDC 's/ //g' | $SEDC 's/\t//g')
  BROA_WLA1=$($IPCA ${wlan1_ipaddres}/${wlan1_netmask} | $GREP 'Broadcast' | $SEDC 's/Broadcast://g' | $AWKC -F '=' '{print $1}' | $SEDC 's/ //g' | $SEDC 's/\t//g')

  if [ "$global_ismaster" = "TRUE" ]; then
    #set ntp1 & ntp2 (it's suficient!) sent by database..
    [ "$global_ntp1" != "" ] && $ECHO "server ${global_ntp1}" >>${NTP_CONF}
    [ "$global_ntp2" != "" ] && $ECHO "server ${global_ntp2}" >>${NTP_CONF}
    #
    #fallback allow hardware clock with stratum 10
    $ECHO "server 127.127.1.0 prefer " >>${NTP_CONF}
    $ECHO "fudge  127.127.1.0 stratum 10 " >>${NTP_CONF}
    $ECHO "driftfile /var/lib/ntp/drift " >>${NTP_CONF}
    $ECHO "broadcastdelay 0.008 " >>${NTP_CONF}
    #all rights to localhost
    $ECHO "restrict 127.0.0.1" >>${NTP_CONF}
    #finaly, only wlan1 on master need to allow ntp client .. i don't care about maintenance pc!
    #allo ntp connection from wlan1
    [ "$wlan1_isactive" = "TRUE" ] && $ECHO "interface listen ${wlan1_ipaddres}" >>${NTP_CONF}
    [ "$wlan1_isactive" = "TRUE" ] && $ECHO "restrict ${RANGE_WLA1} mask ${NETM_WLA1} nomodify notrap" >>${NTP_CONF}
    [ "$wlan1_isactive" = "TRUE" ] && $ECHO "broadcast ${BROA_WLA1}" >>${NTP_CONF}

  else
    #ntp server is robot.
    $ECHO "server ${master_addres} iburst" >>${NTP_CONF}
  fi
  return $OK
}

#############################################################################
#CONFIGURE  CRON ROOT        ################################################
#############################################################################

configure_cron() {
  #CRON_SRC=$EZETC/cron_root
  #CRON_DST=/var/spool/cron/root

  ToRet=$KO

  if [ -s $CRON_SRC ]; then
    $CPCM -f $CRON_SRC $CRON_DST 1>/dev/null 2>&1 && ToRet=$OK || ToRet=$KO
  else
    ToRet=$KO
  fi
  return $ToRet
}

#############################################################################
#CONFIGURE  CORE DUMPER        ##############################################
#############################################################################
configure_coredumper() {
  ToRet=$KO

  [ ! -d $COREDUMP_PATH ] && return $ToRet

  if [ -s $COREDUMP_GEN_SRC ]; then
    $CPCM -f $COREDUMP_GEN_SRC $COREDUMP_GEN_DST 1>/dev/null 2>&1
    [ $? -ne 0 ] && return 22 || ToRet=$OK
  fi

  if [ -s $COREDUMP_CFG_SRC ]; then
    $CPCM -f $COREDUMP_CFG_SRC $COREDUMP_CFG_DST 1>/dev/null 2>&1
    [ $? -ne 0 ] && return 23 || ToRet=$OK
  fi
  return $ToRet
}

#############################################################################
#CONFIGURE  OTHERS           ################################################
#############################################################################

set_config_js_ui_interface() {

  INTERFACE=$1
  [ "$INTERFACE" = "" ] && $ECHO "No interface provided" && return $KO
  UI_CONFIG_PATH=/opt/ezw/www/ui/${INTERFACE}
  Z_IP=$(/sbin/ip -o -4 a s ${INTERFACE} | /usr/bin/awk '{ print $4 }' | /usr/bin/cut -d/ -f1)

  if [ ! -d "$UI_CONFIG_PATH" ]; then
    mkdir -p "$UI_CONFIG_PATH"
  fi

  #  if [ ! -s $UI_CONFIG_PATH/config.js.template ]; then
  $ECHO "var environment = {" >$UI_CONFIG_PATH/config.js
  $ECHO "production: false," >>$UI_CONFIG_PATH/config.js
  $ECHO "api_user_url: \"https://${Z_IP}/api/auth\"," >>$UI_CONFIG_PATH/config.js
  $ECHO "api_fleet_url: \"https://${Z_IP}/api/fleet/v1\"," >>$UI_CONFIG_PATH/config.js
  $ECHO "domain_name: \"https://${Z_IP}\"" >>$UI_CONFIG_PATH/config.js
  $ECHO "};" >>$UI_CONFIG_PATH/config.js
  #  else
  #   $CATC $UI_CONFIG_PATH/config.js.template | $SEDC "s/<ADD_FLEET>/${Z_IP}/g" > $UI_CONFIG_PATH/config.js
  #  fi
  return $OK
}

check_data_dirs() {

  local OPTIND OPTARG opt TODOFORMAT TODOFSTAB TODODATA TODOOPENVPN TODOMOUNTDIR

  TODOFORMAT=0
  TODOFSTAB=0
  TODODATA=0
  TODOOPENVPN=0
  TODOMOUNTDIR=0

  echo_simple "Extract parameters ........................................."
  echo_simple "Extract parameters ........................................." >>$EZLOG/startup.log

  while getopts "p:" opt; do
    case "${opt}" in
    p) #fichier output
      PARTITION="${OPTARG}"
      ;;
    esac
  done

  if [ "$PARTITION" != "" ]; then
    echo_success
    $ECHO ">>> OK ( < ${PARTITION} > passed in parameter)" >>$EZLOG/startup.log
  else
    $ECHO ">>>No partition provided in parameter" >>$EZLOG/startup.log
    echo_failure
    return $KO
  fi

  echo_simple "Check params ..${PARTITION} not mmcblk2p1 nor mmcblk2p2................................."
  echo_simple "Check params ..${PARTITION} not mmcblk2p1 nor mmcblk2p2................................." >>$EZLOG/startup.log

  if [ "$PARTITION" = "mmcblk2p1" ] || [ "$PARTITION" = "mmcblk2p2" ]; then
    echo_warning
    $ECHO "${PARTITION} ? ... sure ? do it manually please................"
    $ECHO "${PARTITION} ? ... sure ? do it manually please................" >>$EZLOG/startup.log
    return $ABORT
  else
    $ECHO ">>> OK" >>$EZLOG/startup.log
    echo_success
  fi

  #########################################################################
  echo_simple "Check exists /dev/${PARTITION} ............................"
  echo_simple "Check exists /dev/${PARTITION} ............................" >>$EZLOG/startup.log
  if [ -e /dev/${PARTITION} ]; then
    $ECHO ">>> OK" >>$EZLOG/startup.log
    echo_success
  else
    echo_failure
    $ECHO ">>> KO" >>$EZLOG/startup.log
    return $KO
  fi

  #########################################################################
  echo_simple "Check formatted /dev/${PARTITION} .........................."
  echo_simple "Check formatted /dev/${PARTITION} .........................." >>$EZLOG/startup.log
  $BLKI /dev/${PARTITION} | $GREP -q "ext" 1>/dev/null 2>&1
  if [ $? -eq 0 ]; then
    $ECHO ">>> OK" >>$EZLOG/startup.log
    echo_success
    TODOFORMAT=0
  else
    $ECHO ">>> TODO" >>$EZLOG/startup.log
    echo_todo
    TODOFORMAT=1
  fi

  #########################################################################
  echo_simple "Check directory /opt/ezw/emmc .............................."
  echo_simple "Check directory /opt/ezw/emmc .............................." >>$EZLOG/startup.log
  if [ ! -d /opt/ezw/emmc ]; then
    echo_todo
    $ECHO ">>> TODO" >>$EZLOG/startup.log
    TODOMOUNTDIR=1
  else
    $ECHO ">>> OK" >>$EZLOG/startup.log
    echo_success
    TODOMOUNTDIR=0
  fi

  #########################################################################
  echo_simple "Check fstab ................................................"
  echo_simple "Check fstab ${PARTITION} in /etc/fstab........................." >>$EZLOG/startup.log
  $GREP -q ${PARTITION} /etc/fstab 1>/dev/null 2>&1
  if [ $? -eq 0 ]; then
    $ECHO ">>> OK" >>$EZLOG/startup.log
    echo_success
    TODOFSTAB=0
  else
    echo_todo
    $ECHO ">>> TODO" >>$EZLOG/startup.log
    TODOFSTAB=1
  fi

  #########################################################################
  if [ $TODOFORMAT -eq 1 ]; then
    echo_simple "!!!!!Formatting Partition ${PARTITION} .........................."
    echo_simple "!!!!!Formatting Partition ${PARTITION} .........................." >>$EZLOG/startup.log
    $MKFS -L 'EZDATAS' -F /dev/${PARTITION}
    if [ $? -eq 0 ]; then
      $ECHO ">>> OK" >>$EZLOG/startup.log
      echo_success
    else
      $ECHO ">>> KO" >>$EZLOG/startup.log
      echo_failure
      return $KO
    fi
  else
    echo_skipped
  fi
  #########################################################################
  if [ $TODOMOUNTDIR -eq 1 ]; then
    echo_simple "Build /opt/ezw/emmc ......................................"
    echo_simple "Build /opt/ezw/emmc ......................................" >>$EZLOG/startup.log
    $MKDI -p /opt/ezw/emmc
    if [ $? -eq 0 ]; then
      $ECHO ">>> OK" >>$EZLOG/startup.log
      echo_success
    else
      echo_failure
      $ECHO ">>> KO" >>$EZLOG/startup.log
      return $KO
    fi
  else
    echo_skipped
  fi
  #########################################################################
  echo_simple "Add ${PARTITION} to fstab .................................."
  echo_simple "Add ${PARTITION} to fstab .................................." >>$EZLOG/startup.log

  if [ $TODOFSTAB -eq 1 ]; then
    $CPCM /etc/fstab /etc/fstab.bKp
    $ECHO "/dev/${PARTITION}  /opt/ezw/emmc    ext4  defaults,sync  0  0" >>/etc/fstab
    if [ $? -eq 0 ]; then
      $ECHO ">>> OK" >>$EZLOG/startup.log
      echo_success
    else
      $ECHO ">>> KO" >>$EZLOG/startup.log
      echo_failure
    fi
    echo_simple "Verify ${PARTITION} is present in fstab ..................."
    echo_simple "Verify ${PARTITION} is present in fstab ......................" >>$EZLOG/startup.log
    $GREP -q ${PARTITION} /etc/fstab 1>/dev/null 2>&1
    if [ $? -eq 0 ]; then
      $ECHO ">>> OK" >>$EZLOG/startup.log
      echo_success
    else
      $ECHO ">>> KO" >>$EZLOG/startup.log
      echo_failure
      return $KO
    fi
  else
    $ECHO ">>> STILL " >>$EZLOG/startup.log
    echo_skipped
  fi
  #########################################################################
  echo_simple "Mounting ${PARTITION} ......................................"
  echo_simple "Mounting ${PARTITION} ......................................" >>$EZLOG/startup.log
  $MOUN /opt/ezw/emmc 1>/dev/null 2>&1
  returnval=$?
  if [ $returnval -eq 0 ]; then
    $ECHO ">>> OK" >>$EZLOG/startup.log
    echo_success
  else
    if [ $returnval -eq 32 ]; then
      $ECHO ">>> STILL ($returnval) " >>$EZLOG/startup.log
      echo_skipped
    else
      $ECHO ">>> KO" >>$EZLOG/startup.log
      echo_failure
      return $KO
    fi
  fi

  #partition is now mounted ####
  #########################################################################
  if [ ! -d /opt/ezw/emmc/openvpn ]; then
    echo_simple "Create Target directory (/opt/ezw/emmc/openvpn)..................."
    echo_simple "Create Target directory (/opt/ezw/emmc/openvpn)..................." >>$EZLOG/startup.log
    $MKDI -p /opt/ezw/emmc/openvpn
    if [ $? -eq 0 ]; then
      $ECHO ">>> OK" >>$EZLOG/startup.log
      echo_success
    else
      $ECHO ">>> KO" >>$EZLOG/startup.log
      echo_failure
    fi
  fi
  #########################################################################

  if [ ! -d /opt/ezw/emmc/logs ]; then
    echo_simple "Create Not Existing (/opt/ezw/emmc/logs)...................."
    echo_simple "Create Not Existing (/opt/ezw/emmc/logs)...................." >>$EZLOG/startup.log
    $MKDI -p /opt/ezw/emmc/logs >>$EZLOG/startup.log
    if [ $? -eq 0 ]; then
      $ECHO ">>> OK" >>$EZLOG/startup.log
      echo_success
    else
      $ECHO ">>> KO" >>$EZLOG/startup.log
      echo_failure
    fi
  fi

  #########################################################################
  if [ ! -d /opt/ezw/emmc/data ]; then
    $ECHO "***********************************" >>$EZLOG/startup.log
    $ECHO "Debug : what in /opt/ezw/emmc?" >>$EZLOG/startup.log
    /bin/ls /opt/ezw/emmc/* >>$EZLOG/startup.log
    $ECHO "" >>$EZLOG/startup.log
    $ECHO "***********************************" >>$EZLOG/startup.log
    ###
    echo_simple "Create Target directory ...................................."
    echo_simple "Create Target directory (/opt/ezw/emmc/data)..................." >>$EZLOG/startup.log
    $MKDI -p /opt/ezw/emmc/data
    if [ $? -eq 0 ]; then
      $ECHO ">>> OK" >>$EZLOG/startup.log
      echo_success
    else
      $ECHO ">>> KO" >>$EZLOG/startup.log
      echo_failure
    fi
    ###
    echo_simple "Chown ezw target directory ...................................."
    echo_simple "Chown ezw target directory (/opt/ezw/emmc/data) ....................." >>$EZLOG/startup.log
    $CHOW -R ezw /opt/ezw/emmc/data
    if [ $? -eq 0 ]; then
      $ECHO ">>> OK" >>$EZLOG/startup.log
      echo_success
    else
      $ECHO ">>> KO" >>$EZLOG/startup.log
      echo_failure
    fi
    ###
    echo_simple "!!!!!!!!! Deploying factory database ................................."
    echo_simple "!!!!!!!!! Deploying factory database ................................." >>$EZLOG/startup.log
    $CPCM -f ${EZDAT}.FACTORY/* /opt/ezw/emmc/data/ 1>/dev/null 2>&1
    if [ $? -eq 0 ]; then
      $ECHO ">>> OK" >>$EZLOG/startup.log
      echo_success
    else
      $ECHO ">>> KO" >>$EZLOG/startup.log
      echo_failure
      return $KO
    fi
  fi

  $ECHO ""
  $ECHO "" >>$EZLOG/startup.log
  return $OK
}

###################################################################################################
###################################################################################################
###################################################################################################

check_ssh() {

  #no backup ssh found => create it
  if [ ! -d $EZSSH ]; then
    $MKDI -p $EZSSH
  fi

  for ssh_file in "ssh_host_dsa_key" "ssh_host_dsa_key.pub" "ssh_host_ecdsa_key" "ssh_host_ecdsa_key.pub" "ssh_host_ed25519_key" "ssh_host_ed25519_key.pub" "ssh_host_rsa_key" "ssh_host_rsa_key.pub"; do
    if [ -s $EZSSH/$ssh_file ]; then
      #restore backup
      $CPCM -f $EZSSH/$ssh_file /etc/ssh/$ssh_file
    else
      #do backup
      $CPCM -f /etc/ssh/$ssh_file $EZSSH/$ssh_file
    fi
  done
  return $OK
}

###################################################################################################
###################################################################################################
###################################################################################################
do_reload_can() {

  ##########################################################################################
  # function have to be called with 2 functions
  # do_reload_can <DEBUG [0|1]> "canX" (can0 by default)
  #
  # if no arg passed to function, values are forced to DEBUG=1 & INTERFACE="can0"
  ##########################################################################################

  DODEBUG=$1
  INTERFACE=$2
  #by default: debug on
  [ "$DODEBUG" = "" ] && DODEBUG=1
  #by default: can0
  [ "$INTERFACE" = "" ] && INTERFACE="can0"

  #Default return value.
  STATUS_RELOAD=$OK

  #CAN: bitrate 1Mbps, soft restart automatic on failure on 100ms. keepalive on $WAITINTERVAL (2s), txqueuelen 1000

  # Two ways of running this function.
  # DODEBUG = 1 => only show in console (systemctl status ez.keepcan0_up.service) the state/status
  # DODEBUG = 0 => effective restart of the CAN stack.
  #             => down $INTERFACE
  #             => unload flexcan kernel module (flush stack)
  #             => load flexcan kernel module
  #             => up interface with $OPTIONS options.

  if [ $DODEBUG -eq 1 ]; then # only show in console : TODO (in blue) for debug reasons.#

    $PRIN "%-80.80s" "DEBUG: Reloading CAN0" && echo_todo
    $PRIN "%-80.80s" "DEBUG:-> $IPCMD link set down $INTERFACE" && echo_todo
    #$PRIN "%-80.80s" "DEBUG:-> $RMMOD flexcan" && echo_todo
    #$PRIN "%-80.80s" "DEBUG:-> $SLEE 1" && echo_todo
    #$PRIN "%-80.80s" "DEBUG:-> $PROB flexcan" && echo_todo
    $PRIN "%-80.80s" "DEBUG:-> $SLEE 1" && echo_todo
    $PRIN "%-80.80s" "DEBUG:-> $IPCMD link set can0 up $OPTIONS" && echo_todo
    $PRIN "%-80.80s" "DEBUG:-> $IFCF $INTERFACE txqueuelen ${TXQUEUELEN}" && echo_todo
  else # effective reload of can interface.
    $PRIN "%-80.80s" "Reloading CAN0..." && $ECHO ""
    $PRIN "%-80.80s" "-->IP DOWN $INTERFACE"
    $IPCMD link set down $INTERFACE 1>/dev/null 2>&1
    echo_success
    #$PRIN "%-80.80s" "-->RMMOD flexcan"
    #$RMMOD flexcan 1>/dev/null 2>&1
    #echo_success
    #$PRIN "%-80.80s" "-->WAIT 1s"
    #$SLEE 1
    # if [ $? -eq 0 ]; then
    #   echo_success
    # else
    #   echo_failure
    #   STATUS_RELOAD=$FAILURE
    # fi
    # $PRIN "%-80.80s" "-->MODPROBE flexcan"
    #$PROBE flexcan
    # if [ $? -eq 0 ]; then
    #   echo_success
    # else
    #   echo_failure
    #   STATUS_RELOAD=$FAILURE
    # fi
    $PRIN "%-80.80s" "-->WAIT 1s"
    $SLEE 1
    if [ $? -eq 0 ]; then
      echo_success
    else
      echo_failure
      STATUS_RELOAD=$FAILURE
    fi
    $PRIN "%-80.80s" "-->IP UP $INTERFACE"
    $IPCMD link set $INTERFACE up $OPTIONS
    if [ $? -eq 0 ]; then
      echo_success
    else
      echo_failure
      STATUS_RELOAD=$FAILURE
    fi
    $PRIN "%-80.80s" "-->IFCONFIG $INTERFACE"
    $IFCF $INTERFACE txqueuelen ${TXQUEUELEN}
    if [ $? -eq 0 ]; then
      echo_success
    else
      echo_failure
      STATUS_RELOAD=$FAILURE
    fi
  fi
  return $STATUS_RELOAD
}

###########################################################################################################
###########################################################################################################
###########################################################################################################
do_survey_can0() {
  #Start counter
  LOOP=1
  ######################################################
  #Passed in parameters . 5 by default if not mentionned.
  NB_LOOP=$1
  [ "$NB_LOOP" = "" ] && NB_LOOP=5
  ######################################################
  HEAVY=1
  status=""
  #the state status is not the role of this function ..... (?)

  #clean our previous f** shit before
  [ -s $TMPFILE2 ] && $RMCM -f $TMPFILE2

  while [ $LOOP -le $NB_LOOP ]; do

    $IPCMD -details -statistics link show can0 >$TMPFILE2
    #can state ERROR-WARNING (berr-counter tx 128 rx 0) restart-ms 0
    status=$($CATC $TMPFILE2 | $GREP -i "can state" | $AWKC '{print $3}')

    $PRIN "%-80.80s" "$LOOP of NB_LOOP , now in status $status .."
    case $status in
    #back in normal state
    #exit from loop and from function
    "ERROR-WARNING" | "ERROR_ACTIVE")
      echo_success
      #only case to return OK (0)...
      return $OK
      ;;
    "ERROR-BUSHEAVY")
      #next loop
      echo_passed
      ;;
    "ERROR-BUSOFF")
      #failed in BUSOFF ...
      echo_failure
      return $FAILURE
      ;;
    "STOPPED")
      #failed in ... Should not arrive => state DOWN , scopped before.
      echo_failure
      return $FAILURE
      ;;
    *)
      #dont' know what to do...
      #next loop for now...
      echo_passed
      ;;
    esac
    LOOP=$((START_LOOP + 1))
    $SLEEP $WAITINTERVAL
  done

  [ -s $TMPFILE2 ] && $RMCM -f $TMPFILE2
  return $FAILURE
}

##################################################################################################################################################
# STARTING EZW STACK
##################################################################################################################################################
#EZUSR=$EZ/usr
#EZUSRBIN=$EZUSR/bin
#EZUSRETC=$EZUSR/etc
#EZUSRLIB=$EZUSR/lib

DBUS_ID_TMP="$EZTMP/SYSTEMCTL_dbus.id"
SCENARIO="$EZDAT/scenario.sh"
SCENARIO_MANU="$EZDAT/scenario_manu.sh"
SERVICE_NOT_READY=999

# PYTHON APPS

# BINARIES APPS
MONSERVI="$EZUSRBIN/ezw-monitoring-service $EZINI"
CANOPEN="$EZUSRBIN/ezw-canopen-service $EZUSRETC/ezw-canopen-service/nodes_som.csv $EZUSRETC/ezw-canopen-service/pdo_mapping.csv"
#IOSERVI="$EZUSRBIN/ezw-io-service $EZUSRETC/ezw-io-service/config.ini $EZUSRETC/ezw-io-service/config.csv"
SWD_LEFT="$EZUSRBIN/ezw-smc-service $EZUSRETC/ezw-smc-core/swd_left_config.ini"
SWD_RIGHT="$EZUSRBIN/ezw-smc-service $EZUSRETC/ezw-smc-core/swd_right_config.ini"

#######################################################
check_dbus() {
  if [ -s "$DBUS_ID_TMP" ]; then
    $DEBUG export $(cat $DBUS_ID_TMP)
  else
    #NO DBUS file => no session.
    $ECHO "FATAL - NO DBUS SESSION YET AVAILABLE ... "
    exit $SERVICE_NOT_READY
  #  $EZSBI/dbus-daemon-launch
  #  LD_LIBRARY_PATH_SAV="$LD_LIBRARY_PATH"
  #  unset LD_LIBRARY_PATH
  #  $DEBUG dbus-launch >$DBUS_ID_TMP
  #  $DEBUG export $(cat $DBUS_ID_TMP)
  #  LD_LIBRARY_PATH="$LD_LIBRARY_PATH_SAV"
  fi
}

#######################################################
load_dbus() {
  $ECHO ""
  if [ -s "$DBUS_ID_TMP" ]; then
    $ECHO "FOUND $DBUS_ID_TMP"
    $ECHO "Exporting following variables :"
    $CATC $DBUS_ID_TMP
    export $($CATC $DBUS_ID_TMP)
  else
    #NO DBUS file => no session.
    $ECHO "FATAL - NO DBUS SESSION YET AVAILABLE ... "
    exit $SERVICE_NOT_READY
  fi
}

#######################################################
load_wait_dbus() {
  $ECHO ""
  while [ ! -s "$DBUS_ID_TMP" ]; do
    $ECHO "WAITING FOR DBUS SESSION ...  WAIT ${DBUSWAIT}s ....."
    $SLEE $DBUSWAIT
  done
  #
  $ECHO "FOUND $DBUS_ID_TMP"
  $ECHO "Exporting following variables :"
  $CATC $DBUS_ID_TMP
  export $(cat $DBUS_ID_TMP)
}

#######################################################
check_can() {
  do_reload_can 0 "can0"
}

#######################################################
check_vcan() {
  if [ "$(ifconfig | grep "vcan0")" != "" ]; then
    echo "Can itface vcan0 is not set up. Setting up..."
    $DEBUG sudo ip link add dev vcan0 type vcan bitrate 1000000
    $DEBUG ip link set down can0
    $DEBUG ip link set up vcan0
  fi
}

#######################################################
launch() {
  if [ ! -e "$2.pipe" ]; then
    $MKFI "$2.pipe"
  fi

  #eval "$1" |& $FTEE "$2.pipe" | $EGREP --line-buffered ";WARN;|;ERROR;" >>"$2"
  eval "$1" |& $EGREP --line-buffered ";WARN;|;ERROR;" >>"$2"
  return ${PIPESTATUS[0]}

  #eval "$1" >> "$2"
  #return $?
}

FUNCTIONS_SOURCED=1
