#!/bin/bash

#
# Copyright (C) 2021 ez-Wheel S.A.S.
#

source /opt/ezw/lib/functions.res
export LD_LIBRARY_PATH=$EZUSRLIB
LOCKFILE=$EZTMP/sce_stack.lck

# Go
ZFILE="$EZUSRLOG/sce_stack.log"
case "$1" in
"start")
  NOW=$(date +"%Y-%m-%d %T")
  $ECHO "##########################" >>$ZFILE
  $ECHO "Starting Release Version : ${CURRENT_RELEASE}" >>$ZFILE
  $ECHO "$NOW" >>$ZFILE
  $ECHO "##########################" >>$ZFILE

  #############################################################
  #load variables from file ..
  #############################################################
  $ECHO ""
  $PRIN "%-80.80s" "loading ini variables ... "
  $PRIN "%-80.80s" "loading ini variables ... " >>$ZFILE
  #  load_ini_vars
  if [ $? -eq 0 ]; then
    echo_success
    $ECHO " OK " >>$ZFILE
  else
    echo_failure
    $ECHO " KO " >>$ZFILE
  fi
  #
  $ECHO "Starting ($(date)) $0" >>$ZFILE
  # parent pid.
  #[ -s $DBUS_ID_TMP ] && $ECHO "$RMCM -f $DBUS_ID_TMP" >>$ZFILE && $RMCM -f $DBUS_ID_TMP >>$ZFILE
  # Create Loop (lock) file
  $ECHO $(date) >$LOCKFILE
  #check_dbus 1>>$ZFILE 2>&1
  #load_dbus 1>>$ZFILE 2>&1
  check_can 1>>$ZFILE 2>&1
  if [ $? -eq 0 ]; then
    echo_success
    $ECHO " OK " >>$ZFILE
  else
    echo_failure
    $ECHO " KO " >>$ZFILE
    # Try again
    sleep 15
    check_can 1>>$ZFILE 2>&1
  fi
  #
  while [ -s $LOCKFILE ]; do
    curdat=$($DATE)
    $ECHO "$curdat: Running ... OK" >>$ZFILE
    $SLEE 30
  done
  exit $OK
  ;;
"stop")
  [ -s $LOCKFILE ] && $RMCM -f $LOCKFILE
  $ECHO "systemctl calling stop sce_stack" >>$ZFILE
  #  [ -s $DBUS_ID_TMP ] && $ECHO "$RMCM -f $DBUS_ID_TMP" >>$ZFILE && $RMCM -f $DBUS_ID_TMP >>$ZFILE
  ;;
esac
[ -s $LOCKFILE ] && $RMCM -f $LOCKFILE
#[ -s $DBUS_ID_TMP ] && $ECHO "$RMCM -f $DBUS_ID_TMP" && $RMCM -f $DBUS_ID_TMP
exit $OK
