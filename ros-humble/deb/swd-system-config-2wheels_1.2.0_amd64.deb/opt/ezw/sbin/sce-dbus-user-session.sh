#!/bin/bash

#
# Copyright (C) 2021 ez-Wheel S.A.S.
#

echo "Starting EZW Dbus user session"

_RUN_DIR="/tmp"
_DBUS_SESSION_FILE="$_RUN_DIR/SYSTEMCTL_dbus.id"
_DBUS_PID_FILE="$_RUN_DIR/SYSTEMCTL_dbus.pid"

# If doesesnt exist create a directory for the gateway files
mkdir -p "$_RUN_DIR"

dbus-launch >"$_DBUS_SESSION_FILE"

# dbus-launch outputs key value pairs, so it can be sourced to read back variables to obtain process pid
# Example output from the dbus-launch:
# DBUS_SESSION_BUS_ADDRESS=unix:abstract=/tmp/dbus-teW5DiLRE0,guid=0a67ec3093886a111bc509a65cc45278
# DBUS_SESSION_BUS_PID=295

source "$_DBUS_SESSION_FILE"

echo "Dbus session started:"
echo -e "\tSession file: $_DBUS_SESSION_FILE"
echo -e "\tPID file: $_DBUS_PID_FILE"
echo -e "\tDbus session socket: $DBUS_SESSION_BUS_ADDRESS"
echo -e "\tProcess PID: $DBUS_SESSION_BUS_PID"

# Write PID to pid file
echo "$DBUS_SESSION_BUS_PID" >"$_DBUS_PID_FILE"
